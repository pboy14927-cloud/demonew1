# **App Name**: ContentDock

## Core Features:

- User Authentication: Secure user authentication for content creators and administrators.
- Content Editor: A Markdown editor that has inline preview rendering for content creation.
- AI Content Assistant: AI-powered tool for content suggestion such as improving writing quality based on chosen blog topics, identifying tone, and providing layout options.
- Admin Dashboard: Administrative dashboard for managing and tracking blog posts and website pages, mirroring the WordPress admin panel with features like Site Health Status, Quick Draft, At a Glance, Activity, and WordPress Events and News.
- Publishing Options: Publish and draft options for content.
- Public Facing Blog: Front-end for displaying published content like WordPress-style blog.

## Style Guidelines:

- Primary color: Calming blue (#64B5F6), evoking professionalism and trust.
- Background color: Light gray (#F0F4F7), for a clean, neutral backdrop that enhances readability.
- Accent color: Soft blue (#90CAF9), providing subtle highlights and interactive cues without distracting from the content.
- Body font: 'Inter' sans-serif, for clear and readable text. Headline font: 'Space Grotesk', sans-serif, used to differentiate headlines
- Use clean, simple icons related to content creation and management.
- Dashboard mimics WordPress admin panel for familiarity.