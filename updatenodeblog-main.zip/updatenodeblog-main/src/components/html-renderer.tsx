

'use client';

import React from 'react';
import parse, { domToReact } from 'html-react-parser';
import ResizableImageComponent from '@/components/editor/resizable-image-component';
import ResizableVideoComponent from '@/components/editor/resizable-video-component';
import { NodeViewProps } from '@tiptap/react';
import { cn } from '@/lib/utils';

type HtmlRendererProps = {
  content: string;
  enableDropCap?: boolean;
};

// Mock the editor and updateAttributes for the components
const mockNodeViewProps = (node: any): NodeViewProps => ({
  node,
  updateAttributes: () => {},
  editor: null as any,
  getPos: () => 0,
  selected: false,
  extension: null as any,
  decorations: [],
  innerDecorations: null as any,
  deleteNode: () => {},
});


export default function HtmlRenderer({ content, enableDropCap = false }: HtmlRendererProps) {
  if (!content || typeof content !== 'string') {
      return null;
  }
  
  const options = {
    replace: (domNode: any) => {
      if (domNode.type === 'tag') {
        if (domNode.name === 'img') {
            const node = {
                attrs: {
                    src: domNode.attribs.src,
                    alt: domNode.attribs.alt,
                    title: domNode.attribs.title,
                    width: domNode.attribs.width ? parseInt(domNode.attribs.width, 10) : '100%',
                    height: domNode.attribs.height || 'auto',
                    align: domNode.attribs['data-align'] || 'center',
                }
            };
          return <ResizableImageComponent {...mockNodeViewProps(node as any)} />;
        }
        if (domNode.name === 'video') {
           const node = {
                attrs: {
                    src: domNode.attribs.src,
                    controls: true,
                    width: domNode.attribs.width || '100%',
                    align: domNode.attribs['data-align'] || 'center',
                }
            };
           return <ResizableVideoComponent {...mockNodeViewProps(node as any)} />;
        }
        if (domNode.name === 'audio') {
            return <audio controls src={domNode.attribs.src} className="w-full" />;
        }
      }
    },
  };

  const reactElement = parse(content, options);

  return <div className={cn("prose max-w-none", enableDropCap && "prose-drop-cap")}>{reactElement}</div>;
}


