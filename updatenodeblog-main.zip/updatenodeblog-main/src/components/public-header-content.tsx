
'use client';

import * as React from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Menu, PenSquare, Home, User, MessageSquare, Sun, Moon, Twitter, Facebook, Instagram, Linkedin, Youtube, Search, ChevronDown } from 'lucide-react';
import { HeaderSettings, BarSettings, HeaderElement, SlotName, Menu as MenuType, BrandingSettings, generatePostUrl, Post, User as UserData, SocialIconStyleSettings } from '@/lib/data';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import ThemeSwitcher from '@/components/theme-switcher';
import type { Session } from 'next-auth';
import InteractiveSearch from './interactive-search';
import { useEffect, useState, useMemo } from 'react';
import Image from 'next/image';
import { Separator } from '../ui/separator';
import ClientDateTime from '@/components/client-date-time';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuGroup,
} from "@/components/ui/dropdown-menu";


const SocialIcon = ({ platform }: { platform: string }) => {
    switch (platform.toLowerCase()) {
        case 'twitter': return <Twitter className="h-4 w-4" />;
        case 'facebook': return <Facebook className="h-4 w-4" />;
        case 'instagram': return <Instagram className="h-4 w-4" />;
        case 'linkedin': return <Linkedin className="h-4 w-4" />;
        case 'youtube': return <Youtube className="h-4 w-4" />;
        default: return <Home className="h-4 w-4" />;
    }
};

const NavLink = ({ item, children }: { item: MenuType['items'][0], children?: React.ReactNode }) => {
    const [url, setUrl] = useState(item.url);
    
    useEffect(() => {
        setUrl(item.url);
    }, [item.url]);
    
    const hasChildren = children && React.Children.count(children) > 0;

    if (hasChildren) {
        return (
            <DropdownMenu>
                <DropdownMenuTrigger asChild>
                    <Button 
                        variant="ghost" 
                        className="text-sm font-medium hover:underline p-0 h-auto"
                        style={{ color: 'var(--link-color)' }}
                        onMouseOver={e => e.currentTarget.style.color = 'var(--link-hover-color)'}
                        onMouseOut={e => e.currentTarget.style.color = 'var(--link-color)'}
                    >
                        {item.label}
                        <ChevronDown className="ml-1 h-4 w-4" />
                    </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                    {children}
                </DropdownMenuContent>
            </DropdownMenu>
        )
    }

    return (
        <Link 
            href={url} 
            className="text-sm font-medium hover:underline"
            style={{ color: 'var(--link-color)' }}
            onMouseOver={e => e.currentTarget.style.color = 'var(--link-hover-color)'}
            onMouseOut={e => e.currentTarget.style.color = 'var(--link-color)'}
        >
            {item.label}
        </Link>
    );
};

const OffCanvasMenu = ({ settings, mainMenu, branding }: { settings: HeaderSettings, mainMenu: MenuType | null, branding: BrandingSettings | null }) => {
    if (!settings.offCanvas.enabled) return null;
    return (
        <SheetContent side={settings.offCanvas.position} className="w-[300px] sm:w-[340px] flex flex-col">
            <SheetHeader className="p-4">
                <SheetTitle className="sr-only">Main Menu</SheetTitle>
                <SheetDescription className="sr-only">Site navigation links.</SheetDescription>
            </SheetHeader>
            <div className="flex-1 overflow-y-auto pr-4">
                {settings.offCanvas.customContentTop && (
                    <div className="mb-6" dangerouslySetInnerHTML={{ __html: settings.offCanvas.customContentTop }} />
                )}
                 {settings.offCanvas.showSearch && <div className="mb-6"><InteractiveSearch /></div>}

                {mainMenu && (
                    <nav className="grid gap-4 text-lg font-medium">
                        {mainMenu.items.map(item => (
                            <Link key={item.id} href={item.url} className="hover:text-primary">{item.label}</Link>
                        ))}
                    </nav>
                )}
                
                {settings.offCanvas.showNewsletter && (
                     <div className="mt-8 p-4 bg-muted rounded-lg">
                        <h4 className="font-semibold mb-2">Subscribe</h4>
                        <Input placeholder="Email Address" className="mb-2" />
                        <Button className="w-full">Subscribe</Button>
                    </div>
                )}
                 {settings.offCanvas.customContentBottom && (
                    <div className="mt-6" dangerouslySetInnerHTML={{ __html: settings.offCanvas.customContentBottom }} />
                )}
            </div>

            {settings.offCanvas.showSocial && branding?.socialLinks && branding.socialLinks.length > 0 && (
                <div className="mt-auto border-t pt-4 flex justify-center gap-2">
                    {branding.socialLinks.map(link => (
                        <Button asChild key={link.id} variant="outline" size="icon">
                            <a href={link.url} target="_blank" rel="noopener noreferrer"><SocialIcon platform={link.platform} /></a>
                        </Button>
                    ))}
                </div>
            )}
        </SheetContent>
    );
}


function RenderElement({ element, settings, mainMenu, branding, session, visibility }: { element: HeaderElement, mainMenu: MenuType | null, branding: BrandingSettings | null, session: Session | null, visibility?: { desktop: boolean, tablet: boolean, mobile: boolean } }) {
    const status = session ? 'authenticated' : 'unauthenticated';

    const visibilityClasses = cn(
        visibility?.mobile === false && 'hidden',
        visibility?.mobile === true && 'flex',
        visibility?.tablet === false && 'md:hidden',
        visibility?.tablet === true && 'md:flex',
        visibility?.desktop === false && 'lg:hidden',
        visibility?.desktop === true && 'lg:flex'
    );
    

    const groupedMenuItems = useMemo(() => {
        if (!mainMenu) return [];
        const menuWithChildren: (MenuType['items'][0] & { children?: MenuType['items'] })[] = [];
        const itemMap: Record<string, MenuType['items'][0] & { children?: MenuType['items'] }> = {};
        
        mainMenu.items.forEach(item => {
            itemMap[item.id] = { ...item, children: [] };
        });

        mainMenu.items.forEach(item => {
            const currentItem = itemMap[item.id];
            if (item.depth > 0) {
                // Find parent
                let parent: (typeof menuWithChildren[0]) | undefined;
                for(let i = mainMenu.items.indexOf(item) - 1; i >= 0; i--) {
                    if (mainMenu.items[i].depth < item.depth) {
                        parent = itemMap[mainMenu.items[i].id];
                        break;
                    }
                }
                parent?.children?.push(currentItem);
            } else {
                menuWithChildren.push(currentItem);
            }
        });
        return menuWithChildren;
    }, [mainMenu]);


    switch(element) {
        case 'site-logo':
             return (
                <Link className={cn("mr-6 items-center space-x-2", visibilityClasses)} href="/">
                    {branding?.logoUrl ? (
                         <Image src={branding.logoUrl} alt={branding.websiteTitle || 'logo'} width={branding.logoWidth || 150} height={40} className="h-auto max-h-12 w-auto" />
                    ) : (
                        <>
                            <PenSquare className="h-6 w-6 text-primary" />
                            <span className="hidden font-bold sm:inline-block font-headline">{branding?.websiteTitle}</span>
                        </>
                    )}
                </Link>
            );
        case 'main-navigation':
            if (!mainMenu || mainMenu.items.length === 0) {
                 return (
                    <nav className={cn("hidden md:flex items-center gap-4", visibilityClasses)}>
                        <Link href="/" className="text-sm font-medium hover:underline text-[var(--link-color)] hover:text-[var(--link-hover-color)]">Home</Link>
                    </nav>
                 );
            }
            return (
                 <nav className={cn("hidden md:flex items-center gap-4", visibilityClasses)}>
                    {groupedMenuItems.map(item => (
                        <NavLink key={item.id} item={item}>
                             {item.children?.map(child => (
                                <DropdownMenuItem key={child.id} asChild>
                                    <Link href={child.url}>{child.label}</Link>
                                </DropdownMenuItem>
                            ))}
                        </NavLink>
                    ))}
                </nav>
            );
         case 'off-canvas-trigger':
            return (
                <div className={cn("flex md:hidden", visibilityClasses)}>
                    <Sheet>
                        <SheetTrigger asChild>
                            <Button variant="ghost" size="icon">
                                <Menu />
                                <span className="sr-only">Toggle Menu</span>
                            </Button>
                        </SheetTrigger>
                        <OffCanvasMenu settings={settings} mainMenu={mainMenu} branding={branding} />
                    </Sheet>
                </div>
            )
        case 'login-register':
            if (status === 'authenticated') {
                 return <div className={visibilityClasses}><Button variant="ghost" size="sm" asChild><Link href="/admin">Dashboard</Link></Button></div>;
            }
            return <div className={visibilityClasses}><Button variant="ghost" size="sm" asChild><Link href="/login">Login/Register</Link></Button></div>;
        case 'current-date':
            return <ClientDateTime type="date" className={visibilityClasses} />
         case 'current-time':
             return <ClientDateTime type="time" className={visibilityClasses} />
        case 'social-icons': {
            const socialSettings = settings.mainHeader?.styling?.socialIcons;
            if (!socialSettings || !branding?.socialLinks || branding.socialLinks.length === 0) {
                return null;
            }

            const officialColors: Record<string, { bg: string; text: string }> = {
                facebook: { bg: '#3b5998', text: '#ffffff' },
                twitter: { bg: '#1da1f2', text: '#ffffff' },
                instagram: { bg: '#e4405f', text: '#ffffff' },
                linkedin: { bg: '#0077b5', text: '#ffffff' },
                youtube: { bg: '#ff0000', text: '#ffffff' },
                default: { bg: '#777777', text: '#ffffff' },
            };
            
            return (
                 <div className={cn("gap-1 items-center", visibilityClasses)}>
                    {branding.socialLinks.map(link => {
                        const baseStyle: React.CSSProperties = {};
                        if (socialSettings.style === 'official') {
                            const colors = officialColors[link.platform] || officialColors.default;
                            baseStyle.backgroundColor = colors.bg;
                            baseStyle.color = colors.text;
                        } else {
                            baseStyle.backgroundColor = socialSettings.backgroundColor;
                            baseStyle.color = socialSettings.textColor;
                        }

                        const handleMouseEnter = (e: React.MouseEvent<HTMLAnchorElement>) => {
                            if (socialSettings.style === 'custom') {
                                e.currentTarget.style.backgroundColor = socialSettings.hoverBackgroundColor || baseStyle.backgroundColor;
                                e.currentTarget.style.color = socialSettings.hoverTextColor || baseStyle.color;
                            } else {
                                e.currentTarget.style.opacity = '0.9';
                            }
                        }

                        const handleMouseLeave = (e: React.MouseEvent<HTMLAnchorElement>) => {
                            e.currentTarget.style.backgroundColor = baseStyle.backgroundColor || '';
                            e.currentTarget.style.color = baseStyle.color || '';
                            e.currentTarget.style.opacity = '1';
                        }
                        
                        return (
                            <a 
                                key={link.id} 
                                href={link.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                aria-label={link.platform}
                                className="inline-flex items-center justify-center h-8 w-8 rounded-md transition-colors"
                                style={baseStyle}
                                onMouseEnter={handleMouseEnter}
                                onMouseLeave={handleMouseLeave}
                            >
                                <SocialIcon platform={link.platform} />
                            </a>
                        )
                    })}
                </div>
            )
        }
        case 'search-form':
            const searchStyles = {
                '--search-icon-color': settings.searchForm?.textColor,
            } as React.CSSProperties;
            const inputStyle = {
                backgroundColor: settings.searchForm?.backgroundColor, 
                color: settings.searchForm?.textColor,
                borderColor: settings.searchForm?.borderColor,
            }
            return (
                 <div className={cn("relative search-form-container", visibilityClasses)} style={searchStyles}>
                    <InteractiveSearch style={inputStyle} />
                </div>
            );
        case 'theme-switcher':
            return <div className={cn('items-center', visibilityClasses)}><ThemeSwitcher /></div>;
        case 'social-theme':
            return (
                 <div className={cn("items-center gap-1", visibilityClasses)}>
                    <RenderElement element={'social-icons'} settings={settings} mainMenu={mainMenu} branding={branding} session={session} />
                    <RenderElement element={'theme-switcher'} settings={settings} mainMenu={mainMenu} branding={branding} session={session} />
                    <RenderElement element={'off-canvas-trigger'} settings={settings} mainMenu={mainMenu} branding={branding} session={session} />
                </div>
            )
        case 'cta-button':
             if (settings?.ctaButton.text && settings.ctaButton.url) {
                const ctaStyles: React.CSSProperties = {
                    fontFamily: settings.ctaButton.fontFamily,
                    fontSize: `${settings.ctaButton.fontSize}px`,
                    fontWeight: settings.ctaButton.fontWeight,
                    color: settings.ctaButton.textColor,
                    border: `${settings.ctaButton.borderWidth}px solid ${settings.ctaButton.borderColor || 'transparent'}`,
                    borderRadius: `${settings.ctaButton.borderRadius}px`,
                };
                 if (settings.ctaButton.backgroundType === 'gradient') {
                     ctaStyles.background = `linear-gradient(to right, ${settings.ctaButton.gradientStart}, ${settings.ctaButton.gradientEnd})`;
                 } else {
                     ctaStyles.backgroundColor = settings.ctaButton.backgroundColor;
                 }
                 
                return (
                    <div className={visibilityClasses}>
                        <Button asChild size="sm" style={ctaStyles} 
                            onMouseEnter={e => {
                                if(settings.ctaButton.hoverBackgroundColor) {
                                    e.currentTarget.style.background = ''; // remove gradient if it exists
                                    e.currentTarget.style.backgroundColor = settings.ctaButton.hoverBackgroundColor;
                                }
                                if(settings.ctaButton.hoverTextColor) e.currentTarget.style.color = settings.ctaButton.hoverTextColor;
                                if(settings.ctaButton.hoverBorderColor) e.currentTarget.style.borderColor = settings.ctaButton.hoverBorderColor;
                            }}
                            onMouseLeave={e => {
                                e.currentTarget.style.background = ctaStyles.background || '';
                                e.currentTarget.style.backgroundColor = ctaStyles.backgroundColor || '';
                                e.currentTarget.style.color = ctaStyles.color || '';
                                e.currentTarget.style.borderColor = ctaStyles.borderColor || 'transparent';
                            }}
                        >
                            <a href={settings.ctaButton.url} target={settings.ctaButton.openInNewTab ? '_blank' : '_self'}>
                                {settings.ctaButton.text}
                            </a>
                        </Button>
                    </div>
                );
            }
            return null;
        case 'header-ad':
                return <div className={cn("bg-muted/50 p-2 text-xs h-full w-full items-center justify-center", visibilityClasses)}>
                    <Image src="https://placehold.co/468x60.png" width={468} height={60} data-ai-hint="advertisement" alt="advertisement"/>
                </div>;
        case 'custom-html':
                 return <div className={cn("text-xs items-center", visibilityClasses)} dangerouslySetInnerHTML={{ __html: '<div>Custom HTML</div>' }} />;
        default:
            return null;
    }
}

function RenderBar({ barSettings, slotSettings, allSettings, mainMenu, branding, session, className }: {barSettings: BarSettings, slotSettings: Record<SlotName, HeaderElement>, allSettings: HeaderSettings, mainMenu: MenuType | null, branding: BrandingSettings | null, session: Session | null, className?: string}) {
    const styles: React.CSSProperties & { [key: string]: string } = {
        height: `${barSettings.height}px`,
        color: barSettings.textColor,
        '--link-color': barSettings.linkColor,
        '--link-hover-color': barSettings.linkHoverColor,
    };

    if (barSettings.backgroundType === 'gradient') {
        styles.background = `linear-gradient(to right, ${barSettings.gradientStart}, ${barSettings.gradientEnd})`;
    } else {
         styles.backgroundColor = barSettings.backgroundColor;
    }
    
    const layoutClasses = {
        'space-between': 'justify-between',
        'center-logo': '', // Requires special handling inside
        '5-columns': 'justify-between'
    };
    
    const slots = (
        <div className={cn("flex items-center w-full", layoutClasses[barSettings.layout as keyof typeof layoutClasses])}>
            <div className={cn("flex items-center gap-x-4", barSettings.layout === 'center-logo' && "flex-1 justify-start")}>
                <RenderElement element={slotSettings.left} settings={allSettings} mainMenu={mainMenu} branding={branding} session={session} visibility={barSettings.slotVisibility.left} />
                <RenderElement element={slotSettings.centerLeft} settings={allSettings} mainMenu={mainMenu} branding={branding} session={session} visibility={barSettings.slotVisibility.centerLeft} />
            </div>
            
            <div className={cn("flex items-center gap-x-4", barSettings.layout === 'space-between' ? 'flex-1 justify-center' : (barSettings.layout === 'center-logo' ? 'flex-shrink-0' : ''))}>
                <RenderElement element={slotSettings.center} settings={allSettings} mainMenu={mainMenu} branding={branding} session={session} visibility={barSettings.slotVisibility.center} />
            </div>

            <div className={cn("flex items-center gap-x-4", barSettings.layout === 'center-logo' && "flex-1 justify-end")}>
                <RenderElement element={slotSettings.centerRight} settings={allSettings} mainMenu={mainMenu} branding={branding} session={session} visibility={barSettings.slotVisibility.centerRight} />
                <RenderElement element={slotSettings.right} settings={allSettings} mainMenu={mainMenu} branding={branding} session={session} visibility={barSettings.slotVisibility.right} />
            </div>
        </div>
    );

    return (
        <div 
            className={cn("w-full border-b", className)}
            style={styles}
        >
            <div className="container h-full flex items-center">
                 {slots}
            </div>
        </div>
    )
}

interface PublicHeaderContentProps {
    settings: HeaderSettings;
    mainMenu: MenuType | null;
    branding: BrandingSettings | null;
    session: Session | null;
}

export default function PublicHeaderContent({ settings, mainMenu, branding, session }: PublicHeaderContentProps) {
  
  const stickyClass = 'sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60';

  return (
    <header className="w-full">
        {settings.topBar.enabled && <RenderBar 
            barSettings={settings.topBar} 
            slotSettings={settings.topBarSlots} 
            allSettings={settings} 
            mainMenu={mainMenu} 
            branding={branding} 
            session={session} 
            className={settings.stickySection === 'top' ? stickyClass : ''}
        />}
        {settings.mainHeader.enabled && <RenderBar 
            barSettings={settings.mainHeader} 
            slotSettings={settings.mainHeaderSlots} 
            allSettings={settings} 
            mainMenu={mainMenu} 
            branding={branding} 
            session={session} 
            className={settings.stickySection === 'main' ? stickyClass : ''}
        />}
        {settings.bottomBar.enabled && <RenderBar 
            barSettings={settings.bottomBar} 
            slotSettings={settings.bottomBarSlots} 
            allSettings={settings} 
            mainMenu={mainMenu} 
            branding={branding} 
            session={session} 
            className={settings.stickySection === 'bottom' ? stickyClass : ''}
        />}
    </header>
  );
}

    