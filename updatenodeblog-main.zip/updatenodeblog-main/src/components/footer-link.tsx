
'use client';

import Link from 'next/link';

export default function FooterLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <Link
      href={href}
      className="text-sm hover:underline"
      style={{ color: 'var(--link-color)' }}
      onMouseOver={(e) => (e.currentTarget.style.color = 'var(--link-hover-color)')}
      onMouseOut={(e) => (e.currentTarget.style.color = 'var(--link-color)')}
    >
      {children}
    </Link>
  );
}
