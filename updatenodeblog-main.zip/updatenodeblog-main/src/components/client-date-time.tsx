
'use client';

import { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';

type ClientDateTimeProps = {
    type: 'date' | 'time';
    className?: string;
}

export default function ClientDateTime({ type, className }: ClientDateTimeProps) {
    const [dateTime, setDateTime] = useState('');

    useEffect(() => {
        const updateDateTime = () => {
            const now = new Date();
            if (type === 'date') {
                setDateTime(now.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }));
            } else {
                setDateTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
            }
        };

        updateDateTime();
        // Update time every minute
        if (type === 'time') {
            const intervalId = setInterval(updateDateTime, 60000);
            return () => clearInterval(intervalId);
        }
    }, [type]);

    if (!dateTime) {
        return <span className={cn("text-xs items-center", className)}>Loading...</span>;
    }

    return (
        <span className={cn("text-xs items-center", className)}>
            {dateTime}
        </span>
    );
}
