
'use client';

import React, { useEffect, useState } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import Link from 'next/link';
import type { Post, User, SidebarSettings as SidebarSettingsType, BlogArchiveSettings, SinglePostSettings, LayoutElement, Comment, BrandingSettings, Category, SocialButtonStyleSettings, Tag } from '@/lib/data';
import HtmlRenderer from '@/components/html-renderer';
import CommentsSection from '@/components/comments-section';
import { Facebook, Twitter, Linkedin, Mail, MessageSquare, Clock, Instagram, Heart, Send, Rss, Youtube } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import { Skeleton } from '@/components/ui/skeleton';
import Sidebar from '@/components/blog/sidebar';
import { getPublishedPosts, getCategories, generatePostUrl, getTags } from '@/lib/data';
import dynamic from 'next/dynamic';
import Image from 'next/image';

const PostCard = dynamic(() => import('@/components/blog/post-card'));

const PinterestIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12.55 16.5A6.5 6.5 0 0 0 19 10c0-3.59-2.91-6.5-6.5-6.5S6 6.41 6 10c0 1.95.86 3.7 2.21 4.95l-1.07 4.55L12.55 16.5z"/>
        <path d="M10 10.5c.34.02.68.02 1.02 0"/>
        <path d="M14 10.5c.34.02.68.02 1.02 0"/>
        <path d="M10 13c.85 0 1.63-.22 2.25-.61.62.39 1.4.61 2.25.61"/>
    </svg>
);

const TelegramIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="m22 2-7 20-4-9-9-4Z" />
        <path d="m22 2-11 11" />
    </svg>
);

const getSocialButtonStyle = (settings: SocialButtonStyleSettings): React.CSSProperties => {
    const style: React.CSSProperties = {
        color: settings.iconColor,
        borderColor: settings.borderColor,
        borderWidth: `${settings.borderWidth}px`,
    };

    if (settings.backgroundType === 'gradient') {
        style.background = `linear-gradient(${settings.gradient.direction}, ${settings.gradient.from}, ${settings.gradient.to})`;
    } else {
        style.backgroundColor = settings.backgroundColor;
    }

    return style;
};

const SocialShare = ({url, title, vertical = false, titleText = 'Share', settings}: {url: string, title: string, vertical?: boolean, titleText?: string, settings: SocialButtonStyleSettings}) => {
    const officialColors: Record<string, string> = {
        facebook: 'bg-[#3b5998] hover:bg-[#3b5998]/90 text-white',
        twitter: 'bg-[#1da1f2] hover:bg-[#1da1f2]/90 text-white',
        pinterest: 'bg-[#bd081c] hover:bg-[#bd081c]/90 text-white',
        linkedin: 'bg-[#0077b5] hover:bg-[#0077b5]/90 text-white',
        telegram: 'bg-[#0088cc] hover:bg-[#0088cc]/90 text-white',
        email: 'bg-gray-500 hover:bg-gray-600 text-white',
    };

    const shapeClasses = {
        default: 'rounded-md',
        rounded: 'rounded-lg',
        circle: 'rounded-full'
    };

    const buttonStyle = settings.style === 'custom' ? getSocialButtonStyle(settings) : {};

    const renderButton = (network: keyof typeof officialColors, href: string, icon: React.ReactNode) => (
        <Button asChild variant="outline" size="icon" className={cn("w-8 h-8", shapeClasses[settings.shape], settings.style === 'official' && officialColors[network])} style={buttonStyle}>
            <a href={href} target="_blank" rel="noopener noreferrer" aria-label={`Share on ${network}`}>
                {icon}
            </a>
        </Button>
    );

    return (
        <div className={cn("flex items-center gap-2", vertical ? 'flex-col items-start' : 'flex-row')}>
            {titleText && <span className="font-semibold text-sm mr-2">{titleText}</span>}
            {renderButton('facebook', `https://www.facebook.com/sharer/sharer.php?u=${url}`, <Facebook className="w-4 h-4"/>)}
            {renderButton('twitter', `https://twitter.com/intent/tweet?url=${url}&text=${title}`, <Twitter className="w-4 h-4"/>)}
            {renderButton('pinterest', `https://pinterest.com/pin/create/button/?url=${url}&media=&description=${title}`, <PinterestIcon className="w-4 h-4"/>)}
            {renderButton('linkedin', `https://www.linkedin.com/shareArticle?mini=true&url=${url}&title=${title}`, <Linkedin className="w-4 h-4"/>)}
            {renderButton('telegram', `https://t.me/share/url?url=${url}&text=${title}`, <TelegramIcon className="w-4 h-4" />)}
            {renderButton('email', `mailto:?subject=${title}&body=${url}`, <Mail className="w-4 h-4"/>)}
        </div>
    );
};

const SocialIcon = ({ platform }: { platform: string }) => {
    switch (platform.toLowerCase()) {
        case 'facebook': return <Facebook className="w-4 h-4" />;
        case 'twitter': return <Twitter className="w-4 h-4" />;
        case 'instagram': return <Instagram className="w-4 h-4" />;
        case 'linkedin': return <Linkedin className="w-4 h-4" />;
        case 'youtube': return <Youtube className="w-4 h-4" />;
        default: return <Rss className="w-4 h-4" />;
    }
}


const FollowUs = ({ settings, brandingSettings }: { settings: SinglePostSettings, brandingSettings: BrandingSettings }) => {
    if (!settings.showFollowUs || !brandingSettings.socialLinks || brandingSettings.socialLinks.length === 0) return null;
    
     const officialColors: Record<string, string> = {
        facebook: 'bg-[#3b5998] hover:bg-[#3b5998]/90 text-white',
        twitter: 'bg-[#1da1f2] hover:bg-[#1da1f2]/90 text-white',
        instagram: 'bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 text-white',
        linkedin: 'bg-[#0077b5] hover:bg-[#0077b5]/90 text-white',
        youtube: 'bg-[#FF0000] hover:bg-[#FF0000]/90 text-white',
    };
    
    const buttonStyle = settings.followButtons.style === 'custom' ? getSocialButtonStyle(settings.followButtons) : {};
     const shapeClasses = {
        default: 'rounded-md',
        rounded: 'rounded-lg',
        circle: 'rounded-full'
    };

    return (
        <div className="flex items-center gap-2">
            <span className="font-semibold text-sm">Follow Us</span>
            <div className="flex items-center gap-1">
                {brandingSettings.socialLinks.map(link => (
                     <Button 
                        asChild 
                        key={link.id} 
                        variant="ghost" 
                        size="icon" 
                        className={cn(
                            "h-7 w-7",
                            shapeClasses[settings.followButtons.shape],
                            settings.followButtons.style === 'official' && (officialColors[link.platform] || 'bg-gray-500 hover:bg-gray-600 text-white')
                        )}
                        style={buttonStyle}
                    >
                        <a href={link.url} target="_blank" rel="noopener noreferrer"><SocialIcon platform={link.platform} /></a>
                    </Button>
                ))}
            </div>
        </div>
    )
}

const PostReactions = ({ postId, settings, initialLikes }: { postId: string, settings: SinglePostSettings, initialLikes: number }) => {
    const [likes, setLikes] = useState(initialLikes);
    const [liked, setLiked] = useState(false);
    const [isClient, setIsClient] = useState(false);
    
    useEffect(() => {
        setIsClient(true);
        if (typeof window !== 'undefined') {
            const likedPosts = JSON.parse(localStorage.getItem('likedPosts') || '[]');
            if (likedPosts.includes(postId)) {
                setLiked(true);
            }
        }
    }, [postId]);

    const handleLike = async () => {
        if (liked) return;

        setLiked(true);
        setLikes(prev => prev + 1);
        
        const likedPosts = JSON.parse(localStorage.getItem('likedPosts') || '[]');
        localStorage.setItem('likedPosts', JSON.stringify([...likedPosts, postId]));

        try {
            await fetch(`/api/posts/${postId}/like`, { method: 'POST' });
        } catch (error) {
            console.error("Failed to save like", error);
            setLiked(false);
            setLikes(prev => prev - 1);
            const updatedLikedPosts = JSON.parse(localStorage.getItem('likedPosts') || '[]').filter((id: string) => id !== postId);
            localStorage.setItem('likedPosts', JSON.stringify(updatedLikedPosts));
        }
    };

    if (!settings.showPostReactions) return null;
    if (!isClient) {
        return (
            <div className="flex items-center gap-4 mt-8 pt-6 border-t">
                <Button variant="outline" size="lg" disabled>
                    <Heart className="mr-2 h-5 w-5" /> 
                    Like
                </Button>
                 <span className="text-sm text-muted-foreground">{initialLikes} likes</span>
            </div>
        )
    }

    return (
        <div className="flex items-center gap-4 mt-8 pt-6 border-t">
            <Button variant="outline" size="lg" onClick={handleLike} disabled={liked}>
                <Heart className={cn("mr-2 h-5 w-5", liked && "fill-red-500 text-red-500")} /> 
                Like
            </Button>
            <span className="text-sm text-muted-foreground">{likes} likes</span>
        </div>
    )
}


const renderPostElement = (element: LayoutElement, data: any) => {
    if (!element.visible) return null;
    
    let authorImageUrl = data.author?.avatar;
    if (authorImageUrl && authorImageUrl.startsWith('/api/media')) {
        authorImageUrl = `${data.brandingSettings.siteUrl}${authorImageUrl}`;
    } else if (!authorImageUrl) {
      authorImageUrl = `https://placehold.co/100x100.png?text=${data.author?.name.charAt(0)}`;
    }

    switch (element.id) {
        case 'breadcrumbs':
            const firstCategory = data.allCategories.find((cat: Category) => cat.name === data.post.categories[0]);
            return (
                <nav className="text-sm text-muted-foreground mb-4">
                    <Link href="/" className="hover:text-primary">Home</Link>
                    <span className="mx-2">/</span>
                    <Link href="/blog" className="hover:text-primary">Blog</Link>
                    <span className="mx-2">/</span>
                    {firstCategory && (
                        <>
                            <Link href={`/category/${firstCategory.slug}`} className="hover:text-primary capitalize">{firstCategory.name}</Link>
                            <span className="mx-2">/</span>
                        </>
                    )}
                    <span className="truncate">{data.post.title}</span>
                </nav>
            );
        case 'category-badge':
            const categoryBadgeCat = data.allCategories.find((cat: Category) => cat.name === data.post.categories[0]);
            return categoryBadgeCat && (
                <Link href={`/category/${categoryBadgeCat.slug}`} className="text-sm font-semibold text-primary uppercase tracking-wider">{categoryBadgeCat.name}</Link>
            );
        case 'title':
            return <h1 className="text-3xl md:text-4xl font-bold font-headline">{data.post.title}</h1>;
        case 'excerpt':
             return data.post.excerpt && <p className="text-lg text-muted-foreground mt-2">{data.post.excerpt}</p>;
        case 'author-meta':
            return (
                 <div className="flex items-center flex-wrap gap-x-4 gap-y-2 text-sm text-muted-foreground">
                    <div className="flex items-center gap-2">
                        <Avatar className="h-6 w-6">
                            <AvatarImage src={authorImageUrl} alt={data.author?.name} />
                            <AvatarFallback>{data.author?.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <span>By <Link href={`/author/${data.author?.id}`} className="text-foreground hover:text-primary">{data.author?.name}</Link></span>
                    </div>
                    <span>{data.postDate}</span>
                    <div className="flex items-center gap-1">
                        <MessageSquare className="h-4 w-4" />
                        <span>{data.postComments.length} Comments</span>
                    </div>
                </div>
            );
        case 'top-share':
             return (
                 <div className="flex items-center justify-between">
                    <SocialShare url={data.fullPostUrl} title={data.post.title} settings={data.settings.shareButtons}/>
                    <FollowUs settings={data.settings} brandingSettings={data.brandingSettings}/>
                </div>
            );
        case 'featured-image':
            const imageStyle: React.CSSProperties = {
                width: data.settings.featuredImageWidth ? `${data.settings.featuredImageWidth}px` : '100%',
                height: data.settings.featuredImageHeight ? `${data.settings.featuredImageHeight}px` : 'auto',
                objectFit: 'cover'
            };
            return data.post.featuredImage && (
                <Image 
                    src={data.post.featuredImage} 
                    alt={data.post.title} 
                    className="w-full h-auto rounded-lg my-4" 
                    width={data.settings.featuredImageWidth || 882}
                    height={data.settings.featuredImageHeight || 576}
                    style={imageStyle}
                    priority
                />
            );
        case 'content':
             return <HtmlRenderer content={data.post.content} enableDropCap={data.settings.enableDropCap} />;
        case 'post-reactions':
            return <PostReactions postId={data.post.id} settings={data.settings} initialLikes={data.post.likes || 0} />;
        case 'tags':
            return data.post.tags.length > 0 && (
                <div className="mt-8 pt-6 border-t flex flex-wrap items-center gap-2">
                    <span className="font-semibold">Tags:</span>
                    {data.post.tags.map((tag:string) => (
                        <Link key={tag} href={`/tag/${tag.toLowerCase().replace(/\s+/g, '-')}`} className="text-sm bg-muted text-muted-foreground px-3 py-1 rounded-full hover:bg-primary hover:text-primary-foreground">{tag}</Link>
                    ))}
                </div>
            );
        case 'bottom-share':
            return (
                 <div className="mt-8 pt-6 border-t flex items-center gap-4">
                     <SocialShare url={data.fullPostUrl} title={data.post.title} settings={data.settings.shareButtons}/>
                </div>
            );
        case 'author-box':
            return data.author && (
                <div className="mt-12 p-6 border rounded-lg flex flex-col sm:flex-row items-center gap-6">
                    <Avatar className="h-24 w-24">
                        <AvatarImage src={authorImageUrl} alt={data.author.name} />
                        <AvatarFallback>{data.author.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="text-center sm:text-left">
                        <h4 className="text-lg font-bold">{data.author.name}</h4>
                        <p className="text-muted-foreground mt-1 text-sm">{data.author.bio || 'The author has not provided a bio yet.'}</p>
                    </div>
                </div>
            );
        case 'related-posts':
             return data.relatedPosts.length > 0 && (
                 <section className="mt-16">
                     <Separator className="mb-8" />
                     <h2 className="text-2xl font-bold mb-8 text-center">YOU MIGHT ALSO LIKE</h2>
                     <div className={cn("grid gap-8", data.settings.relatedPostsLayout === 'grid' ? 'sm:grid-cols-2 lg:grid-cols-3' : 'grid-cols-1')}>
                         {data.relatedPosts.map((relatedPost: Post & { author: User | null }) => (
                            <PostCard 
                                key={relatedPost.id} 
                                post={relatedPost} 
                                author={relatedPost.author} 
                                settings={data.archiveSettings} 
                                layout={data.settings.relatedPostsLayout === 'grid' ? 'related-posts-grid' : 'related-list'}
                            />
                        ))}
                     </div>
                 </section>
             );
         case 'comments':
             return data.post.commentStatus === 'open' && (
                <div className="mt-12">
                   <CommentsSection postId={data.post.id} />
                </div>
            );
        default:
            return null;
    }
}

type PostPageClientProps = {
    pageData: {
        post: Post;
        settings: SinglePostSettings;
        sidebarSettings: SidebarSettingsType;
        archiveSettings: BlogArchiveSettings;
        author: User | null;
        brandingSettings: BrandingSettings;
        postComments: Comment[];
        relatedPosts: (Post & { author: User | null })[];
        sidebarData: {
            latestPosts: Post[],
            categories: Category[],
            tags?: Tag[],
        }
    }
};

export default function PostPageClient({ pageData }: PostPageClientProps) {
    const {
        post,
        settings,
        sidebarSettings,
        archiveSettings,
        author,
        brandingSettings,
        postComments,
        relatedPosts,
        sidebarData
    } = pageData;

    const [allCategories, setAllCategories] = useState<Category[]>([]);
    const [allTags, setAllTags] = useState<Tag[]>([]);
    const [fullPostUrl, setFullPostUrl] = useState('');

    useEffect(() => {
        const getUrl = async () => {
            const url = await generatePostUrl(post);
            setFullPostUrl(`${brandingSettings.siteUrl}${url}`);
        }
        getUrl();
        if (sidebarData && sidebarData.categories) {
            setAllCategories(sidebarData.categories);
        }
        
        getTags().then(setAllTags);

    }, [post, brandingSettings.siteUrl, sidebarData]);

    const postDate = new Date(post.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
    const renderData = { post, settings, author, postComments, postDate, fullPostUrl, relatedPosts, archiveSettings, brandingSettings, allCategories };

    const showRightSidebar = settings.showRightSidebar && sidebarSettings.right.desktop;
    const showStickyShare = settings.showStickyShare;

    return (
        <div className="container mx-auto px-4 md:px-6 py-8 md:py-12">
            <div className="lg:grid lg:grid-cols-[auto_1fr_auto] lg:gap-8 items-start">
                 <div className="hidden lg:block w-[60px] sticky top-28">
                    {showStickyShare && (
                        <div className="space-y-2">
                            <SocialShare url={fullPostUrl} title={post.title} vertical={true} titleText="" settings={settings.shareButtons}/>
                        </div>
                    )}
                </div>
                
                <main className="min-w-0">
                    <div className="space-y-4 mb-8">
                        {settings.layout.map(element => (
                             <React.Fragment key={element.id}>{renderPostElement(element, renderData)}</React.Fragment>
                        ))}
                    </div>
                </main>

                 <div className="hidden lg:block lg:w-[338px] sticky top-28">
                    {showRightSidebar && sidebarData && (
                        <div className="space-y-8">
                            <Sidebar 
                                widgets={sidebarSettings.rightWidgets} 
                                settings={sidebarSettings}
                                latestPosts={sidebarData.latestPosts} 
                                categories={sidebarData.categories}
                                socialLinks={brandingSettings.socialLinks} 
                                tags={allTags}
                            />
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

    