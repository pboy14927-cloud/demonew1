
'use client';

import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import type { Media } from '@/lib/data';
import { cn } from '@/lib/utils';
import { Check, Music, FileText, File as FileIcon, Film, Image as ImageIcon } from 'lucide-react';
import Image from 'next/image';

type MediaCardProps = {
  media: Media;
  isSelected: boolean;
  onSelect: (e: React.MouseEvent) => void;
  onClick: (e: React.MouseEvent) => void;
};

const MediaPreview = ({ media }: { media: Media }) => {
    const imageUrl = `/api/media/${media.id}/file`;
    if (media.fileType.startsWith('image/')) {
        return <Image src={imageUrl} alt={media.altText || media.fileName} width={200} height={200} className="w-full h-full object-cover" />;
    }
    if (media.fileType.startsWith('video/')) {
        return (
             <div className="w-full h-full flex items-center justify-center bg-muted relative">
                <Film className="w-8 h-8 text-muted-foreground" />
                <div className="absolute inset-0 bg-black/30" />
            </div>
        )
    }
    if (media.fileType.startsWith('audio/')) {
        return <div className="w-full h-full flex items-center justify-center bg-muted"><Music className="w-8 h-8 text-muted-foreground" /></div>;
    }
     if (media.fileType === 'application/pdf') {
        return <div className="w-full h-full flex items-center justify-center bg-muted"><FileText className="w-8 h-8 text-muted-foreground" /></div>;
    }
    return <div className="w-full h-full flex items-center justify-center bg-muted"><FileIcon className="w-8 h-8 text-muted-foreground" /></div>;
}

export default function MediaCard({ media, isSelected, onSelect, onClick }: MediaCardProps) {
  return (
    <Card 
        className={cn(
            "overflow-hidden aspect-square relative group cursor-pointer",
            isSelected && "ring-2 ring-primary ring-offset-2"
        )}
        onClick={onClick}
    >
        <CardContent className="p-0 h-full">
           <MediaPreview media={media} />
            {isSelected && (
                 <div className="absolute inset-0 bg-primary/40" />
            )}
        </CardContent>
         <div 
            className={cn("absolute top-2 right-2 z-10", !isSelected && "hidden group-hover:block")}
         >
            <button 
                onClick={onSelect} 
                aria-label={`Select ${media.fileName}`}
                className={cn(
                    "w-6 h-6 rounded-md flex items-center justify-center border",
                    isSelected ? "bg-primary border-primary-foreground text-primary-foreground" : "bg-background/80 border-border"
                )}
            >
               {isSelected && <Check className="w-4 h-4" />}
            </button>
        </div>

    </Card>
  );
}
