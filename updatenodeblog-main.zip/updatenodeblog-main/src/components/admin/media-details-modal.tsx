
'use client';

import React, { useState, useEffect, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import type { Media } from '@/lib/data';
import { useToast } from '@/hooks/use-toast';
import { Copy, Download, Trash2, Loader2 } from 'lucide-react';
import Link from 'next/link';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription as AlertDialogDesc,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import Image from 'next/image';

type MediaDetailsModalProps = {
    media: Media;
    isOpen: boolean;
    onOpenChange: (open: boolean) => void;
    onUpdate: (updatedMedia: Media) => void;
    onDelete: (mediaId: string) => void;
};

const MediaPreview = ({ media }: { media: Media }) => {
    const fileUrl = `/api/media/${media.id}/file`;
    if (media.fileType.startsWith('image/')) {
        return <Image src={fileUrl} alt={media.altText || ''} width={512} height={512} className="max-w-full h-auto object-contain" />;
    }
    if (media.fileType.startsWith('video/')) {
        return (
            <div className="relative w-full h-full flex items-center justify-center">
                 <video src={fileUrl} controls className="max-w-full max-h-full" />
            </div>
        );
    }
    if (media.fileType.startsWith('audio/')) {
        return <audio src={fileUrl} controls className="w-full" />;
    }
    return <p className="text-muted-foreground">No preview available for this file type.</p>;
}

export default function MediaDetailsModal({ media, isOpen, onOpenChange, onUpdate, onDelete }: MediaDetailsModalProps) {
    const [mediaDetails, setMediaDetails] = useState(media);
    const { toast } = useToast();
    const [isSaving, setIsSaving] = useState(false);
    
    useEffect(() => {
        if (media) {
            setMediaDetails(media);
        }
    }, [media]);

    const handleInputChange = (field: keyof Media, value: string) => {
        setMediaDetails(prev => ({...prev, [field]: value} as Media));
    }

    const uploadedDate = new Date(mediaDetails.createdAt).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
    });

    const fileUrl = `${window.location.origin}/api/media/${mediaDetails.id}/file`;

    const handleCopyUrl = () => {
        navigator.clipboard.writeText(fileUrl);
        toast({ title: 'URL copied to clipboard.'});
    }
    
    const handleDeleteClick = () => {
        onDelete(mediaDetails.id);
        onOpenChange(false); // Close the modal after triggering delete
    }

    const handleSaveChanges = async () => {
        setIsSaving(true);
        try {
            const response = await fetch(`/api/media/${mediaDetails.id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(mediaDetails)
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || 'Failed to update media');
            }
            
            const updatedMedia = await response.json();
            onUpdate(updatedMedia);
            toast({ title: 'Media updated successfully.' });
            onOpenChange(false);

        } catch (error: any) {
            toast({ variant: 'destructive', title: 'Error', description: error.message });
        } finally {
            setIsSaving(false);
        }
    }

    return (
        <>
            <Dialog open={isOpen} onOpenChange={onOpenChange}>
                <DialogContent className="max-w-6xl h-[90vh]">
                     <DialogHeader>
                        <DialogTitle>Attachment details</DialogTitle>
                         <DialogDescription>
                            View and edit the details for this media attachment.
                        </DialogDescription>
                    </DialogHeader>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 h-full overflow-hidden pt-4">
                        <div className="md:col-span-2 flex flex-col items-center justify-center bg-muted/30 p-4 rounded-lg overflow-y-auto">
                            <MediaPreview media={mediaDetails} />
                        </div>
                        <div className="md:col-span-1 flex flex-col overflow-y-auto pr-4">
                            <div className="text-xs text-muted-foreground space-y-1 mb-6">
                                <p><strong>Uploaded on:</strong> {uploadedDate}</p>
                                <p><strong>Uploaded by:</strong> <Link href="#" className="text-primary hover:underline">{mediaDetails.uploadedBy}</Link></p>
                                <p><strong>File name:</strong> {mediaDetails.fileName}</p>
                                <p><strong>File type:</strong> {mediaDetails.fileType}</p>
                                <p><strong>File size:</strong> {mediaDetails.fileSize ? (mediaDetails.fileSize / 1024).toFixed(2) : 0} KB</p>
                            </div>
                            <div className="space-y-4">
                                <div className="space-y-2">
                                    <Label htmlFor="alt-text">Alternative Text</Label>
                                    <Textarea id="alt-text" value={mediaDetails.altText || ''} onChange={(e) => handleInputChange('altText', e.target.value)} />
                                    <p className="text-xs text-muted-foreground">
                                        <Link href="#" className="text-primary hover:underline">Learn how to describe the purpose of the image.</Link> Leave empty if the image is purely decorative.
                                    </p>
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="title">Title</Label>
                                    <Input id="title" value={mediaDetails.fileName} onChange={(e) => handleInputChange('fileName', e.target.value)} />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="file-url">File URL</Label>
                                    <div className="flex">
                                        <Input id="file-url" readOnly value={fileUrl} className="bg-muted/50" />
                                    </div>
                                    <Button variant="secondary" size="sm" onClick={handleCopyUrl} className="mt-2">Copy URL to clipboard</Button>
                                </div>
                            </div>
                             <div className="text-sm flex gap-2 items-center mt-auto pt-4">
                                <Link href={fileUrl} target="_blank" className="text-primary hover:underline">View media file</Link>
                                <span className="text-muted-foreground">|</span>
                                 <a href={fileUrl} download={mediaDetails.fileName} className="text-primary hover:underline">Download file</a>
                                 <span className="text-muted-foreground">|</span>
                                <AlertDialog>
                                    <AlertDialogTrigger asChild>
                                        <button className="text-destructive hover:underline">Delete permanently</button>
                                    </AlertDialogTrigger>
                                    <AlertDialogContent>
                                        <AlertDialogHeader>
                                            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                                            <AlertDialogDesc>
                                            This action cannot be undone. This will permanently delete the media file from your library.
                                            </AlertDialogDesc>
                                        </AlertDialogHeader>
                                        <AlertDialogFooter>
                                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                                            <AlertDialogAction onClick={handleDeleteClick}>Delete</AlertDialogAction>
                                        </AlertDialogFooter>
                                    </AlertDialogContent>
                                </AlertDialog>
                                <Button onClick={handleSaveChanges} disabled={isSaving} className="ml-auto">
                                    {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                    Update
                                </Button>
                            </div>
                        </div>
                    </div>
                </DialogContent>
            </Dialog>
        </>
    )
}
