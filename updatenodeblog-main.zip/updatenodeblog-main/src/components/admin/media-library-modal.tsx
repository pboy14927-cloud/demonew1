
'use client';

import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { getMedia, Media } from '@/lib/data';
import MediaCard from './media-card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Input } from '../ui/input';
import { UploadCloud, File as FileIcon, Loader2, CheckCircle, AlertCircle, X, Trash2 } from 'lucide-react';
import { Card, CardContent } from '../ui/card';
import { cn } from '@/lib/utils';
import { Progress } from '../ui/progress';
import { useSession } from 'next-auth/react';
import Image from 'next/image';
import { DataTablePagination } from './data-table-pagination';


type UploadStatus = 'pending' | 'uploading' | 'success' | 'error';

type UploadableFile = {
    id: string;
    file: File;
    status: UploadStatus;
    progress: number;
    previewUrl?: string;
    error?: string;
    newMedia?: Media; // Store the full media object on success
}


type MediaLibraryModalProps = {
    isOpen: boolean;
    onOpenChange: (open: boolean) => void;
    onSelect: (media: Media) => void;
};

export default function MediaLibraryModal({ isOpen, onOpenChange, onSelect }: MediaLibraryModalProps) {
    const [mediaItems, setMediaItems] = useState<Media[]>([]);
    const [selectedMediaId, setSelectedMediaId] = useState<string | null>(null);
    const [uploadingFiles, setUploadingFiles] = useState<UploadableFile[]>([]);
    const [isDragging, setIsDragging] = useState(false);
    const [activeTab, setActiveTab] = useState('upload-files');
    const fileInputRef = useRef<HTMLInputElement>(null);
    const { data: session } = useSession();
    
    // Pagination state
    const [page, setPage] = useState(1);
    const [pageSize, setPageSize] = useState(24);

    const fetchMedia = useCallback(async () => {
        const media = await getMedia(true); // Force refresh
        setMediaItems(media.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
        return media;
    }, []);

    useEffect(() => {
        if (isOpen && activeTab === 'media-library') {
            fetchMedia();
        }
    }, [isOpen, activeTab, fetchMedia]);

    useEffect(() => {
        // Reset state when dialog is closed
        if (!isOpen) {
            setUploadingFiles([]);
            setSelectedMediaId(null);
            setActiveTab('upload-files');
            setPage(1);
        }
    }, [isOpen]);

    const paginatedMedia = useMemo(() => {
        const startIndex = (page - 1) * pageSize;
        return mediaItems.slice(startIndex, startIndex + pageSize);
    }, [mediaItems, page, pageSize]);

    const totalPages = Math.ceil(mediaItems.length / pageSize);
    
    const selectedItem = mediaItems.find(item => item.id === selectedMediaId);
    
     const handleFileSelect = (selectedFiles: FileList | null) => {
        if (!selectedFiles) return;

        const newFiles = Array.from(selectedFiles).map(file => {
            const newFile: UploadableFile = {
                id: `${file.name}-${file.lastModified}`,
                file,
                status: 'pending' as UploadStatus,
                progress: 0,
            };
            if (file.type.startsWith('image/')) {
                newFile.previewUrl = URL.createObjectURL(file);
            }
            return newFile;
        });
        
        setUploadingFiles(prev => [...prev, ...newFiles]);
        startUpload(newFiles);
    };

    const startUpload = (filesToUpload: UploadableFile[]) => {
        filesToUpload.forEach(uploadableFile => {
            const formData = new FormData();
            formData.append('file', uploadableFile.file);
            formData.append('userId', (session?.user as any)?.id || '1');

            const xhr = new XMLHttpRequest();

            xhr.upload.onprogress = (event) => {
                if (event.lengthComputable) {
                    const progress = Math.round((event.loaded / event.total) * 100);
                     setUploadingFiles(prev => prev.map(f => f.id === uploadableFile.id ? { ...f, progress } : f));
                }
            };
            
            xhr.onload = async () => {
                if (xhr.status >= 200 && xhr.status < 300) {
                     const newMedia: Media = JSON.parse(xhr.responseText);
                     setUploadingFiles(prev => prev.map(f => f.id === uploadableFile.id ? { ...f, status: 'success', progress: 100, newMedia } : f));
                     // Auto-select the newly uploaded file
                     setSelectedMediaId(newMedia.id);
                     // Refresh media library in the background
                     await fetchMedia();

                } else {
                    try {
                        const errorResponse = JSON.parse(xhr.responseText);
                         setUploadingFiles(prev => prev.map(f => f.id === uploadableFile.id ? { ...f, status: 'error' as UploadStatus, error: errorResponse.message || 'Upload failed' } : f));
                    } catch {
                         setUploadingFiles(prev => prev.map(f => f.id === uploadableFile.id ? { ...f, status: 'error' as UploadStatus, error: 'Upload failed' } : f));
                    }
                }
            };

            xhr.onerror = () => {
                setUploadingFiles(prev => prev.map(f => f.id === uploadableFile.id ? { ...f, status: 'error' as UploadStatus, error: 'Network error' } : f));
            };
            
            xhr.open('POST', '/api/media', true);
            xhr.send(formData);

            setUploadingFiles(prev => prev.map(f => f.id === uploadableFile.id ? { ...f, status: 'uploading' as UploadStatus } : f));
        });
    }

     const handleDragEnter = (e: React.DragEvent) => { e.preventDefault(); e.stopPropagation(); setIsDragging(true); };
     const handleDragLeave = (e: React.DragEvent) => { e.preventDefault(); e.stopPropagation(); setIsDragging(false); };
     const handleDrop = (e: React.DragEvent) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);
        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
            handleFileSelect(e.dataTransfer.files);
            e.dataTransfer.clearData();
        }
    };
    
    const handleSetFeaturedImage = () => {
        let itemToSelect: Media | undefined = selectedItem;

        // If no item is selected from the library, check if there's a successful upload
        if (!itemToSelect) {
            const lastSuccessfulUpload = uploadingFiles.filter(f => f.status === 'success').pop();
            itemToSelect = lastSuccessfulUpload?.newMedia;
        }

        if (itemToSelect) {
            onSelect(itemToSelect);
        }
    };
    
    // The "Set" button should be enabled if an item is selected in the library OR if there's at least one successful upload
    const isSetButtonEnabled = selectedMediaId !== null || uploadingFiles.some(f => f.status === 'success');


    return (
        <Dialog open={isOpen} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-6xl h-[90vh] flex flex-col">
                <Tabs value={activeTab} onValueChange={setActiveTab} className="flex flex-col flex-1 h-full overflow-hidden">
                    <DialogHeader className="flex-row items-center flex-shrink-0">
                        <div className="flex flex-col">
                            <DialogTitle>Media Library</DialogTitle>
                            <DialogDescription>Upload new files or select existing media from your library.</DialogDescription>
                        </div>
                         <TabsList className="ml-8">
                            <TabsTrigger value="upload-files">Upload files</TabsTrigger>
                            <TabsTrigger value="media-library">Media Library</TabsTrigger>
                        </TabsList>
                    </DialogHeader>
                    <TabsContent value="upload-files" className="flex-1 flex items-center justify-center mt-2">
                         <Card 
                            className={cn("border-dashed border-2 w-full h-full flex items-center justify-center", isDragging && "border-primary bg-primary/10")}
                            onDragEnter={handleDragEnter}
                            onDragLeave={handleDragLeave}
                            onDragOver={handleDragEnter}
                            onDrop={handleDrop}
                        >
                            <CardContent className="p-12 text-center">
                                {uploadingFiles.length > 0 ? (
                                     <div className="space-y-4">
                                        {uploadingFiles.map(uploadableFile => (
                                            <div key={uploadableFile.id} className="p-4 border rounded-lg flex items-center gap-4 text-left">
                                            {uploadableFile.previewUrl ? (
                                                    <Image src={uploadableFile.previewUrl} width={48} height={48} alt={uploadableFile.file.name} className="h-12 w-12 object-cover rounded-md flex-shrink-0" />
                                                ) : (
                                                    <FileIcon className="h-8 w-8 text-muted-foreground flex-shrink-0"/>
                                                )}
                                                <div className="flex-1 overflow-hidden">
                                                    <p className="font-semibold truncate">{uploadableFile.file.name}</p>
                                                    <div className="flex items-center gap-2 mt-1">
                                                        <Progress value={uploadableFile.progress} className="h-2 flex-1" />
                                                        <span className="text-xs font-mono w-10 text-right">{uploadableFile.progress}%</span>
                                                    </div>
                                                </div>
                                                <div className="flex items-center gap-2">
                                                    {uploadableFile.status === 'uploading' && <Loader2 className="h-5 w-5 animate-spin" />}
                                                    {uploadableFile.status === 'success' && <CheckCircle className="h-5 w-5 text-green-500" />}
                                                    {uploadableFile.status === 'error' && <AlertCircle className="h-5 w-5 text-destructive" />}
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                ) : (
                                     <div className="flex flex-col items-center justify-center space-y-4">
                                        <p className="text-xl text-muted-foreground">Drop files to upload</p>
                                        <p className="text-muted-foreground">or</p>
                                        <Button onClick={() => fileInputRef.current?.click()}>Select Files</Button>
                                        <Input ref={fileInputRef} type="file" className="hidden" multiple onChange={(e) => handleFileSelect(e.target.files)} />
                                    </div>
                                )}
                            </CardContent>
                        </Card>
                    </TabsContent>
                    <TabsContent value="media-library" className="flex-1 overflow-y-auto mt-2">
                        <div className="grid grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-4 pr-4 py-4">
                            {paginatedMedia.map(item => (
                                <MediaCard 
                                    key={item.id} 
                                    media={item}
                                    isSelected={selectedMediaId === item.id}
                                    onSelect={(e) => { e.stopPropagation(); setSelectedMediaId(item.id); }}
                                    onClick={() => setSelectedMediaId(item.id)}
                                />
                            ))}
                        </div>
                    </TabsContent>
                    <DialogFooter className="mt-auto pt-4 border-t flex-shrink-0">
                        <div className="w-full flex justify-between items-center">
                            <div>
                                {activeTab === 'media-library' && mediaItems.length > pageSize && (
                                     <DataTablePagination
                                        currentPage={page}
                                        totalPages={totalPages}
                                        onPageChange={setPage}
                                        pageSize={pageSize}
                                        onPageSizeChange={setPageSize}
                                        itemCount={mediaItems.length}
                                        className="p-0"
                                     />
                                )}
                               {activeTab !== 'media-library' && selectedItem && <span className="text-sm">{selectedItem.fileName}</span>}
                            </div>
                             <div>
                                <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
                                <Button onClick={handleSetFeaturedImage} disabled={!isSetButtonEnabled} className="ml-2">
                                    Select
                                </Button>
                            </div>
                        </div>
                    </DialogFooter>
                </Tabs>
            </DialogContent>
      </Dialog>
    );
}
