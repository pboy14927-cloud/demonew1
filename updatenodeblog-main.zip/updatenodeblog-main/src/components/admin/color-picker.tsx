
'use client';

import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';

type ColorPickerProps = {
    label: string;
    color: string; // Expects a HEX string like "#RRGGBB"
    onChange: (color: string) => void;
}

export default function ColorPicker({ label, color, onChange }: ColorPickerProps) {

    const handleHexChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const newHex = e.target.value;
        onChange(newHex);
    };

    return (
        <div className="grid grid-cols-3 items-center gap-4 py-2">
            <Label className="w-full">{label}</Label>
            <div className="col-span-2 flex items-center gap-2">
                 <Input
                    type="color"
                    value={color || '#ffffff'}
                    onChange={handleHexChange}
                    className="p-1 h-10 w-14"
                />
                <Input
                    type="text"
                    value={color || ''}
                    onChange={handleHexChange}
                    placeholder="#RRGGBB"
                    className="font-mono text-sm"
                />
            </div>
        </div>
    );
}
