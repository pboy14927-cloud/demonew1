
"use client";
import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { getPosts, getPublishedPosts, getPages, Post, getComments, createPostDb } from "@/lib/data";
import { CheckCircle, MessageSquare, Newspaper, FileText } from "lucide-react";
import Link from 'next/link';
import { useToast } from '@/hooks/use-toast';
import { useSession } from 'next-auth/react';

export function SiteHealthCard() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-headline text-base">Site Health Status</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-2 text-primary">
            <CheckCircle className="w-8 h-8"/>
            <p className="text-lg font-semibold">Good</p>
        </div>
        <p className="text-muted-foreground mt-2">
          Congratulations, your site's health is looking good!
        </p>
        <CardFooter className="px-0 pt-4">
            <Button variant="secondary">Go to Site Health</Button>
        </CardFooter>
      </CardContent>
    </Card>
  );
}

export function AtAGlanceCard() {
  const [postCount, setPostCount] = useState(0);
  const [pageCount, setPageCount] = useState(0);
  const [commentCount, setCommentCount] = useState(0);

  useEffect(() => {
    const fetchCounts = async () => {
        const posts = await getPosts();
        const pages = await getPages();
        const comments = await getComments();
        setPostCount(posts.length);
        setPageCount(pages.length);
        setCommentCount(comments.filter(c => c.status === 'approved' || c.status === 'pending').length);
    }
    fetchCounts();
  }, []);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-headline text-base">At a Glance</CardTitle>
      </CardHeader>
      <CardContent className="grid grid-cols-2 gap-4">
        <div className="flex items-center gap-2">
          <FileText className="w-5 h-5 text-primary" />
          <Link href="/admin/posts" className="text-primary hover:underline">{postCount} {postCount === 1 ? 'Post' : 'Posts'}</Link>
        </div>
        <div className="flex items-center gap-2">
          <MessageSquare className="w-5 h-5 text-primary" />
          <Link href="/admin/comments" className="text-primary hover:underline">{commentCount} {commentCount === 1 ? 'Comment' : 'Comments'}</Link>
        </div>
        <div className="flex items-center gap-2">
          <FileText className="w-5 h-5 text-primary" />
          <Link href="/admin/pages" className="text-primary hover:underline">{pageCount} {pageCount === 1 ? 'Page' : 'Pages'}</Link>
        </div>
      </CardContent>
    </Card>
  );
}

export function QuickDraftCard() {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const { toast } = useToast();
  const { data: session } = useSession();

  const handleSaveDraft = async () => {
    if (!title || !content) {
      toast({
        variant: "destructive",
        title: "Missing fields",
        description: "Please enter a title and content for your draft.",
      });
      return;
    }
    try {
      const authorId = (session?.user as any)?.id;
      if (!authorId) {
        throw new Error("You must be logged in to save a draft.");
      }
      await createPostDb({
        title,
        content,
        status: 'draft',
        authorId: authorId,
      });
      toast({
        title: "Draft Saved",
        description: `"${title}" has been saved as a draft.`,
      });
      setTitle('');
      setContent('');
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error saving draft",
        description: "Could not save your draft. Please try again.",
      });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-headline text-base">Quick Draft</CardTitle>
      </CardHeader>
      <CardContent>
        <form className="space-y-4">
          <div className="space-y-1">
            <Label htmlFor="draft-title">Title</Label>
            <Input 
              id="draft-title" 
              placeholder="What's on your mind?" 
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>
          <div className="space-y-1">
            <Label htmlFor="draft-content">Content</Label>
            <Textarea 
              id="draft-content" 
              placeholder="Start writing..." 
              rows={4} 
              value={content}
              onChange={(e) => setContent(e.target.value)}
            />
          </div>
        </form>
      </CardContent>
      <CardFooter>
        <Button onClick={handleSaveDraft}>Save Draft</Button>
      </CardFooter>
    </Card>
  );
}

type FormattedPost = Post & {
    formattedDate: string;
    formattedTime: string;
}

export function ActivityCard() {
    const [formattedPosts, setFormattedPosts] = useState<FormattedPost[] | null>(null);

    useEffect(() => {
        const fetchAndFormatPosts = async () => {
            const initialPosts = await getPublishedPosts();
            const slicedPosts = initialPosts.slice(0, 3);
            const postsWithFormattedDates = slicedPosts.map(post => ({
                ...post,
                formattedDate: new Date(post.createdAt).toLocaleDateString([], { month: 'short', day: 'numeric' }),
                formattedTime: new Date(post.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true })
            }));
            setFormattedPosts(postsWithFormattedDates);
        };
        fetchAndFormatPosts();
    }, []);

    if (formattedPosts === null) {
        return (
             <Card>
                <CardHeader>
                    <CardTitle className="font-headline text-base">Activity</CardTitle>
                    <CardDescription>Recently published</CardDescription>
                </CardHeader>
                <CardContent>
                    <p>Loading...</p>
                </CardContent>
            </Card>
        )
    }

    return (
        <Card>
            <CardHeader>
                <CardTitle className="font-headline text-base">Activity</CardTitle>
                <CardDescription>Recently published</CardDescription>
            </CardHeader>
            <CardContent>
                <ul className="space-y-3">
                    {formattedPosts.map(post => (
                        <li key={post.id} className="text-sm text-muted-foreground grid grid-cols-[auto_1fr] items-start gap-4">
                            <span className="text-right">{post.formattedDate}<br/>{post.formattedTime}</span>
                            <span className="font-semibold text-foreground">
                                <Link href={`/${post.slug}`} className="text-primary hover:underline" target="_blank">{post.title}</Link>
                            </span> 
                        </li>
                    ))}
                </ul>
            </CardContent>
        </Card>
    );
}

export function NewsCard() {
    const [posts, setPosts] = useState<Post[]>([]);

    useEffect(() => {
        getPublishedPosts().then(p => setPosts(p.slice(0,3)));
    }, []);
    
    return (
        <Card>
            <CardHeader>
                <CardTitle className="font-headline text-base flex items-center gap-2">
                    <Newspaper className="text-muted-foreground" />
                    <span>Recently Published</span>
                </CardTitle>
            </CardHeader>
            <CardContent>
                <ul className="space-y-2 list-disc pl-5">
                    {posts.length > 0 ? (
                        posts.map(post => (
                             <li key={post.id} className="text-sm"><Link href={`/${post.slug}`} className="text-primary hover:underline">{post.title}</Link></li>
                        ))
                    ) : (
                        <p className="text-sm text-muted-foreground">No posts published yet.</p>
                    )}
                </ul>
            </CardContent>
        </Card>
    );
}
