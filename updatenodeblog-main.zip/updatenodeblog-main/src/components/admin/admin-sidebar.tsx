

"use client"
import * as React from 'react';
import { usePathname } from 'next/navigation';
import Link from 'next/link';
import {
  Sidebar,
  SidebarContent,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarFooter,
  SidebarSeparator,
  SidebarHeader,
  useSidebar,
} from '@/components/ui/sidebar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible"
import {
  LayoutDashboard,
  FileText,
  Settings,
  ImageIcon,
  Book,
  MessageSquare,
  Paintbrush,
  Users,
  Wrench,
  ChevronsRight,
  ChevronDown,
  TrendingUp,
  Briefcase,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { getSettings } from '@/lib/data';
import { useSession } from 'next-auth/react';

const WordpressIcon = () => (
    <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 20 20"><path d="M10 0C4.477 0 0 4.477 0 10c0 5.523 4.477 10 10 10s10-4.477 10-10C20 4.477 15.523 0 10 0zM8.52 4.483l5.592 1.996a.54.54 0 01.388.508v5.938c0 .288-.19.539-.461.61L8.52 15.517a.645.645 0 01-.84-.57V5.053a.645.645 0 01.84-.57zm1.14 1.14v8.754l4.242-1.514V7.14L9.66 5.623zM4.09 7.143l3.81 1.36v2.99l-3.81 1.36V7.143z"></path></svg>
)

const hasPermission = (role: string | undefined, allowedRoles: string[]): boolean => {
    if (!role) return false;
    if (role === 'administrator') return true;
    return allowedRoles.includes(role);
};


const SidebarItems = ({ isCollapsed }: { isCollapsed: boolean }) => {
    const pathname = usePathname();
    const { data: session } = useSession();
    const userRole = (session?.user as any)?.role;

    const linkClass = (path: string, exact: boolean = false) => {
        const isActive = exact ? pathname === path : pathname.startsWith(path);
        return `block hover:text-sidebar-accent-foreground ${isActive ? 'text-sidebar-accent-foreground' : ''}`;
    }

    const menuItems = [
        {
            icon: <FileText />,
            label: 'Posts',
            path: '/admin/posts',
            roles: ['editor', 'author', 'contributor'],
            content: [
                { path: '/admin/posts', label: 'All Posts', roles: ['editor', 'author', 'contributor'] },
                { path: '/admin/posts/new', label: 'Add New Post', roles: ['editor', 'author', 'contributor'] },
                { path: '/admin/posts/categories', label: 'Categories', roles: ['editor'] },
                { path: '/admin/posts/tags', label: 'Tags', roles: ['editor'] },
            ]
        },
        {
            icon: <ImageIcon />,
            label: 'Media',
            path: '/admin/media',
            roles: ['editor', 'author', 'contributor'],
            content: [
                { path: '/admin/media', label: 'Library', roles: ['editor', 'author', 'contributor'] },
                { path: '/admin/media/new', label: 'Add New Media', roles: ['editor', 'author', 'contributor'] },
            ]
        },
        {
            icon: <Book />,
            label: 'Pages',
            path: '/admin/pages',
            roles: ['editor'],
            content: [
                { path: '/admin/pages', label: 'All Pages', exact: true, roles: ['editor'] },
                { path: '/admin/pages/new', label: 'Add New Page', roles: ['editor'] },
            ]
        },
        {
            icon: <TrendingUp />,
            label: 'Digiotic SEO',
            path: '/admin/seo',
            roles: ['editor'],
            content: [
                { path: '/admin/seo', label: 'Dashboard', exact: true, roles: ['editor'] },
                { path: '/admin/seo/search-appearance', label: 'Search Appearance', roles: ['editor'] },
                { path: '/admin/seo/webmaster-tools', label: 'Webmaster Tools', roles: ['editor'] },
                { path: '/admin/seo/sitemaps', label: 'XML Sitemaps', roles: ['editor'] },
                { path: '/admin/seo/tools', label: 'Tools', roles: ['editor'] },
            ]
        },
        {
            icon: <Paintbrush />,
            label: 'Appearance',
            path: '/admin/appearance',
            roles: [], // Admin only
            content: [
                { path: '/admin/appearance', label: 'Themes', exact: true, roles: [] },
                { path: '/admin/appearance/branding', label: 'Branding', roles: [] },
                { path: '/admin/appearance/menus', label: 'Menus', roles: [] },
                { path: '/admin/appearance/homepage', label: 'Homepage Design', roles: [] },
                { path: '/admin/appearance/headers', label: 'Headers', roles: [] },
                { path: '/admin/appearance/footers', label: 'Footers', roles: [] },
            ]
        },
        {
            icon: <Users />,
            label: 'Users',
            path: '/admin/users',
            roles: [], // Admin only
            content: [
                { path: '/admin/users', label: 'All Users', exact: true, roles: [] },
                { path: '/admin/users/new', label: 'Add New', roles: [] },
            ]
        },
         {
            icon: <Wrench />,
            label: 'Tools',
            path: '/admin/tools',
            roles: [], // Admin only
            content: [
                { path: '/admin/tools', label: 'Available Tools', exact: true, roles: [] },
                { path: '/admin/tools/import', label: 'Import', roles: [] },
                { path: '/admin/tools/export', label: 'Export', roles: [] },
                { path: '/admin/tools/database', label: 'Database', roles: [] },
            ]
        },
    ];

    const renderMenuItem = (item: typeof menuItems[0]) => {
        if (!hasPermission(userRole, item.roles)) return null;
        
        const filteredContent = item.content.filter(subItem => hasPermission(userRole, subItem.roles));

        if (isCollapsed) {
            return (
                <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                        <SidebarMenuButton isActive={pathname.startsWith(item.path)} tooltip={item.label} className="justify-center">
                           {item.icon}
                        </SidebarMenuButton>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent side="right" align="start">
                       {filteredContent.map(subItem => (
                           <DropdownMenuItem key={subItem.path} asChild>
                               <Link href={subItem.path}>{subItem.label}</Link>
                           </DropdownMenuItem>
                       ))}
                    </DropdownMenuContent>
                </DropdownMenu>
            );
        }

        return (
            <Collapsible>
                <CollapsibleTrigger asChild>
                    <SidebarMenuButton isActive={pathname.startsWith(item.path)} tooltip={item.label} className="justify-between">
                        <div className="flex items-center gap-2"> {item.icon} <span>{item.label}</span> </div>
                        <ChevronDown className="h-4 w-4" />
                    </SidebarMenuButton>
                </CollapsibleTrigger>
                <CollapsibleContent>
                    <ul className="pl-8 py-2 space-y-2 text-sm">
                        {filteredContent.map(subItem => (
                             <li key={subItem.path}>
                                <Link href={subItem.path} className={linkClass(subItem.path, subItem.exact)}>{subItem.label}</Link>
                            </li>
                        ))}
                    </ul>
                </CollapsibleContent>
            </Collapsible>
        );
    };

    return (
        <SidebarMenu>
          <SidebarMenuItem>
              <SidebarMenuButton asChild isActive={pathname === '/admin'} tooltip="Dashboard">
                 <Link href="/admin"> <LayoutDashboard /> {!isCollapsed && <span>Dashboard</span>} </Link>
              </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarSeparator />
           {menuItems.map(item => <SidebarMenuItem key={item.path}>{renderMenuItem(item)}</SidebarMenuItem>)}
          
          {hasPermission(userRole, ['editor']) && (
             <SidebarMenuItem>
                 <SidebarMenuButton asChild isActive={pathname.startsWith('/admin/comments')} tooltip="Comments">
                  <Link href="/admin/comments"> <MessageSquare /> {!isCollapsed && <span>Comments</span>} </Link>
                </SidebarMenuButton>
             </SidebarMenuItem>
          )}

          <SidebarSeparator />
          
           {hasPermission(userRole, ['editor']) && (
             <SidebarMenuItem>
                <Collapsible>
                    <CollapsibleTrigger asChild>
                        <SidebarMenuButton isActive={pathname.startsWith('/admin/promotion')} tooltip="Promotion" className="justify-between">
                            <div className="flex items-center gap-2"><Briefcase />{!isCollapsed && <span>Promotion</span>}</div>
                            {!isCollapsed && <ChevronDown className="h-4 w-4" />}
                        </SidebarMenuButton>
                    </CollapsibleTrigger>
                    <CollapsibleContent>
                        <ul className="pl-8 py-2 space-y-2 text-sm">
                            <li><Link href="/admin/promotion/partner" className={linkClass('/admin/promotion/partner')}>Partner Page</Link></li>
                            <li><Link href="/admin/promotion/sponsors" className={linkClass('/admin/promotion/sponsors')}>Sponsors</Link></li>
                            <li><Link href="/admin/promotion/all-sponsors" className={linkClass('/admin/promotion/all-sponsors')}>All Sponsored Links</Link></li>
                            <li><Link href="/admin/promotion/partner-content" className={linkClass('/admin/promotion/partner-content', true)}>All Partner Content</Link></li>
                            <li><Link href="/admin/promotion/partner-content/new" className={linkClass('/admin/promotion/partner-content/new')}>Add New</Link></li>
                        </ul>
                    </CollapsibleContent>
                </Collapsible>
              </SidebarMenuItem>
           )}

          {hasPermission(userRole, []) && (
              <SidebarMenuItem>
                <SidebarMenuButton asChild isActive={pathname.startsWith('/admin/settings')} tooltip="Settings">
                  <Link href="/admin/settings"> <Settings /> {!isCollapsed && <span>Settings</span>} </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
          )}
        </SidebarMenu>
    );
};


export default function AdminSidebar() {
  const { state, toggleSidebar } = useSidebar();
  const [siteTitle, setSiteTitle] = React.useState('Loading...');
  const isCollapsed = state === 'collapsed';

  React.useEffect(() => {
      getSettings().then(s => setSiteTitle(s.siteTitle));
  }, []);

  return (
    <Sidebar collapsible="icon" className="border-r hidden md:flex">
      <SidebarHeader>
        <Button asChild variant="ghost" className="h-10 w-full justify-start px-2 group-data-[collapsible=icon]:h-10 group-data-[collapsible=icon]:w-10 group-data-[collapsible=icon]:justify-center">
            <Link href="/admin">
                 <WordpressIcon />
                 <span className="group-data-[collapsible=icon]:hidden">{siteTitle}</span>
            </Link>
        </Button>
      </SidebarHeader>
      <SidebarContent>
        <SidebarItems isCollapsed={isCollapsed} />
      </SidebarContent>
      <SidebarFooter>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton tooltip="Collapse Menu" onClick={toggleSidebar}>
                <ChevronsRight className={`transition-transform duration-300 ${isCollapsed ? '' : 'rotate-180'}`} />
                <span className="group-data-[collapsible=icon]:hidden">Collapse menu</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
}
