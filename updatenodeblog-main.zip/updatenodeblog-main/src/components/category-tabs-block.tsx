

'use client';

import React, { useState } from 'react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from './ui/tabs';
import { Post, User, Category, BlogArchiveSettings } from '@/lib/data';
import PostCard from './blog/post-card';
import { cn } from '@/lib/utils';
import { Separator } from './ui/separator';

type CategoryTabsBlockProps = {
    categories: Category[];
    initialPosts: Record<string, (Post & { author: User | null })[]>;
    blockSettings: Record<string, any>;
    archiveSettings: BlogArchiveSettings;
}

export default function CategoryTabsBlock({ categories, initialPosts, blockSettings, archiveSettings }: CategoryTabsBlockProps) {
    const [activeTab, setActiveTab] = useState(categories[0]?.id || '');
    const numColumns = parseInt(blockSettings?.columns || '3', 10);

    const gridColsClassMap: { [key: number]: string } = {
        1: 'md:grid-cols-1',
        2: 'md:grid-cols-2',
        3: 'md:grid-cols-3',
        4: 'md:grid-cols-4',
        5: 'md:grid-cols-5',
        6: 'md:grid-cols-6',
    };
    const gridColsClass = gridColsClassMap[numColumns] || 'md:grid-cols-3';

    return (
        <div>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList>
                    {categories.map(cat => (
                        <TabsTrigger key={cat.id} value={cat.id}>{cat.name}</TabsTrigger>
                    ))}
                </TabsList>
                <Separator className="my-4" />
                {categories.map(cat => (
                    <TabsContent key={cat.id} value={cat.id}>
                        <div className={cn("grid gap-6", blockSettings.layout === 'grid' ? gridColsClass : 'grid-cols-1')}>
                            {(initialPosts[cat.id] || []).map(post => (
                                <PostCard 
                                    key={post.id}
                                    post={post}
                                    author={post.author}
                                    settings={archiveSettings}
                                    layout={blockSettings.layout === 'list' ? 'list' : 'grid'}
                                />
                            ))}
                        </div>
                    </TabsContent>
                ))}
            </Tabs>
        </div>
    );
}
