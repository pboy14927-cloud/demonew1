

'use server';

import React, { CSSProperties, lazy, Suspense } from 'react';
import { Block, BlockType, Post, Category, BlogArchiveSettings, User, getSidebarSettings, getBrandingSettings, SocialLink, getPostById, SidebarSettings, getComments, getTags } from '@/lib/data';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from 'next/link';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';
import { cn } from '@/lib/utils';
import { Input } from './ui/input';
import HtmlRenderer from './html-renderer';
import { Separator } from './ui/separator';
import Sidebar from './blog/sidebar';
import dynamic from 'next/dynamic';
import Image from 'next/image';
import { SocialIcon } from './blog/sidebar';
import { Tabs, TabsList, TabsTrigger } from './ui/tabs';


const PostCard = dynamic(() => import('@/components/blog/post-card'));
const PaginatedPosts = dynamic(() => import('@/components/blog/paginated-posts'));

const CategoryTabsBlock = dynamic(() => import('@/components/category-tabs-block'));


const blockInfo: Record<string, { name: string, isContainer?: boolean }> = {
    // Digiotic Blocks
    'news-focus-block': { name: 'News Focus Block' },
    'focus-grid-block': { name: 'Focus Grid Block' },
    'highlights-block': { name: 'Highlights Block' },
    'large-block': { name: 'Large Block' },
    'overlay-block': { name: 'Overlay Block' },
    'featured-area-grids': { name: 'Featured Area Grids' },
    'featured-hero': { name: 'Featured Hero' },
    'double-featured': { name: 'Double Featured' },
    'grid-below-featured': { name: 'Grid Below Featured' },
    'category-tabs': { name: 'Category Tabs' },
    'custom-block': { name: 'Custom Block' },
    'carousel-block': { name: 'Carousel Block' },
    'image-gallery': { name: 'Image Gallery' },
    'video': { name: 'Video' },
    'paginated-block': { name: 'Paginated Block' },
    // Structure
    'section': { name: 'Section', isContainer: true },
    'two-column': { name: 'Two-Column Layout', isContainer: true },
    'three-column': { name: 'Three-Column Layout', isContainer: true },
    'four-column': { name: 'Four-Column Layout', isContainer: true },
    'five-column': { name: 'Five-Column Layout', isContainer: true },
    'six-column': { name: 'Six-Column Layout', isContainer: true },
    'seven-column': { name: 'Seven-Column Layout', isContainer: true },
    'eight-column': { name: 'Eight-Column Layout', isContainer: true },
    'sidebar-left': { name: 'Sidebar Left', isContainer: true },
    'sidebar-right': { name: 'Sidebar Right', isContainer: true },
    'accordion': { name: 'Accordion', isContainer: true },
    'accordion-item': { name: 'Accordion Item', isContainer: true },
    'sidebar': { name: 'Sidebar' },
    // Grids
    'classic-grid': { name: 'Classic Grid' },
    'masonry-grid': { name: 'Masonry Grid' },
    'metro-grid': { name: 'Metro Grid' },
    'pinterest-style': { name: 'Pinterest Style' },
    'full-width-grid': { name: 'Full Width Grid' },
    // List-Based
    'list-block': { name: 'List Block' },
    'small-list-block': { name: 'Small List Block' },
    'classic-list': { name: 'Classic List' },
    'compact-list': { name: 'Compact List' },
    'numbered-list': { name: 'Numbered List' },
    'timeline': { name: 'Timeline' },
    // Utility
    'spacer': { name: 'Spacer' },
    'divider': { name: 'Divider' },
    'custom-html': { name: 'Custom HTML' },
    'block-heading': { name: 'Block Heading' },
    'breadcrumbs': { name: 'Breadcrumbs' },
    'social-icons': { name: 'SmartMag Social Icons' },
    'ads-codes': { name: 'Ads / Codes' },
    'newsletter-form-digiotic': { name: 'Newsletter Form' },
};


const RenderBlock = async ({ block, allPosts, allCategories, archiveSettings, sidebarSettings, brandingSettings }: { block: Block; allPosts: (Post & { author: User | null })[], allCategories: Category[], archiveSettings: BlogArchiveSettings, sidebarSettings: SidebarSettings, brandingSettings: BrandingSettings }) => {
    const blockMeta = blockInfo[block.type];

    if (!blockMeta) {
        return (
            <Card className="my-4 border-destructive">
                <CardContent className="p-4">
                    <p className="font-semibold text-destructive">Unknown block type: {block.type}</p>
                </CardContent>
            </Card>
        );
    }
    
    const sectionStyles: CSSProperties = {
        backgroundColor: block.styles?.backgroundColor,
        paddingTop: block.styles?.paddingTop ? `${block.styles.paddingTop}px` : undefined,
        paddingBottom: block.styles?.paddingBottom ? `${block.styles.paddingBottom}px` : undefined,
        paddingLeft: block.styles?.paddingLeft ? `${block.styles.paddingLeft}px` : undefined,
        paddingRight: block.styles?.paddingRight ? `${block.styles.paddingRight}px` : undefined,
    }

    if (blockMeta.isContainer) {
        let containerClasses = "my-4";
        if (block.type.includes('column') || block.type.includes('sidebar')) {
            containerClasses += ` grid gap-8`;
            if (block.type === 'two-column') containerClasses += ' md:grid-cols-2';
            if (block.type === 'three-column') containerClasses += ' md:grid-cols-3';
            if (block.type === 'four-column') containerClasses += ' md:grid-cols-4';
            if (block.type === 'five-column') containerClasses += ' md:grid-cols-5';
            if (block.type === 'six-column') containerClasses += ' md:grid-cols-6';
            if (block.type === 'seven-column') containerClasses += ' md:grid-cols-7';
            if (block.type === 'eight-column') containerClasses += ' md:grid-cols-8';
            if (block.type === 'sidebar-left') containerClasses += ' md:grid-cols-[1fr_3fr]';
            if (block.type === 'sidebar-right') containerClasses += ' md:grid-cols-[3fr_1fr]';
        }

        if(block.type === 'accordion') {
            return (
                <Accordion type="multiple" className="w-full my-4">
                    {block.children?.map((child: any) => (
                        <AccordionItem key={child.id} value={child.id}>
                            <AccordionTrigger>{child.settings?.title || 'Accordion Item'}</AccordionTrigger>
                            <AccordionContent>
                                {child.children?.map((grandchild: any) => (
                                    <RenderBlock key={grandchild.id} block={grandchild} allPosts={allPosts} allCategories={allCategories} archiveSettings={archiveSettings} sidebarSettings={sidebarSettings} brandingSettings={brandingSettings} />
                                ))}
                            </AccordionContent>
                        </AccordionItem>
                    ))}
                </Accordion>
            )
        }
        
        let childElements = block.children || [];
        if (block.type === 'sidebar-left') {
            // For sidebar-left, the first child (sidebar) should render first in the DOM,
            // which corresponds to the first column in the grid.
        } else if (block.type === 'sidebar-right') {
             // For sidebar-right, the main content is first, then the sidebar.
        }

        return (
            <div className={cn(containerClasses)} style={sectionStyles}>
                {childElements.map((childBlock: any, index: number) => {
                     const isSidebarColumn = (block.type === 'sidebar-left' && index === 0) || (block.type === 'sidebar-right' && index === 1);
                     return (
                        <div key={childBlock.id} className={cn(isSidebarColumn && "sticky top-8 h-fit")}>
                            {childBlock.children?.map((grandChildBlock: any) => (
                                <RenderBlock key={grandChildBlock.id} block={grandChildBlock} allPosts={allPosts} allCategories={allCategories} archiveSettings={archiveSettings} sidebarSettings={sidebarSettings} brandingSettings={brandingSettings} />
                            ))}
                        </div>
                     )
                })}
            </div>
        )
    }

    let posts = [...allPosts];
    if (block.settings?.category && block.settings.category !== 'all') {
        const category = allCategories.find(c => c.slug === block.settings.category);
        if(category) {
            posts = allPosts.filter(p => p.categories.includes(category.name));
        }
    }

    if (block.settings?.order === 'popular') {
        posts.sort((a,b) => (b.likes || 0) - (a.likes || 0));
    } else if (block.settings?.order === 'most_commented') {
        const comments = await getComments();
        const commentCounts = comments.reduce((acc: Record<string, number>, comment) => {
            acc[comment.postId] = (acc[comment.postId] || 0) + 1;
            return acc;
        }, {});
        posts.sort((a, b) => (commentCounts[b.id] || 0) - (commentCounts[a.id] || 0));
    }
    
    const skipPosts = block.settings?.skipPosts || 0;
    if (skipPosts > 0) {
        posts = posts.slice(skipPosts);
    }
    
    const postLimit = block.settings?.count || block.settings?.posts_limit || 5;

    const Title = () => {
        if (!block.settings?.title) return null;

        const styles = block.styles || {};
        const titleStyles: CSSProperties & { [key: string]: any } = {
            fontFamily: styles.fontFamily,
            fontSize: styles.fontSize ? `${styles.fontSize}px` : undefined,
            fontWeight: styles.fontWeight,
            textAlign: styles.textAlign as any,
            padding: styles.padding ? `${styles.padding}px` : undefined,
            display: 'inline-block',
        };

        if (styles.backgroundType === 'gradient' && styles.gradient) {
            titleStyles.background = `linear-gradient(to right, ${styles.gradient.from}, ${styles.gradient.to})`;
            if (styles.color) {
              titleStyles.color = styles.color;
            }
        } else if (styles.backgroundType === 'solid') {
            titleStyles.backgroundColor = styles.backgroundColor;
            if (styles.color) {
              titleStyles.color = styles.color;
            }
        } else if (styles.colorType === 'gradient' && styles.gradient) {
            titleStyles.background = `linear-gradient(to right, ${styles.gradient.from}, ${styles.gradient.to})`;
            titleStyles.WebkitBackgroundClip = 'text';
            titleStyles.backgroundClip = 'text';
            titleStyles.color = 'transparent';
        } else {
            titleStyles.color = styles.color;
        }

        const headingContent = (
            <h2 className="text-2xl font-bold mb-4" style={titleStyles}>
                {block.settings.title}
            </h2>
        );

        if (block.settings?.url) {
            return <Link href={block.settings.url}>{headingContent}</Link>;
        }
        return headingContent;
    };


    const getPostsByCategorySlug = (slug: string) => {
        if (!slug || slug === 'all') {
            return allPosts;
        }
        const category = allCategories.find(c => c.slug === slug);
        if (!category) return [];
        return allPosts.filter(p => p.categories.includes(category.name));
    };
    
    const numColumns = parseInt(block.settings?.columns || '1', 10);
    const gridColsClassMap: { [key: number]: string } = {
        1: 'md:grid-cols-1',
        2: 'md:grid-cols-2',
        3: 'md:grid-cols-3',
        4: 'md:grid-cols-4',
        5: 'md:grid-cols-5',
        6: 'md:grid-cols-6',
    };
    const gridColsClass = gridColsClassMap[numColumns] || 'md:grid-cols-1';


    const cardContainerStyle = {
        gap: block.styles?.spacing ? `${block.styles.spacing}px` : undefined
    };

    switch(block.type) {
        case 'category-tabs':
            const tabCategories = allCategories.filter(c => block.settings?.categories?.includes(c.id));
            if (tabCategories.length === 0) {
                return (
                    <Card className="my-4">
                        <CardContent className="p-4">
                            <p className="text-muted-foreground">Please select at least one category for the Category Tabs block.</p>
                        </CardContent>
                    </Card>
                )
            }
            // Prepare posts for each category
            const postsByCat = tabCategories.reduce((acc, cat) => {
                acc[cat.id] = getPostsByCategorySlug(cat.slug).slice(0, postLimit);
                return acc;
            }, {} as Record<string, (Post & {author: User | null})[]>);

            return (
                <div className="my-8">
                    <Title />
                    <CategoryTabsBlock 
                        categories={tabCategories} 
                        initialPosts={postsByCat}
                        blockSettings={block.settings || {}}
                        archiveSettings={archiveSettings}
                    />
                </div>
            )
        case 'block-heading':
            const headingStyle = block.settings?.headingStyle || 'underline';
            const titleStyles: CSSProperties & { [key: string]: any } = {
                fontFamily: block.styles?.fontFamily,
                fontSize: block.styles?.fontSize ? `${block.styles.fontSize}px` : undefined,
                fontWeight: block.styles?.fontWeight,
                textAlign: block.styles?.textAlign as any,
                padding: block.styles?.padding ? `${block.styles.padding}px` : undefined,
            };
            if (block.styles?.backgroundType === 'gradient' && block.styles.gradient) {
                titleStyles.background = `linear-gradient(${block.styles.gradient.direction}, ${block.styles.gradient.from}, ${block.styles.gradient.to})`;
                titleStyles.color = block.styles?.color || '#ffffff';
                titleStyles.display = 'inline-block';
            } else if (block.styles?.backgroundType === 'solid') {
                titleStyles.backgroundColor = block.styles?.backgroundColor;
                titleStyles.color = titleStyles.color || '#ffffff';
                titleStyles.display = 'inline-block';
            } else {
                titleStyles.color = block.styles?.color;
            }
            return (
                <div className="my-4" style={{textAlign: block.styles?.textAlign as any}}>
                    <a href={block.settings?.url || '#'}>
                         <h2 className={cn(
                            "text-xl font-bold pb-2 inline-block",
                            headingStyle === 'underline' && 'border-b-2 border-primary',
                            headingStyle === 'border' && 'border-b'
                            )} style={titleStyles}>
                            {block.settings?.title || 'Block Heading'}
                        </h2>
                    </a>
                    {block.settings?.subtitle && <p className="text-muted-foreground text-sm">{block.settings.subtitle}</p>}
                </div>
            );
        case 'news-focus-block':
            const mainFocusPost = posts.length > 0 ? posts[0] : null;
            const sidePosts = posts.slice(1, postLimit);
             return (
                <div className="my-8">
                    <Title />
                    <div className="grid lg:grid-cols-2 gap-8">
                        <div>
                            {mainFocusPost && <Suspense fallback={<div>Loading card...</div>}><PostCard isPriority post={mainFocusPost} author={mainFocusPost.author} layout="grid" settings={archiveSettings} block={block} /></Suspense>}
                        </div>
                        <div className="space-y-4">
                            {sidePosts.map(post => (
                                <Suspense fallback={<div>Loading card...</div>} key={post.id}>
                                    <PostCard post={post} author={post.author} layout="related-list" settings={archiveSettings} block={block} />
                                </Suspense>
                            ))}
                        </div>
                    </div>
                </div>
            );
        case 'focus-grid-block':
            const mainFocusPost2 = posts.length > 0 ? posts[0] : null;
            const gridPostsFocus = posts.slice(1, postLimit); 
            return (
               <div className="my-8">
                   <Title />
                    <div className="grid lg:grid-cols-[2fr_1fr] gap-8">
                       <div>
                           {mainFocusPost2 && <Suspense fallback={<div>Loading card...</div>}><PostCard isPriority post={mainFocusPost2} author={mainFocusPost2.author} layout="classic" settings={archiveSettings} block={block} /></Suspense>}
                       </div>
                       <div className="space-y-6">
                           {gridPostsFocus.map(post => (
                               <Suspense fallback={<div>Loading card...</div>} key={post.id}>
                                   <PostCard post={post} author={post.author} layout="small-list" settings={archiveSettings} block={block} />
                                </Suspense>
                           ))}
                       </div>
                    </div>
               </div>
           );
        case 'highlights-block':
             return (
                <div className="my-8">
                    <Title />
                     <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                         {posts.slice(0, postLimit).map(post => (
                             <Suspense fallback={<div>Loading card...</div>} key={post.id}>
                                 <PostCard post={post} author={post.author} layout="grid" settings={{...archiveSettings, ...block.settings}} block={{...block, settings: {...block.settings, gridSize: 'small' }}}/>
                             </Suspense>
                         ))}
                     </div>
                </div>
            );
        case 'large-block':
            const largePost = posts.length > 0 ? posts[0] : null;
            return largePost && (
                <div className="my-8">
                    <Title />
                    <Suspense fallback={<div>Loading card...</div>}>
                        <PostCard isPriority post={largePost} author={largePost.author} layout="classic" settings={archiveSettings} block={block} />
                    </Suspense>
                </div>
            );
        case 'overlay-block':
            const overlayPost = posts.length > 0 ? posts[0] : null;
            const overlayStyle = {
                height: block.settings?.blockHeight ? `${block.settings.blockHeight}px` : '400px'
            }
            return overlayPost && (
                 <div className="my-8 relative" style={overlayStyle}>
                    <Title />
                    <Suspense fallback={<div>Loading card...</div>}>
                        <PostCard isPriority post={overlayPost} author={overlayPost.author} layout="grid-featured" settings={archiveSettings} block={block}/>
                    </Suspense>
                </div>
            )
        case 'featured-area-grids':
            const offset = block.settings?.skipPosts || 0;
            const limit = block.settings?.count || 4;
            const areaAPosts = getPostsByCategorySlug(block.settings?.areaA || 'all').slice(offset, offset + 1);
            const areaBPosts = getPostsByCategorySlug(block.settings?.areaB || 'all').slice(offset, offset + 2);
            const areaCPosts = getPostsByCategorySlug(block.settings?.areaC || 'all').slice(offset, offset + 2);
            return (
                <div className="my-8">
                    <Title />
                    <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 h-[600px]">
                        <div className="lg:col-span-2 lg:row-span-2 h-full relative">
                             {areaAPosts[0] && <PostCard isPriority post={areaAPosts[0]} author={areaAPosts[0].author} layout="grid-featured" settings={archiveSettings} block={block} />}
                        </div>
                         {areaBPosts.map(post => <div key={post.id} className="h-full relative"><PostCard post={post} author={post.author} layout="grid-featured" settings={archiveSettings} block={block} /></div>)}
                         {areaCPosts.map(post => <div key={post.id} className="h-full relative"><PostCard post={post} author={post.author} layout="grid-featured" settings={archiveSettings} block={block} /></div>)}
                    </div>
                </div>
            );
        case 'featured-hero':
            const heroPostId = block.settings?.postId;
            const heroPost = heroPostId ? allPosts.find(p => p.id === heroPostId) : null;
            if (!heroPost) return null;
            return (
                <div className="my-8 p-16 rounded-lg text-center" style={{ backgroundColor: block.styles?.backgroundColor || '#f0f0f0', color: block.styles?.textColor || '#000000', textAlign: block.styles?.textAlign as any || 'center' }}>
                    <h2 className="text-4xl font-bold">{block.settings?.title || heroPost.title}</h2>
                    <p className="mt-4 text-lg">{block.settings?.subtitle || heroPost.excerpt}</p>
                    <Button asChild className="mt-6"><Link href={`/${heroPost.slug}`}>Read More</Link></Button>
                </div>
            );
        case 'double-featured':
            const post1Id = block.settings?.post1;
            const post2Id = block.settings?.post2;
            const post1 = post1Id ? allPosts.find(p => p.id === post1Id) : null;
            const post2 = post2Id ? allPosts.find(p => p.id === post2Id) : null;
            return (
                 <div className="my-8 grid md:grid-cols-2 gap-8">
                    {post1 && <div className="relative min-h-[400px]"><PostCard isPriority post={post1} author={post1.author} layout="grid-featured" settings={archiveSettings} block={block}/></div>}
                    {post2 && <div className="relative min-h-[400px]"><PostCard post={post2} author={post2.author} layout="grid-featured" settings={archiveSettings} block={block}/></div>}
                </div>
            );
        case 'grid-below-featured':
             const mainPostId = block.settings?.mainPost;
             const mainPost = mainPostId ? allPosts.find(p => p.id === mainPostId) : null;
             const gridCat = block.settings?.gridCategory;
             const gridPosts = gridCat ? getPostsByCategorySlug(gridCat).slice(0, 4) : allPosts.slice(0, 4);
             return (
                <div className="my-8 space-y-8">
                    {mainPost && <PostCard isPriority post={mainPost} author={mainPost.author} layout="classic" settings={archiveSettings} block={block}/>}
                    <div className="grid md:grid-cols-4 gap-6">
                        {gridPosts.map(p => <PostCard key={p.id} post={p} author={p.author} layout="grid" settings={archiveSettings} block={{ ...block, settings: { ...block.settings, gridSize: 'small' } }}/>)}
                    </div>
                </div>
             )
        case 'ads-codes':
             return <div className="my-4" dangerouslySetInnerHTML={{ __html: block.settings?.html || '' }} />;
        case 'social-icons':
             return (
                 <div className="my-4">
                     <Title/>
                     <div className="flex gap-2">
                        {brandingSettings.socialLinks.map(link => (
                            <Button asChild key={link.id} variant="outline" size="icon">
                                <a href={link.url} target="_blank" rel="noopener noreferrer"><SocialIcon platform={link.platform} /></a>
                            </Button>
                        ))}
                    </div>
                </div>
            );
        case 'breadcrumbs':
             return (
                <div className="my-4 text-sm text-muted-foreground">
                    <Link href="/" className="hover:text-primary">Home</Link>
                    <span className="mx-2">&raquo;</span>
                    <span>Current Page</span>
                </div>
            );
        case 'classic-grid':
        case 'masonry-grid':
        case 'metro-grid':
        case 'pinterest-style':
        case 'full-width-grid':
            return (
                <div className="my-8">
                    <Title/>
                    <div className={cn("grid gap-6", gridColsClass)} style={cardContainerStyle}>
                        {posts.slice(0, postLimit).map((post, index) => <Suspense fallback={<div>Loading card...</div>} key={post.id}><PostCard isPriority={index < 2} post={post} layout="grid" settings={archiveSettings} author={post.author} block={block} /></Suspense>)}
                    </div>
                </div>
            );
        case 'list-block':
        case 'small-list-block':
        case 'classic-list':
        case 'compact-list':
        case 'numbered-list':
        case 'timeline':
             const postCardLayoutMap = {
                'list-block': 'related-list',
                'small-list-block': 'small-list',
                'classic-list': 'list',
                'compact-list': 'compact-list',
                'numbered-list': 'numbered-list',
                'timeline': 'timeline',
             }
             const postCardLayout = postCardLayoutMap[block.type as keyof typeof postCardLayoutMap] || 'related-list';
             return (
                <div className="my-8">
                    <Title/>
                    <div className={cn("grid gap-6", gridColsClass)} style={cardContainerStyle}>
                        {posts.slice(0, postLimit).map((post, index) => <Suspense fallback={<div>Loading card...</div>} key={post.id}><PostCard isPriority={index < 1} post={post} layout={postCardLayout as any} index={index + 1} settings={archiveSettings} author={post.author} block={block} /></Suspense>)}
                    </div>
                </div>
            );
         case 'custom-block':
            const customLayout = block.settings?.layout || 'large-left-small-right';
            const largePostCount = block.settings?.largePostCount || 1;
            const largePostColumns = block.settings?.largePostColumns || 1;
            const smallPostCount = block.settings?.smallPostCount || 3;
            const smallPostColumns = block.settings?.smallPostColumns || 2;
            
            const largePostGridClass = gridColsClassMap[largePostColumns] || 'md:grid-cols-1';
            const smallPostGridClass = gridColsClassMap[smallPostColumns] || 'md:grid-cols-2';

            const customMainPosts = posts.slice(0, largePostCount);
            const customSidePosts = posts.slice(largePostCount, largePostCount + smallPostCount);
            
            const MainContent = () => <div className={cn("grid gap-8", largePostGridClass)}>{customMainPosts.map(p => <PostCard key={p.id} post={p} author={p.author} layout="classic" settings={archiveSettings} block={block} />)}</div>
            const SideContentVertical = () => <div className="space-y-6">{customSidePosts.map(p => <PostCard key={p.id} post={p} author={p.author} layout="small-list" settings={archiveSettings} block={block} />)}</div>
            const SideContentGrid = () => <div className={cn("grid gap-6", smallPostGridClass)}>{customSidePosts.map(p => <PostCard key={p.id} post={p} author={p.author} layout="grid" settings={archiveSettings} block={{...block, settings: {...block.settings, gridSize: 'small'}}} />)}</div>
            
            const OverlayContent = ({isLarge}: {isLarge: boolean}) => (
                <div className={cn("grid gap-6 h-full", isLarge ? largePostGridClass : smallPostGridClass)}>
                    {(isLarge ? customMainPosts : customSidePosts).map(p => 
                        <div key={p.id} className="h-full relative">
                            <PostCard post={p} author={p.author} layout="grid-featured" settings={archiveSettings} block={block}/>
                        </div>
                    )}
                </div>
            );
            
            const layoutMap: Record<string, React.ReactNode> = {
                'large-left-small-right': <div className="grid lg:grid-cols-[2fr_1fr] gap-8"><MainContent /><SideContentVertical /></div>,
                'large-right-small-left': <div className="grid lg:grid-cols-[1fr_2fr] gap-8"><SideContentVertical /><MainContent /></div>,
                'large-left-small-grid': <div className="grid lg:grid-cols-[2fr_1fr] gap-8"><MainContent /><SideContentGrid /></div>,
                'large-right-small-grid': <div className="grid lg:grid-cols-[1fr_2fr] gap-8"><SideContentGrid /><MainContent /></div>,
                'large-top-small-grid': <div className="space-y-8"><MainContent /><SideContentGrid /></div>,
                'mixed-grid': <div className={cn("grid gap-8 grid-cols-1", smallPostGridClass)}><MainContent /><SideContentGrid/></div>,
                'overlay-large-left-small-right': <div className="grid lg:grid-cols-2 gap-8 min-h-[500px]"><OverlayContent isLarge={true} /><SideContentGrid /></div>,
                'overlay-large-right-small-left': <div className="grid lg:grid-cols-2 gap-8 min-h-[500px]"><SideContentGrid /><OverlayContent isLarge={true} /></div>,
                'overlay-large-top-small-bottom': <div className="grid grid-rows-2 gap-8 min-h-[600px]"><OverlayContent isLarge={true} /><SideContentGrid /></div>,
                'overlay-large-bottom-small-top': <div className="grid grid-rows-2 gap-8 min-h-[600px]"><SideContentGrid /><OverlayContent isLarge={true} /></div>,
            };
            
            return (
                <div className="my-8">
                    <Title />
                    {layoutMap[customLayout]}
                </div>
            );
        case 'paginated-block':
            const pagedPosts = posts.slice(0, block.settings?.postsPerPage || 6);
            return (
                 <div className="my-8">
                    <Title/>
                    <PaginatedPosts 
                        initialPosts={pagedPosts}
                        allPosts={posts}
                        settings={{
                            ...archiveSettings,
                            layout: block.settings?.layout || 'grid',
                            postsPerPage: block.settings?.postsPerPage || 6,
                            paginationStyle: block.settings?.paginationStyle || 'numbered',
                            columns: block.settings?.columns || '3',
                        }}
                        totalPages={Math.ceil(posts.length / (block.settings?.postsPerPage || 6))}
                        currentPage={1}
                    />
                </div>
            )
        case 'carousel-block':
            const carouselPosts = posts.slice(0, postLimit);
             return (
                <div className="my-8">
                    <Title/>
                     {carouselPosts.length > 0 ? (
                        <Carousel opts={{ loop: block.settings?.loop, slidesToScroll: 1, align: 'start' }}>
                            <CarouselContent className="-ml-4">
                                {carouselPosts.map((post, index) => (
                                    <CarouselItem key={post.id} className={cn(
                                        'pl-4',
                                        block.settings?.slidesToShow === 1 && 'md:basis-full',
                                        block.settings?.slidesToShow === 2 && 'md:basis-1/2',
                                        block.settings?.slidesToShow === 3 && 'md:basis-1/2 lg:basis-1/3',
                                        block.settings?.slidesToShow === 4 && 'md:basis-1/2 lg:basis-1/4',
                                    )}>
                                        <div style={{ height: block.settings?.cardHeight ? `${block.settings.cardHeight}px` : 'auto' }}>
                                            <Suspense fallback={<div>Loading card...</div>}>
                                                <PostCard isPriority={index < 2} post={post} layout="grid" author={post.author} settings={archiveSettings} block={block} />
                                            </Suspense>
                                        </div>
                                    </CarouselItem>
                                ))}
                            </CarouselContent>
                            <CarouselPrevious />
                            <CarouselNext />
                        </Carousel>
                     ) : <p>No posts to display.</p>}
                </div>
            );
        case 'video':
            const videoId = block.settings?.url?.split('v=')[1];
            const embedUrl = videoId ? `https://www.youtube.com/embed/${videoId}` : '';
            return (
                <div className="my-4 aspect-video">
                    {embedUrl ? (
                        <iframe width="100%" height="100%" src={embedUrl} title="YouTube video player" frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen></iframe>
                    ) : (
                        <div className="w-full h-full bg-muted flex items-center justify-center rounded-lg">
                            <p className="text-muted-foreground">Video URL not set</p>
                        </div>
                    )}
                </div>
            );
         case 'image-gallery':
                return (
                    <div className="my-8">
                        <h2 className="text-2xl font-bold mb-4">Image Gallery</h2>
                        <div className={cn("grid gap-4", gridColsClassMap[block.settings?.columns || 4] || 'grid-cols-4')}>
                            {[...Array(block.settings?.columns || 4)].map((_, i) => (
                                <Image key={i} src={`https://placehold.co/400x400.png?text=Image+${i+1}`} width={400} height={400} alt={`Gallery placeholder ${i+1}`} className="rounded-lg object-cover aspect-square" />
                            ))}
                        </div>
                    </div>
                );
            case 'spacer':
                return <div style={{ height: `${block.settings?.height || 20}px` }} />;
            case 'divider':
                const dividerStyles: CSSProperties = {
                    borderTopStyle: block.styles?.borderStyle as any,
                    borderTopColor: block.styles?.borderColor,
                    borderTopWidth: block.styles?.borderWidth ? `${block.styles.borderWidth}px` : '1px',
                    width: block.styles?.width ? `${block.styles.width}%` : '100%',
                    marginTop: block.styles?.marginTop ? `${block.styles.marginTop}px` : '1rem',
                    marginBottom: block.styles?.marginBottom ? `${block.styles.marginBottom}px` : '1rem',
                    marginLeft: 'auto',
                    marginRight: 'auto',
                };
                return <hr style={dividerStyles} />;
            case 'custom-html':
                return <div className="my-4" dangerouslySetInnerHTML={{ __html: block.settings?.html || '' }} />;
            case 'sidebar':
                const tags = await getTags();
                return (
                     <div className="sticky top-8 space-y-8">
                        <Sidebar
                            widgets={block.settings?.widgets || []}
                            settings={sidebarSettings}
                            latestPosts={allPosts.slice(0, 5)}
                            categories={allCategories}
                            socialLinks={brandingSettings.socialLinks}
                            tags={tags}
                        />
                    </div>
                );
        case 'newsletter-form-digiotic':
            return (
                 <div className="my-4 p-6 text-center bg-muted rounded-lg">
                    <h4 className="font-bold text-lg">{block.settings?.title || 'Subscribe To Updates'}</h4>
                    <p className="text-sm text-muted-foreground mt-1 mb-4">
                      {block.settings?.description || 'Get the latest posts & updates delivered to your inbox.'}
                    </p>
                    <div className="flex gap-2 max-w-sm mx-auto">
                        <Input placeholder="Your email address" className="mb-2 bg-background" />
                        <Button className="w-full">Subscribe</Button>
                    </div>
                </div>
            )
        default:
            return (
                <Card className="my-4">
                    <CardContent className="p-4">
                        <p className="text-sm text-muted-foreground">
                            Preview for block type '{block.type}' is not yet implemented.
                        </p>
                    </CardContent>
                </Card>
            );
    }
};

type HomepageBuilderProps = {
    layout: Block[];
    allPosts: (Post & {author: User | null})[];
    allCategories: Category[];
    archiveSettings: BlogArchiveSettings;
};

export default async function HomepageBuilder({ layout, allPosts, allCategories, archiveSettings }: HomepageBuilderProps) {
    if (!layout || layout.length === 0) {
        return (
            <div className="container mx-auto px-4 md:px-6 py-12 text-center">
                <h1 className="text-3xl font-bold">Welcome to your site!</h1>
                <p className="text-muted-foreground mt-2">
                    To get started, add some blocks to your homepage in the admin panel under <br/>
                    <Link href="/admin/appearance/homepage" className="text-primary underline">Appearance &gt; Homepage Design</Link>.
                </p>
            </div>
        );
    }
    
    const sidebarSettings = await getSidebarSettings();
    const brandingSettings = await getBrandingSettings();

    return (
        <div className="bg-background">
            <div className="container mx-auto px-4 md:px-6 py-12">
                {layout.map((block) => (
                    <RenderBlock 
                        key={block.id} 
                        block={block} 
                        allPosts={allPosts} 
                        allCategories={allCategories} 
                        archiveSettings={archiveSettings}
                        sidebarSettings={sidebarSettings}
                        brandingSettings={brandingSettings}
                    />
                ))}
            </div>
        </div>
    );
}
