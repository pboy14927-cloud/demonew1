
'use client';

import * as React from 'react';
import { Button } from './ui/button';
import { Moon, Sun } from 'lucide-react';
import { useTheme } from 'next-themes';
import { useState, useEffect } from 'react';

const ThemeSwitcher = () => {
    const { theme, setTheme } = useTheme();
    const [mounted, setMounted] = useState(false);

    useEffect(() => {
        setMounted(true);
    }, []);

    if (!mounted) {
        return <div className="h-7 w-7" />; // Return a placeholder to avoid layout shift
    }

    return (
        <div className="flex items-center gap-1 p-0.5 rounded-full">
            <Button size="icon" className="h-7 w-7 rounded-full" variant="ghost" onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}>
                {theme === 'light' ? <Moon /> : <Sun />}
                 <span className="sr-only">Toggle theme</span>
            </Button>
        </div>
    )
}

export default ThemeSwitcher;
