

'use server';

import { 
    Post, 
    SponsorSettings, 
    SponsorStyleSettings, 
    PartnerPageSettings, 
    SidebarSettings as SidebarSettingsType, 
    Category,
    BrandingSettings,
    SponsoredLink,
    generatePostUrl,
    getTags,
    Tag
} from '@/lib/data';
import Link from 'next/link';
import PartnerPostCard from '@/components/blog/partner-post-card';
import { Separator } from '@/components/ui/separator';
import { Button } from '@/components/ui/button';
import { CSSProperties } from 'react';
import Sidebar from '@/components/blog/sidebar';
import { colord } from 'colord';
import CommentsSection from '@/components/comments-section';
import Image from 'next/image';

type PartnerPageContentProps = {
    page: Post;
    partnerContent: Post[];
    sponsors: SponsoredLink[];
    sponsorSettings: SponsorSettings;
    partnerPageSettings: PartnerPageSettings;
    sponsorStyleSettings: SponsorStyleSettings;
    sidebarSettings: SidebarSettingsType;
    latestPosts: Post[];
    categories: Category[];
    brandingSettings: BrandingSettings;
}

export default async function PartnerPageContent({ 
    page,
    partnerContent = [], 
    sponsors = [], 
    sponsorSettings, 
    partnerPageSettings,
    sponsorStyleSettings,
    sidebarSettings,
    latestPosts,
    categories,
    brandingSettings
}: PartnerPageContentProps) {
  
    const recommendedContent = partnerContent.filter(p => partnerPageSettings.recommendedContentIds.includes(p.id));

    const showLeftSidebar = partnerPageSettings.showLeftSidebar && sidebarSettings.left.desktop;
    const showRightSidebar = partnerPageSettings.showRightSidebar && sidebarSettings.right.desktop;
    const allTags = await getTags();
    
    const getTypographyStyles = (styles: any): CSSProperties => {
        if (!styles) return {};
        const cssStyles: CSSProperties & { [key: string]: string } = {
            fontFamily: styles.fontFamily,
            fontSize: `${styles.fontSize}px`,
            fontWeight: styles.fontWeight,
            textAlign: styles.textAlign as any,
        };
        if (styles.colorType === 'gradient' && styles.gradient) {
            cssStyles.background = `linear-gradient(${styles.gradient.direction}, ${styles.gradient.from}, ${styles.gradient.to})`;
            cssStyles.WebkitBackgroundClip = 'text';
            cssStyles.backgroundClip = 'text';
            cssStyles.color = 'transparent';
        } else {
            cssStyles.color = styles.color;
        }
        return cssStyles;
    };

    const getSponsorLinkStyles = (): CSSProperties => {
        const styles: CSSProperties & { [key: string]: string } = {
            color: sponsorStyleSettings.textColor,
            border: `${sponsorStyleSettings.borderWidth}px solid ${sponsorStyleSettings.borderColor}`,
            borderRadius: `${sponsorStyleSettings.borderRadius}px`,
            padding: `${sponsorStyleSettings.paddingY}px ${sponsorStyleSettings.paddingX}px`,
            fontFamily: sponsorStyleSettings.fontFamily,
            fontSize: `${sponsorStyleSettings.fontSize}px`,
            fontWeight: sponsorStyleSettings.fontWeight,
            '--hover-color': sponsorStyleSettings.textColor,
            '--hover-bg-color': sponsorStyleSettings.backgroundColor,
        };
        
        if(sponsorStyleSettings.backgroundType === 'gradient') {
            styles.background = `linear-gradient(${sponsorStyleSettings.gradient.direction}, ${sponsorStyleSettings.gradient.from}, ${sponsorStyleSettings.gradient.to})`;
        } else {
            styles.backgroundColor = sponsorStyleSettings.backgroundColor;
        }

        return styles;
    }
    
    const titleStyles = getTypographyStyles(partnerPageSettings.titleStyles);
    const descriptionStyles = getTypographyStyles(partnerPageSettings.descriptionStyles);
    const recommendedTitleStyles = getTypographyStyles(partnerPageSettings.recommendedContentStyles);
    const sponsorTitleStyles = getTypographyStyles(sponsorSettings.titleStyles);
    const sponsorDescriptionStyles = getTypographyStyles(sponsorSettings.descriptionStyles);
    const sponsorLinkStyles = getSponsorLinkStyles();

    const partnerContentWithUrls = await Promise.all(partnerContent.map(async (p) => ({
        ...p,
        url: await generatePostUrl(p)
    })));

    const recommendedContentWithUrls = await Promise.all(recommendedContent.map(async (p) => ({
        ...p,
        url: await generatePostUrl(p)
    })));

    return (
    <>
      <div className="py-12 md:py-16">
        <div className="container px-4 md:px-6">
            <div className="flex flex-col lg:flex-row gap-8">
                {showLeftSidebar && (
                  <div className="w-full lg:w-80 flex-shrink-0 order-first lg:order-none">
                    <div className="sticky top-8">
                       <Sidebar widgets={sidebarSettings.leftWidgets} settings={sidebarSettings} latestPosts={latestPosts} categories={categories} socialLinks={brandingSettings.socialLinks} tags={allTags} />
                    </div>
                  </div>
                )}
                <div className="flex-1">
                      <div className="mb-8 text-center" style={{ textAlign: partnerPageSettings.titleStyles.textAlign as any }}>
                        <h1 
                          className="font-headline mb-2"
                          style={titleStyles}
                        >
                          {partnerPageSettings.title}
                        </h1>
                        <p 
                          className="text-lg text-muted-foreground max-w-3xl mx-auto"
                          style={descriptionStyles}
                        >
                          {partnerPageSettings.description}
                        </p>
                      </div>
                      
                      {partnerContentWithUrls.length > 0 && (
                          <section className="mb-16">
                              <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
                                  {partnerContentWithUrls.map((post) => (
                                      <PartnerPostCard key={post.id} post={post} postUrl={post.url} cardStyles={partnerPageSettings.cardStyles} />
                                  ))}
                              </div>
                          </section>
                      )}

                      {recommendedContentWithUrls.length > 0 && (
                        <section className="mb-16">
                            <h2 className="mb-4" style={recommendedTitleStyles}>{(partnerPageSettings.recommendedContentStyles as any).title}</h2>
                            <Separator className="mb-8" />
                            <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
                            {recommendedContentWithUrls.map((post) => (
                                <PartnerPostCard key={post.id} post={post} postUrl={post.url} cardStyles={partnerPageSettings.cardStyles} />
                            ))}
                            </div>
                        </section>
                      )}

                      {sponsors.length > 0 && (
                        <section id="sponsors">
                          <div className="text-center mb-8">
                            <h2 style={sponsorTitleStyles}>
                                {sponsorSettings.title}
                            </h2>
                             {sponsorSettings.description && (
                              <p 
                                className="mt-2 max-w-2xl mx-auto"
                                style={sponsorDescriptionStyles}
                              >
                                  {sponsorSettings.description}
                              </p>
                            )}
                          </div>
                          <div className="flex flex-wrap items-center justify-center gap-4" style={{ textAlign: sponsorStyleSettings.textAlign as any }}>
                            {sponsors.map(sponsor => (
                                <Link 
                                  href={sponsor.url} 
                                  key={sponsor.id}
                                  target={sponsor.openInNewTab ? "_blank" : "_self"}
                                  rel={sponsor.openInNewTab ? "noopener noreferrer" : ""}
                                  className="inline-block transition-transform hover:scale-105"
                                  style={sponsorLinkStyles}
                                >
                                  {sponsor.name}
                                </Link>
                            ))}
                          </div>
                        </section>
                      )}
                 </div>
                 {showRightSidebar && (
                  <div className="w-full lg:w-80 flex-shrink-0">
                     <div className="sticky top-8">
                        <Sidebar widgets={sidebarSettings.rightWidgets} settings={sidebarSettings} latestPosts={latestPosts} categories={categories} socialLinks={brandingSettings.socialLinks} tags={allTags} />
                     </div>
                  </div>
                )}
            </div>
        </div>
      </div>
    </>
  );
}
