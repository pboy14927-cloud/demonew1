

'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { getComments, Comment } from '@/lib/data';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';

const CommentItem = ({ comment }: { comment: Comment }) => {
    const commentDate = new Date(comment.createdAt).toLocaleString();
    return (
        <div className="flex gap-4">
            <Avatar>
                <AvatarImage src={comment.author.avatar} alt={comment.author.name} />
                <AvatarFallback>{comment.author.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
                <div className="flex items-center justify-between">
                    <p className="font-semibold">{comment.author.name}</p>
                    <p className="text-xs text-muted-foreground">{commentDate}</p>
                </div>
                <p className="text-sm mt-1">{comment.content}</p>
                <Button variant="link" size="sm" className="p-0 h-auto mt-1">Reply</Button>
            </div>
        </div>
    )
}

export default function CommentsSection({ postId }: { postId: string }) {
    const [comments, setComments] = useState<Comment[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const { data: session } = useSession();
    const { toast } = useToast();

    const fetchComments = async () => {
         const allComments = await getComments();
         const postComments = allComments.filter(c => c.postId === postId && c.status === 'approved');
         setComments(postComments);
    }

    useEffect(() => {
        fetchComments();
    }, [postId]);

    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setIsLoading(true);

        const formData = new FormData(e.currentTarget);
        const content = formData.get('comment') as string;
        
        const payload: any = {
            postId,
            content,
        };

        if (session?.user) {
            payload.authorId = (session.user as any).id;
        } else {
             payload.guestName = formData.get('name') as string;
             payload.guestEmail = formData.get('email') as string;
        }

        try {
            const response = await fetch('/api/comments', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || 'Failed to submit comment.');
            }

            toast({
                title: 'Comment Submitted',
                description: 'Your comment is awaiting moderation.'
            });
            (e.target as HTMLFormElement).reset();
            // Optional: fetch comments again to show the new (pending) one if the backend logic is adjusted
            // For now, we just reset the form.

        } catch(error: any) {
            toast({
                variant: 'destructive',
                title: 'Error',
                description: error.message
            })
        } finally {
            setIsLoading(false);
        }
    }

    return (
        <div id="comments" className="space-y-8">
            <h2 className="text-2xl font-bold">Comments ({comments.length})</h2>
            <div className="space-y-6">
                {comments.length > 0 ? (
                    comments.map(comment => <CommentItem key={comment.id} comment={comment} />)
                ) : (
                    <p className="text-muted-foreground">No comments yet. Be the first to leave a comment!</p>
                )}
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Leave a Reply</CardTitle>
                </CardHeader>
                <CardContent>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div className="space-y-2">
                             <Label htmlFor="comment">Comment</Label>
                             <Textarea id="comment" name="comment" required />
                        </div>
                        { !session ? (
                           <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                               <div className="space-y-2">
                                   <Label htmlFor="name">Name</Label>
                                   <Input id="name" name="name" required />
                               </div>
                               <div className="space-y-2">
                                   <Label htmlFor="email">Email</Label>
                                   <Input id="email" name="email" type="email" required />
                               </div>
                           </div>
                        ) : (
                             <p className="text-sm text-muted-foreground">
                                Logged in as <strong>{session.user?.name}</strong>.
                            </p>
                        )}
                        <Button type="submit" disabled={isLoading}>
                            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            Post Comment
                        </Button>
                    </form>
                </CardContent>
            </Card>
        </div>
    )
}
