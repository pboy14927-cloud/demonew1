
'use client';

import { useState, useEffect, useCallback } from 'react';
import { Input } from '@/components/ui/input';
import { Search } from 'lucide-react';
import { getAllContent, Post } from '@/lib/data';
import Link from 'next/link';
import { CSSProperties } from 'react';

type InteractiveSearchProps = {
    style?: CSSProperties
}

export default function InteractiveSearch({ style }: InteractiveSearchProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Post[]>([]);
  const [allContent, setAllContent] = useState<Post[]>([]);

  useEffect(() => {
    getAllContent().then(content => setAllContent(content.filter(item => item.status === 'published')));
  }, []);

  const handleSearch = useCallback((searchQuery: string) => {
    setQuery(searchQuery);
    if (searchQuery.length < 3) {
      setResults([]);
      return;
    }

    const lowerCaseQuery = searchQuery.toLowerCase();
    const filteredResults = allContent.filter(item =>
      item.title.toLowerCase().includes(lowerCaseQuery) ||
      (item.content && item.content.toLowerCase().includes(lowerCaseQuery))
    );
    setResults(filteredResults.slice(0, 5)); // Limit to 5 results
  }, [allContent]);

  return (
    <div className="relative w-full max-w-sm">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
        <Input
          type="search"
          placeholder="Search..."
          className="pl-10 h-9"
          value={query}
          onChange={(e) => handleSearch(e.target.value)}
          style={style}
        />
      </div>
      {query.length >= 3 && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-background border rounded-md shadow-lg z-10">
          {results.length > 0 ? (
            <ul className="py-2">
              {results.map(item => (
                <li key={item.id}>
                  <Link href={`/${item.slug}`} className="block px-4 py-2 text-sm hover:bg-accent" onClick={() => setQuery('')}>
                    {item.title}
                  </Link>
                </li>
              ))}
            </ul>
          ) : (
            <p className="p-4 text-sm text-muted-foreground">No results found.</p>
          )}
        </div>
      )}
    </div>
  );
}
