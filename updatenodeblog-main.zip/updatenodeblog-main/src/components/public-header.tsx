
'use server';

import { getHeaderSettings, getMenus, getBrandingSettings, Menu } from '@/lib/data';
import { getServerSession } from 'next-auth';
import PublicHeaderContent from './public-header-content';
import { authOptions } from '@/lib/auth';

export default async function PublicHeader() {
  const settings = await getHeaderSettings();
  const menus = await getMenus();
  // Find the menu assigned to the 'header' location
  const mainMenu = menus.find((menu: Menu) => menu.locations.includes('header')) || null;
  const branding = await getBrandingSettings();
  const session = await getServerSession(authOptions);

  if (!settings || !branding) {
      return (
        <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
            <div className="container flex h-14 items-center">
                {/* Skeleton Loader */}
            </div>
        </header>
      )
  }

  return (
    <PublicHeaderContent
        settings={settings}
        mainMenu={mainMenu}
        branding={branding}
        session={session}
    />
  )
}
