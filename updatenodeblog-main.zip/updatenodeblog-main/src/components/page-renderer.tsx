
'use server';

import { notFound } from 'next/navigation';
import { 
    getPublishedPosts, 
    getBlogArchiveSettings, 
    getSidebarSettings, 
    getBrandingSettings, 
    getCategories,
    getHomepageLayout,
    getPartnerContent,
    getSponsoredLinks,
    getSponsorSettings,
    getPartnerPageSettings,
    getSponsorStyleSettings,
    getTags,
} from '@/lib/data';
import type { Post, Category } from '@/lib/data';
import HtmlRenderer from '@/components/html-renderer';
import ArchivePageLayout from '@/components/blog/archive-page-layout';
import Sidebar from '@/components/blog/sidebar';
import PartnerPageContent from '@/components/partner-page-content';
import HomepageBuilder from '@/components/homepage-builder';

type PageRendererProps = {
    page: Post;
}

export default async function PageRenderer({ page }: PageRendererProps) {
  if (!page || page.status !== 'published') {
    notFound();
  }

  const template = page.template || 'default';

  if (template === 'blog') {
      const posts = await getPublishedPosts();
      const settings = await getBlogArchiveSettings(); // Correctly fetch blog archive settings
      return (
          <ArchivePageLayout 
              title={page.title || 'Blog'}
              description={page.excerpt || ''}
              posts={posts}
              settings={settings}
          />
      )
  }

  if (template === 'partner') {
    const [
        allPartnerContent,
        sponsors,
        sponsorSettings,
        partnerPageSettings,
        sponsorStyleSettings,
        sidebarSettings,
        allPosts,
        categories,
        brandingSettings
      ] = await Promise.all([
        getPartnerContent(),
        getSponsoredLinks(),
        getSponsorSettings(),
        getPartnerPageSettings(),
        getSponsorStyleSettings(),
        getSidebarSettings(),
        getPublishedPosts(),
        getCategories(),
        getBrandingSettings()
      ]);

    return (
        <PartnerPageContent
            page={page}
            partnerContent={allPartnerContent.filter(p => p.status === 'published')}
            sponsors={sponsors}
            sponsorSettings={sponsorSettings}
            partnerPageSettings={partnerPageSettings}
            sponsorStyleSettings={sponsorStyleSettings}
            sidebarSettings={sidebarSettings}
            latestPosts={allPosts.slice(0, 5)}
            categories={categories}
            brandingSettings={brandingSettings}
      />
    )
  }
  
  if(template === 'with-sidebar') {
    const sidebarSettings = await getSidebarSettings();
    const latestPosts = (await getPublishedPosts()).slice(0, 3);
    const categories = await getCategories();
    const brandingSettings = await getBrandingSettings();
    const allTags = await getTags();
    return (
        <div className="py-12 md:py-24">
            <div className="container px-4 md:px-6 flex gap-8">
                {sidebarSettings.left.desktop && <Sidebar widgets={sidebarSettings.leftWidgets} settings={sidebarSettings} latestPosts={latestPosts} categories={categories} socialLinks={brandingSettings.socialLinks} tags={allTags}/>}
                <article className="prose lg:prose-xl mx-auto flex-1">
                    <div className="space-y-2 not-prose">
                        <h1 className="text-4xl font-extrabold tracking-tight lg:text-5xl font-headline">{page.title}</h1>
                    </div>
                    <div className="mt-8">
                        <HtmlRenderer content={page.content} />
                    </div>
                </article>
                 {sidebarSettings.right.desktop && <Sidebar widgets={sidebarSettings.rightWidgets} settings={sidebarSettings} latestPosts={latestPosts} categories={categories} socialLinks={brandingSettings.socialLinks} tags={allTags}/>}
            </div>
        </div>
    )
  }

  if (template === 'full-width') {
     return (
      <div className="py-12 md:py-24">
        <article className="container-fluid prose lg:prose-xl mx-auto px-4 md:px-6">
          <div className="space-y-2 not-prose text-center mb-12">
            <h1 className="text-4xl font-extrabold tracking-tight lg:text-5xl font-headline">{page.title}</h1>
          </div>
          <div className="mt-8">
            <HtmlRenderer content={page.content} />
          </div>
        </article>
      </div>
    );
  }
  
  if (template === 'full-width-no-title') {
     return (
      <div className="py-12 md:py-24">
        <article className="container-fluid prose lg:prose-xl mx-auto px-4 md:px-6">
          <div className="mt-8">
            <HtmlRenderer content={page.content} />
          </div>
        </article>
      </div>
    );
  }
  
  // Default Template
  return (
      <div className="py-12 md:py-24">
        <article className="container prose lg:prose-xl mx-auto px-4 md:px-6">
          <div className="space-y-2 not-prose">
            <h1 className="text-4xl font-extrabold tracking-tight lg:text-5xl font-headline">{page.title}</h1>
          </div>
          <div className="mt-8">
            <HtmlRenderer content={page.content} />
          </div>
        </article>
      </div>
  );
}
