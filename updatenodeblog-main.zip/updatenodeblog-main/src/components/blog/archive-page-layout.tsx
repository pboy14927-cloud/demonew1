
'use server';

import { getSidebarSettings, getUserById, getPublishedPosts, getCategories, getBrandingSettings, getTags } from '@/lib/data';
import Sidebar from '@/components/blog/sidebar';
import PaginatedPosts from '@/components/blog/paginated-posts';
import type { BlogArchiveSettings, Post, User } from '@/lib/data';
import { Separator } from '../ui/separator';
import Link from 'next/link';
import { cn } from '@/lib/utils';
import { ReactNode } from 'react';

type ArchivePageLayoutProps = {
  title: string | ReactNode;
  description: string;
  posts: Post[];
  settings: BlogArchiveSettings;
};

export default async function ArchivePageLayout({ title, description, posts, settings }: ArchivePageLayoutProps) {
  const sidebarSettings = await getSidebarSettings();
  const showRightSidebar = sidebarSettings.right.desktop;

  // Fetch authors for all posts to be available for client-side pagination
  const authors = await Promise.all(posts.map(post => getUserById(post.authorId)));
  const allPostsWithAuthors = posts.map((post, i) => ({ ...post, author: authors[i] }));
  
  // Paginate the posts that are passed in for the initial view.
  const initialPosts = allPostsWithAuthors.slice(0, settings.postsPerPage);
  const totalPages = Math.ceil(posts.length / settings.postsPerPage);
  
  // Sidebar data
  const allPublishedPosts = await getPublishedPosts();
  const latestPosts = allPublishedPosts.slice(0, 5);
  const categories = await getCategories();
  const brandingSettings = await getBrandingSettings();
  const tags = await getTags();
  
  const isBlogPage = typeof title === 'string' && (title === brandingSettings.websiteTitle || title === 'Blog');
  
  const pageTitle = isBlogPage ? 'Blog' : 
    (typeof title === 'string' ? title.replace(/Category: |Author: |Tag: "/g, '').replace(/"/g, '') : title);


  return (
      <section id="posts" className="w-full py-12 md:py-16">
        <div className="container px-4 md:px-6">
            <div className="text-left mb-8">
                <nav className="text-sm text-muted-foreground mb-4">
                    <Link href="/" className="hover:text-primary">Home</Link>
                    <span className="mx-2">»</span>
                    {typeof title === 'string' ? <span>{pageTitle}</span> : <span>Author</span>}
                </nav>
                 <div className="flex items-center">
                    <div className="w-1 h-8 bg-primary mr-4"></div>
                     {typeof title === 'string' ? (
                        <h1 className="text-xl font-bold uppercase tracking-wider">
                            {isBlogPage ? 'BLOG' : `BROWSING: ${pageTitle}`}
                        </h1>
                     ) : title}
                </div>
            </div>
          <div className="grid lg:grid-cols-[1fr_320px] gap-12 items-start">
            <div className="flex-1">
              <PaginatedPosts 
                initialPosts={initialPosts}
                allPosts={allPostsWithAuthors}
                settings={settings}
                totalPages={totalPages}
                currentPage={1} 
              />
            </div>

            {showRightSidebar && (
              <div className="w-full lg:w-80 xl:w-96 flex-shrink-0">
                <div className="sticky top-8 space-y-8">
                  <Sidebar
                    widgets={sidebarSettings.rightWidgets}
                    settings={sidebarSettings}
                    latestPosts={latestPosts}
                    categories={categories}
                    socialLinks={brandingSettings.socialLinks}
                    tags={tags}
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      </section>
  );
}
