

'use client';

import Link from 'next/link';
import type { Post, PartnerPageCardStyles, CardTypographyStyles } from '@/lib/data';
import { CSSProperties } from 'react';
import { cn } from '@/lib/utils';
import { colord } from 'colord';
import Image from 'next/image';

type PartnerPostCardProps = {
  post: Post;
  cardStyles: PartnerPageCardStyles;
  postUrl: string;
};

// Helper function to strip HTML tags
function stripHtml(html: string){
   if(!html) return '';
   return html.replace(/<[^>]*>?/gm, '');
}

function hexToRgba(hex: string, alpha: number): string {
    return colord(hex).alpha(alpha).toRgbString();
}

export default function PartnerPostCard({ post, cardStyles, postUrl }: PartnerPostCardProps) {
  const postDate = new Date(post.createdAt).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const getTypographyStyles = (styles: CardTypographyStyles | undefined): CSSProperties => {
    if (!styles) return {};
    
    const cssStyles: CSSProperties & { [key: string]: any } = {
        fontFamily: styles.fontFamily,
        fontSize: styles.fontSize ? `${styles.fontSize}px` : undefined,
        fontWeight: styles.fontWeight,
        textAlign: styles.textAlign as any,
        '--hover-color': styles.hoverColor,
    };

    if (styles.color) {
      cssStyles.color = styles.color;
    }

    if (styles.backgroundType === 'gradient' && styles.gradient) {
        cssStyles.background = `linear-gradient(${styles.gradient.direction || 'to right'}, ${styles.gradient.from}, ${styles.gradient.to})`;
    } else if (styles.backgroundType === 'solid' && styles.backgroundColor) {
        cssStyles.backgroundColor = styles.backgroundColor;
    }
    
    if (styles.colorType === 'gradient' && styles.gradient) {
        cssStyles.background = `linear-gradient(${styles.gradient.direction || 'to right'}, ${styles.gradient.from}, ${styles.gradient.to})`;
        cssStyles.WebkitBackgroundClip = 'text';
        cssStyles.backgroundClip = 'text';
        cssStyles.color = 'transparent';
    }

    return cssStyles;
  };
  
  const categoryStyles = getTypographyStyles(cardStyles.categoryStyles);
  const titleStyles = getTypographyStyles(cardStyles.titleStyles);
  const excerptStyles = getTypographyStyles(cardStyles.excerptStyles);
  
  const plainExcerpt = stripHtml(post.excerpt || post.content).substring(0, 150);

  const getOverlayStyle = (): CSSProperties => {
    const opacity = cardStyles.thumbnailOverlayOpacity || 0.5;
    if (cardStyles.thumbnailOverlayType === 'solid') {
      return { backgroundColor: hexToRgba(cardStyles.thumbnailOverlaySolidColor, opacity) };
    }
    if (cardStyles.thumbnailOverlayType === 'gradient') {
      const fromColor = hexToRgba(cardStyles.thumbnailOverlayGradient.from, opacity);
      const toColor = hexToRgba(cardStyles.thumbnailOverlayGradient.to, opacity);
      return { background: `linear-gradient(${cardStyles.thumbnailOverlayGradient.direction}, ${fromColor}, ${toColor})` };
    }
    return {};
  };

  return (
    <div className="flex flex-col group">
      <div className="overflow-hidden rounded-lg mb-4 relative">
        <Link href={postUrl}>
          <Image
            src={post.featuredImage || "https://placehold.co/400x400.png"}
            alt={post.title}
            width={400}
            height={400}
            data-ai-hint="people portrait"
            className="w-full h-auto object-cover aspect-square transition-transform duration-300 ease-in-out group-hover:scale-105"
          />
           {cardStyles.thumbnailOverlayType !== 'none' && (
             <div className="absolute inset-0" style={getOverlayStyle()} />
          )}
        </Link>
      </div>
      <div className="text-sm text-muted-foreground" style={{ textAlign: cardStyles.categoryStyles.textAlign as any }}>
        <span className="font-semibold uppercase px-2 py-1 rounded" style={categoryStyles}>{post.categories[0] || 'General'}</span>
        <span className="mx-2">·</span>
        <span>{postDate}</span>
      </div>
      <h3 className="text-lg font-semibold leading-snug mt-1" style={{ textAlign: cardStyles.titleStyles.textAlign as any }}>
        <Link href={postUrl} className="transition-colors hover:text-[var(--hover-color)]" style={titleStyles}>{post.title}</Link>
      </h3>
      <p className="text-sm mt-2 line-clamp-3" style={{...excerptStyles, textAlign: cardStyles.excerptStyles.textAlign as any}}>
        {plainExcerpt}
      </p>
    </div>
  );
}

    