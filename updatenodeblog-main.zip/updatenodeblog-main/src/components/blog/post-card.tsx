

'use client';

import Link from 'next/link';
import type { Post, User, BlogArchiveSettings, Block, CardTypographyStyles } from '@/lib/data';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { useState, useEffect, CSSProperties } from 'react';
import { generatePostUrl } from '@/lib/data';
import Image from 'next/image';
import { colord } from 'colord';


// Helper function to strip HTML tags
function stripHtml(html: string){
   if(!html) return '';
   return html.replace(/<[^>]*>?/gm, '');
}

export default function PostCard({ post, author, settings, layout = 'grid', index, block, isPriority = false }: { post: Post & {author: User | null}, author: User | null, settings?: BlogArchiveSettings, layout?: 'grid' | 'list' | 'classic' | 'masonry' | 'standard' | 'compact-list' | 'numbered-list' | 'timeline' | 'related-list' | 'related-posts-grid' | 'small-list' | 'grid-featured', index?: number, block?: Block, isPriority?: boolean }) {
  const [postUrl, setPostUrl] = useState('');

  useEffect(() => {
      const getUrl = async () => {
          const url = await generatePostUrl(post);
          setPostUrl(url);
      }
      getUrl();
  }, [post]);
  
  const postDate = new Date(post.createdAt).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  
  const excerptWordCount = block?.settings?.excerptLength || settings?.excerptLength || 20;
  const plainExcerpt = stripHtml(post.excerpt || post.content).split(' ').slice(0, excerptWordCount).join(' ') + '...';

  const showCategory = block?.settings?.showCategory ?? settings?.showCategories ?? true;
  const showAuthor = block?.settings?.showAuthor ?? settings?.showAuthor ?? true;
  const showDate = block?.settings?.showDate ?? settings?.showDate ?? true;
  const showTitle = block?.settings?.showTitle ?? true;
  const showExcerpt = block?.settings?.showExcerpt ?? settings?.showExcerpt ?? true;
  const showFeaturedImage = block?.settings?.showFeaturedImage ?? settings?.showFeaturedImage ?? true;
  const showReadMore = block?.settings?.showReadMore ?? true;

  const cardStyleProps: CSSProperties = {
      backgroundColor: block?.styles?.cardBackgroundColor,
      borderRadius: block?.styles?.cardBorderRadius ? `${block.styles.cardBorderRadius}px` : undefined,
      boxShadow: block?.styles?.cardShadow,
  };
    
const getTypographyStyles = (styles: CardTypographyStyles | undefined): CSSProperties => {
    if (!styles) return {};
    const cssStyles: CSSProperties & { [key: string]: any } = {};

    if (styles.fontFamily) cssStyles.fontFamily = styles.fontFamily;
    if (styles.fontSize) cssStyles.fontSize = `${styles.fontSize}px`;
    if (styles.fontWeight) cssStyles.fontWeight = styles.fontWeight;
    if (styles.textAlign) cssStyles.textAlign = styles.textAlign as any;
    if (styles.hoverColor) cssStyles['--hover-color'] = styles.hoverColor;

    if (styles.colorType === 'gradient' && styles.gradient) {
        cssStyles.background = `linear-gradient(${styles.gradient.direction || 'to right'}, ${styles.gradient.from}, ${styles.gradient.to})`;
        cssStyles.WebkitBackgroundClip = 'text';
        cssStyles.backgroundClip = 'text';
        cssStyles.color = 'transparent';
        cssStyles.WebkitTextFillColor = 'transparent';
    } else if (styles.color) {
        cssStyles.color = styles.color;
    }
    
    return cssStyles;
};

const getElementStyles = (styles: CardTypographyStyles | undefined): CSSProperties => {
     if (!styles) return {};
    const cssStyles: CSSProperties & { [key: string]: any } = getTypographyStyles(styles);
    
    if (styles.backgroundType === 'gradient' && styles.gradient) {
        cssStyles.background = `linear-gradient(${styles.gradient.direction || 'to right'}, ${styles.gradient.from}, ${styles.gradient.to})`;
    } else if (styles.backgroundColor) {
        cssStyles.backgroundColor = styles.backgroundColor;
    }

    if (styles.borderWidth) {
        cssStyles.borderWidth = `${styles.borderWidth}px`;
        cssStyles.borderColor = styles.borderColor || 'transparent';
        cssStyles.borderStyle = 'solid';
    }
    
    if (styles.borderRadius) {
        cssStyles.borderRadius = `${styles.borderRadius}px`;
    }
    
    if (styles.padding) {
        cssStyles.padding = `${styles.padding}px`;
    } else if (styles.padding !== 0) { // Check if padding is not explicitly set to 0
        cssStyles.padding = '0.25rem 0.5rem';
    }

    return cssStyles;
}
  
  const categoryBadgeStyleProps: CSSProperties = getElementStyles(block?.styles?.categoryStyles);
  const categoryTextStyleProps: CSSProperties = getTypographyStyles(block?.styles?.categoryStyles);
  const titleStyleProps: CSSProperties = getTypographyStyles(block?.styles?.titleStyles);
  const excerptStyleProps: CSSProperties = getTypographyStyles(block?.styles?.excerptStyles);
  const authorStyleProps: CSSProperties = getTypographyStyles(block?.styles?.authorStyles);
  const dateStyleProps: CSSProperties = getTypographyStyles(block?.styles?.dateStyles);
  const readMoreStyleProps: CSSProperties = getElementStyles(block?.styles?.readMoreStyles);
    
  const CategoryBadge = () => {
    if (!post.categories[0] || !showCategory) return null;
    const categorySlug = post.categories[0].toLowerCase().replace(/\s+/g, '-');
    
    const badgeContent = (
      <span className="font-semibold uppercase rounded" style={categoryBadgeStyleProps}>
        <span style={categoryTextStyleProps}>{post.categories[0]}</span>
      </span>
    );

    if (layout === 'grid-featured') {
      return badgeContent;
    }

    return <Link href={`/category/${categorySlug}`}>{badgeContent}</Link>;
  }


  const DateDisplay = () => {
    if (!showDate) return null;
    return <span style={dateStyleProps}>{postDate}</span>;
  }
  
  const AuthorLink = () => {
      if (!showAuthor || !author) return null;

      const authorContent = <span style={authorStyleProps}>by {author?.name}</span>;

      if (layout === 'grid-featured') {
          return authorContent;
      }
      return (
        <span style={authorStyleProps}>
            by <Link href={`/author/${author?.id}`} className="hover:text-[var(--hover-color)]">{author?.name}</Link>
        </span>
      )
  }

  const MetaInfo = () => (
     <div className="text-muted-foreground mt-2 text-xs">
        {showAuthor && author && (
          <>
            <AuthorLink />
            {showDate && <span className="mx-1">•</span>}
          </>
        )}
        {showDate && <DateDisplay />}
    </div>
  );

  const TitleLink = ({className}: {className?: string}) => {
    if (!showTitle) return null;
    
    const titleContent = <h2 className={cn("font-bold leading-snug", className, layout === 'grid-featured' && 'text-white')} style={titleStyleProps}>{post.title}</h2>;

    if (layout === 'grid-featured') {
        return titleContent;
    }
    
    return <Link href={postUrl} className="hover:text-[var(--hover-color)]">{titleContent}</Link>
  }
  
  const ReadMoreButton = () => {
    if (!showReadMore) return null;

    const buttonStyle: React.CSSProperties & { '--hover-color'?: string; '--hover-bg-color'?: string } = {
        ...readMoreStyleProps,
        '--hover-color': block?.styles?.readMoreStyles?.hoverColor || readMoreStyleProps.color,
        '--hover-bg-color': block?.styles?.readMoreStyles?.backgroundColor,
    };


    return (
        <div className="mt-4">
            <Button asChild style={buttonStyle}
                onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = buttonStyle['--hover-bg-color'] as string;
                    e.currentTarget.style.color = buttonStyle['--hover-color'] as string;
                }}
                onMouseLeave={(e) => {
                    e.currentTarget.style.background = buttonStyle.background as string;
                    e.currentTarget.style.backgroundColor = buttonStyle.backgroundColor as string;
                    e.currentTarget.style.color = buttonStyle.color as string;
                }}
            >
                <Link href={postUrl}>Read More <ArrowRight className="ml-1 h-4 w-4" /></Link>
            </Button>
        </div>
    )
}

  if (layout === 'grid' || layout === 'masonry') {
      const gridSize = block?.settings?.gridSize || 'large';
      const textSizeClasses = { large: 'text-xl', medium: 'text-lg', small: 'text-base font-semibold' };

      return (
         <div className={cn("group flex flex-col h-full bg-background rounded-lg border overflow-hidden")} style={cardStyleProps}>
            {showFeaturedImage && (
                <div className="overflow-hidden">
                    <Link href={postUrl}>
                        <Image {...(isPriority ? { priority: true } : { loading: 'lazy' })} src={post.featuredImage || "https://placehold.co/600x400.png"} width={600} height={400} sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw" data-ai-hint="fashion lifestyle" alt={post.title} className="w-full h-auto object-cover aspect-[4/3] transition-transform duration-300 ease-in-out group-hover:scale-105" />
                    </Link>
                </div>
            )}
             <div className="p-4 flex-grow flex flex-col">
                 <div className="mb-2"><CategoryBadge /></div>
                 <TitleLink className={textSizeClasses[gridSize as keyof typeof textSizeClasses]}/>
                 <MetaInfo />
                {showExcerpt && <p className="text-sm text-muted-foreground line-clamp-2 mt-2 flex-grow" style={excerptStyleProps}>{plainExcerpt}</p>}
                <ReadMoreButton />
            </div>
        </div>
      )
  }


  if (layout === 'grid-featured') {
    return (
      <div className="relative group overflow-hidden rounded-lg h-full">
        <Link href={postUrl} className="block h-full relative">
          <Image {...(isPriority ? { priority: true } : { loading: 'lazy' })} src={post.featuredImage || "https://placehold.co/800x600.png"} alt={post.title} fill sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw" className="object-cover transition-transform duration-300 group-hover:scale-105" data-ai-hint="featured content" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/40 to-transparent" />
          <div className="absolute bottom-0 left-0 p-6 text-white">
            <CategoryBadge />
            <TitleLink className="text-2xl font-headline" />
            <MetaInfo />
          </div>
        </Link>
      </div>
    );
  }
  
  if (layout === 'related-list') {
    return (
        <div className="flex items-center gap-4 group">
            <Image 
                loading="lazy"
                src={post.featuredImage || "https://placehold.co/150x150.png"}
                alt={post.title}
                width={150}
                height={150}
                data-ai-hint="related content"
                className="w-16 h-16 object-cover rounded-md flex-shrink-0"
            />
            <div className="flex-1">
                 <TitleLink className="text-base font-semibold leading-snug" />
                 {showExcerpt && <p className="text-sm text-muted-foreground line-clamp-2 mt-1" style={excerptStyleProps}>{plainExcerpt}</p>}
            </div>
        </div>
    )
  }
  
  if (layout === 'small-list') {
    return (
        <div className="flex items-center gap-4 group border-t pt-4">
            <div className="flex-1">
                 <TitleLink className="text-base font-semibold leading-snug" />
                 <MetaInfo />
            </div>
        </div>
    )
  }

  if (layout === 'related-posts-grid') {
    return (
      <div className="group">
        <div className="overflow-hidden rounded-lg mb-2">
            <Link href={postUrl}>
                <Image {...(isPriority ? { priority: true } : { loading: 'lazy' })} src={post.featuredImage || "https://placehold.co/400x300.png"} alt={post.title} width={400} height={300} data-ai-hint="blog post" className="w-full h-auto object-cover aspect-[4/3] transition-transform duration-300 ease-in-out group-hover:scale-105" />
            </Link>
        </div>
        <TitleLink className="text-base font-semibold leading-snug" />
        <MetaInfo />
      </div>
    );
  }

  if(layout === 'compact-list') {
    return (
        <div className="flex items-center gap-4">
            <div className="flex-1">
                <TitleLink className="text-sm font-semibold" />
                <MetaInfo />
            </div>
        </div>
    )
  }

  if(layout === 'numbered-list') {
      return (
        <div className="flex items-start gap-4">
            <div className="text-4xl font-bold text-muted-foreground">{String(index).padStart(2, '0')}</div>
            <div className="flex-1">
                <TitleLink className="text-lg" />
                {showExcerpt && <p className="text-sm text-muted-foreground line-clamp-2 mt-1" style={excerptStyleProps}>{plainExcerpt}</p>}
                <MetaInfo />
            </div>
        </div>
      )
  }

  if (layout === 'timeline') {
    const timelineDate = new Date(post.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    return (
        <div className="grid grid-cols-[auto_1fr] items-start gap-4 relative pl-10 md:pl-0">
             <div className="flex flex-col items-center self-stretch absolute md:relative h-full md:h-auto left-0 -translate-x-1/2 md:translate-x-0">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-primary-foreground z-10">
                    <span className="text-xs font-bold">{timelineDate.split(' ')[0]}</span>
                </div>
                <div className="w-px flex-grow bg-border"></div>
            </div>
            <div className="pt-1.5">
                <MetaInfo />
                <TitleLink className="text-lg" />
                {showExcerpt && <p className="text-sm text-muted-foreground line-clamp-2 mt-1" style={excerptStyleProps}>{plainExcerpt}</p>}
            </div>
        </div>
    )
  }
  
  if (layout === 'classic' || layout === 'list') {
       return (
        <Card className={cn("flex flex-col group", layout === 'list' && 'md:flex-row')} style={cardStyleProps}>
          {showFeaturedImage && (
            <div className={cn(
                "overflow-hidden",
                layout === 'classic' && "p-0",
                layout === 'list' && "md:w-1/3",
            )}>
                <Link href={postUrl}>
                    <Image
                    {...(isPriority ? { priority: true } : { loading: 'lazy' })}
                    src={post.featuredImage || "https://placehold.co/800x400.png"}
                    width={800}
                    height={400}
                    alt={post.title}
                    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                    data-ai-hint="programming blog"
                    className={cn(
                        "w-full h-full object-cover group-hover:scale-105 transition-transform duration-300",
                        layout === 'list' ? 'rounded-l-lg' : 'rounded-t-lg',
                        layout === 'classic' ? 'aspect-video' : 'aspect-square'
                    )}
                    />
                </Link>
            </div>
          )}
          <div className="flex flex-col flex-grow p-6">
            <CardHeader className="p-0">
                <CategoryBadge />
                <TitleLink className="font-headline text-2xl mt-2" />
            </CardHeader>
            <CardContent className="flex-grow p-0 pt-2">
                <MetaInfo />
                {showExcerpt && <p className="text-muted-foreground line-clamp-3 mt-2" style={excerptStyleProps}>{plainExcerpt}</p>}
            </CardContent>
            {showReadMore && (
                <CardFooter className="flex justify-end p-0 pt-4">
                    <ReadMoreButton />
                </CardFooter>
            )}
          </div>
        </Card>
      );
  }

  return (
    <div>PostCard: Invalid layout prop.</div>
  )
}
