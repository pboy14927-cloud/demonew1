

'use client';

import Link from 'next/link';
import { Separator } from '@/components/ui/separator';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Facebook, Twitter, Instagram, Linkedin, Rss, Send, Youtube } from 'lucide-react';
import type { Post, Category, Tag, BrandingSettings, SidebarSettings } from '@/lib/data';
import InteractiveSearch from '../interactive-search';
import { useState, useEffect } from 'react';
import { generatePostUrl, getComments } from '@/lib/data';
import Image from 'next/image';
import { cn } from '@/lib/utils';
import { getSocialButtonStyle } from '@/lib/utils';


const SearchWidget = () => (
  <InteractiveSearch />
);

const LatestNewsWidget = ({ posts }: { posts: Post[] }) => {
    return (
      <ul className="space-y-4">
        {posts.map(post => (
          <li key={post.id} className="flex items-center gap-4">
            <Image
              src={post.featuredImage || 'https://placehold.co/100x100.png'}
              alt={post.title}
              width={100}
              height={100}
              data-ai-hint="news story"
              className="w-16 h-16 object-cover rounded-md"
              loading="lazy"
            />
            <div>
              <PostLink post={post} />
              <p className="text-xs text-muted-foreground mt-1">
                {new Date(post.createdAt).toLocaleDateString()}
              </p>
            </div>
          </li>
        ))}
      </ul>
    );
};

const PostLink = ({ post }: { post: Post }) => {
    const [url, setUrl] = useState('');
    useEffect(() => {
        generatePostUrl(post).then(setUrl);
    }, [post]);

    return (
        <Link href={url} className="text-sm font-semibold hover:text-primary leading-tight line-clamp-2">
            {post.title}
        </Link>
    )
}

export const SocialIcon = ({ platform }: { platform: string }) => {
    switch (platform.toLowerCase()) {
        case 'facebook': return <Facebook className="w-4 w-4" />;
        case 'twitter': return <Twitter className="w-4 w-4" />;
        case 'instagram': return <Instagram className="w-4 w-4" />;
        case 'linkedin': return <Linkedin className="w-4 w-4" />;
        case 'youtube': return <Youtube className="w-4 w-4" />;
        case 'custom': return <Send className="w-4 w-4" />;
        default: return <Rss className="w-4 w-4" />;
    }
};

const officialColors: Record<string, string> = {
    facebook: 'bg-[#3b5998] hover:bg-[#3b5998]/90 text-white',
    twitter: 'bg-[#1da1f2] hover:bg-[#1da1f2]/90 text-white',
    instagram: 'bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 text-white',
    linkedin: 'bg-[#0077b5] hover:bg-[#0077b5]/90 text-white',
    youtube: 'bg-[#FF0000] hover:bg-[#FF0000]/90 text-white',
    custom: 'bg-gray-500 hover:bg-gray-600 text-white',
};

const shapeClasses = {
    default: 'rounded-md',
    rounded: 'rounded-lg',
    circle: 'rounded-full'
};

const StayConnectedWidget = ({ socialLinks, settings }: { socialLinks: any[], settings: SidebarSettings }) => {
    const buttonStyle = settings.socialIconStyle.style === 'custom' ? getSocialButtonStyle(settings.socialIconStyle) : {};
    
    return (
        <div className="flex flex-wrap gap-2">
            {socialLinks.map(link => (
            <Button
                key={link.id}
                asChild
                variant="outline"
                size="icon"
                className={cn(
                    shapeClasses[settings.socialIconStyle.shape],
                    settings.socialIconStyle.style === 'official' && (officialColors[link.platform] || officialColors.custom), 
                    'social-icon'
                )}
                style={buttonStyle}
            >
                <a href={link.url} target="_blank" rel="noopener noreferrer">
                <SocialIcon platform={link.platform} />
                </a>
            </Button>
            ))}
        </div>
    );
};


const SubscribeWidget = ({ settings }: { settings: SidebarSettings }) => (
  <div className="p-6 text-center bg-muted rounded-lg">
    <h4 className="font-bold text-lg">{settings.widgetTitles['Newsletter']}</h4>
    <p className="text-sm text-muted-foreground mt-1 mb-4">
      {settings.newsletterDescription}
    </p>
    <Input placeholder="Your email address" className="mb-2 bg-background" />
    <Button className="w-full">Subscribe</Button>
  </div>
);

const AdWidget = () => (
  <div className="bg-muted rounded-lg p-4 text-center">
    <p className="text-xs text-muted-foreground mb-2">Advertisement</p>
    <Image src="https://placehold.co/300x250.png" alt="advertisement" width={300} height={250} data-ai-hint="advertisement" className="mx-auto" />
  </div>
);

const CategoriesWidget = ({ categories }: { categories: Category[] }) => (
  <ul className="space-y-2">
    {categories.map(category => (
      <li key={category.id}>
        <Link href={`/category/${category.slug}`} className="text-sm hover:text-primary">
          {category.name}
        </Link>
      </li>
    ))}
  </ul>
);

const TagCloudWidget = ({ tags }: { tags: Tag[] }) => {
    return (
        <div className="flex flex-wrap gap-2">
            {tags.map(tag => (
                <Button key={tag.id} asChild size="sm" variant="outline" className="text-xs">
                    <Link href={`/tag/${tag.slug}`}>{tag.name}</Link>
                </Button>
            ))}
        </div>
    )
}

const MostCommentedWidget = ({ posts }: { posts: Post[] }) => {
    const [commentCounts, setCommentCounts] = useState<Record<string, number>>({});
    useEffect(() => {
        getComments().then(comments => {
            const counts: Record<string, number> = {};
            comments.forEach(comment => {
                counts[comment.postId] = (counts[comment.postId] || 0) + 1;
            });
            setCommentCounts(counts);
        })
    }, []);

    const sortedPosts = [...posts].sort((a, b) => (commentCounts[b.id] || 0) - (commentCounts[a.id] || 0));

    return (
        <ul className="space-y-4">
            {sortedPosts.map(post => (
                <li key={post.id} className="flex items-center gap-4">
                    <Image
                        src={post.featuredImage || 'https://placehold.co/100x100.png'}
                        alt={post.title}
                        width={100}
                        height={100}
                        data-ai-hint="news story"
                        className="w-16 h-16 object-cover rounded-md"
                        loading="lazy"
                    />
                    <div>
                        <PostLink post={post} />
                        <p className="text-xs text-muted-foreground mt-1">
                            {commentCounts[post.id] || 0} Comments
                        </p>
                    </div>
                </li>
            ))}
        </ul>
    );
}

const WidgetPreview = ({ widgetType, settings, latestPosts, categories, socialLinks, tags, mostCommentedPosts }: any) => {
  switch (widgetType.toLowerCase()) {
    case 'search':
      return <SearchWidget />;
    case 'recent posts':
      return <LatestNewsWidget posts={latestPosts} />;
    case 'categories':
      return <CategoriesWidget categories={categories} />;
    case 'follow us':
      return <StayConnectedWidget socialLinks={socialLinks} settings={settings} />;
    case 'subscribe':
      return <SubscribeWidget settings={settings} />;
    case 'advertisement':
      return <AdWidget />;
    case 'tag cloud':
      return <TagCloudWidget tags={tags} />;
    case 'most commented':
      return <MostCommentedWidget posts={mostCommentedPosts} />;
    default:
      return <p className="text-sm text-muted-foreground">Widget: {widgetType}</p>;
  }
};

export default function Sidebar({
  widgets,
  settings,
  latestPosts,
  categories,
  socialLinks,
  tags
}: {
  widgets: string[];
  settings: SidebarSettings;
  latestPosts: Post[];
  categories: Category[];
  socialLinks: any[];
  tags?: Tag[];
}) {
  
  if (!widgets || widgets.length === 0) return null;

  const getWidgetTitle = (widgetKey: string) => {
      return settings.widgetTitles[widgetKey] || widgetKey;
  }
  
  const isVisualWidget = (widget: string) => {
      const visualTypes = ['subscribe', 'advertisement'];
      return visualTypes.includes(widget.toLowerCase());
  }

  return (
    <aside className="space-y-8">
      {widgets.map((widget, index) => (
        <div key={`${widget}-${index}`}>
          {!isVisualWidget(widget) && (
            <>
              <h4 className="font-bold text-lg mb-4">{getWidgetTitle(widget)}</h4>
              <Separator className="mb-4" />
            </>
          )}
          <WidgetPreview
            widgetType={widget}
            settings={settings}
            latestPosts={latestPosts.slice(settings?.skipPosts || 0, (settings?.skipPosts || 0) + (settings?.numRecentPosts || 5))}
            mostCommentedPosts={latestPosts.slice(settings?.skipPosts || 0, (settings?.skipPosts || 0) + (settings?.numMostCommented || 5))}
            categories={categories.slice(0, settings?.numCategories || 7)}
            tags={tags ? tags.slice(0, settings?.numTags || 15) : []}
            socialLinks={socialLinks}
          />
        </div>
      ))}
    </aside>
  );
}
