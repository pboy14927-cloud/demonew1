

'use client';

import { useState, useEffect, useRef, useCallback, Suspense, lazy } from 'react';
import { Button } from '../ui/button';
import { cn } from '@/lib/utils';
import { Loader2 } from 'lucide-react';
import type { Post, User, BlogArchiveSettings } from '@/lib/data';
import { Skeleton } from '../ui/skeleton';

const PostCard = lazy(() => import('./post-card'));

type PostWithAuthor = Post & { author: User | null };

type PaginatedPostsProps = {
  initialPosts: PostWithAuthor[];
  allPosts: PostWithAuthor[];
  settings: BlogArchiveSettings;
  totalPages?: number;
  currentPage?: number;
};

const PostCardSkeleton = ({ layout }: { layout: string }) => {
  if (layout === 'list' || layout === 'classic') {
    return (
      <div className="flex gap-4">
        <Skeleton className="w-1/3 h-48" />
        <div className="w-2/3 space-y-3">
          <Skeleton className="h-8 w-3/4" />
          <Skeleton className="h-4 w-1/2" />
          <Skeleton className="h-16 w-full" />
        </div>
      </div>
    );
  }
  return (
    <div className="space-y-3">
      <Skeleton className="h-48 w-full" />
      <Skeleton className="h-8 w-3/4" />
      <Skeleton className="h-4 w-1/2" />
    </div>
  );
};


export default function PaginatedPosts({ initialPosts, allPosts, settings, totalPages = 1, currentPage = 1 }: PaginatedPostsProps) {
  const [posts, setPosts] = useState<PostWithAuthor[]>(initialPosts);
  const [page, setPage] = useState(currentPage);
  const [isLoading, setIsLoading] = useState(false);
  const [hasMore, setHasMore] = useState(initialPosts.length < allPosts.length);
  
  const observer = useRef<IntersectionObserver>();
  
  const lastPostElementRef = useCallback((node: any) => {
      if (isLoading) return;
      if (observer.current) observer.current.disconnect();
      
      observer.current = new IntersectionObserver(entries => {
          if (entries[0].isIntersecting && hasMore && settings.paginationStyle === 'infinite-scroll') {
              loadMorePosts();
          }
      });
      
      if (node) observer.current.observe(node);

  }, [isLoading, hasMore, settings.paginationStyle]);

  const handleNumberedPageChange = (newPage: number) => {
    if (newPage < 1 || newPage > totalPages) return;
    setIsLoading(true);
    const start = (newPage - 1) * settings.postsPerPage;
    const end = start + settings.postsPerPage;
    setPosts(allPosts.slice(start, end));
    setPage(newPage);
    setIsLoading(false);
    
    const postsSection = document.getElementById('posts');
    if(postsSection) {
        postsSection.scrollIntoView({ behavior: 'smooth' });
    }
  };


  const loadMorePosts = async () => {
    if (!hasMore || isLoading) return;

    setIsLoading(true);
    const nextPage = page + 1;
    const start = page * settings.postsPerPage;
    const end = start + settings.postsPerPage;
    const newPosts = allPosts.slice(start, end);
    
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 500));
      
    setPosts(prev => [...prev, ...newPosts]);
    setPage(nextPage);
    setHasMore(end < allPosts.length);

    setIsLoading(false);
  };

  if (posts.length === 0) {
    return <p className="text-center text-muted-foreground col-span-full">No posts found.</p>;
  }
  
  const getPageNumbers = () => {
    const pageNumbers = [];
    const maxPagesToShow = 5;
    const ellipsis = '...';

    if (totalPages <= maxPagesToShow + 2) {
      for (let i = 1; i <= totalPages; i++) {
        pageNumbers.push(i);
      }
    } else {
      pageNumbers.push(1);
      if (page > maxPagesToShow - 1) {
        pageNumbers.push(ellipsis);
      }
      
      let start = Math.max(2, page - 1);
      let end = Math.min(totalPages - 1, page + 1);

      if(page <= 3) {
          start = 2;
          end = 4;
      }

       if(page >= totalPages - 2) {
          start = totalPages - 3;
          end = totalPages - 1;
      }
      
      for (let i = start; i <= end; i++) {
        pageNumbers.push(i);
      }
      
      if (page < totalPages - 2) {
        pageNumbers.push(ellipsis);
      }

      pageNumbers.push(totalPages);
    }
    return pageNumbers;
  };

  const renderPagination = () => {
    if (settings.paginationStyle === 'numbered' && totalPages > 1) {
      return (
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" disabled={page === 1 || isLoading} onClick={() => handleNumberedPageChange(page - 1)}>Prev</Button>
          {getPageNumbers().map((p, index) =>
             typeof p === 'number' ? (
                 <Button key={index} variant={p === page ? 'secondary' : 'outline'} size="sm" onClick={() => handleNumberedPageChange(p)} disabled={isLoading}>
                    {p}
                 </Button>
             ) : (
                <span key={`ellipsis-${index}`} className="px-3 py-1 text-sm">...</span>
             )
          )}
          <Button variant="outline" size="sm" disabled={page === totalPages || isLoading} onClick={() => handleNumberedPageChange(page + 1)}>Next</Button>
        </div>
      );
    }

    if (settings.paginationStyle === 'load-more' && hasMore) {
      return (
        <Button onClick={loadMorePosts} disabled={isLoading}>
          {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Load More
        </Button>
      );
    }

    if (settings.paginationStyle === 'infinite-scroll' && isLoading) {
        return <Loader2 className="h-8 w-8 animate-spin text-primary" />;
    }
    
    if (!hasMore && page > 1) {
        return <p className="text-muted-foreground">You've reached the end.</p>;
    }

    return null;
  };
  
   const numColumns = parseInt(settings.columns || '2', 10);
    const gridColsClassMap: { [key: number]: string } = {
        1: 'sm:grid-cols-1',
        2: 'sm:grid-cols-2',
        3: 'sm:grid-cols-3',
        4: 'sm:grid-cols-4',
    };
    const gridColsClass = gridColsClassMap[numColumns] || 'sm:grid-cols-2';

  return (
    <>
      <div
        className={cn(
          'grid gap-8',
          (settings.layout === 'grid' || settings.layout === 'masonry') && gridColsClass,
          settings.layout === 'list' && 'grid-cols-1',
          settings.layout === 'classic' && 'grid-cols-1',
        )}
      >
        {posts.map((post, index) => (
            <Suspense key={post.id} fallback={<PostCardSkeleton layout={settings.layout} />}>
                <div ref={posts.length === index + 1 ? lastPostElementRef : null}>
                   <PostCard post={post} author={post.author} layout={settings.layout} settings={settings} />
                </div>
            </Suspense>
        ))}
      </div>

      <div className={cn("flex justify-center mt-12", (settings.layout === 'grid' || settings.layout === 'masonry') && 'col-span-full')}>
        {renderPagination()}
      </div>
    </>
  );
}
