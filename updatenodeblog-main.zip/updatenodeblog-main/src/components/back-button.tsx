
'use client';

import Link from 'next/link';

export default function BackButton() {
  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    window.history.back();
  };

  return (
    <Link href="#" className="text-primary hover:underline" onClick={handleClick}>
      Go to Previous Page
    </Link>
  );
}
