
'use client';

import { SessionProvider } from 'next-auth/react';
import { Toaster } from '@/components/ui/toaster';
import TopLoader from '@/components/ui/top-loader';
import { ThemeProvider } from './theme-provider';

export default function Providers({ children }: { children: React.ReactNode }) {
  return (
    <SessionProvider>
      <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
        <TopLoader />
        {children}
        <Toaster />
      </ThemeProvider>
    </SessionProvider>
  );
}
