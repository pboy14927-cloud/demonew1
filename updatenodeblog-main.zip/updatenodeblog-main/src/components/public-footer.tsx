
'use server';

import Link from 'next/link';
import { getFooterSettings, getMenus, FooterSettings, Menu, FooterSlotSettings, FooterStyling, getBrandingSettings, getPublishedPosts, getCategories, getTags, generatePostUrl, Post, SocialIconStyleSettings } from '@/lib/data';
import { CSSProperties } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Facebook, Twitter, Instagram } from 'lucide-react';
import { SocialIcon } from './blog/sidebar';
import Image from 'next/image';
import FooterLink from './footer-link';
import { cn } from '@/lib/utils';

const getSocialButtonStyle = (settings: SocialIconStyleSettings | undefined): React.CSSProperties => {
    if (!settings) return {};
    const style: React.CSSProperties & { [key: string]: string } = {
        '--hover-bg': settings.hoverBackgroundColor || 'transparent',
        '--hover-text': settings.hoverIconColor || settings.iconColor,
        color: settings.iconColor,
        backgroundColor: settings.backgroundColor,
    };
    return style;
};

const officialColors: Record<string, string> = {
    facebook: 'bg-[#3b5998] hover:bg-[#3b5998]/90 text-white',
    twitter: 'bg-[#1da1f2] hover:bg-[#1da1f2]/90 text-white',
    instagram: 'bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 text-white',
    linkedin: 'bg-[#0077b5] hover:bg-[#0077b5]/90 text-white',
    youtube: 'bg-[#FF0000] hover:bg-[#FF0000]/90 text-white',
    custom: 'bg-gray-500 hover:bg-gray-600 text-white',
};


async function renderSlot(slot: FooterSlotSettings, settings: FooterSettings, menus: Menu[], brandingSettings: any, posts: any[], categories: any[], tags: any[], socialIconSettings: SocialIconStyleSettings) {
    if (!settings || !menus) return null;
    
    switch(slot.elementType) {
        case 'site-logo':
            return brandingSettings.logoUrl ? <Link href="/"><Image src={brandingSettings.logoUrl} alt="logo" width={brandingSettings.logoWidth || 150} height={40} className="h-10 w-auto" /></Link> : null;
        case 'text-widget':
            return (
                <div className="space-y-2">
                    <h4 className="font-semibold">{slot.widgetTitle}</h4>
                    <p className="text-sm opacity-80">{settings.aboutText}</p>
                </div>
            )
        case 'logo-with-about':
             return (
                <div className="space-y-2">
                    {brandingSettings.logoUrl && <Link href="/"><Image src={brandingSettings.logoUrl} alt="logo" width={brandingSettings.logoWidth || 150} height={40} className="h-10 w-auto" /></Link>}
                    <p className="text-sm opacity-80">{settings.aboutText}</p>
                </div>
            )
        case 'social-icons':
             if (!socialIconSettings) return null;
             return (
                <div className="space-y-2">
                    <h4 className="font-semibold">{slot.widgetTitle}</h4>
                    <div className="flex space-x-2">
                        {brandingSettings.socialLinks.map((link: any) => (
                            <Button
                                key={link.id} 
                                asChild 
                                variant="outline" 
                                size="icon"
                                className={cn(socialIconSettings.style === 'official' && (officialColors[link.platform] || officialColors.custom), 'social-icon')}
                                style={socialIconSettings.style === 'custom' ? getSocialButtonStyle(socialIconSettings) : {}}
                            >
                                <a href={link.url} target="_blank"><SocialIcon platform={link.platform} /></a>
                            </Button>
                        ))}
                    </div>
                </div>
            )
         case 'copyright':
            return (
                <p className="text-sm opacity-80">
                    {settings.copyrightText.replace('[year]', new Date().getFullYear().toString())}
                </p>
            )
         case 'footer-navigation':
             const footerMenu = menus.find(m => m.id === settings.footerNavMenu || m.locations.includes('footer'));
            return (
                <nav className="flex flex-nowrap items-center gap-x-6">
                    {footerMenu?.items.map(item => (
                         <FooterLink key={item.id} href={item.url}>{item.label}</FooterLink>
                    ))}
                </nav>
            )
         case 'recent-posts':
            return (
                <div className="space-y-2">
                    <h4 className="font-semibold">{slot.widgetTitle}</h4>
                    <ul className="text-sm space-y-1">
                        {await Promise.all(posts.slice(0, settings.numPosts).map(async (post: any) => {
                            const url = await generatePostUrl(post);
                            return (
                                <li key={post.id}><FooterLink href={url}>{post.title}</FooterLink></li>
                            )
                        }))}
                    </ul>
                </div>
            )
        case 'popular-posts':
             return (
                <div className="space-y-2">
                    <h4 className="font-semibold">{slot.widgetTitle}</h4>
                    <ul className="text-sm space-y-1">
                        {await Promise.all(posts.slice(0, settings.numPosts).map(async (post: any) => {
                             const url = await generatePostUrl(post);
                             return (
                                <li key={post.id}><FooterLink href={url}>{post.title}</FooterLink></li>
                             )
                        }))}
                    </ul>
                </div>
            )
         case 'categories':
             return (
                <div className="space-y-2">
                    <h4 className="font-semibold">{slot.widgetTitle}</h4>
                    <ul className="text-sm space-y-1">
                       {categories.slice(0, settings.numCategories).map((cat: any) => (
                            <li key={cat.id}><FooterLink href={`/category/${cat.slug}`}>{cat.name}</FooterLink></li>
                        ))}
                    </ul>
                </div>
             )
         case 'tag-cloud':
            return (
                <div className="space-y-2">
                    <h4 className="font-semibold">{slot.widgetTitle}</h4>
                    <div className="flex flex-wrap gap-2">
                       {tags.slice(0, settings.numTags).map((tag: any) => (
                           <Button asChild key={tag.id} size="sm" variant="outline" className="text-xs" style={{color: 'var(--link-color)'}}><Link href={`/tag/${tag.slug}`}>{tag.name}</Link></Button>
                       ))}
                    </div>
                </div>
            )
         case 'newsletter-form':
            return (
                <div className="space-y-2">
                    <h4 className="font-semibold">{slot.widgetTitle}</h4>
                    <div className="flex gap-2">
                        <Input placeholder="Email address" className="bg-background/50 text-foreground" />
                        <Button variant="secondary" className="text-foreground">Subscribe</Button>
                    </div>
                </div>
            )
        case 'custom-html':
             return (
                <div className="space-y-2">
                    <h4 className="font-semibold">{slot.widgetTitle}</h4>
                    <div dangerouslySetInnerHTML={{ __html: settings.customHtml }} />
                </div>
            )
        case 'footer-ad':
            return (
                <div className="space-y-2">
                    <h4 className="font-semibold">{slot.widgetTitle}</h4>
                    <div className="p-4 bg-muted/50 rounded-md text-center">
                        <Image src="https://placehold.co/300x250.png" width={300} height={250} data-ai-hint="advertisement" alt="advertisement" />
                    </div>
                </div>
            )
        default:
            return null;
    }
}

const getBarStyles = (styling: FooterStyling): CSSProperties => {
    const styles: CSSProperties & { [key: string]: string } = {
        '--text-color': styling.textColor,
        '--link-color': styling.linkColor,
        '--link-hover-color': styling.linkHoverColor,
        fontFamily: styling.fontFamily,
        fontSize: `${styling.fontSize}px`,
        fontWeight: styling.fontWeight,
        color: styling.textColor
    };

    if (styling.backgroundType === 'gradient') {
        styles.background = `linear-gradient(to right, ${styling.gradientStart}, ${styling.gradientEnd})`;
    } else {
        styles.backgroundColor = styling.backgroundColor;
    }
    return styles;
};

export default async function PublicFooter() {
    const settings = await getFooterSettings();
    const menus = await getMenus();
    const brandingSettings = await getBrandingSettings();
    const posts = await getPublishedPosts();
    const categories = await getCategories();
    const tags = await getTags();

    if (!settings || !menus) {
        return (
            <footer className="w-full border-t">
                 {/* Skeleton Loader */}
            </footer>
        )
    }

    const { topFooter, mainFooter, bottomFooter } = settings;

  return (
    <footer className="border-t">
        {topFooter.enabled && topFooter.styling && (
            <div className="py-8" style={getBarStyles(topFooter.styling)}>
                <div className={`container px-4 md:px-6 grid gap-8 grid-cols-1 sm:grid-cols-2 md:grid-cols-${topFooter.layout.split('-')[0]}`}>
                    {await Promise.all(Object.values(topFooter.slots).map((slot, i) => (
                        <div key={i}>{renderSlot(slot, settings, menus, brandingSettings, posts, categories, tags, topFooter.styling.socialIconStyles)}</div>
                    )))}
                </div>
            </div>
        )}
        {mainFooter.enabled && mainFooter.styling && (
            <div className="py-8 border-t" style={getBarStyles(mainFooter.styling)}>
                <div className={`container px-4 md:px-6 grid gap-8 grid-cols-1 sm:grid-cols-2 md:grid-cols-${mainFooter.layout.split('-')[0]}`}>
                    {await Promise.all(Object.values(mainFooter.slots).map((slot, i) => (
                        <div key={i}>{renderSlot(slot, settings, menus, brandingSettings, posts, categories, tags, mainFooter.styling.socialIconStyles)}</div>
                    )))}
                </div>
            </div>
        )}
        {bottomFooter.enabled && bottomFooter.styling && (
            <div className="py-4 border-t" style={getBarStyles(bottomFooter.styling)}>
                <div className="container px-4 md:px-6 flex justify-between items-center">
                    {await renderSlot(bottomFooter.slots.left, settings, menus, brandingSettings, posts, categories, tags, bottomFooter.styling.socialIconStyles)}
                    {await renderSlot(bottomFooter.slots.right, settings, menus, brandingSettings, posts, categories, tags, bottomFooter.styling.socialIconStyles)}
                </div>
            </div>
        )}
    </footer>
  );
}
