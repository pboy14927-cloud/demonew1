
import { Node, mergeAttributes } from '@tiptap/core';
import { ReactNodeViewRenderer } from '@tiptap/react';
import ResizableImageComponent from './resizable-image-component';

export interface ResizableImageOptions {
  inline: boolean;
  HTMLAttributes: Record<string, any>;
}

declare module '@tiptap/core' {
  interface Commands<ReturnType> {
    resizableImage: {
      setImageAttributes: (attributes: { align?: 'left' | 'center' | 'right' }) => ReturnType;
    };
  }
}

export default Node.create<ResizableImageOptions>({
  name: 'resizable-image',
  group: 'block',
  atom: true,
  draggable: true,

  addAttributes() {
    return {
      src: {
        default: null,
      },
      alt: {
        default: null,
      },
      title: {
        default: null,
      },
      width: {
        default: '100%',
        renderHTML: attributes => {
            return {
                width: attributes.width,
            }
        }
      },
      height: {
        default: 'auto',
         renderHTML: attributes => {
            return {
                height: attributes.height,
            }
        }
      },
      align: {
          default: 'center',
          renderHTML: attributes => {
              return {
                  'data-align': attributes.align,
              }
          }
      }
    };
  },

  parseHTML() {
    return [
      {
        tag: 'img[src]',
        getAttrs: (dom) => {
          if (typeof dom === 'string') return {};
          const element = dom as HTMLImageElement;
          const align = element.getAttribute('data-align') || element.style.textAlign || 'center';
          return {
            src: element.getAttribute('src'),
            alt: element.getAttribute('alt'),
            title: element.getAttribute('title'),
            width: element.getAttribute('width'),
            height: element.getAttribute('height'),
            align: align,
          };
        },
      },
    ];
  },

  renderHTML({ HTMLAttributes }) {
    return ['img', mergeAttributes(this.options.HTMLAttributes, HTMLAttributes)];
  },
  
  addCommands() {
    return {
       setImageAttributes: (attributes) => ({ commands }) => {
        return commands.updateAttributes('resizable-image', attributes)
      },
    }
  },

  addNodeView() {
    return ReactNodeViewRenderer(ResizableImageComponent);
  },
});
