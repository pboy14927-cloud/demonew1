
'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Pin, UploadCloud } from 'lucide-react';
import MediaLibraryModal from '../admin/media-library-modal';
import Image from 'next/image';
import { Button } from '../ui/button';
import { Media } from '@/lib/data';

type FeaturedImageMetaboxProps = {
    image: string | null;
    onImageChange: (imageUrl: string | null) => void;
}

export default function FeaturedImageMetabox({ image, onImageChange }: FeaturedImageMetaboxProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const handleImageSelect = (media: Media) => {
    onImageChange(`/api/media/${media.id}/file`);
    setIsDialogOpen(false);
  }

  return (
    <>
    <Card>
      <CardHeader>
        <CardTitle className="text-base font-semibold flex items-center gap-2">
            <Pin className="h-4 w-4" /> Featured image
        </CardTitle>
      </CardHeader>
      <CardContent>
        {image ? (
            <div className="space-y-2">
                <Image src={image} width={400} height={250} data-ai-hint="featured image" alt="Featured" className="w-full h-auto object-cover rounded-md border" />
                <div className="flex justify-between items-center">
                    <button onClick={() => onImageChange(null)} className="text-sm text-destructive hover:underline">
                        Remove featured image
                    </button>
                     <button onClick={() => setIsDialogOpen(true)} className="text-sm text-primary hover:underline">
                        Replace image
                    </button>
                </div>
            </div>
        ) : (
             <Button variant="outline" className="w-full h-auto p-4 flex-col gap-2 border-dashed" onClick={() => setIsDialogOpen(true)}>
                <UploadCloud className="h-8 w-8 text-muted-foreground" />
                <span>Set featured image</span>
            </Button>
        )}
      </CardContent>
    </Card>
    <MediaLibraryModal 
        isOpen={isDialogOpen}
        onOpenChange={setIsDialogOpen}
        onSelect={handleImageSelect}
    />
    </>
  );
}
