

'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { X, Pin } from 'lucide-react';
import { getTags, Tag, createTag } from '@/lib/data';
import { useToast } from '@/hooks/use-toast';

type TagsMetaboxProps = {
    tags: string[];
    onTagsChange: (tags: string[]) => void;
}

export default function TagsMetabox({ tags, onTagsChange }: TagsMetaboxProps) {
  const [newTagInput, setNewTagInput] = useState('');
  const [availableTags, setAvailableTags] = useState<Tag[]>([]);
  const { toast } = useToast();

  const fetchTags = async () => {
    setAvailableTags(await getTags());
  }

  useEffect(() => {
    fetchTags();
  }, []);

  const handleAddTags = async () => {
    if (!newTagInput) return;
    
    const newTags = newTagInput.split(',').map(t => t.trim()).filter(Boolean);
    const uniqueNewTags = newTags.filter(t => !tags.includes(t));

    if (uniqueNewTags.length > 0) {
      onTagsChange([...tags, ...uniqueNewTags]);

      for (const tagName of uniqueNewTags) {
        if (!availableTags.some(t => t.name.toLowerCase() === tagName.toLowerCase())) {
          try {
             const response = await fetch('/api/tags', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name: tagName }),
            });
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || 'Failed to create tag on server.');
            }
          } catch (e: any) {
            console.error(`Failed to create tag: ${tagName}`, e);
            toast({ variant: "destructive", title: "Error creating tag", description: e.message });
          }
        }
      }
      
      await fetchTags();
    }
    
    setNewTagInput('');
  };

  const handleRemoveTag = (tagToRemove: string) => {
    onTagsChange(tags.filter(tag => tag !== tagToRemove));
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base font-semibold flex items-center gap-2">
            <Pin className="h-4 w-4" /> Tags
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex gap-2 items-start">
            <Input 
              id="tags" 
              placeholder="Add a tag"
              value={newTagInput}
              onChange={(e) => setNewTagInput(e.target.value)}
              onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ',') {
                      e.preventDefault();
                      handleAddTags();
                  }
              }}
            />
            <Button variant="secondary" type="button" onClick={handleAddTags}>Add</Button>
        </div>
        <p className="text-xs text-muted-foreground mt-1">Separate tags with commas or the Enter key.</p>
        <div className="mt-4 flex flex-wrap gap-2 min-h-[24px]">
          {tags.map(tag => (
            <Badge key={tag} variant="secondary" className="pr-1">
              {tag}
              <button onClick={() => handleRemoveTag(tag)} className="ml-1 rounded-full p-0.5 hover:bg-destructive/50">
                <X className="h-3 w-3" />
                <span className="sr-only">Remove {tag}</span>
              </button>
            </Badge>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

