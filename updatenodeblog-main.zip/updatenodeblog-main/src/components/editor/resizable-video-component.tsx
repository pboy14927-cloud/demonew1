
'use client';

import React, { useState } from 'react';
import { NodeViewWrapper, NodeViewProps } from '@tiptap/react';
import { cn } from '@/lib/utils';
import { PlayCircle } from 'lucide-react';
import Image from 'next/image';

const ResizableVideoComponent: React.FC<NodeViewProps> = ({ node, updateAttributes, editor }) => {
  const { align, src, ...rest } = node.attrs;
  const [isPlaying, setIsPlaying] = useState(false);

  const wrapperClassName = cn('resizable-video-wrapper', 'relative', 'cursor-pointer');

  const handlePlay = () => {
    setIsPlaying(true);
  };

  if (!isPlaying) {
    return (
        <NodeViewWrapper 
            as="div"
            className={wrapperClassName}
            data-align={align}
            onClick={handlePlay}
            style={{ width: typeof node.attrs.width === 'number' ? `${node.attrs.width}px` : node.attrs.width }}
        >
            <Image src={node.attrs.poster || "https://placehold.co/600x400.png?text=Video+Preview"} alt="Video preview" width={600} height={400} className="w-full h-auto" data-ai-hint="video placeholder" />
            <div className="video-play-button">
              <PlayCircle className="w-16 h-16" />
            </div>
      </NodeViewWrapper>
    )
  }

  return (
    <NodeViewWrapper 
        className={wrapperClassName}
        data-align={align}
    >
      <video
        {...rest}
        src={src}
        style={{
            width: typeof node.attrs.width === 'number' ? `${node.attrs.width}px` : node.attrs.width,
        }}
        controls
        autoPlay
        draggable="true"
        data-drag-handle
      />
    </NodeViewWrapper>
  );
};

export default ResizableVideoComponent;
