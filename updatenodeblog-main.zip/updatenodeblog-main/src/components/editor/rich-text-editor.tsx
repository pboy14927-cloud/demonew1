
'use client';

import { useEditor, EditorContent, Editor, BubbleMenu } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import CharacterCount from '@tiptap/extension-character-count';
import {
  Bold,
  Italic,
  Underline,
  Strikethrough,
  List,
  ListOrdered,
  Heading1,
  Heading2,
  Heading3,
  Heading4,
  Heading5,
  Heading6,
  Code,
  Quote,
  Minus,
  Pilcrow,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  Palette,
  Undo,
  Redo,
  Sparkles,
  ListPlus,
  Text,
  Link as LinkIcon,
  Image as ImageIcon,
  Pencil,
  Trash2,
  Video as VideoIcon,
} from 'lucide-react';
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Separator } from '@/components/ui/separator';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { useCallback, useState, useEffect, useRef } from 'react';
import Image from '@tiptap/extension-image';
import Table from '@tiptap/extension-table';
import TableRow from '@tiptap/extension-table-row';
import TableCell from '@tiptap/extension-table-cell';
import TableHeader from '@tiptap/extension-table-header';
import UnderlineExtension from '@tiptap/extension-underline';
import Highlight from '@tiptap/extension-highlight';
import SubscriptExtension from '@tiptap/extension-subscript';
import SuperscriptExtension from '@tiptap/extension-superscript';
import TextAlign from '@tiptap/extension-text-align';
import Link from '@tiptap/extension-link';
import { Textarea } from '../ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from '../ui/button';
import { cn } from '@/lib/utils';
import { Tooltip, TooltipProvider, TooltipTrigger, TooltipContent } from '../ui/tooltip';
import { Popover, PopoverContent, PopoverTrigger } from '../ui/popover';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Color } from '@tiptap/extension-color'
import TextStyle from '@tiptap/extension-text-style'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import ResizableImage from './resizable-image-extension';
import ResizableVideo from './resizable-video-extension';
import { ToggleGroup, ToggleGroupItem } from '../ui/toggle';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Media } from '@/lib/data';

const ToolbarButton = ({ editor, action, value, children, tooltip, onClick }: { editor: Editor, action?: string, value?: any, children: React.ReactNode, tooltip: string, onClick?: () => void }) => {
    const [isActive, setIsActive] = useState(false);

    const handleClick = () => {
        if (onClick) {
            onClick();
            return;
        }
        if (!action) return;
        
        const chain = editor.chain().focus();
        
        if (action === 'setColor') {
            chain.setColor(value).run();
            return;
        }

        const command = (chain as any)[action];
        if (command) {
            if (value !== undefined) {
                command(value).run();
            } else {
                command().run();
            }
        }
    };
    
    useEffect(() => {
        const checkActive = () => {
            if (!editor || !action) {
                setIsActive(false);
                return;
            };

            let checkName = action;
            let checkValue = value;

            if (action.startsWith('toggle')) {
                checkName = action.replace('toggle', '').charAt(0).toLowerCase() + action.slice(7);
            }

            if (action.startsWith('toggleHeading')) {
                checkName = 'heading';
            }
            
            if (action === 'setTextAlign') {
                setIsActive(editor.isActive({ textAlign: value }));
                return;
            }
            if (action === 'setColor') {
                setIsActive(editor.isActive('textStyle', { color: value }));
                return;
            }
            
            if (value !== undefined) {
                setIsActive(editor.isActive(checkName, checkValue));
            } else {
                setIsActive(editor.isActive(checkName));
            }
        };

        checkActive();

        editor.on('transaction', checkActive);
        return () => {
            editor.off('transaction', checkActive);
        };
    }, [editor, action, value]);


    return (
        <Tooltip>
            <TooltipTrigger asChild>
                <Button 
                    type="button"
                    variant="ghost" 
                    size="icon" 
                    onClick={handleClick}
                    className={cn('h-8 w-8', isActive && 'border-2 border-black bg-accent')}
                >
                    {children}
                </Button>
            </TooltipTrigger>
            <TooltipContent>
                <p>{tooltip}</p>
            </TooltipContent>
        </Tooltip>
    );
};


const LinkPopover = ({ editor }: { editor: Editor }) => {
    const [url, setUrl] = useState(editor.getAttributes('link').href || '');
    const [isOpen, setIsOpen] = useState(false);

    const setLink = useCallback(() => {
        if (url === null) {
            return;
        }

        if (url === '') {
            editor.chain().focus().extendMarkRange('link').unsetLink().run();
            setIsOpen(false);
            return;
        }
        
        let finalUrl = url;
        if (!/^(https?:\/\/|mailto:|tel:|\/|#)/i.test(finalUrl)) {
            finalUrl = `https://${finalUrl}`;
        }
        
        editor.chain().focus().extendMarkRange('link').setLink({ href: finalUrl }).run();
        setIsOpen(false);
    }, [editor, url]);
    
    const handleOpenChange = (open: boolean) => {
        if(open) {
            setUrl(editor.getAttributes('link').href || '');
        }
        setIsOpen(open);
    }
    
    return (
        <Popover open={isOpen} onOpenChange={handleOpenChange}>
            <PopoverTrigger asChild>
                 <Button
                    type="button"
                    variant="ghost" 
                    size="icon"
                    className={cn('h-8 w-8', editor.isActive('link') && 'border-2 border-black bg-accent')}
                 >
                    <LinkIcon className="h-4 w-4" />
                </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80">
                <div className="grid gap-4">
                    <div className="space-y-2">
                        <h4 className="font-medium leading-none">Set Link</h4>
                        <p className="text-sm text-muted-foreground">
                           Enter the URL you want to link to.
                        </p>
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="link-url">URL</Label>
                        <Input id="link-url" value={url} onChange={(e) => setUrl(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); setLink(); } }} />
                    </div>
                    <Button onClick={setLink}>Set Link</Button>
                </div>
            </PopoverContent>
        </Popover>
    )
}

const ImageEditModal = ({ isOpen, onOpenChange, editor }: { isOpen: boolean, onOpenChange: (isOpen: boolean) => void, editor: Editor | null }) => {
    const [attrs, setAttrs] = useState<any>({});
    const [sizePreset, setSizePreset] = useState('custom');

    useEffect(() => {
        if (isOpen && editor) {
            const currentAttrs = editor.getAttributes('resizable-image');
            setAttrs(currentAttrs);
            // Logic to determine preset from width/height could go here
            if (currentAttrs.width === 150) setSizePreset('thumbnail');
            else if (currentAttrs.width === 300) setSizePreset('medium');
            else if (currentAttrs.width === 1024) setSizePreset('large');
            else if (currentAttrs.width === '100%') setSizePreset('full');
            else setSizePreset('custom');
        }
    }, [isOpen, editor]);

    const handleSave = () => {
        if(editor) {
            editor.chain().focus().updateAttributes('resizable-image', attrs).run();
        }
        onOpenChange(false);
    }
    
    const handleSizePresetChange = (value: string) => {
        setSizePreset(value);
        switch(value) {
            case 'thumbnail': setAttrs({...attrs, width: 150, height: 'auto'}); break;
            case 'medium': setAttrs({...attrs, width: 300, height: 'auto'}); break;
            case 'large': setAttrs({...attrs, width: 1024, height: 'auto'}); break;
            case 'full': setAttrs({...attrs, width: '100%', height: 'auto'}); break;
            default: setAttrs({...attrs, height: 'auto'}); break; // Custom
        }
    }

    if (!isOpen || !editor) return null;

    return (
        <Dialog open={isOpen} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-4xl">
                <DialogHeader>
                    <DialogTitle>Image details</DialogTitle>
                </DialogHeader>
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-8 py-4">
                    <div className="md:col-span-2 space-y-4">
                        <div className="space-y-2">
                           <Label htmlFor="alt-text">Alternative Text</Label>
                           <Textarea id="alt-text" value={attrs.alt || ''} onChange={(e) => setAttrs({...attrs, alt: e.target.value})} />
                           <p className="text-xs text-muted-foreground">
                            <a href="#" className="text-primary underline">Learn how to describe the purpose of the image.</a> Leave empty if the image is purely decorative.
                           </p>
                        </div>
                         
                        <h4 className="font-semibold text-sm">DISPLAY SETTINGS</h4>
                        <div className="space-y-4">
                            <div className="flex items-center gap-4">
                                <Label className="w-16">Align</Label>
                                <ToggleGroup type="single" value={attrs.align} onValueChange={(value) => value && setAttrs({...attrs, align: value})}>
                                    <ToggleGroupItem value="left">Left</ToggleGroupItem>
                                    <ToggleGroupItem value="center">Center</ToggleGroupItem>
                                    <ToggleGroupItem value="right">Right</ToggleGroupItem>
                                </ToggleGroup>
                            </div>
                            <div className="flex items-center gap-4">
                                <Label className="w-16">Size</Label>
                                <Select value={sizePreset} onValueChange={handleSizePresetChange}>
                                    <SelectTrigger><SelectValue/></SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="thumbnail">Thumbnail</SelectItem>
                                        <SelectItem value="medium">Medium</SelectItem>
                                        <SelectItem value="large">Large</SelectItem>
                                        <SelectItem value="full">Full Size</SelectItem>
                                        <SelectItem value="custom">Custom Size</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            {sizePreset === 'custom' && (
                                <div className="flex items-center gap-4 pl-20">
                                    <div className="flex items-center gap-2">
                                        <Label htmlFor="width">Width</Label>
                                        <Input id="width" type="number" className="w-20" value={attrs.width === '100%' ? '' : attrs.width || ''} onChange={e => setAttrs({...attrs, width: parseInt(e.target.value) || 0})} />
                                    </div>
                                    <span>x</span>
                                     <div className="flex items-center gap-2">
                                        <Label htmlFor="height">Height</Label>
                                        <Input id="height" type="text" className="w-20" value={attrs.height || ''} onChange={e => setAttrs({...attrs, height: e.target.value})} />
                                    </div>
                                </div>
                            )}
                             <div className="flex items-center gap-4">
                                <Label className="w-16">Link To</Label>
                                <Select>
                                    <SelectTrigger><SelectValue placeholder="None"/></SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="none">None</SelectItem>
                                        <SelectItem value="media">Media File</SelectItem>
                                        <SelectItem value="custom">Custom URL</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>

                    </div>
                    <div className="md:col-span-1 space-y-4">
                        <img src={attrs.src} data-ai-hint="image preview" alt="Preview" className="w-full h-auto rounded-md border" />
                        <div className="flex gap-2">
                            <Button variant="outline" className="w-full">Replace</Button>
                        </div>
                    </div>
                 </div>
                <DialogFooter>
                    <Button onClick={handleSave}>Update</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    )
}

const VideoEditModal = ({ isOpen, onOpenChange, editor }: { isOpen: boolean, onOpenChange: (isOpen: boolean) => void, editor: Editor | null }) => {
    const [attrs, setAttrs] = useState<any>({});
    const [sizePreset, setSizePreset] = useState('custom');

    useEffect(() => {
        if (isOpen && editor) {
            const currentAttrs = editor.getAttributes('resizable-video');
            setAttrs(currentAttrs);
            if (currentAttrs.width === 300) setSizePreset('medium');
            else if (currentAttrs.width === '100%') setSizePreset('full');
            else setSizePreset('custom');
        }
    }, [isOpen, editor]);

    const handleSave = () => {
        if(editor) {
            editor.chain().focus().updateAttributes('resizable-video', attrs).run();
        }
        onOpenChange(false);
    }
    
    const handleSizePresetChange = (value: string) => {
        setSizePreset(value);
        switch(value) {
            case 'medium': setAttrs({...attrs, width: 300 }); break;
            case 'full': setAttrs({...attrs, width: '100%' }); break;
            default: break;
        }
    }

    if (!isOpen || !editor) return null;

    return (
        <Dialog open={isOpen} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-2xl">
                <DialogHeader>
                    <DialogTitle>Video details</DialogTitle>
                </DialogHeader>
                <div className="py-4 space-y-4">
                    <div className="flex items-center gap-4">
                        <Label className="w-16">Align</Label>
                        <ToggleGroup type="single" value={attrs.align} onValueChange={(value) => value && setAttrs({...attrs, align: value})}>
                            <ToggleGroupItem value="left">Left</ToggleGroupItem>
                            <ToggleGroupItem value="center">Center</ToggleGroupItem>
                            <ToggleGroupItem value="right">Right</ToggleGroupItem>
                        </ToggleGroup>
                    </div>
                    <div className="flex items-center gap-4">
                        <Label className="w-16">Size</Label>
                        <Select value={sizePreset} onValueChange={handleSizePresetChange}>
                            <SelectTrigger><SelectValue/></SelectTrigger>
                            <SelectContent>
                                <SelectItem value="medium">Medium</SelectItem>
                                <SelectItem value="full">Full Width</SelectItem>
                                <SelectItem value="custom">Custom</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                    {sizePreset === 'custom' && (
                        <div className="flex items-center gap-4 pl-20">
                            <div className="flex items-center gap-2">
                                <Label htmlFor="width">Width (px or %)</Label>
                                <Input id="width" className="w-24" value={attrs.width} onChange={e => setAttrs({...attrs, width: e.target.value})} />
                            </div>
                        </div>
                    )}
                </div>
                <DialogFooter>
                    <Button onClick={handleSave}>Update</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    )
}

const Toolbar = ({ editor }: { editor: Editor | null }) => {
    const [showAdvanced, setShowAdvanced] = useState(false);
    
    if (!editor) {
        return null;
    }
    
    const handleReadMore = useCallback(() => {
        editor.chain().focus().insertContent('<hr class="more-divider" />').run();
    }, [editor]);
    
    const getHeadingLevel = (): `h${1|2|3|4|5|6}` | 'p' => {
      for (let i = 1; i <=6; i++) {
          if (editor.isActive('heading', { level: i })) {
              return `h${i}` as `h${1|2|3|4|5|6}`;
          }
      }
      return 'p';
    }
  
    return (
        <TooltipProvider>
            <div className="border-b rounded-t-lg p-1 bg-muted">
                <div className="flex items-center gap-1 flex-wrap">
            
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm" className="w-32 justify-start h-8">
                                {
                                    getHeadingLevel() === 'p' ? 'Paragraph' : `Heading ${getHeadingLevel().replace('h', '')}`
                                }
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent>
                            <DropdownMenuItem onClick={() => editor.chain().focus().setParagraph().run()} className={cn(getHeadingLevel() === 'p' && 'bg-accent')}>Paragraph</DropdownMenuItem>
                            <DropdownMenuItem onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()} className={cn("text-4xl", getHeadingLevel() === 'h1' && 'bg-accent')}>Heading 1</DropdownMenuItem>
                            <DropdownMenuItem onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()} className={cn("text-3xl", getHeadingLevel() === 'h2' && 'bg-accent')}>Heading 2</DropdownMenuItem>
                            <DropdownMenuItem onClick={() => editor.chain().focus().toggleHeading({ level: 3 }).run()} className={cn("text-2xl", getHeadingLevel() === 'h3' && 'bg-accent')}>Heading 3</DropdownMenuItem>
                            <DropdownMenuItem onClick={() => editor.chain().focus().toggleHeading({ level: 4 }).run()} className={cn("text-xl", getHeadingLevel() === 'h4' && 'bg-accent')}>Heading 4</DropdownMenuItem>
                            <DropdownMenuItem onClick={() => editor.chain().focus().toggleHeading({ level: 5 }).run()} className={cn("text-lg", getHeadingLevel() === 'h5' && 'bg-accent')}>Heading 5</DropdownMenuItem>
                            <DropdownMenuItem onClick={() => editor.chain().focus().toggleHeading({ level: 6 }).run()} className={cn("text-base", getHeadingLevel() === 'h6' && 'bg-accent')}>Heading 6</DropdownMenuItem>
                        </DropdownMenuContent>
                    </DropdownMenu>

                    <Separator orientation="vertical" className="h-8 mx-1" />

                <ToolbarButton editor={editor} action="toggleBold" tooltip="Bold"><Bold className="h-4 w-4" /></ToolbarButton>
                <ToolbarButton editor={editor} action="toggleItalic" tooltip="Italic"><Italic className="h-4 w-4" /></ToolbarButton>
                <LinkPopover editor={editor} />
                
                <Separator orientation="vertical" className="h-8 mx-1" />
                
                <ToolbarButton editor={editor} action="toggleBulletList" tooltip="Bulleted List"><List className="h-4 w-4" /></ToolbarButton>
                <ToolbarButton editor={editor} action="toggleOrderedList" tooltip="Numbered List"><ListOrdered className="h-4 w-4" /></ToolbarButton>
                <ToolbarButton editor={editor} action="toggleBlockquote" tooltip="Blockquote"><Quote className="h-4 w-4" /></ToolbarButton>
                
                <Separator orientation="vertical" className="h-8 mx-1" />
                
                <ToolbarButton editor={editor} action="setTextAlign" value="left" tooltip="Align Left"><AlignLeft className="h-4 w-4" /></ToolbarButton>
                <ToolbarButton editor={editor} action="setTextAlign" value="center" tooltip="Align Center"><AlignCenter className="h-4 w-4" /></ToolbarButton>
                <ToolbarButton editor={editor} action="setTextAlign" value="right" tooltip="Align Right"><AlignRight className="h-4 w-4" /></ToolbarButton>

                <Separator orientation="vertical" className="h-8 mx-1" />

                    <Tooltip>
                        <TooltipTrigger asChild>
                            <Button variant="ghost" size="icon" onClick={handleReadMore} className="h-8 w-8">
                            <Minus className="h-4 w-4" />
                            </Button>
                        </TooltipTrigger>
                        <TooltipContent><p>Read More</p></TooltipContent>
                    </Tooltip>
                <ToolbarButton editor={editor} onClick={() => setShowAdvanced(!showAdvanced)} tooltip="Toggle Toolbar">
                        <ListPlus className="h-4 w-4" />
                </ToolbarButton>
                </div>
                {showAdvanced && (
                    <div className="flex items-center gap-1 flex-wrap mt-1">
                        <ToolbarButton editor={editor} action="toggleUnderline" tooltip="Underline"><Underline className="h-4 w-4" /></ToolbarButton>
                        <ToolbarButton editor={editor} action="toggleStrike" tooltip="Strikethrough"><Strikethrough className="h-4 w-4" /></ToolbarButton>
                        <ToolbarButton editor={editor} action="setTextAlign" value="justify" tooltip="Align Justify"><AlignJustify className="h-4 w-4" /></ToolbarButton>
                        <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-8 w-8">
                                    <Palette className="h-4 w-4" />
                                </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent className="grid grid-cols-4 gap-2 p-2">
                                {['#000000', '#444444', '#666666', '#999999', '#cccccc', '#eeeeee', '#fefefe', '#ffffff', '#ff0000', '#00ff00', '#0000ff', '#ffff00'].map(color => (
                                    <DropdownMenuItem key={color} onSelect={() => editor.chain().focus().setColor(color).run()} className="p-0 m-0 w-6 h-6 justify-center">
                                        <div style={{backgroundColor: color}} className="w-4 h-4 rounded-sm border" />
                                    </DropdownMenuItem>
                                ))}
                            </DropdownMenuContent>
                        </DropdownMenu>
                        <Separator orientation="vertical" className="h-8 mx-1" />
                        <ToolbarButton editor={editor} action="setHardBreak" tooltip="Paste as Text"><Text className="h-4 w-4" /></ToolbarButton>
                        <ToolbarButton editor={editor} action="unsetAllMarks" tooltip="Clear Formatting"><Sparkles className="h-4 w-4" /></ToolbarButton>
                        <Separator orientation="vertical" className="h-8 mx-1" />
                        <ToolbarButton editor={editor} action="undo" tooltip="Undo"><Undo className="h-4 w-4" /></ToolbarButton>
                        <ToolbarButton editor={editor} action="redo" tooltip="Redo"><Redo className="h-4 w-4" /></ToolbarButton>
                    </div>
                )}
            </div>
        </TooltipProvider>
    );
};

interface RichTextEditorProps {
    initialContent: string;
    setEditorInstance: (editor: Editor | null) => void;
}

const RichTextEditor = ({ initialContent, setEditorInstance }: RichTextEditorProps) => {
    const [activeTab, setActiveTab] = useState('visual');
    const [htmlContent, setHtmlContent] = useState(initialContent);
    const [isClient, setIsClient] = useState(false);
    const [isImageEditModalOpen, setIsImageEditModalOpen] = useState(false);
    const [isVideoEditModalOpen, setIsVideoEditModalOpen] = useState(false);
    
    useEffect(() => {
        setIsClient(true);
    }, []);
    
    const editor = useEditor({
        immediatelyRender: false,
        extensions: [
            StarterKit,
            CharacterCount,
            UnderlineExtension,
            ResizableImage,
            ResizableVideo,
            Highlight,
            SubscriptExtension,
            SuperscriptExtension,
            TextAlign.configure({
                types: ['heading', 'paragraph', 'resizable-image', 'resizable-video'],
            }),
            Table.configure({ resizable: true }),
            TableRow,
            TableHeader,
            TableCell,
            TextStyle,
            Color,
            Link.configure({
                openOnClick: false,
                autolink: true,
            }),
        ],
        content: initialContent,
        editorProps: {
            attributes: {
                class: 'prose dark:prose-invert max-w-none focus:outline-none p-4',
            },
        },
    }, []);
    
    useEffect(() => {
        if (editor) {
            setEditorInstance(editor);
        }
    }, [editor, setEditorInstance]);

    useEffect(() => {
        return () => {
            editor?.destroy();
        }
    }, [editor]);
    

    const syncHtmlToEditor = () => {
        if(editor && editor.getHTML() !== htmlContent) {
            editor.commands.setContent(htmlContent, false);
        }
    }
    
    useEffect(() => {
        if(editor && activeTab === 'visual') {
            syncHtmlToEditor();
        }
    }, [activeTab, editor, htmlContent]);


    if (!isClient) {
        return <div className="min-h-[400px] border rounded-lg bg-muted/50" />;
    }
    
    return (
        <Tabs value={activeTab} onValueChange={setActiveTab} className="relative">
            <div className="absolute top-0 right-0 p-1 z-10">
                <TabsList>
                    <TabsTrigger value="visual">Visual</TabsTrigger>
                    <TabsTrigger value="text" onClick={() => setHtmlContent(editor?.getHTML() || '')}>Text</TabsTrigger>
                </TabsList>
            </div>
            <Card>
                 {editor && (
                     <>
                        <BubbleMenu editor={editor} tippyOptions={{ duration: 100 }}
                            shouldShow={({ editor }) => editor.isActive('resizable-image')}
                        >
                            <div className="flex gap-1 bg-background border shadow-md rounded-md p-1">
                                <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => editor.chain().focus().setImageAttributes({ align: 'left' }).run()}><AlignLeft className="h-4 w-4" /></Button>
                                <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => editor.chain().focus().setImageAttributes({ align: 'center' }).run()}><AlignCenter className="h-4 w-4" /></Button>
                                <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => editor.chain().focus().setImageAttributes({ align: 'right' }).run()}><AlignRight className="h-4 w-4" /></Button>
                                <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => setIsImageEditModalOpen(true)}><Pencil className="h-4 w-4" /></Button>
                                <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => editor.chain().focus().deleteSelection().run()}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                            </div>
                        </BubbleMenu>
                         <BubbleMenu editor={editor} tippyOptions={{ duration: 100 }}
                            shouldShow={({ editor }) => editor.isActive('resizable-video')}
                        >
                            <div className="flex gap-1 bg-background border shadow-md rounded-md p-1">
                                <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => editor.chain().focus().setVideoAttributes({ align: 'left' }).run()}><AlignLeft className="h-4 w-4" /></Button>
                                <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => editor.chain().focus().setVideoAttributes({ align: 'center' }).run()}><AlignCenter className="h-4 w-4" /></Button>
                                <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => editor.chain().focus().setVideoAttributes({ align: 'right' }).run()}><AlignRight className="h-4 w-4" /></Button>
                                <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => setIsVideoEditModalOpen(true)}><Pencil className="h-4 w-4" /></Button>
                                <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => editor.chain().focus().deleteSelection().run()}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                            </div>
                        </BubbleMenu>
                    </>
                )}
                <div style={{ display: activeTab === 'visual' ? 'block' : 'none' }}>
                     {editor && <Toolbar editor={editor} />}
                     <EditorContent editor={editor} className="min-h-[400px]" />
                </div>
                 <div style={{ display: activeTab === 'text' ? 'block' : 'none' }}>
                    <Textarea
                        value={htmlContent}
                        onChange={(e) => setHtmlContent(e.target.value)}
                        className="h-full w-full min-h-[400px] rounded-b-md border-0 bg-background p-4 font-mono text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none"
                    />
                </div>
                <CardFooter className="p-2 text-xs text-muted-foreground justify-between bg-muted/50">
                    <span>Word count: {editor?.storage.characterCount.words()}</span>
                </CardFooter>
            </Card>
            <ImageEditModal isOpen={isImageEditModalOpen} onOpenChange={setIsImageEditModalOpen} editor={editor} />
            <VideoEditModal isOpen={isVideoEditModalOpen} onOpenChange={setIsVideoEditModalOpen} editor={editor} />
        </Tabs>
    );
};

export default RichTextEditor;
