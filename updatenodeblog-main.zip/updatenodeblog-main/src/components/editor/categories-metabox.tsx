
'use client';

import { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Pin } from 'lucide-react';
import { getCategories, createCategory, Category } from '@/lib/data';
import { useToast } from '@/hooks/use-toast';

type CategoriesMetaboxProps = {
    selectedCategories: string[];
    onCategoryChange: (categoryName: string) => void;
}

export default function CategoriesMetabox({ selectedCategories, onCategoryChange }: CategoriesMetaboxProps) {
  const [newCategory, setNewCategory] = useState('');
  const [availableCategories, setAvailableCategories] = useState<Category[]>([]);
  const { toast } = useToast();
  
  const fetchCategories = useCallback(async () => {
    setAvailableCategories(await getCategories());
  }, []);

  useEffect(() => {
    fetchCategories();
  }, [fetchCategories]);

  const handleAddNewCategory = async () => {
    if (newCategory && !availableCategories.some(c => c.name === newCategory)) {
        try {
            await createCategory({ name: newCategory });
            onCategoryChange(newCategory);
            setNewCategory('');
            await fetchCategories(); // Refetch to update the list
            toast({ title: "Category created"});
        } catch (e) {
            toast({ variant: "destructive", title: "Error creating category"});
        }
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base font-semibold flex items-center gap-2">
            <Pin className="h-4 w-4" /> Categories
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2 max-h-40 overflow-y-auto border p-2 rounded-md">
          {availableCategories.map(category => (
            <div key={category.id} className="flex items-center space-x-2">
              <Checkbox 
                id={`category-${category.id}`} 
                checked={selectedCategories.includes(category.name)}
                onCheckedChange={() => onCategoryChange(category.name)}
              />
              <Label htmlFor={`category-${category.id}`} className="font-normal">{category.name}</Label>
            </div>
          ))}
        </div>
        <div className="mt-4">
          <a href="#add-category" className="text-sm text-primary hover:underline" onClick={(e) => {
              e.preventDefault();
              const el = document.getElementById('add-category-form');
              el?.classList.toggle('hidden');
          }}>+ Add New Category</a>
          <div id="add-category-form" className="hidden mt-2 space-y-2">
            <Input 
              placeholder="New Category Name" 
              value={newCategory} 
              onChange={(e) => setNewCategory(e.target.value)}
            />
            <Button variant="secondary" size="sm" type="button" onClick={handleAddNewCategory}>Add New Category</Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
