
import { Node, mergeAttributes } from '@tiptap/core';
import { ReactNodeViewRenderer } from '@tiptap/react';
import ResizableVideoComponent from './resizable-video-component';

export interface ResizableVideoOptions {
  inline: boolean;
  HTMLAttributes: Record<string, any>;
}

declare module '@tiptap/core' {
  interface Commands<ReturnType> {
    resizableVideo: {
      setVideo: (options: { src: string, width?: string | number, align?: 'left' | 'center' | 'right', poster?: string }) => ReturnType;
      setVideoAttributes: (attributes: { width?: string | number, align?: 'left' | 'center' | 'right' }) => ReturnType;
    };
  }
}

export default Node.create<ResizableVideoOptions>({
  name: 'resizable-video',
  group: 'block',
  atom: true,
  draggable: true,

  addAttributes() {
    return {
      src: {
        default: null,
      },
      controls: {
        default: true,
      },
      width: {
        default: '100%',
      },
      align: {
        default: 'center',
        renderHTML: attributes => {
            return {
                'data-align': attributes.align,
            }
        }
      },
      poster: {
          default: null,
      }
    };
  },

  parseHTML() {
    return [
      {
        tag: 'video',
        getAttrs: (dom) => {
             if (typeof dom === 'string') return {};
             const element = dom as HTMLVideoElement;
             const align = element.getAttribute('data-align') || element.style.textAlign || 'center';
             const src = element.querySelector('source')?.getAttribute('src') || element.getAttribute('src');
             return {
                 src: src,
                 width: element.getAttribute('width'),
                 align: align,
                 poster: element.getAttribute('poster'),
             }
        }
      },
    ];
  },

  renderHTML({ HTMLAttributes }) {
    return ['video', mergeAttributes(this.options.HTMLAttributes, HTMLAttributes, { controls: 'true' }), ['source', { src: HTMLAttributes.src }]];
  },
  
  addCommands() {
    return {
       setVideo: (options) => ({ commands }) => {
        return commands.insertContent({
            type: this.name,
            attrs: options,
        })
      },
      setVideoAttributes: (attributes) => ({ commands }) => {
        return commands.updateAttributes('resizable-video', attributes)
      },
    }
  },

  addNodeView() {
    return ReactNodeViewRenderer(ResizableVideoComponent);
  },
});
