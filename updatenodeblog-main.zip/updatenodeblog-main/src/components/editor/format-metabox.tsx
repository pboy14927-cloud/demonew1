
'use client';

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Pin, GalleryHorizontal, Image as ImageIcon, Video, Music } from "lucide-react";

type FormatMetaboxProps = {
    selectedFormat: 'standard' | 'gallery' | 'image' | 'video' | 'audio';
    onFormatChange: (format: 'standard' | 'gallery' | 'image' | 'video' | 'audio') => void;
};

const formatOptions = [
    { value: 'standard', label: 'Standard', icon: <Pin className="h-4 w-4" /> },
    { value: 'gallery', label: 'Gallery', icon: <GalleryHorizontal className="h-4 w-4" /> },
    { value: 'image', label: 'Image', icon: <ImageIcon className="h-4 w-4" /> },
    { value: 'video', label: 'Video', icon: <Video className="h-4 w-4" /> },
    { value: 'audio', label: 'Audio', icon: <Music className="h-4 w-4" /> },
];

export default function FormatMetabox({ selectedFormat, onFormatChange }: FormatMetaboxProps) {
    return (
        <Card>
            <CardHeader>
                <CardTitle className="text-base font-semibold flex items-center gap-2">
                    <Pin className="h-4 w-4" /> Format
                </CardTitle>
            </CardHeader>
            <CardContent>
                <RadioGroup
                    value={selectedFormat}
                    onValueChange={onFormatChange}
                    className="space-y-2"
                >
                    {formatOptions.map(option => (
                        <div key={option.value} className="flex items-center space-x-2">
                            <RadioGroupItem value={option.value} id={`format-${option.value}`} />
                            <Label htmlFor={`format-${option.value}`} className="flex items-center gap-2 font-normal">
                                {option.icon}
                                {option.label}
                            </Label>
                        </div>
                    ))}
                </RadioGroup>
            </CardContent>
        </Card>
    );
}
