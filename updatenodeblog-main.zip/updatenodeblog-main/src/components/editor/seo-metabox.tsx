
'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TrendingUp, Upload, CheckCircle2, XCircle, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Post, SeoData, getSeoSettings as fetchSeoSettings, getBrandingSettings } from '@/lib/data';
import MediaLibraryModal from '../admin/media-library-modal';
import { cn } from '@/lib/utils';
import { generatePostUrl } from '@/lib/data';


type SeoMetaboxProps = {
    post: Partial<Post>;
    siteUrl: string;
    onSeoChange: (seoData: Partial<SeoData>) => void;
    onSeoScoreChange: (score: number | null) => void;
    currentUrl: string;
}

const SmartTag = ({ tag, variable, onClick }: { tag: string; variable: string; onClick: (tag: string) => void }) => (
    <Button
        type="button"
        variant="outline"
        size="sm"
        className="h-auto px-2 py-1 text-xs"
        onClick={() => onClick(variable)}
    >
        + {tag}
    </Button>
);

const AnalysisItem = ({ success, text }: { success: boolean; text: string }) => (
    <li className="flex items-center gap-2">
        {success ? <CheckCircle2 className="h-4 w-4 text-green-500 flex-shrink-0" /> : <XCircle className="h-4 w-4 text-destructive flex-shrink-0" />}
        <span className="text-sm">{text}</span>
    </li>
);

export default function SeoMetabox({ post, siteUrl, onSeoChange, onSeoScoreChange, currentUrl }: SeoMetaboxProps) {
    const { toast } = useToast();
    const [isMediaDialogOpen, setIsMediaDialogOpen] = useState(false);
    const [socialImageTarget, setSocialImageTarget] = useState<'facebook' | 'twitter' | null>(null);

    const [siteTitle, setSiteTitle] = useState('');
    const [siteTagline, setSiteTagline] = useState('');
    const [seoSettings, setSeoSettings] = useState<any>(null);


    const { seo, title: postTitle = '', content: postContent = '', excerpt: postExcerpt = '' } = post;
    const focusKeyphrase = seo?.focusKeyphrase || '';

    useEffect(() => {
        const loadSettings = async () => {
            const branding = await getBrandingSettings();
            const seoData = await fetchSeoSettings();
            setSiteTitle(branding.websiteTitle);
            setSiteTagline(branding.websiteDescription);
            setSeoSettings(seoData);
        }
        loadSettings();
    }, [post]);

    const handleSeoChange = (field: keyof SeoData, value: string) => {
        onSeoChange({ [field]: value });
    };
    
    const handleImageSelect = (media: { url: string }) => {
        if(socialImageTarget === 'facebook') {
            handleSeoChange('facebookImage', media.url);
        } else if (socialImageTarget === 'twitter') {
            handleSeoChange('twitterImage', media.url);
        }
        setIsMediaDialogOpen(false);
        setSocialImageTarget(null);
    }
    
    const openMediaLibrary = (target: 'facebook' | 'twitter') => {
        setSocialImageTarget(target);
        setIsMediaDialogOpen(true);
    }
    
    const replaceTags = useCallback((template: string | undefined | null, isDescription = false) => {
        if (!seoSettings) return template || '';
        
        const defaultTitleTemplate = post.isPage ? seoSettings.contentTypes.pages.titleTemplate : seoSettings.contentTypes.posts.titleTemplate;
        const defaultDescriptionTemplate = post.isPage ? seoSettings.contentTypes.pages.metaDescription : seoSettings.contentTypes.posts.metaDescription;

        let result = template || (isDescription ? defaultDescriptionTemplate : defaultTitleTemplate);
        
        result = result.replace(/\{\{site_title\}\}/g, siteTitle);
        result = result.replace(/\{\{sep\}\}/g, ` ${seoSettings.separator} `);
        result = result.replace(/\{\{tagline\}\}/g, siteTagline);
        result = result.replace(/\{\{post_title\}\}/g, postTitle || '');
        result = result.replace(/\{\{page_title\}\}/g, postTitle || '');
        result = result.replace(/\{\{term_title\}\}/g, postTitle || '');

        const excerptContent = postExcerpt || (postContent ? postContent.substring(0, 150) : '');
        result = result.replace(/\{\{post_excerpt\}\}/g, excerptContent);
        result = result.replace(/\{\{page_excerpt\}\}/g, excerptContent);
        
        return result;
    }, [seoSettings, siteTitle, siteTagline, postTitle, postExcerpt, postContent, post.isPage]);
    
    const displaySeoTitle = seo?.title || '';
    const displaySeoDescription = seo?.description || '';
    
    const finalSeoTitle = replaceTags(displaySeoTitle, false);
    const finalSeoDescription = replaceTags(displaySeoDescription, true);

    const createTagInserter = (currentValue: string, field: keyof SeoData) => (tag: string) => {
        handleSeoChange(field, `${currentValue || ''} ${tag}`.trim());
    }

    const analysis = React.useMemo(() => {
        if (!focusKeyphrase) {
            return null;
        }
        
        const keyphrase = focusKeyphrase.toLowerCase();
        
        const results = {
            good: [] as string[],
            improvements: [] as string[],
            score: 0,
        };

        // Title checks
        if (finalSeoTitle) {
            if(finalSeoTitle.toLowerCase().includes(keyphrase)) {
                results.good.push('Focus keyphrase appears in the SEO title.');
                results.score += 20;
            } else {
                results.improvements.push('Focus keyphrase does not appear in the SEO title.');
            }

            if (finalSeoTitle.length > 0) {
                 results.good.push('SEO title has a good length.');
                 results.score += 10;
            }
        } else {
             results.improvements.push('SEO title is missing.');
        }

        // Description checks
        if (finalSeoDescription) {
             if (finalSeoDescription.toLowerCase().includes(keyphrase)) {
                results.good.push('Focus keyphrase appears in the meta description.');
                results.score += 20;
            } else {
                results.improvements.push('Focus keyphrase not in meta description.');
            }

            if(finalSeoDescription.length >= 120) {
                 results.good.push('Meta description has a good length.');
                 results.score += 10;
            } else {
                 results.improvements.push('Meta description is too short.');
            }
        } else {
            results.improvements.push('Meta description is missing.');
        }
        
        // Post Title check
        if (postTitle && postTitle.toLowerCase().includes(keyphrase)) {
            results.good.push('Focus keyphrase appears in the post title.');
            results.score += 20;
        } else {
            results.improvements.push('Focus keyphrase does not appear in the post title.');
        }
        
        // Post Content check
        if (postContent && postContent.toLowerCase().includes(keyphrase)) {
             results.good.push('Focus keyphrase found in the content.');
             results.score += 20;
        } else {
            results.improvements.push('Focus keyphrase not found in the content.');
        }

        return results;

    }, [focusKeyphrase, finalSeoTitle, finalSeoDescription, postTitle, postContent]);
    
     useEffect(() => {
        onSeoScoreChange(analysis?.score ?? null);
    }, [analysis, onSeoScoreChange]);


    const getSeoLabelAndColor = () => {
        if (analysis === null || analysis.score === null) return { label: 'Enter a keyphrase', color: ''};
        if (analysis.score >= 80) return { label: 'Good SEO', color: 'text-green-600' };
        if (analysis.score >= 50) return { label: 'Okay SEO', color: 'text-yellow-600' };
        return { label: 'Poor SEO', color: 'text-red-600' };
    }

    const { label: seoLabel, color: seoColor } = getSeoLabelAndColor();
    
  return (
    <>
    <Card>
        <CardHeader>
            <CardTitle className="text-base font-semibold flex items-center justify-between">
                 <div className="flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-primary" /> Digiotic SEO
                </div>
                 <span className={cn("text-sm", seoColor)}>{seoLabel}</span>
            </CardTitle>
             {analysis && (
                <div className="flex items-center gap-2 pt-2">
                    <Progress value={analysis.score} className="w-full" />
                    <span className="text-sm font-semibold">{analysis.score} / 100</span>
                </div>
            )}
        </CardHeader>
        <CardContent>
            <Tabs defaultValue="general" className="w-full">
                <TabsList className="w-full grid grid-cols-2">
                    <TabsTrigger value="general">General</TabsTrigger>
                    <TabsTrigger value="social">Social</TabsTrigger>
                </TabsList>

                <TabsContent value="general" className="pt-4">
                    <div className="space-y-4">
                         <div>
                            <Label htmlFor="focus-keyphrase">Focus keyphrase</Label>
                            <Input id="focus-keyphrase" value={focusKeyphrase} onChange={(e) => handleSeoChange('focusKeyphrase', e.target.value)} />
                            <CardDescription className="text-xs mt-1">Pick the main keyword or keyphrase for this post.</CardDescription>
                        </div>

                        <div>
                            <Label>Google preview</Label>
                            <div className="p-4 border rounded-lg mt-1">
                                <p className="text-blue-700 text-lg hover:underline cursor-pointer truncate">{finalSeoTitle || 'SEO Title will be displayed here'}</p>
                                <p className="text-green-600 text-sm truncate">{seo?.canonical || (siteUrl ? `${siteUrl.replace(/\/$/, '')}${currentUrl}` : 'Permalink will display here')}</p>
                                <p className="text-sm text-gray-600 mt-1 line-clamp-2">{finalSeoDescription || 'Please provide a meta description by editing the snippet below.'}</p>
                            </div>
                        </div>

                        <div className='space-y-1'>
                            <Label htmlFor="seo-title">SEO title</Label>
                             <div className="flex gap-1 flex-wrap mb-1">
                                <SmartTag tag="Title" variable="{{post_title}}" onClick={createTagInserter(seo?.title || '', 'title')} />
                                <SmartTag tag="Separator" variable="{{sep}}" onClick={createTagInserter(seo?.title || '', 'title')} />
                                <SmartTag tag="Site Title" variable="{{site_title}}" onClick={createTagInserter(seo?.title || '', 'title')} />
                            </div>
                            <Input id="seo-title" value={displaySeoTitle} onChange={(e) => handleSeoChange('title', e.target.value)} placeholder={replaceTags('', false)} />
                             <Progress value={finalSeoTitle.length / 60 * 100} className="h-1 mt-1" />
                             <div className="text-xs text-muted-foreground text-right mt-1">
                                {finalSeoTitle.length} out of 60 max recommended characters.
                            </div>
                        </div>
                        
                        <div className='space-y-1'>
                            <Label htmlFor="meta-description">Meta description</Label>
                             <div className="flex gap-1 flex-wrap mb-1">
                                <SmartTag tag="Excerpt" variable="{{post_excerpt}}" onClick={createTagInserter(seo?.description || '', 'description')} />
                                <SmartTag tag="Separator" variable="{{sep}}" onClick={createTagInserter(seo?.description || '', 'description')} />
                                <SmartTag tag="Site Title" variable="{{site_title}}" onClick={createTagInserter(seo?.description || '', 'description')} />
                            </div>
                            <Textarea id="meta-description" value={displaySeoDescription} onChange={(e) => handleSeoChange('description', e.target.value)} placeholder={replaceTags('', true)} />
                            <Progress value={(finalSeoDescription?.length || 0) / 160 * 100} className="h-1 mt-1" />
                             <div className="text-xs text-muted-foreground text-right mt-1">
                                {finalSeoDescription?.length || 0} out of 160 max recommended characters.
                            </div>
                        </div>

                        <div>
                            <Label htmlFor="canonical-url">Canonical URL</Label>
                            <Input id="canonical-url" value={seo?.canonical || ''} onChange={(e) => handleSeoChange('canonical', e.target.value)} placeholder={`${siteUrl.replace(/\/$/, '')}${currentUrl}`} />
                            <CardDescription className="text-xs mt-1">The source URL of this content. If it's not set, the permalink will be used.</CardDescription>
                        </div>
                        
                        {analysis && (
                            <div className="space-y-4 pt-4 border-t">
                                 <h4 className="font-semibold">SEO Analysis</h4>
                                {analysis.improvements.length > 0 && (
                                     <div>
                                        <h5 className="font-medium mb-2">Improvements</h5>
                                        <ul className="space-y-1">
                                            {analysis.improvements.map((item, i) => <AnalysisItem key={`imp-${i}`} success={false} text={item} />)}
                                        </ul>
                                    </div>
                                )}
                                 {analysis.good.length > 0 && (
                                     <div>
                                        <h5 className="font-medium mb-2">Good results</h5>
                                        <ul className="space-y-1">
                                            {analysis.good.map((item, i) => <AnalysisItem key={`good-${i}`} success={true} text={item} />)}
                                        </ul>
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                </TabsContent>
                
                <TabsContent value="social" className="pt-4 space-y-6">
                    <Tabs defaultValue="facebook" className="w-full">
                        <TabsList className="grid w-full grid-cols-2">
                           <TabsTrigger value="facebook">Facebook</TabsTrigger>
                           <TabsTrigger value="twitter">X (Twitter)</TabsTrigger>
                        </TabsList>
                        <TabsContent value="facebook" className="pt-4">
                             <div className="space-y-4">
                                <h3 className="text-lg font-semibold">Facebook Preview</h3>
                                <div className="border rounded-lg mt-1 overflow-hidden max-w-lg">
                                    <div className="aspect-[1.91/1] bg-muted flex items-center justify-center">
                                         <img src={seo?.facebookImage || post.featuredImage || 'https://placehold.co/1200x630.png'} data-ai-hint="social media preview" alt="Facebook Preview" className="object-cover w-full h-full" />
                                    </div>
                                    <div className="p-4 bg-muted/50">
                                        <p className="text-xs text-muted-foreground uppercase">{siteUrl.replace(/https?:\/\//, '')}</p>
                                        <p className="font-semibold text-card-foreground truncate">{replaceTags(seo?.facebookTitle) || finalSeoTitle}</p>
                                        <p className="text-sm text-muted-foreground truncate">{replaceTags(seo?.facebookDescription, true) || finalSeoDescription}</p>
                                    </div>
                                </div>
                                <div>
                                    <Label htmlFor="fb-title">Facebook Title</Label>
                                    <Input id="fb-title" value={seo?.facebookTitle || ''} onChange={(e) => handleSeoChange('facebookTitle', e.target.value)} placeholder={finalSeoTitle} />
                                </div>
                                <div>
                                    <Label htmlFor="fb-description">Facebook Description</Label>
                                    <Textarea id="fb-description" value={seo?.facebookDescription || ''} onChange={(e) => handleSeoChange('facebookDescription', e.target.value)} placeholder={finalSeoDescription} />
                                </div>
                                <div>
                                    <Label>Facebook Image</Label>
                                    <Button variant="outline" className="w-full mt-1" onClick={() => openMediaLibrary('facebook')}>
                                        <Upload className="mr-2 h-4 w-4" />
                                        Upload Image
                                    </Button>
                                </div>
                            </div>
                        </TabsContent>
                         <TabsContent value="twitter" className="pt-4">
                             <div className="space-y-4">
                                <h3 className="text-lg font-semibold">Twitter Preview</h3>
                                <div className="border rounded-lg mt-1 overflow-hidden max-w-lg">
                                     <div className="aspect-[1.91/1] bg-muted flex items-center justify-center">
                                        <img src={seo?.twitterImage || post.featuredImage || 'https://placehold.co/1200x630.png'} data-ai-hint="social media preview" alt="Twitter Preview" className="object-cover w-full h-full" />
                                     </div>
                                    <div className="p-4 bg-muted/50">
                                        <p className="font-semibold text-card-foreground truncate">{replaceTags(seo?.twitterTitle) || finalSeoTitle}</p>
                                        <p className="text-sm text-muted-foreground truncate">{replaceTags(seo?.twitterDescription, true) || finalSeoDescription}</p>
                                        <p className="text-xs text-muted-foreground uppercase mt-1">{siteUrl.replace(/https?:\/\//, '')}</p>
                                    </div>
                                </div>
                                <div>
                                    <Label htmlFor="x-title">Twitter Title</Label>
                                    <Input id="x-title" value={seo?.twitterTitle || ''} onChange={(e) => handleSeoChange('twitterTitle', e.target.value)} placeholder={finalSeoTitle} />
                                </div>
                                <div>
                                    <Label htmlFor="x-description">Twitter Description</Label>
                                    <Textarea id="x-description" value={seo?.twitterDescription || ''} onChange={(e) => handleSeoChange('twitterDescription', e.target.value)} placeholder={finalSeoDescription} />
                                </div>
                                <div>
                                    <Label>Twitter Image</Label>
                                    <Button variant="outline" className="w-full mt-1" onClick={() => openMediaLibrary('twitter')}>
                                        <Upload className="mr-2 h-4 w-4" />
                                        Upload Image
                                    </Button>
                                </div>
                            </div>
                        </TabsContent>
                    </Tabs>
                </TabsContent>
            </Tabs>
        </CardContent>
    </Card>
     <MediaLibraryModal isOpen={isMediaDialogOpen} onOpenChange={setIsMediaDialogOpen} onSelect={handleImageSelect} />
    </>
  );
}

    