
'use client';

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import type { User } from "@/lib/data";

type AuthorMetaboxProps = {
    allUsers: User[];
    selectedAuthorId: string;
    onAuthorChange: (authorId: string) => void;
    slug: string;
    onSlugChange: (slug: string) => void;
    isPage: boolean;
};

export default function AuthorMetabox({ allUsers, selectedAuthorId, onAuthorChange, slug, onSlugChange, isPage }: AuthorMetaboxProps) {
  return (
    <Card>
      <CardContent className="space-y-4 pt-6">
        {isPage && (
          <div className="space-y-1">
            <Label htmlFor="slug">Slug</Label>
            <Input 
                id="slug"
                value={slug}
                onChange={(e) => onSlugChange(e.target.value)}
            />
        </div>
        )}
        <div className="space-y-1">
            <Label htmlFor="author">Author</Label>
            <Select value={selectedAuthorId} onValueChange={onAuthorChange}>
                <SelectTrigger id="author">
                    <SelectValue placeholder="Select an author" />
                </SelectTrigger>
                <SelectContent>
                    {allUsers.map(user => (
                        <SelectItem key={user.id} value={user.id}>{user.name}</SelectItem>
                    ))}
                </SelectContent>
            </Select>
        </div>
      </CardContent>
    </Card>
  );
}
