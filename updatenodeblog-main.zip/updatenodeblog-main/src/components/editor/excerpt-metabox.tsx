
'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Pin } from 'lucide-react';

type ExcerptMetaboxProps = {
    excerpt: string;
    onExcerptChange: (value: string) => void;
}

export default function ExcerptMetabox({ excerpt, onExcerptChange }: ExcerptMetaboxProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base font-semibold flex items-center gap-2">
          <Pin className="h-4 w-4" /> Excerpt
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Textarea 
          placeholder="Write an excerpt (optional)" 
          rows={4} 
          value={excerpt}
          onChange={(e) => onExcerptChange(e.target.value)}
        />
        <CardDescription className="mt-2 text-xs">
          Excerpts are optional hand-crafted summaries of your content that can be used in your theme.
        </CardDescription>
      </CardContent>
    </Card>
  );
}
