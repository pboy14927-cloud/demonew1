
'use client';

import { useState, useEffect, useCallback, useMemo } from "react";
import { useRouter } from 'next/navigation';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Save, Send, Trash2, Edit, Pin, Eye, KeyRound, CalendarIcon, TrendingUp, ImageIcon, CheckCircle, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import RichTextEditor from "./rich-text-editor";
import CategoriesMetabox from "./categories-metabox";
import TagsMetabox from "./tags-metabox";
import { Separator } from "@/components/ui/separator";
import FeaturedImageMetabox from "./featured-image-metabox";
import ExcerptMetabox from "./excerpt-metabox";
import { Post, updatePost, createPostDb, Media, getBrandingSettings, SeoData, User, generatePostUrl } from "@/lib/data";
import SeoMetabox from "./seo-metabox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import MediaLibraryModal from "../admin/media-library-modal";
import type { Editor } from "@tiptap/react";
import { cn } from "@/lib/utils";
import { RadioGroup, RadioGroupItem } from "../ui/radio-group";
import FormatMetabox from "./format-metabox";
import PageAttributesMetabox from "./page-attributes-metabox";
import DiscussionMetabox from "./discussion-metabox";
import AuthorMetabox from "./author-metabox";
import { Alert, AlertDescription, AlertTitle } from "../ui/alert";
import Link from "next/link";
import { useSession } from "next-auth/react";


type ContentEditorProps = {
    post?: Post;
    title: string;
    allUsers: User[];
    allPages: Post[];
    authorId?: string; // Optional for existing posts, required for new
}

type Notification = {
    message: string;
    url: string;
    type: 'success' | 'error';
}

// Helper to generate a URL-friendly slug
const generateSlug = (text: string) => {
    if (!text) return '';
    return text
        .toLowerCase()
        .replace(/\s+/g, '-') // Replace spaces with -
        .replace(/[^\w-]+/g, '') // Remove all non-word chars
        .replace(/--+/g, '-') // Replace multiple - with single -
        .replace(/^-+/, '') // Trim - from start of text
        .replace(/-+$/, '') // Trim - from end of text
        .slice(0, 70); // Max 70 chars
}

export default function ContentEditor({ post: initialPost, title: pageTitle, allUsers, allPages, authorId }: ContentEditorProps) {
  const router = useRouter();
  const { toast } = useToast();
  
  const [editorInstance, setEditorInstance] = useState<Editor | null>(null);

  const [post, setPost] = useState<Partial<Post>>(initialPost || {
      title: '',
      slug: '',
      content: '',
      status: 'draft',
      authorId: authorId || '',
      tags: [],
      categories: [],
      featuredImage: null,
      isPage: pageTitle.includes('Page'),
      isPartnerContent: pageTitle.includes('Partner'),
      format: 'standard',
      template: 'default',
      commentStatus: 'open',
      pingStatus: 'open',
      seo: {
          title: '',
          description: '',
          canonical: '',
          facebookTitle: '',
          facebookDescription: '',
          facebookImage: '',
          twitterTitle: '',
          twitterDescription: '',
          twitterImage: '',
          focusKeyphrase: '',
      }
  });

  const [isMediaDialogOpen, setIsMediaDialogOpen] = useState(false);
  const [publishedDate, setPublishedDate] = useState(initialPost ? new Date(initialPost.createdAt) : new Date());
  const [formattedPublishedDate, setFormattedPublishedDate] = useState<string | null>(null);

  const [isEditingStatus, setIsEditingStatus] = useState(false);
  const [isEditingVisibility, setIsEditingVisibility] = useState(false);
  const [isEditingDate, setIsEditingDate] = useState(false);
  
  const [visibility, setVisibility] = useState<'public' | 'private' | 'password'>('public');
  const [password, setPassword] = useState('');

  const [tempDate, setTempDate] = useState({
      month: publishedDate.toLocaleString('default', { month: 'short' }),
      day: publishedDate.getDate().toString().padStart(2, '0'),
      year: publishedDate.getFullYear().toString(),
      hour: publishedDate.getHours().toString().padStart(2, '0'),
      minute: publishedDate.getMinutes().toString().padStart(2, '0'),
  });

  const [seoScore, setSeoScore] = useState<number | null>(null);
  const [siteUrl, setSiteUrl] = useState('');
  const [isSlugManuallyEdited, setIsSlugManuallyEdited] = useState(!!initialPost?.slug);
  const [currentUrl, setCurrentUrl] = useState('');
  const [notification, setNotification] = useState<Notification | null>(null);

  const isPublished = post.status === 'published';

  useEffect(() => {
    getBrandingSettings().then(branding => setSiteUrl(branding.siteUrl));
  }, []);
  
  useEffect(() => {
    const updateUrl = async () => {
        if (post.slug) {
            const url = await generatePostUrl(post as Post);
            setCurrentUrl(url);
        }
    }
    updateUrl();
  }, [post]);

  useEffect(() => {
    const dateStr = publishedDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    const timeStr = publishedDate.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
    setFormattedPublishedDate(`${dateStr} at ${timeStr}`);
  }, [publishedDate]);
  
  const handleValueChange = (field: keyof Post, value: any) => {
    setPost(prev => {
        const isNewPost = !prev.id;
        let newSlug = prev.slug;
        
        if (field === 'title' && !isSlugManuallyEdited && (isNewPost || !isPublished)) {
            newSlug = generateSlug(value);
        }

        if (field === 'slug') {
            setIsSlugManuallyEdited(true);
            newSlug = generateSlug(value);
        }

        return {
            ...prev,
            [field]: value,
            slug: newSlug,
        };
    });
  }

  const handleSeoChange = (seoData: Partial<SeoData>) => {
      setPost(prev => ({...prev, seo: { ...prev.seo, ...seoData } as SeoData}));
  }

  const handleSaveDate = () => {
      const newDate = new Date(
          parseInt(tempDate.year),
          new Date(Date.parse(tempDate.month +" 1, 2012")).getMonth(),
          parseInt(tempDate.day),
          parseInt(tempDate.hour),
          parseInt(tempDate.minute)
      );
      setPublishedDate(newDate);
      setIsEditingDate(false);
  }
  
 const saveContent = useCallback(async (newStatus?: Post['status']) => {
    if (!post.authorId) {
        toast({ variant: 'destructive', title: 'Author not set.', description: 'Cannot save post without an author.'});
        return;
    }

    if (!editorInstance) {
        toast({ variant: 'destructive', title: 'Editor not ready.', description: 'Please wait a moment and try again.'});
        return;
    }

    const statusToSave = newStatus || post.status || 'draft';
    
    const postData: Partial<Post> = {
        ...post,
        content: editorInstance.getHTML(),
        status: statusToSave,
        slug: post.slug || generateSlug(post.title || ''),
        createdAt: publishedDate.toISOString(),
    }
    
    try {
        if (post.id) {
            await updatePost(post.id, postData);
            const viewUrl = await generatePostUrl({ ...post, status: statusToSave } as Post);
            setNotification({ message: 'Content Updated.', url: viewUrl, type: 'success'});
        } else {
            const newPostInfo = await createPostDb(postData);
            const newPostData = { ...postData, id: newPostInfo.id };

            if (newPostInfo.isPage || newPostInfo.isPartnerContent) {
                toast({
                    title: 'Content Created!',
                    description: 'Your content has been created successfully.',
                });
                let redirectPath = newPostInfo.isPartnerContent
                    ? '/admin/promotion/partner-content'
                    : '/admin/pages';
                router.push(redirectPath);
            } else {
                 // It's a post, so we stay on the page and update the URL
                 const newUrl = `/admin/posts/edit/${newPostData.id}`;
                 const viewUrl = await generatePostUrl(newPostData as Post);
                 
                 // Update the URL in the browser without a full reload
                 window.history.replaceState({ ...window.history.state, as: newUrl, url: newUrl }, '', newUrl);

                 // Update the component state to reflect the newly created post
                 setPost(newPostData);
                 
                 setNotification({ message: statusToSave === 'published' ? 'Post published.' : 'Post saved as draft.', url: viewUrl, type: 'success'});
            }
        }
    } catch(err) {
        console.error(err);
        setNotification({ message: 'Error saving content.', url: '#', type: 'error'});
    }
  }, [post, editorInstance, publishedDate, router, toast]);


  const handlePublish = async () => {
    await saveContent('published');
    setPublishedDate(new Date());
  }
  
  const handleMoveToTrash = async () => {
    if (post.id) {
        await saveContent('trash');
        let redirectPath = '/admin/posts';
        if (post.isPage) {
            redirectPath = '/admin/pages';
        } else if (post.isPartnerContent) {
            redirectPath = '/admin/promotion/partner-content';
        }
        router.push(redirectPath);
    } else {
        toast({ title: 'Cannot trash an unsaved post.' });
    }
  }
  
  const handlePreview = async () => {
    if (!editorInstance) return;

    const previewData = {
        ...post,
        content: editorInstance.getHTML(),
        status: 'draft',
        createdAt: publishedDate.toISOString(),
    };
    
    const path = await generatePostUrl(previewData as Post);
    
    localStorage.setItem('postPreview', JSON.stringify({ data: previewData, path }));
    window.open(path, '_blank');
  };
  
  const handleMediaInsert = (media: Media) => {
    if (editorInstance) {
        const mediaUrl = `/api/media/${media.id}/file`;
        if (media.fileType.startsWith('image/')) {
            editorInstance.chain().focus().insertContent({
                type: 'resizable-image',
                attrs: { src: mediaUrl, alt: media.altText || media.fileName },
            }).run();
        } else if (media.fileType.startsWith('video/')) {
            editorInstance.chain().focus().insertContent({
                type: 'resizable-video',
                attrs: { src: mediaUrl },
            }).run();
        } else if (media.fileType.startsWith('audio/')) {
            editorInstance.chain().focus().insertContent(`<audio controls src="${mediaUrl}"></audio>`).run();
        } else {
            editorInstance.chain().focus().insertContent(`<a href="${mediaUrl}" target="_blank">${media.fileName}</a>`).run();
        }
    }
    setIsMediaDialogOpen(false);
  };
  
  const getSeoLabelAndColor = () => {
    if (seoScore === null || !post.seo?.focusKeyphrase) return { label: 'Not available', color: 'text-muted-foreground' };
    if (seoScore >= 80) return { label: 'Good', color: 'text-green-600' };
    if (seoScore >= 50) return { label: 'Okay', color: 'text-yellow-600' };
    return { label: 'Poor', color: 'text-red-600' };
  }

  const { label: seoLabel, color: seoColor } = getSeoLabelAndColor();
  
  const visibilityText = visibility.charAt(0).toUpperCase() + visibility.slice(1);

  return (
    <>
    <div className="p-6">
        {notification && (
            <div className={cn("mb-6 p-4 rounded-md border text-sm relative", notification.type === 'success' ? 'bg-green-50 border-green-200 text-green-800' : 'bg-red-50 border-red-200 text-red-800')}>
                <div className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5" />
                    <p>
                        {notification.message}
                        {notification.type === 'success' && <Link href={notification.url} className="font-bold underline ml-2 hover:text-green-900" target="_blank">View {post.isPage ? 'Page' : 'Post'}</Link>}
                    </p>
                     <Button variant="ghost" size="icon" className="h-6 w-6 absolute top-1 right-1" onClick={() => setNotification(null)}>
                        <X className="h-4 w-4" />
                     </Button>
                </div>
            </div>
        )}
        <h1 className="text-2xl font-semibold mb-6">{pageTitle}</h1>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-9 space-y-6">
             <Card>
              <CardContent className="p-4 space-y-2">
                  <Input
                    id="title"
                    placeholder="Add title"
                    value={post.title}
                    onChange={(e) => handleValueChange('title', e.target.value)}
                    className="text-xl h-12 border-0 shadow-none focus-visible:ring-0"
                  />
                  {post.title && !post?.isPage && (
                    <div className="flex items-center gap-2 text-sm pl-2">
                        <strong className="font-semibold">Permalink:</strong>
                        <span className="text-muted-foreground">{siteUrl.endsWith('/') ? siteUrl : `${siteUrl}/`}</span>
                        <Input 
                          value={post.slug} 
                          onChange={(e) => handleValueChange('slug', e.target.value)} 
                          className="h-7 w-auto"
                        />
                         <span className="text-muted-foreground">/</span>
                    </div>
                  )}
              </CardContent>
            </Card>
            <div className="flex items-center gap-2 mb-4">
                <Button onClick={() => setIsMediaDialogOpen(true)} variant="outline">
                    <ImageIcon className="mr-2 h-4 w-4" />
                    Add Media
                </Button>
            </div>
             <RichTextEditor
                setEditorInstance={setEditorInstance}
                initialContent={post.content || ''}
            />
            <ExcerptMetabox 
                excerpt={post.excerpt || ''}
                onExcerptChange={(e) => handleValueChange('excerpt', e)} 
            />
             <DiscussionMetabox
                commentStatus={post.commentStatus || 'open'}
                pingStatus={post.pingStatus || 'open'}
                onCommentChange={(status) => handleValueChange('commentStatus', status)}
                onPingChange={(status) => handleValueChange('pingStatus', status)}
             />
             <AuthorMetabox
                allUsers={allUsers}
                selectedAuthorId={post.authorId || ''}
                onAuthorChange={(id) => handleValueChange('authorId', id)}
                slug={post.slug || ''}
                onSlugChange={(slug) => handleValueChange('slug', slug)}
                isPage={!!post.isPage}
             />
            <SeoMetabox 
                siteUrl={siteUrl}
                post={post}
                onSeoChange={handleSeoChange}
                onSeoScoreChange={setSeoScore}
                currentUrl={currentUrl}
            />
          </div>
          <div className="lg:col-span-3 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base font-semibold">Publish</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                 <div className="flex items-center justify-between">
                    <Button variant="outline" size="sm" onClick={() => saveContent('draft')}><Save className="mr-2 h-4 w-4" /> Save Draft</Button>
                    <Button variant="outline" size="sm" onClick={handlePreview}>Preview</Button>
                </div>
                <Separator/>
                <div className="space-y-3 text-sm">
                   <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2">
                        <KeyRound className="h-4 w-4 text-muted-foreground"/> 
                        <Label>Status:</Label> 
                        <span className="font-semibold">{post.status?.charAt(0).toUpperCase() + post.status!.slice(1)}</span>
                      </div>
                      <Button variant="link" size="sm" className="p-0 h-auto" onClick={() => setIsEditingStatus(!isEditingStatus)}>Edit</Button>
                   </div>
                   {isEditingStatus && (
                     <div className="p-2 border rounded-md space-y-2">
                        <Select value={post.status} onValueChange={(v) => handleValueChange('status', v)}>
                            <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
                            <SelectContent>
                                <SelectItem value="published">Published</SelectItem>
                                <SelectItem value="draft">Draft</SelectItem>
                                <SelectItem value="pending">Pending Review</SelectItem>
                            </SelectContent>
                        </Select>
                        <div className="flex justify-end gap-2">
                            <Button size="sm" variant="secondary" onClick={() => setIsEditingStatus(false)}>OK</Button>
                            <Button size="sm" variant="link" onClick={() => setIsEditingStatus(false)}>Cancel</Button>
                        </div>
                     </div>
                   )}
                   <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2">
                         <Eye className="h-4 w-4 text-muted-foreground"/> 
                         <Label>Visibility:</Label> 
                         <span className="font-semibold">{visibilityText}</span>
                      </div>
                      <Button variant="link" size="sm" className="p-0 h-auto" onClick={() => setIsEditingVisibility(!isEditingVisibility)}>Edit</Button>
                   </div>
                   {isEditingVisibility && (
                     <div className="p-2 border rounded-md space-y-2">
                        <RadioGroup value={visibility} onValueChange={(v:any) => setVisibility(v)}>
                            <div className="flex items-center space-x-2">
                                <RadioGroupItem value="public" id="vis-public" />
                                <Label htmlFor="vis-public" className="font-normal">Public</Label>
                            </div>
                             <div className="flex items-center space-x-2">
                                <RadioGroupItem value="private" id="vis-private" />
                                <Label htmlFor="vis-private" className="font-normal">Private</Label>
                            </div>
                             <div className="flex items-center space-x-2">
                                <RadioGroupItem value="password" id="vis-password" />
                                <Label htmlFor="vis-password" className="font-normal">Password protected</Label>
                            </div>
                        </RadioGroup>
                         {visibility === 'password' && (
                            <div className="space-y-1 pl-6">
                                <Label htmlFor="post-password">Password</Label>
                                <Input id="post-password" type="text" value={password} onChange={(e) => setPassword(e.target.value)} className="h-8"/>
                            </div>
                         )}
                        <div className="flex justify-end gap-2">
                            <Button size="sm" variant="secondary" onClick={() => setIsEditingVisibility(false)}>OK</Button>
                            <Button size="sm" variant="link" onClick={() => setIsEditingVisibility(false)}>Cancel</Button>
                        </div>
                     </div>
                   )}
                   <div className="flex items-start justify-between">
                        <div className="flex items-center gap-2">
                          <CalendarIcon className="h-4 w-4 text-muted-foreground"/> 
                          <Label>{isPublished ? 'Published on:' : 'Publish:'}</Label> 
                        </div>
                        <Button variant="link" size="sm" className="p-0 h-auto" onClick={() => setIsEditingDate(!isEditingDate)}>Edit</Button>
                   </div>
                    <p className="font-semibold -mt-2">{formattedPublishedDate || '...'}</p>

                    {isEditingDate && (
                       <div className="p-2 border rounded-md space-y-2">
                            <div className="flex items-center gap-2 flex-wrap">
                                <Select value={tempDate.month} onValueChange={(v) => setTempDate({...tempDate, month: v})}>
                                    <SelectTrigger className="h-8 w-20"><SelectValue /></SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="Jan">Jan</SelectItem>
                                        <SelectItem value="Feb">Feb</SelectItem>
                                        <SelectItem value="Mar">Mar</SelectItem>
                                        <SelectItem value="Apr">Apr</SelectItem>
                                        <SelectItem value="May">May</SelectItem>
                                        <SelectItem value="Jun">Jun</SelectItem>
                                        <SelectItem value="Jul">Jul</SelectItem>
                                        <SelectItem value="Aug">Aug</SelectItem>
                                        <SelectItem value="Sep">Sep</SelectItem>
                                        <SelectItem value="Oct">Oct</SelectItem>
                                        <SelectItem value="Nov">Nov</SelectItem>
                                        <SelectItem value="Dec">Dec</SelectItem>
                                    </SelectContent>
                                </Select>
                                <Input value={tempDate.day} onChange={(e) => setTempDate({...tempDate, day: e.target.value})} className="w-12 h-8" maxLength={2} />,
                                <Input value={tempDate.year} onChange={(e) => setTempDate({...tempDate, year: e.target.value})} className="w-16 h-8" maxLength={4} /> at
                                <Input value={tempDate.hour} onChange={(e) => setTempDate({...tempDate, hour: e.target.value})} className="w-12 h-8" maxLength={2} /> :
                                <Input value={tempDate.minute} onChange={(e) => setTempDate({...tempDate, minute: e.target.value})} className="w-12 h-8" maxLength={2} />
                            </div>
                            <div className="flex justify-end gap-2">
                               <Button size="sm" variant="secondary" onClick={handleSaveDate}>OK</Button>
                               <Button size="sm" variant="link" onClick={() => setIsEditingDate(false)}>Cancel</Button>
                            </div>
                       </div>
                    )}
                    <div className="flex items-center gap-2">
                        <TrendingUp className="h-4 w-4 text-muted-foreground" /> Digiotic SEO: <span className={cn("font-semibold", seoColor)}>{seoLabel}</span>
                    </div>
                </div>
              </CardContent>
               <CardFooter className="flex justify-between items-center bg-muted/50 p-3">
                 <Button variant="link" className="text-destructive p-0 h-auto" onClick={handleMoveToTrash}><Trash2 className="mr-2 h-4 w-4"/> Move to trash</Button>
                 {isPublished ? (
                    <Button onClick={() => saveContent('published')}>Update</Button>
                 ): (
                    <Button onClick={handlePublish}><Send className="mr-2 h-4 w-4" /> Publish</Button>
                 )}
              </CardFooter>
            </Card>
            <FeaturedImageMetabox 
                image={post.featuredImage || null} 
                onImageChange={(img) => handleValueChange('featuredImage', img)} 
            />
            {post.isPage && !post.isPartnerContent ? (
                <PageAttributesMetabox
                    selectedTemplate={post.template || 'default'}
                    onTemplateChange={(template) => handleValueChange('template', template)}
                    allPages={allPages}
                    selectedParent={post.parent || 'none'}
                    onParentChange={(parent) => handleValueChange('parent', parent)}
                />
            ) : !post.isPartnerContent && (
                <>
                    <FormatMetabox
                        selectedFormat={post.format || 'standard'}
                        onFormatChange={(format) => handleValueChange('format', format)}
                    />
                    <CategoriesMetabox 
                        selectedCategories={post.categories || []} 
                        onCategoryChange={(cat) => handleValueChange('categories', post.categories?.includes(cat) ? post.categories.filter(c => c !== cat) : [...(post.categories || []), cat] )}
                    />
                    <TagsMetabox 
                        tags={post.tags || []} 
                        onTagsChange={(t) => handleValueChange('tags', t)} 
                    />
                </>
            )}
          </div>
        </div>
    </div>
     <MediaLibraryModal 
        isOpen={isMediaDialogOpen}
        onOpenChange={setIsMediaDialogOpen}
        onSelect={handleMediaInsert}
    />
    </>
  );
}
