
'use client';

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";

type DiscussionMetaboxProps = {
    commentStatus: 'open' | 'closed';
    pingStatus: 'open' | 'closed';
    onCommentChange: (status: 'open' | 'closed') => void;
    onPingChange: (status: 'open' | 'closed') => void;
};

export default function DiscussionMetabox({
    commentStatus,
    pingStatus,
    onCommentChange,
    onPingChange
}: DiscussionMetaboxProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base font-semibold">Discussion</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center space-x-2">
            <Checkbox 
                id="allow-comments"
                checked={commentStatus === 'open'}
                onCheckedChange={(checked) => onCommentChange(checked ? 'open' : 'closed')}
            />
            <Label htmlFor="allow-comments" className="font-normal">Allow comments</Label>
        </div>
         <div className="flex items-center space-x-2">
            <Checkbox 
                id="allow-pings"
                checked={pingStatus === 'open'}
                onCheckedChange={(checked) => onPingChange(checked ? 'open' : 'closed')}
            />
            <Label htmlFor="allow-pings" className="font-normal">Allow trackbacks and pingbacks</Label>
        </div>
      </CardContent>
    </Card>
  );
}
