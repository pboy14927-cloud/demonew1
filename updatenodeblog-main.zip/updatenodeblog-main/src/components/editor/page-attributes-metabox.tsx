
'use client';

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import type { Post } from "@/lib/data";

type PageAttributesMetaboxProps = {
    selectedTemplate: string;
    onTemplateChange: (template: string) => void;
    allPages: Post[];
    selectedParent: string;
    onParentChange: (parentId: string) => void;
};

export default function PageAttributesMetabox({ selectedTemplate, onTemplateChange, allPages, selectedParent, onParentChange }: PageAttributesMetaboxProps) {
  return (
    <Card>
        <CardHeader>
            <CardTitle className="text-base font-semibold">Page Attributes</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
             <div className="space-y-1">
                <Label htmlFor="parent_id">Parent Page</Label>
                <Select value={selectedParent} onValueChange={onParentChange}>
                    <SelectTrigger id="parent_id">
                        <SelectValue placeholder="(no parent)" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="none">(no parent)</SelectItem>
                        {allPages.map(page => (
                            <SelectItem key={page.id} value={page.id}>{page.title}</SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </div>
             <div className="space-y-1">
                <Label htmlFor="template">Template</Label>
                <Select value={selectedTemplate || 'default'} onValueChange={onTemplateChange}>
                    <SelectTrigger id="template">
                        <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="default">Default Template</SelectItem>
                        <SelectItem value="full-width">Full Width Page</SelectItem>
                        <SelectItem value="full-width-no-title">Full Width (No Title)</SelectItem>
                        <SelectItem value="blog">Blog</SelectItem>
                        <SelectItem value="with-sidebar">Page with Sidebar</SelectItem>
                        <SelectItem value="partner">Partner Page</SelectItem>
                        <SelectItem value="homepage">Homepage</SelectItem>
                        <SelectItem value="homepage-sidebar">Homepage with Sidebar</SelectItem>
                    </SelectContent>
                </Select>
            </div>
        </CardContent>
    </Card>
  );
}
