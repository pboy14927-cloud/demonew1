
'use client';

import React, { useRef } from 'react';
import { NodeViewWrapper, NodeViewProps } from '@tiptap/react';
import { cn } from '@/lib/utils';

const ResizableImageComponent: React.FC<NodeViewProps> = ({ node, updateAttributes, editor }) => {
  const imgRef = useRef<HTMLImageElement>(null);

  const { align, ...rest } = node.attrs;

  const wrapperClassName = cn(
    'resizable-image-wrapper',
    'group',
    'relative',
    'inline-block',
  );

  return (
    <NodeViewWrapper
        as="span"
        className={wrapperClassName}
        data-align={align}
    >
      <img
        {...rest}
        ref={imgRef}
        className={cn({ 'mx-auto': align === 'center' })}
        style={{
            width: typeof node.attrs.width === 'number' ? `${node.attrs.width}px` : node.attrs.width,
        }}
        draggable="true"
        data-drag-handle
      />
    </NodeViewWrapper>
  );
};

export default ResizableImageComponent;
