
'use server';

import { getPosts, getBrandingSettings, generatePostUrl, getSitemapSettings } from '@/lib/data';
import { Post } from '@/lib/data';

async function generateSiteMap(posts: Post[]) {
  const brandingSettings = await getBrandingSettings();
  const sitemapSettings = await getSitemapSettings();
  const priority = sitemapSettings.priority.postTypes.priority;
  const frequency = sitemapSettings.priority.postTypes.frequency;
  const URL = brandingSettings.siteUrl.endsWith('/') ? brandingSettings.siteUrl.slice(0, -1) : brandingSettings.siteUrl;

  return `<?xml version="1.0" encoding="UTF-8"?>
<?xml-stylesheet type="text/xsl" href="/sitemap.xsl"?>
   <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
      <config>
        <siteUrl>${URL}</siteUrl>
      </config>
     ${(await Promise.all(posts.map(async (post) => {
         const url = await generatePostUrl(post);
         const lastmodDate = new Date(post.createdAt);
         const isoLastMod = !isNaN(lastmodDate.getTime()) ? lastmodDate.toISOString() : new Date().toISOString();
         return `
           <url>
               <loc>${`${URL}${url}`}</loc>
                <lastmod>${isoLastMod}</lastmod>
                <changefreq>${frequency}</changefreq>
                <priority>${priority}</priority>
           </url>
         `;
       }))).join('')}
   </urlset>
 `;
}

export async function GET() {
    const posts = await getPosts();
    const publishedPosts = posts.filter(p => p.status === 'published' && !p.isPage && !p.isPartnerContent);
    const body = await generateSiteMap(publishedPosts);

    return new Response(body, {
        status: 200,
        headers: {
        'Content-Type': 'application/xml',
        },
    });
}
