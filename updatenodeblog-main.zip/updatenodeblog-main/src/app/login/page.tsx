
'use client';

import Link from 'next/link';
import { PenSquare } from 'lucide-react';
import LoginForm from '@/components/auth/login-form';
import { getBrandingSettings } from '@/lib/data';
import { useEffect, useState } from 'react';
import { Skeleton } from '@/components/ui/skeleton';

type BrandingSettings = {
    websiteTitle: string;
    logoUrl?: string;
    logoWidth?: number;
    siteUrl: string;
}

export default function LoginPage() {
    const [settings, setSettings] = useState<BrandingSettings | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        getBrandingSettings().then(s => {
            setSettings(s as BrandingSettings);
            setLoading(false);
        });
    }, []);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <div className="w-full max-w-md">
        <div className="flex justify-center mb-8 h-10 items-center">
            {loading ? (
                 <Skeleton className="h-8 w-48" />
            ) : (
                <Link href="/" className="flex items-center space-x-2">
                    {settings?.logoUrl ? (
                        <img src={settings.logoUrl.startsWith('/api') ? `${settings.siteUrl}${settings.logoUrl}` : settings.logoUrl} alt={settings.websiteTitle} style={{ width: `${settings.logoWidth || 150}px` }} />
                    ) : (
                        <>
                            <PenSquare className="h-8 w-8 text-primary" />
                            <span className="text-2xl font-bold font-headline">{settings?.websiteTitle}</span>
                        </>
                    )}
                </Link>
            )}
        </div>
        <LoginForm />
        <div className="mt-4 text-center text-sm text-muted-foreground">
          <p>
            <Link href="/" className="underline hover:text-primary">
              ← Back to website
            </Link>
          </p>
           <p className="mt-2">
            No account yet?{' '}
            <Link href="/register" className="underline hover:text-primary">
              Register here
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
