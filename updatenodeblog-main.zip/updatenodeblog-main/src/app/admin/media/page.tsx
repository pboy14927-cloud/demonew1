
'use client';

import React, { useState, useMemo, useEffect } from 'react';
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { getMedia, Media, getUserById } from "@/lib/data";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import MediaCard from '@/components/admin/media-card';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import MediaDetailsModal from '@/components/admin/media-details-modal';
import { Grid, List } from 'lucide-react';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import Image from 'next/image';
import { DataTablePagination } from '@/components/admin/data-table-pagination';

function MediaTableRow({ item, onCardClick, onDeleteMedia, onSelect, isSelected }: { item: Media, onCardClick: (item: Media) => void, onDeleteMedia: (id: string) => void, onSelect: (id: string) => void, isSelected: boolean }) {
    const [author, setAuthor] = React.useState<any>(null);

    useEffect(() => {
        if (item.uploadedBy) {
            getUserById(item.uploadedBy).then(setAuthor);
        }
    }, [item.uploadedBy]);

    return (
        <TableRow key={item.id} className="group" data-state={isSelected ? "selected" : "deselected"}>
            <TableCell>
                <Checkbox
                    checked={isSelected}
                    onCheckedChange={() => onSelect(item.id)}
                />
            </TableCell>
            <TableCell className="font-medium">
                <div className="flex items-center gap-2">
                    <Image src={item.url} alt={item.altText} width={48} height={48} data-ai-hint="uploaded media" className="w-12 h-12 object-cover rounded-sm" />
                    <div>
                        <button onClick={() => onCardClick(item)} className="font-semibold text-primary hover:underline">{item.fileName}</button>
                        <div className="text-xs text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity space-x-1">
                            <button onClick={() => onCardClick(item)} className="text-primary hover:underline">Edit</button>
                            <span className="text-muted-foreground">|</span>
                            <AlertDialog>
                                <AlertDialogTrigger asChild>
                                     <button className="text-destructive hover:underline">Delete Permanently</button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                    <AlertDialogHeader>
                                    <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                                    <AlertDialogDescription>
                                        This action cannot be undone. This will permanently delete the media file.
                                    </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                                    <AlertDialogAction onClick={() => onDeleteMedia(item.id)}>Delete</AlertDialogAction>
                                    </AlertDialogFooter>
                                </AlertDialogContent>
                            </AlertDialog>
                            <span className="text-muted-foreground">|</span>
                            <a href={item.url} target="_blank" className="text-primary hover:underline">View</a>
                        </div>
                    </div>
                </div>
            </TableCell>
            <TableCell>{author?.name || 'Unknown'}</TableCell>
            <TableCell>(Unattached)</TableCell>
            <TableCell>{new Date(item.createdAt).toLocaleDateString()}</TableCell>
        </TableRow>
    )
}


export default function MediaLibraryPage() {
  const [allMedia, setAllMedia] = useState<(Media & { selected?: boolean})[]>([]);
  const [isBulkDeleteAlertOpen, setIsBulkDeleteAlertOpen] = useState(false);
  const [selectedMedia, setSelectedMedia] = useState<Media | null>(null);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const { toast } = useToast();
  
  // Filtering state
  const [typeFilter, setTypeFilter] = useState('all');
  const [dateFilter, setDateFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  // Pagination state
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(24);

  const fetchMedia = () => {
     getMedia().then(media => setAllMedia(media.map(m => ({...m, selected: false}))));
  }

  useEffect(() => {
    fetchMedia();
  }, []);

  const availableDates = useMemo(() => {
      const dates = new Set(allMedia.map(item => {
          const d = new Date(item.createdAt);
          return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      }));
      return Array.from(dates).map(dateStr => {
          const [year, month] = dateStr.split('-');
          const dateObj = new Date(parseInt(year), parseInt(month) - 1);
          return {
              value: dateStr,
              label: dateObj.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })
          }
      });
  }, [allMedia]);

  const filteredMediaItems = useMemo(() => {
      return allMedia
        .filter(item => {
            if (typeFilter === 'all') return true;
            if (typeFilter === 'documents') return ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'].includes(item.fileType);
             if (typeFilter === 'archives') return ['application/zip', 'application/x-rar-compressed'].includes(item.fileType);
            return item.fileType.startsWith(`${typeFilter}/`);
        })
        .filter(item => {
            if (dateFilter === 'all') return true;
            const itemDate = new Date(item.createdAt);
            const [year, month] = dateFilter.split('-');
            return itemDate.getFullYear() === parseInt(year) && itemDate.getMonth() === parseInt(month) - 1;
        })
        .filter(item => 
            item.fileName.toLowerCase().includes(searchTerm.toLowerCase()) || 
            (item.altText && item.altText.toLowerCase().includes(searchTerm.toLowerCase()))
        );
  }, [allMedia, typeFilter, dateFilter, searchTerm]);
  
  const paginatedMedia = useMemo(() => {
    const startIndex = (page - 1) * pageSize;
    return filteredMediaItems.slice(startIndex, startIndex + pageSize);
  }, [filteredMediaItems, page, pageSize]);

  const totalPages = Math.ceil(filteredMediaItems.length / pageSize);

  useEffect(() => {
    setPage(1);
  }, [typeFilter, dateFilter, searchTerm, pageSize]);

  const selectedItems = useMemo(() => allMedia.filter(item => item.selected), [allMedia]);

  const toggleSelect = (id: string) => {
    setAllMedia(items =>
      items.map(item =>
        item.id === id ? { ...item, selected: !item.selected } : item
      )
    );
  };

  const toggleSelectAll = (checked: boolean) => {
     setAllMedia(items => items.map(i => {
         const itemsToToggle = paginatedMedia;
         if (itemsToToggle.some(fi => fi.id === i.id)) {
             return {...i, selected: checked }
         }
         return i;
     }));
  };
  
  const handleBulkDelete = async () => {
    const itemsToDelete = selectedItems.map(item => item.id);
    if (itemsToDelete.length === 0) return;

    try {
        await Promise.all(itemsToDelete.map(id => 
            fetch(`/api/media/${id}`, { method: 'DELETE' })
        ));
        toast({ title: `${itemsToDelete.length} media item(s) deleted.`});
        fetchMedia(); // Refetch media after deletion
    } catch (error) {
        toast({ variant: 'destructive', title: 'Error deleting media.'});
    } finally {
        setIsBulkDeleteAlertOpen(false);
    }
  };

  const handleCardClick = (mediaItem: Media) => {
      setSelectedMedia(mediaItem);
  }

  const handleUpdateMedia = (updatedMedia: Media) => {
      setAllMedia(prev => prev.map(m => m.id === updatedMedia.id ? updatedMedia : m));
      setSelectedMedia(updatedMedia);
  }

  const handleDeleteMedia = async (mediaId: string) => {
      try {
          const response = await fetch(`/api/media/${mediaId}`, { method: 'DELETE' });
          if (!response.ok) throw new Error('Failed to delete');
          toast({ title: 'Media item deleted.'});
          fetchMedia();
          if (selectedMedia?.id === mediaId) {
              setSelectedMedia(null);
          }
      } catch (error) {
          toast({ variant: 'destructive', title: 'Error deleting media.'});
      }
  }
  
  const selectedCount = paginatedMedia.filter(p => p.selected).length;
  const totalCount = paginatedMedia.length;
  const isAllSelected = selectedCount > 0 && selectedCount === totalCount;
  const isIndeterminate = selectedCount > 0 && selectedCount < totalCount;

  return (
    <>
      <main className="p-6">
        <div className='flex items-center justify-between pb-4'>
            <h1 className="text-2xl font-semibold">Media Library</h1>
            <Button asChild>
                <Link href="/admin/media/new">Add New</Link>
            </Button>
        </div>

        <div className="flex items-center justify-between pb-4 gap-4">
             <div className="flex items-center gap-2">
                 <ToggleGroup type="single" value={viewMode} onValueChange={(value) => value && setViewMode(value as any)} aria-label="View mode">
                    <ToggleGroupItem value="grid" aria-label="Grid view">
                        <Grid className="h-4 w-4" />
                    </ToggleGroupItem>
                    <ToggleGroupItem value="list" aria-label="List view">
                        <List className="h-4 w-4" />
                    </ToggleGroupItem>
                </ToggleGroup>

                 <Select value={typeFilter} onValueChange={setTypeFilter}>
                    <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Filter by type" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="all">All media items</SelectItem>
                        <SelectItem value="image">Images</SelectItem>
                        <SelectItem value="video">Video</SelectItem>
                        <SelectItem value="audio">Audio</SelectItem>
                        <SelectItem value="documents">Documents</SelectItem>
                        <SelectItem value="archives">Archives</SelectItem>
                    </SelectContent>
                </Select>
                 <Select value={dateFilter} onValueChange={setDateFilter}>
                    <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Filter by date" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="all">All dates</SelectItem>
                        {availableDates.map(date => (
                            <SelectItem key={date.value} value={date.value}>{date.label}</SelectItem>
                        ))}
                    </SelectContent>
                </Select>
                {selectedItems.length > 0 && (
                  <AlertDialog open={isBulkDeleteAlertOpen} onOpenChange={setIsBulkDeleteAlertOpen}>
                    <AlertDialogTrigger asChild>
                       <Button variant="destructive">Delete ({selectedItems.length})</Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                        <AlertDialogHeader>
                        <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                        <AlertDialogDescription>
                            You are about to permanently delete {selectedItems.length} media item(s). This action cannot be undone.
                        </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={handleBulkDelete}>Yes, delete</AlertDialogAction>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                   </AlertDialog>
                )}
            </div>
            <div className="w-full max-w-sm">
                <Input 
                    placeholder="Search media..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>
        </div>
        
        <DataTablePagination
            className="pb-4"
            currentPage={page}
            totalPages={totalPages}
            onPageChange={setPage}
            pageSize={pageSize}
            onPageSizeChange={setPageSize}
            itemCount={filteredMediaItems.length}
        />
        
        {viewMode === 'grid' ? (
            <>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-8 gap-4">
                {paginatedMedia.map((item) => (
                    <MediaCard 
                        key={item.id} 
                        media={item} 
                        isSelected={!!item.selected}
                        onSelect={(e:any) => { e.stopPropagation(); toggleSelect(item.id); }}
                        onClick={() => handleCardClick(item)}
                    />
                ))}
                </div>
            </>
        ) : (
             <div className="border rounded-lg mt-4">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[40px]">
                           <Checkbox 
                                checked={isAllSelected}
                                onCheckedChange={(checked) => toggleSelectAll(Boolean(checked))}
                                aria-label="Select all"
                                data-state={isIndeterminate ? 'indeterminate' : (isAllSelected ? 'checked' : 'unchecked')}
                            />
                        </TableHead>
                        <TableHead>File</TableHead>
                        <TableHead>Author</TableHead>
                        <TableHead>Uploaded to</TableHead>
                        <TableHead>Date</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                        {paginatedMedia.map((item) => (
                           <MediaTableRow
                             key={item.id}
                             item={item}
                             isSelected={!!item.selected}
                             onSelect={toggleSelect}
                             onCardClick={handleCardClick}
                             onDeleteMedia={handleDeleteMedia}
                           />
                        ))}
                    </TableBody>
                  </Table>
             </div>
        )}
        
        <DataTablePagination
            className="mt-4"
            currentPage={page}
            totalPages={totalPages}
            onPageChange={setPage}
            pageSize={pageSize}
            onPageSizeChange={setPageSize}
            itemCount={filteredMediaItems.length}
        />

      </main>
      {selectedMedia && (
        <MediaDetailsModal
            media={selectedMedia}
            isOpen={!!selectedMedia}
            onOpenChange={() => setSelectedMedia(null)}
            onUpdate={handleUpdateMedia}
            onDelete={handleDeleteMedia}
        />
      )}
    </>
  );
}
