
'use client';

import React, { useState, useRef, useCallback } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import Link from "next/link";
import { useToast } from '@/hooks/use-toast';
import { UploadCloud, File as FileIcon, Loader2, CheckCircle, AlertCircle, Trash2 } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { useRouter } from 'next/navigation';
import { cn } from '@/lib/utils';
import { useSession } from 'next-auth/react';
import Image from 'next/image';

type UploadStatus = 'pending' | 'uploading' | 'success' | 'error';

type UploadableFile = {
    id: string;
    file: File;
    status: UploadStatus;
    progress: number;
    previewUrl?: string;
    error?: string;
}

export default function NewMediaPage() {
    const router = useRouter();
    const { toast } = useToast();
    const { data: session } = useSession();
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [files, setFiles] = useState<UploadableFile[]>([]);
    const [isDragging, setIsDragging] = useState(false);

    const handleFileSelect = (selectedFiles: FileList | null) => {
        if (!selectedFiles) return;

        const newFiles = Array.from(selectedFiles).map(file => {
            const newFile: UploadableFile = {
                id: `${file.name}-${file.lastModified}`,
                file,
                status: 'pending' as UploadStatus,
                progress: 0,
            };
            if (file.type.startsWith('image/')) {
                newFile.previewUrl = URL.createObjectURL(file);
            }
            return newFile;
        });
        
        setFiles(prev => [...prev, ...newFiles]);
        startUpload(newFiles);
    };

    const startUpload = async (filesToUpload: UploadableFile[]) => {
        for (const uploadableFile of filesToUpload) {
            setFiles(prev => prev.map(f => f.id === uploadableFile.id ? { ...f, status: 'uploading' as UploadStatus } : f));
            
            try {
                const formData = new FormData();
                formData.append('file', uploadableFile.file);
                
                const response = await fetch('/api/media', {
                    method: 'POST',
                    body: formData,
                });

                if (!response.ok) {
                    let errorData;
                    try {
                        errorData = await response.json();
                    } catch {
                        errorData = { message: `Upload failed with status: ${response.statusText}` };
                    }
                    throw new Error(errorData.message || 'Upload failed');
                }
                
                const newMedia = await response.json();
                
                setFiles(prev => prev.map(f => f.id === uploadableFile.id ? { ...f, status: 'success' as UploadStatus, progress: 100 } : f));

            } catch (error: any) {
                setFiles(prev => prev.map(f => f.id === uploadableFile.id ? { ...f, status: 'error' as UploadStatus, error: error.message } : f));
            }
        }
    }

    const handleDragEnter = (e: React.DragEvent) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(true);
    };

    const handleDragLeave = (e: React.DragEvent) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);
    };


    const handleDrop = (e: React.DragEvent) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);
        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
            handleFileSelect(e.dataTransfer.files);
            e.dataTransfer.clearData();
        }
    };
    
    const removeFile = (id: string) => {
        setFiles(prev => prev.filter(f => f.id !== id));
    };


  return (
    <>
      <main className="p-6">
        <h1 className="text-2xl font-semibold mb-6">Upload New Media</h1>
        <Card 
            className={cn("border-dashed border-2 transition-colors", isDragging && "border-primary bg-primary/10")}
            onDragEnter={handleDragEnter}
            onDragLeave={handleDragLeave}
            onDragOver={handleDragEnter}
            onDrop={handleDrop}
        >
            <CardContent className="p-12 text-center">
                 <div className="flex flex-col items-center justify-center space-y-4">
                    <UploadCloud className="h-12 w-12 text-muted-foreground" />
                    <p className="text-xl text-muted-foreground">Drop files to upload</p>
                    <p className="text-muted-foreground">or</p>
                    <Button type="button" onClick={() => fileInputRef.current?.click()}>Select Files</Button>
                    <Input 
                        ref={fileInputRef}
                        type="file" 
                        className="hidden" 
                        multiple 
                        onChange={(e) => handleFileSelect(e.target.files)}
                    />
                 </div>
            </CardContent>
        </Card>
        <p className="text-sm text-muted-foreground mt-4">
            Maximum upload file size: 2 GB.
        </p>

        {files.length > 0 && (
            <div className="mt-8">
                <h2 className="text-lg font-semibold mb-4">Uploads</h2>
                <div className="space-y-4 max-h-96 overflow-y-auto pr-4">
                    {files.map(uploadableFile => (
                        <div key={uploadableFile.id} className="p-4 border rounded-lg flex items-center gap-4">
                           {uploadableFile.previewUrl ? (
                                <Image src={uploadableFile.previewUrl} alt={uploadableFile.file.name} width={48} height={48} className="h-12 w-12 object-cover rounded-md flex-shrink-0" />
                            ) : (
                                <FileIcon className="h-8 w-8 text-muted-foreground flex-shrink-0"/>
                            )}
                            <div className="flex-1 overflow-hidden">
                                <p className="font-semibold truncate">{uploadableFile.file.name}</p>
                                <p className="text-xs text-muted-foreground">{Math.round(uploadableFile.file.size / 1024)} KB</p>
                                {uploadableFile.status === 'uploading' && <Progress value={uploadableFile.progress} className="h-2 flex-1 mt-1" />}
                                {uploadableFile.status === 'error' && <p className="text-xs text-destructive mt-1">{uploadableFile.error}</p>}
                            </div>
                            <div className="flex items-center gap-2">
                                {uploadableFile.status === 'pending' && <Loader2 className="h-5 w-5 text-muted-foreground" />}
                                {uploadableFile.status === 'uploading' && <Loader2 className="h-5 w-5 animate-spin" />}
                                {uploadableFile.status === 'success' && <CheckCircle className="h-5 w-5 text-green-500" />}
                                {uploadableFile.status === 'error' && <AlertCircle className="h-5 w-5 text-destructive" />}
                                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => removeFile(uploadableFile.id)}><Trash2 className="h-4 w-4" /></Button>
                            </div>
                        </div>
                    ))}
                </div>
                 <Button className="mt-6" onClick={() => router.push('/admin/media')}>Go to Media Library</Button>
            </div>
        )}
      </main>
    </>
  );
}
