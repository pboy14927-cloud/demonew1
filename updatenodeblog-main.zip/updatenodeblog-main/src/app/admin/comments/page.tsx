
'use client';

import React, { useState, useMemo, useEffect } from 'react';
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { getComments, Comment, updateCommentStatus, deleteComment, updateCommentContent } from "@/lib/data";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useSession } from 'next-auth/react';
import { DataTablePagination } from '@/components/admin/data-table-pagination';


type CommentWithSelection = Comment & { selected?: boolean };

export default function AdminCommentsPage() {
  const [allComments, setAllComments] = useState<CommentWithSelection[]>([]);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState('');
  const [bulkAction, setBulkAction] = useState('');
  
  const [editingComment, setEditingComment] = useState<Comment | null>(null);
  const [replyingToComment, setReplyingToComment] = useState<Comment | null>(null);
  const [editText, setEditText] = useState('');
  const [replyText, setReplyText] = useState('');
  const { toast } = useToast();
  const { data: session } = useSession();

  // Pagination State
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  
  const fetchComments = () => {
      getComments().then(comments => setAllComments(comments.map(c => ({...c, selected: false}))));
  }

  useEffect(() => {
    fetchComments();
  }, []);

  const filteredComments = useMemo(() => {
    return allComments
      .filter((comment) => {
        if (statusFilter === "all") return true;
        if (statusFilter === 'mine') return comment.author.id === (session?.user as any)?.id;
        if (statusFilter === 'pending') return comment.status === 'pending';
        if (statusFilter === 'approved') return comment.status === 'approved';
        if (statusFilter === 'spam') return comment.status === 'spam';
        if (statusFilter === 'trash') return comment.status === 'trash';
        return true;
      })
      .filter((comment) => 
        comment.author.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        comment.content.toLowerCase().includes(searchTerm.toLowerCase())
      );
  }, [allComments, statusFilter, searchTerm, session]);

    const paginatedComments = useMemo(() => {
      const startIndex = (page - 1) * pageSize;
      return filteredComments.slice(startIndex, startIndex + pageSize);
  }, [filteredComments, page, pageSize]);

  const totalPages = Math.ceil(filteredComments.length / pageSize);

  useEffect(() => {
    setPage(1);
  }, [statusFilter, searchTerm, pageSize]);

  const statusCounts = useMemo(() => {
    const counts: Record<string, number> = { all: 0, mine: 0, pending: 0, approved: 0, spam: 0, trash: 0 };
    const currentUserId = (session?.user as any)?.id;

    for (const comment of allComments) {
        counts.all++;
        if (comment.author.id === currentUserId) counts.mine++;
        if (comment.status in counts) {
          counts[comment.status]++;
        }
    }
    return counts;
  }, [allComments, session]);


  const handleStatusChange = async (status: CommentStatus, commentIds: string[]) => {
     try {
        await Promise.all(commentIds.map(id => updateCommentStatus(id, status)));
        toast({ title: "Comments updated" });
        fetchComments();
    } catch(e) {
        toast({ variant: 'destructive', title: "Error updating comments" });
    }
  };

  const handleDelete = async (commentIds: string[]) => {
      try {
        await Promise.all(commentIds.map(id => deleteComment(id)));
        toast({ title: "Comments deleted" });
        fetchComments();
    } catch(e) {
        toast({ variant: 'destructive', title: "Error deleting comments" });
    }
  }
  
  const applyBulkAction = () => {
    const selectedIds = allComments.filter(c => c.selected).map(c => c.id);
    if(selectedIds.length === 0 || !bulkAction) return;

    if(bulkAction === 'approve') handleStatusChange('approved', selectedIds);
    else if(bulkAction === 'unapprove') handleStatusChange('pending', selectedIds);
    else if (bulkAction === 'spam') handleStatusChange('spam', selectedIds);
    else if (bulkAction === 'trash') handleStatusChange('trash', selectedIds);
    else if (bulkAction === 'delete_permanently') handleDelete(selectedIds);
    
    setBulkAction('');
  };

  const toggleSelectAll = (checked: boolean) => {
     setAllComments(comments => comments.map(c => {
        if(paginatedComments.some(pc => pc.id === c.id)) {
            return {...c, selected: checked }
        }
        return c;
     }));
  }

  const toggleSelect = (commentId: string) => {
     setAllComments(comments => comments.map(c => c.id === commentId ? { ...c, selected: !c.selected } : c));
  }
  
  const handleEditClick = (comment: Comment) => {
    setEditingComment(comment);
    setEditText(comment.content);
  }

  const handleReplyClick = (comment: Comment) => {
    setReplyingToComment(comment);
  }
  
  const handleSaveChanges = async () => {
    if(!editingComment) return;
    try {
        await updateCommentContent(editingComment.id, editText);
        toast({ title: "Comment updated." });
        setEditingComment(null);
        setEditText('');
        fetchComments();
    } catch {
        toast({ variant: 'destructive', title: "Error updating comment." });
    }
  }

  const handleSendReply = async () => {
    if(!replyingToComment || !replyText || !session?.user) return;
     try {
        // In a real app, you would create a new comment record here
        console.log(`Replying to ${replyingToComment.id} with: ${replyText}`);
        toast({ title: "Reply sent." });
        setReplyingToComment(null);
        setReplyText('');
        fetchComments();
    } catch {
        toast({ variant: 'destructive', title: "Error sending reply." });
    }
  }


  const selectedCount = paginatedComments.filter(p => p.selected).length;
  const isAllSelected = selectedCount > 0 && selectedCount === paginatedComments.length;
  const isIndeterminate = selectedCount > 0 && selectedCount < paginatedComments.length;


  return (
    <>
      <main className="p-6">
        <div className='flex items-center justify-between pb-4'>
            <h1 className="text-2xl font-semibold">Comments</h1>
        </div>
        <div className="flex items-center space-x-2 pb-4">
            <button onClick={() => setStatusFilter('all')} className={`px-2 py-1 text-sm ${statusFilter === 'all' ? 'text-primary' : 'text-primary hover:underline'}`}>All ({statusCounts.all})</button>
            <span className="text-muted-foreground">|</span>
            <button onClick={() => setStatusFilter('mine')} className={`px-2 py-1 text-sm ${statusFilter === 'mine' ? 'text-primary' : 'text-primary hover:underline'}`}>Mine ({statusCounts.mine})</button>
            <span className="text-muted-foreground">|</span>
            <button onClick={() => setStatusFilter('pending')} className={`px-2 py-1 text-sm ${statusFilter === 'pending' ? 'text-primary' : 'text-primary hover:underline'}`}>Pending ({statusCounts.pending})</button>
            <span className="text-muted-foreground">|</span>
            <button onClick={() => setStatusFilter('approved')} className={`px-2 py-1 text-sm ${statusFilter === 'approved' ? 'text-primary' : 'text-primary hover:underline'}`}>Approved ({statusCounts.approved})</button>
            <span className="text-muted-foreground">|</span>
            <button onClick={() => setStatusFilter('spam')} className={`px-2 py-1 text-sm ${statusFilter === 'spam' ? 'text-primary' : 'text-primary hover:underline'}`}>Spam ({statusCounts.spam})</button>
            <span className="text-muted-foreground">|</span>
            <button onClick={() => setStatusFilter('trash')} className={`px-2 py-1 text-sm ${statusFilter === 'trash' ? 'text-primary' : 'text-primary hover:underline'}`}>Trash ({statusCounts.trash})</button>
        </div>
        <div className="flex items-center justify-between pb-4">
            <div className="flex items-center space-x-2">
                 <Select value={bulkAction} onValueChange={setBulkAction}>
                    <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Bulk actions" />
                    </SelectTrigger>
                    <SelectContent>
                        {statusFilter === 'trash' || statusFilter === 'spam' ? (
                             <>
                                <SelectItem value="approve">Approve</SelectItem>
                                <SelectItem value="delete_permanently">Delete Permanently</SelectItem>
                            </>
                        ) : (
                            <>
                                <SelectItem value="unapprove">Unapprove</SelectItem>
                                <SelectItem value="approve">Approve</SelectItem>
                                <SelectItem value="spam">Mark as Spam</SelectItem>
                                <SelectItem value="trash">Move to Trash</SelectItem>
                            </>
                        )}
                    </SelectContent>
                </Select>
                <Button variant="secondary" onClick={applyBulkAction}>Apply</Button>
            </div>
            <div className="w-full max-w-sm">
                <Input 
                    placeholder="Search comments..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>
        </div>

        <DataTablePagination
            currentPage={page}
            totalPages={totalPages}
            onPageChange={setPage}
            pageSize={pageSize}
            onPageSizeChange={setPageSize}
            itemCount={filteredComments.length}
        />

        <div className="border rounded-lg mt-4">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[40px]">
                   <Checkbox 
                        checked={isAllSelected}
                        onCheckedChange={(checked) => toggleSelectAll(Boolean(checked))}
                        aria-label="Select all"
                        data-state={isIndeterminate ? 'indeterminate' : (isAllSelected ? 'checked' : 'unchecked')}
                    />
                </TableHead>
                <TableHead>Author</TableHead>
                <TableHead>Comment</TableHead>
                <TableHead>In Response To</TableHead>
                <TableHead>Submitted On</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginatedComments.map((comment) => {
                const commentDate = new Date(comment.createdAt).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric',
                });
                return (
                  <TableRow key={comment.id} data-state={comment.selected ? "selected" : "deselected"} className={`group ${comment.status === 'pending' ? 'bg-yellow-50' : ''}`}>
                    <TableCell>
                        <Checkbox 
                            checked={!!comment.selected}
                            onCheckedChange={() => toggleSelect(comment.id)}
                            aria-label={`Select comment by "${comment.author.name}"`}
                        />
                    </TableCell>
                    <TableCell className="font-medium">
                        <div className="flex items-center gap-2">
                            <Avatar className="h-8 w-8">
                                <AvatarImage src={comment.author.avatar} alt={comment.author.name} />
                                <AvatarFallback>{comment.author.name.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div>
                                <span className="font-semibold">{comment.author.name}</span>
                                <p><a href={`mailto:${comment.author.email}`} className="text-primary hover:underline text-xs">{comment.author.email}</a></p>
                            </div>
                        </div>
                    </TableCell>
                     <TableCell>
                        <p>{comment.content}</p>
                        {comment.status !== 'approved' && <Badge variant="secondary" className="my-1">{comment.status}</Badge>}
                        <div className="text-xs text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity space-x-1">
                           {comment.status === 'approved' && <button onClick={() => handleStatusChange('pending', [comment.id])} className="text-primary hover:underline">Unapprove</button>}
                           {(comment.status === 'pending' || comment.status === 'spam') && <button onClick={() => handleStatusChange('approved', [comment.id])} className="text-primary hover:underline">Approve</button>}
                           <span className="text-muted-foreground">|</span>
                           <button onClick={() => handleReplyClick(comment)} className="text-primary hover:underline">Reply</button>
                           <span className="text-muted-foreground">|</span>
                           <button onClick={() => handleEditClick(comment)} className="text-primary hover:underline">Edit</button>
                           <span className="text-muted-foreground">|</span>
                           {comment.status !== 'spam' && <button onClick={() => handleStatusChange('spam', [comment.id])} className="text-destructive hover:underline">Spam</button>}
                           {comment.status === 'spam' && <button onClick={() => handleStatusChange('approved', [comment.id])} className="text-primary hover:underline">Not Spam</button>}
                           <span className="text-muted-foreground">|</span>
                           {comment.status !== 'trash' ? (
                            <button onClick={() => handleStatusChange('trash', [comment.id])} className="text-destructive hover:underline">Trash</button>
                           ) : (
                             <button onClick={() => handleDelete([comment.id])} className="text-destructive hover:underline">Delete Permanently</button>
                           )}
                        </div>
                    </TableCell>
                     <TableCell>
                        <Link href={`/admin/posts/edit/${comment.postId}`} className="text-primary hover:underline">View Post</Link>
                     </TableCell>
                    <TableCell>{commentDate}</TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
         <DataTablePagination
            className="mt-4"
            currentPage={page}
            totalPages={totalPages}
            onPageChange={setPage}
            pageSize={pageSize}
            onPageSizeChange={setPageSize}
            itemCount={filteredComments.length}
        />
      </main>

      {/* Edit Comment Dialog */}
      <Dialog open={!!editingComment} onOpenChange={(isOpen) => !isOpen && setEditingComment(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Comment</DialogTitle>
          </DialogHeader>
          <div className="space-y-2">
            <Label htmlFor="edit-comment-content">Content</Label>
            <Textarea 
                id="edit-comment-content"
                value={editText}
                onChange={(e) => setEditText(e.target.value)}
                rows={8}
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingComment(null)}>Cancel</Button>
            <Button onClick={handleSaveChanges}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Reply to Comment Dialog */}
      <Dialog open={!!replyingToComment} onOpenChange={(isOpen) => !isOpen && setReplyingToComment(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reply to Comment</DialogTitle>
             <DialogDescription>
                Replying to: <strong>{replyingToComment?.author.name}</strong>
             </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="text-sm p-3 bg-muted/80 rounded-md border italic">
               "{replyingToComment?.content}"
            </div>
             <div className="space-y-2">
                <Label htmlFor="reply-content">Your Reply</Label>
                <Textarea 
                    id="reply-content"
                    value={replyText}
                    onChange={(e) => setReplyText(e.target.value)}
                    rows={6}
                    placeholder="Type your reply here..."
                />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setReplyingToComment(null)}>Cancel</Button>
            <Button onClick={handleSendReply}>Send Reply</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
