
'use client';

import dynamic from 'next/dynamic';
import { Skeleton } from '@/components/ui/skeleton';

const CardSkeleton = () => (
    <Skeleton className="h-48 w-full" />
);

const AtAGlanceCard = dynamic(() => import('@/components/admin/dashboard-cards').then(mod => mod.AtAGlanceCard), { loading: () => <CardSkeleton />, ssr: false });
const QuickDraftCard = dynamic(() => import('@/components/admin/dashboard-cards').then(mod => mod.QuickDraftCard), { loading: () => <CardSkeleton />, ssr: false });
const SiteHealthCard = dynamic(() => import('@/components/admin/dashboard-cards').then(mod => mod.SiteHealthCard), { loading: () => <CardSkeleton />, ssr: false });
const ActivityCard = dynamic(() => import('@/components/admin/dashboard-cards').then(mod => mod.ActivityCard), { loading: () => <CardSkeleton />, ssr: false });
const NewsCard = dynamic(() => import('@/components/admin/dashboard-cards').then(mod => mod.NewsCard), { loading: () => <CardSkeleton />, ssr: false });


export default function DashboardPage() {
  return (
    <>
      <div className="p-6">
        <h1 className="text-2xl font-semibold mb-6">Dashboard</h1>
        <div className="grid gap-6 grid-cols-1 lg:grid-cols-2">
            <div className="space-y-6">
                <SiteHealthCard />
                <AtAGlanceCard />
                <ActivityCard />
            </div>
            <div className="space-y-6">
                <QuickDraftCard />
                <NewsCard />
            </div>
        </div>
      </div>
    </>
  );
}
