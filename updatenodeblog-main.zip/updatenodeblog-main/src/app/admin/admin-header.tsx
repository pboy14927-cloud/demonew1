
"use client";

import Link from "next/link";
import { useSession, signOut } from "next-auth/react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { LifeBuoy, LogOut, Settings, User, MessageSquare, Plus, Home } from "lucide-react";
import { SidebarTrigger } from "@/components/ui/sidebar";
import { getSettings, getComments } from "@/lib/data";
import { useState, useEffect } from "react";
import Image from 'next/image';

type AdminHeaderProps = {
    title?: string;
    children?: React.ReactNode;
}

const WordpressIcon = () => (
    <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 20 20"><path d="M10 0C4.477 0 0 4.477 0 10c0 5.523 4.477 10 10 10s10-4.477 10-10C20 4.477 15.523 0 10 0zM8.52 4.483l5.592 1.996a.54.54 0 01.388.508v5.938c0 .288-.19.539-.461.61L8.52 15.517a.645.645 0 01-.84-.57V5.053a.645.645 0 01.84-.57zm1.14 1.14v8.754l4.242-1.514V7.14L9.66 5.623zM4.09 7.143l3.81 1.36v2.99l-3.81 1.36V7.143z"></path></svg>
)


export default function AdminHeader({ title, children }: AdminHeaderProps) {
  const { data: session, status } = useSession();
  const [siteTitle, setSiteTitle] = useState('Loading...');
  const [pendingComments, setPendingComments] = useState(0);
  
  useEffect(() => {
    getSettings().then(s => setSiteTitle(s.siteTitle));
    getComments('pending').then(c => {
        setPendingComments(c.length);
    });
  }, []);

  const userId = session?.user ? (session.user as any).id : null;
  const userAvatar = session?.user?.image || `https://placehold.co/100x100.png?text=${session?.user?.name?.charAt(0) || 'A'}`;

  return (
    <header className="sticky top-0 z-30 flex h-14 items-center gap-4 border-b bg-sidebar text-sidebar-foreground px-2 md:px-4">
        <div className="flex items-center gap-1 md:gap-2">
            <SidebarTrigger className="md:hidden"/>
            <DropdownMenu>
                <DropdownMenuTrigger asChild>
                    <button className="flex items-center gap-2 p-2 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground rounded-md">
                         <WordpressIcon />
                        <h1 className="text-lg font-semibold whitespace-nowrap hidden sm:block">{siteTitle}</h1>
                    </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                    <DropdownMenuItem asChild>
                        <Link href="/">
                             <Home className="mr-2 h-4 w-4" />
                            Visit Site
                        </Link>
                    </DropdownMenuItem>
                </DropdownMenuContent>
            </DropdownMenu>
        </div>

      <div className="flex items-center gap-1 md:gap-2">
        <Button asChild variant="ghost" size="sm" className="hidden sm:inline-flex hover:bg-sidebar-accent hover:text-sidebar-accent-foreground">
            <Link href="/admin/comments">
                <MessageSquare className="h-4 w-4" />
                <span className="ml-2">{pendingComments}</span>
            </Link>
        </Button>
        <DropdownMenu>
            <DropdownMenuTrigger asChild>
                 <Button variant="ghost" size="sm" className="hidden sm:inline-flex hover:bg-sidebar-accent hover:text-sidebar-accent-foreground">
                    <Plus className="h-4 w-4" />
                    <span className="ml-2">New</span>
                </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
                <DropdownMenuItem asChild><Link href="/admin/posts/new">Post</Link></DropdownMenuItem>
                <DropdownMenuItem asChild><Link href="/admin/media/new">Media</Link></DropdownMenuItem>
                <DropdownMenuItem asChild><Link href="/admin/pages/new">Page</Link></DropdownMenuItem>
                <DropdownMenuItem asChild><Link href="/admin/users/new">User</Link></DropdownMenuItem>
            </DropdownMenuContent>
        </DropdownMenu>
        {children}
      </div>

      <div className="ml-auto flex items-center gap-2">
         <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="flex items-center gap-2 text-sm p-2 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground rounded-md">
               {status === 'loading' ? (
                <>
                    <Skeleton className="h-8 w-20" />
                    <Skeleton className="h-8 w-8 rounded-full" />
                </>
              ) : (
                <>
                <span className="hidden sm:inline">Howdy, {session?.user?.name}</span>
                <span className="sm:hidden">{session?.user?.name}</span>
                <Avatar className="h-7 w-7">
                  <AvatarImage src={userAvatar} alt={session?.user?.name || "Admin"} />
                  <AvatarFallback>{session?.user?.name?.charAt(0) || 'A'}</AvatarFallback>
                </Avatar>
                </>
              )}
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel className="flex items-center gap-2">
                 <Avatar>
                  <AvatarImage src={userAvatar} alt={session?.user?.name || "Admin"} />
                  <AvatarFallback>{session?.user?.name?.charAt(0) || 'A'}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">{session?.user?.name}</p>
                </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            {userId && (
              <DropdownMenuItem asChild>
                  <Link href={`/admin/users/edit/${userId}`}>
                      <User className="mr-2 h-4 w-4" />
                      <span>Profile</span>
                  </Link>
              </DropdownMenuItem>
            )}
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => signOut({ callbackUrl: '/login' })}>
                <LogOut className="mr-2 h-4 w-4" />
                <span>Log Out</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
