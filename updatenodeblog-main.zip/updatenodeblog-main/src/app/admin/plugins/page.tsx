
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function PluginsPage() {
  return (
    <>
      <main className="p-6">
        <h1 className="text-2xl font-semibold mb-6">Plugins</h1>
        <Card>
          <CardHeader>
            <CardTitle>Plugins</CardTitle>
            <CardDescription>This page will allow you to manage your plugins. This feature is under construction.</CardDescription>
          </CardHeader>
          <CardContent>
            <p>Coming soon!</p>
          </CardContent>
        </Card>
      </main>
    </>
  );
}
