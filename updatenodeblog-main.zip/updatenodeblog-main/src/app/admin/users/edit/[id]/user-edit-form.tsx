
'use client';

import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Eye, EyeOff, Plus, Trash2, Loader2 } from 'lucide-react';
import type { User, SocialLink, Media } from '@/lib/data';
import { useSession } from 'next-auth/react';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import MediaLibraryModal from "@/components/admin/media-library-modal";
import { useRouter } from 'next/navigation';

type UserRole = 'administrator' | 'editor' | 'author' | 'contributor' | 'subscriber';

export default function UserEditForm({ user: initialUser }: { user: User }) {
    const router = useRouter();
    const [user, setUser] = useState<User>(initialUser);
    const { data: session, update: updateSession } = useSession();
    const { toast } = useToast();

    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [isMediaDialogOpen, setIsMediaDialogOpen] = useState(false);
    const [isSaving, setIsSaving] = useState(false);

    useEffect(() => {
        setUser(initialUser);
    }, [initialUser]);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { id, value } = e.target;
        setUser(prev => ({...prev, [id]: value }));
    }

    const generatePassword = () => {
        const newPassword = Math.random().toString(36).slice(-12) + '#A$b!';
        setPassword(newPassword);
        toast({ title: 'New password generated.', description: 'Click "Update User" to save it.' });
    }
    
    const isEditingSelf = session?.user && (session.user as any).id === user.id;
    const pageTitle = isEditingSelf ? 'Profile' : 'Edit User';
    const canEditRole = session?.user && (session.user as any).role === 'administrator';
    
    const handleAddSocialLink = () => {
        const newLinks = [...(user.socialLinks || []), { id: `link-${Date.now()}`, platform: '', url: '' }];
        setUser(prev => ({ ...prev, socialLinks: newLinks }));
    };

    const handleRemoveSocialLink = (id: string) => {
        if(!user || !user.socialLinks) return;
        const newLinks = user.socialLinks.filter(link => link.id !== id);
        setUser(prev => ({...prev, socialLinks: newLinks }));
    };

    const handleSocialLinkChange = (id: string, field: 'platform' | 'url', value: string) => {
        if(!user || !user.socialLinks) return;
        const newLinks = user.socialLinks.map(link => link.id === id ? { ...link, [field]: value } : link);
        setUser(prev => ({...prev, socialLinks: newLinks }));
    };

    const handleUpdateUser = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSaving(true);
        
        try {
            const response = await fetch(`/api/users/id/${user.id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    userData: user,
                    newPassword: password,
                }),
            });
            
            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.message || 'Failed to update user.');
            }
            
            toast({
                title: "User Updated",
                description: `${user.name}'s profile has been saved.`,
            });
            
            if (isEditingSelf) {
                 await updateSession({ user: result.user });
            }

            setPassword(''); // Clear password field after successful update
        } catch (error: any) {
             toast({
                variant: 'destructive',
                title: "Error",
                description: error.message,
            });
        } finally {
            setIsSaving(false);
        }
    }

    const handleImageSelect = (media: Media) => {
        setUser(prev => ({ ...prev, avatar: media.url}));
        setIsMediaDialogOpen(false);
    }

  return (
    <>
      <main className="p-6">
        <h1 className="text-2xl font-semibold mb-2">{pageTitle}</h1>
        {isEditingSelf && <p className="text-muted-foreground mb-6">Manage your personal information and settings.</p>}
        
        <form onSubmit={handleUpdateUser} className="space-y-6 max-w-4xl">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
                <Label htmlFor="username" className="md:text-right">Username</Label>
                <div className="md:col-span-3">
                    <Input id="username" value={user.username} disabled />
                    <p className="text-sm text-muted-foreground mt-1">Usernames cannot be changed.</p>
                </div>
            </div>
            {canEditRole && (
                 <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
                    <Label htmlFor="role" className="md:text-right">Role</Label>
                    <div className="md:col-span-3">
                         <Select value={user.role} onValueChange={(value) => setUser(prev => ({...prev, role: value as UserRole}))} disabled={isEditingSelf && user.role === 'administrator'}>
                            <SelectTrigger id="role">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="subscriber">Subscriber</SelectItem>
                                <SelectItem value="contributor">Contributor</SelectItem>
                                <SelectItem value="author">Author</SelectItem>
                                <SelectItem value="editor">Editor</SelectItem>
                                <SelectItem value="administrator">Administrator</SelectItem>
                            </SelectContent>
                        </Select>
                         {isEditingSelf && user.role === 'administrator' && <p className="text-sm text-muted-foreground mt-1">Administrators cannot change their own role.</p>}
                    </div>
                </div>
            )}

            <Separator/>

             <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
                <Label htmlFor="name" className="md:text-right">Name</Label>
                <div className="md:col-span-3">
                    <Input id="name" value={user.name} onChange={handleInputChange}/>
                </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
                <Label htmlFor="email" className="md:text-right">Email (required)</Label>
                <div className="md:col-span-3">
                    <Input id="email" type="email" required value={user.email} onChange={handleInputChange} />
                </div>
            </div>
             <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
                <Label htmlFor="website" className="md:text-right">Website</Label>
                <div className="md:col-span-3">
                    <Input id="website" type="url" value={user.website || ''} onChange={handleInputChange} />
                </div>
            </div>
             <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-start">
                <Label htmlFor="bio" className="md:text-right mt-2">Biographical Info</Label>
                <div className="md:col-span-3">
                    <Textarea id="bio" rows={5} value={user.bio || ''} onChange={handleInputChange} />
                    <p className="text-sm text-muted-foreground mt-1">Share a little biographical information to fill out your profile. This may be displayed publicly.</p>
                </div>
            </div>
            <Separator />

             <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-start">
                <Label className="md:text-right mt-2">Profile Picture</Label>
                <div className="md:col-span-3 flex items-center gap-4">
                    <Avatar className="h-24 w-24">
                        <AvatarImage src={user.avatar} />
                        <AvatarFallback>{user.name?.charAt(0)}</AvatarFallback>
                    </Avatar>
                     <Button type="button" variant="outline" onClick={() => setIsMediaDialogOpen(true)}>Change Picture</Button>
                </div>
            </div>

            <Separator />
             <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-start">
                <Label className="md:text-right mt-2">Social Links</Label>
                <div className="md:col-span-3 space-y-4">
                    {(user.socialLinks || []).map((link) => (
                        <div key={link.id} className="space-y-2 border p-3 rounded-md">
                            <div className="flex justify-end">
                                <Button type="button" variant="ghost" size="icon" className="h-6 w-6" onClick={() => handleRemoveSocialLink(link.id)}>
                                    <Trash2 className="h-4 w-4 text-destructive"/>
                                </Button>
                            </div>
                            <div className="space-y-2">
                                <Label>Platform</Label>
                                <Select value={link.platform} onValueChange={(v) => handleSocialLinkChange(link.id, 'platform', v)}>
                                    <SelectTrigger><SelectValue placeholder="Select a platform" /></SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="twitter">Twitter</SelectItem>
                                        <SelectItem value="facebook">Facebook</SelectItem>
                                        <SelectItem value="instagram">Instagram</SelectItem>
                                        <SelectItem value="linkedin">LinkedIn</SelectItem>
                                        <SelectItem value="youtube">YouTube</SelectItem>
                                        <SelectItem value="custom">Custom</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="space-y-2">
                                <Label>URL</Label>
                                <Input
                                    type="url"
                                    value={link.url}
                                    onChange={(e) => handleSocialLinkChange(link.id, 'url', e.target.value)}
                                    placeholder="https://..."
                                />
                            </div>
                        </div>
                    ))}
                    <Button type="button" variant="outline" className="w-full" onClick={handleAddSocialLink}>
                        <Plus className="mr-2 h-4 w-4" /> Add New Social Link
                    </Button>
                </div>
            </div>
            
            <Separator />

             <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-start">
                <Label htmlFor="password" className="md:text-right mt-2">New Password</Label>
                <div className="md:col-span-3 space-y-2">
                    <Button type="button" variant="secondary" onClick={generatePassword}>Generate password</Button>
                    <div className="relative">
                       <Input id="password" type={showPassword ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value)} className="pr-10" placeholder="Enter new password" />
                       <Button type="button" variant="ghost" size="icon" className="absolute top-1/2 right-1 -translate-y-1/2 h-8 w-8" onClick={() => setShowPassword(!showPassword)}>
                         {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                       </Button>
                    </div>
                     <p className="text-sm text-muted-foreground mt-1">If you would like to change the password type a new one. Otherwise leave this blank.</p>
                </div>
            </div>
            
            <div className="pt-4">
                 <Button type="submit" disabled={isSaving}>
                    {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Update {isEditingSelf ? 'Profile' : 'User'}
                </Button>
            </div>
        </form>
      </main>

      <MediaLibraryModal
        isOpen={isMediaDialogOpen}
        onOpenChange={setIsMediaDialogOpen}
        onSelect={handleImageSelect}
      />
    </>
  );
}
