
'use server';

import { getUserById, User } from '@/lib/data';
import { notFound } from 'next/navigation';
import UserEditForm from './user-edit-form';


type EditUserPageProps = {
    params: {
        id: string;
    }
}

export default async function EditUserPage({ params }: EditUserPageProps) {
    const { id } = params;
    const user = await getUserById(id);

    if (!user) {
        notFound();
    }

    return <UserEditForm user={user} />;
}
