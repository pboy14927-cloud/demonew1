
'use client';

import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Eye, EyeOff, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation';
import { UserRole } from '@/lib/data';

export default function NewUserPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [website, setWebsite] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [sendNotification, setSendNotification] = useState(true);
  const [role, setRole] = useState<UserRole>('subscriber');

  const generatePassword = () => {
    const newPassword = Math.random().toString(36).slice(-12) + 'aA1!';
    setPassword(newPassword);
    setShowPassword(true);
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    // Basic validation
    if (!email.includes('@')) {
      toast({
        variant: 'destructive',
        title: 'Invalid email',
        description: 'Please enter a valid email address.',
      });
      return;
    }
    if (password.length < 6) {
      toast({
        variant: 'destructive',
        title: 'Weak password',
        description: 'Password must be at least 6 characters long.',
      });
      return;
    }

    setIsLoading(true);

    try {
      const response = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username,
          name,
          email,
          password,
          role,
          website,
          sendNotification
        }),
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.message || 'Failed to create user.');
      }

      toast({
        title: 'User Created',
        description: `User "${username}" was created successfully.`,
      });

      router.push('/admin/users');
    } catch (error: any) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: error.message,
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <main className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Add User</h1>
      <p className="text-muted-foreground mb-6">
        Create a brand new user and add them to this site.
      </p>

      <form onSubmit={handleSubmit} className="space-y-6 max-w-2xl">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
          <Label htmlFor="username" className="md:text-right">Username (required)</Label>
          <div className="md:col-span-3">
            <Input id="username" value={username} onChange={e => setUsername(e.target.value)} required />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
          <Label htmlFor="name" className="md:text-right">Full Name</Label>
          <div className="md:col-span-3">
            <Input id="name" value={name} onChange={e => setName(e.target.value)} />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
          <Label htmlFor="email" className="md:text-right">Email (required)</Label>
          <div className="md:col-span-3">
            <Input id="email" type="email" required value={email} onChange={e => setEmail(e.target.value)} />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
          <Label htmlFor="website" className="md:text-right">Website</Label>
          <div className="md:col-span-3">
            <Input id="website" type="url" value={website} onChange={e => setWebsite(e.target.value)} />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-start">
          <Label htmlFor="password" className="md:text-right mt-2">Password</Label>
          <div className="md:col-span-3 space-y-2">
            <div className="relative">
              <Input
                id="password"
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="pr-20"
                required
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="absolute top-1/2 right-9 -translate-y-1/2 h-8 w-8"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </Button>
              <Button
                type="button"
                variant="secondary"
                onClick={generatePassword}
                className="absolute top-1/2 right-1 -translate-y-1/2 h-8 text-xs"
              >
                Generate
              </Button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
          <Label className="md:text-right">Send User Notification</Label>
          <div className="md:col-span-3 flex items-center space-x-2">
            <Checkbox
              id="send-notification"
              checked={sendNotification}
              onCheckedChange={(checked) => setSendNotification(Boolean(checked))}
            />
            <Label htmlFor="send-notification" className="font-normal">
              Send the new user an email about their account
            </Label>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
          <Label htmlFor="role" className="md:text-right">Role</Label>
          <div className="md:col-span-3">
            <Select value={role} onValueChange={(value: UserRole) => setRole(value)}>
              <SelectTrigger id="role">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="subscriber">Subscriber</SelectItem>
                <SelectItem value="contributor">Contributor</SelectItem>
                <SelectItem value="author">Author</SelectItem>
                <SelectItem value="editor">Editor</SelectItem>
                <SelectItem value="administrator">Administrator</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="pt-4">
          <Button type="submit" disabled={isLoading}>
            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Add New User
          </Button>
        </div>
      </form>
    </main>
  );
}
