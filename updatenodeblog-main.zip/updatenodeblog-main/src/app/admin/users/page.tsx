

'use client';

import React, { useState, useMemo, useEffect } from 'react';
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { getUsers, User, getPosts } from "@/lib/data";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

type UserWithSelection = User & { selected?: boolean };

export default function AdminUsersPage() {
  const [allUsers, setAllUsers] = useState<UserWithSelection[]>([]);
  const [roleFilter, setRoleFilter] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState('');
  const [bulkAction, setBulkAction] = useState('');
  const [changeRole, setChangeRole] = useState('');
  
  const [allPosts, setAllPosts] = useState<any[]>([]);

  useEffect(() => {
      const fetchData = async () => {
          const [users, posts] = await Promise.all([
            getUsers(true),
            getPosts(true)
          ]);
          setAllUsers(users.map(user => ({ ...user, selected: false })));
          setAllPosts(posts);
      }
      fetchData();
  }, []);

  const userPostsCount = useMemo(() => {
    const counts: { [key: string]: number } = {};
    for (const user of allUsers) {
        counts[user.id] = allPosts.filter(p => p.authorId === user.id).length;
    }
    return counts;
  }, [allUsers, allPosts]);

  const filteredUsers = useMemo(() => {
    return allUsers
      .filter((user) => {
        if (roleFilter === "all") return true;
        return user.role === roleFilter;
      })
      .filter((user) => {
        const username = user.username || '';
        return user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
               user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
               username.toLowerCase().includes(searchTerm.toLowerCase());
      }
      );
  }, [allUsers, roleFilter, searchTerm]);
  
  const roleCounts = useMemo(() => {
      const counts: {[key: string]: number} = { all: allUsers.length };
      allUsers.forEach(user => {
          counts[user.role] = (counts[user.role] || 0) + 1;
      });
      return counts;
  }, [allUsers]);

  const handleDeleteUsers = (userIds: string[]) => {
      setAllUsers(prevUsers => prevUsers.filter(u => !userIds.includes(u.id)));
  }

  const applyBulkAction = () => {
    const selectedIds = allUsers.filter(u => u.selected).map(u => u.id);
    if(selectedIds.length === 0 || !bulkAction) return;

    if(bulkAction === 'delete') {
        handleDeleteUsers(selectedIds);
    }
    setBulkAction('');
    // Unselect all after action
    setAllUsers(prev => prev.map(u => ({...u, selected: false})));
  };

  const applyRoleChange = () => {
    const selectedIds = allUsers.filter(u => u.selected).map(u => u.id);
    if(selectedIds.length === 0 || !changeRole) return;
    
    setAllUsers(prev => prev.map(u => 
        selectedIds.includes(u.id) ? { ...u, role: changeRole as any, selected: false } : u
    ));
    setChangeRole('');
  }

  const toggleSelectAll = (checked: boolean) => {
     setAllUsers(users => users.map(u => {
        if(filteredUsers.some(fu => fu.id === u.id)) {
            return {...u, selected: checked }
        }
        return u;
     }));
  }

  const toggleSelect = (userId: string) => {
     setAllUsers(users => users.map(u => u.id === userId ? { ...u, selected: !u.selected } : u));
  }

  const selectedCount = filteredUsers.filter(p => p.selected).length;
  const isAllSelected = selectedCount > 0 && selectedCount === filteredUsers.length;
  const isIndeterminate = selectedCount > 0 && selectedCount < filteredUsers.length;


  return (
    <>
      <main className="p-6">
         <div className='flex items-center justify-between pb-4'>
            <h1 className="text-2xl font-semibold">Users</h1>
            <Button asChild>
                <Link href="/admin/users/new">Add New</Link>
            </Button>
        </div>
        <div className="flex items-center space-x-2 pb-4">
            <button onClick={() => setRoleFilter('all')} className={`px-1 py-1 text-sm ${roleFilter === 'all' ? 'text-primary' : 'text-primary hover:underline'}`}>
                All ({roleCounts.all || 0})
            </button>
            <span className="text-muted-foreground">|</span>
            <button onClick={() => setRoleFilter('administrator')} className={`px-1 py-1 text-sm ${roleFilter === 'administrator' ? 'text-primary' : 'text-primary hover:underline'}`}>
                Administrator ({roleCounts.administrator || 0})
            </button>
             <span className="text-muted-foreground">|</span>
             <button onClick={() => setRoleFilter('editor')} className={`px-1 py-1 text-sm ${roleFilter === 'editor' ? 'text-primary' : 'text-primary hover:underline'}`}>
                Editor ({roleCounts.editor || 0})
            </button>
             <span className="text-muted-foreground">|</span>
             <button onClick={() => setRoleFilter('author')} className={`px-1 py-1 text-sm ${roleFilter === 'author' ? 'text-primary' : 'text-primary hover:underline'}`}>
                Author ({roleCounts.author || 0})
            </button>
             <span className="text-muted-foreground">|</span>
             <button onClick={() => setRoleFilter('contributor')} className={`px-1 py-1 text-sm ${roleFilter === 'contributor' ? 'text-primary' : 'text-primary hover:underline'}`}>
                Contributor ({roleCounts.contributor || 0})
            </button>
             <span className="text-muted-foreground">|</span>
             <button onClick={() => setRoleFilter('subscriber')} className={`px-1 py-1 text-sm ${roleFilter === 'subscriber' ? 'text-primary' : 'text-primary hover:underline'}`}>
                Subscriber ({roleCounts.subscriber || 0})
            </button>
        </div>
        <div className="flex flex-col sm:flex-row items-center justify-between pb-4 gap-4">
            <div className="flex items-center space-x-2">
                 <Select value={bulkAction} onValueChange={setBulkAction}>
                    <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Bulk actions" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="delete">Delete</SelectItem>
                    </SelectContent>
                </Select>
                <Button variant="secondary" onClick={applyBulkAction}>Apply</Button>
                
                 <Select value={changeRole} onValueChange={setChangeRole}>
                    <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Change role to..." />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="subscriber">Subscriber</SelectItem>
                        <SelectItem value="contributor">Contributor</SelectItem>
                        <SelectItem value="author">Author</SelectItem>
                        <SelectItem value="editor">Editor</SelectItem>
                        <SelectItem value="administrator">Administrator</SelectItem>
                    </SelectContent>
                </Select>
                <Button variant="secondary" onClick={applyRoleChange}>Change</Button>
            </div>
            <div className="w-full sm:w-auto flex items-center space-x-2">
                <div className="w-full sm:max-w-sm">
                    <Input 
                        placeholder="Search users..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>
                 <Button>Search Users</Button>
            </div>
        </div>

        <div className="border rounded-lg">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[40px]">
                   <Checkbox
                        checked={isAllSelected}
                        onCheckedChange={(checked) => toggleSelectAll(Boolean(checked))}
                        aria-label="Select all"
                        data-state={isIndeterminate ? 'indeterminate' : (isAllSelected ? 'checked' : 'unchecked')}
                    />
                </TableHead>
                <TableHead>Username</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Posts</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUsers.map((user) => {
                const username = user.username || '';
                return (
                  <TableRow key={user.id} data-state={user.selected ? "selected" : "deselected"} className="group">
                    <TableCell>
                        <Checkbox 
                            checked={!!user.selected}
                            onCheckedChange={() => toggleSelect(user.id)}
                            aria-label={`Select user "${user.name}"`}
                        />
                    </TableCell>
                    <TableCell className="font-medium">
                        <div className="flex items-center gap-2">
                            <Avatar className="h-8 w-8">
                                <AvatarImage src={user.avatar} alt={user.name} />
                                <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div>
                                <Link href={`/admin/users/edit/${user.id}`} className="hover:text-primary font-semibold">{username}</Link>
                                <div className="text-xs text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity">
                                    <Link href={`/admin/users/edit/${user.id}`} className="text-primary hover:underline">Edit</Link> | 
                                    <button onClick={() => handleDeleteUsers([user.id])} className="text-destructive hover:underline px-1">Delete</button> | 
                                    <Link href={`/author/${user.id}`} target="_blank" className="hover:underline px-1">View</Link>
                                </div>
                            </div>
                        </div>
                    </TableCell>
                    <TableCell>{user.name}</TableCell>
                    <TableCell><a href={`mailto:${user.email}`} className="text-primary hover:underline">{user.email}</a></TableCell>
                     <TableCell className="capitalize">
                        {user.role}
                    </TableCell>
                    <TableCell>
                        <Link href="#" className="text-primary hover:underline">{userPostsCount[user.id] || 0}</Link>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </main>
    </>
  );
}
