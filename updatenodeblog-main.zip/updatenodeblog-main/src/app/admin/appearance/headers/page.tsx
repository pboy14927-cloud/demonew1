

import React from 'react';
import HeaderEditor from './header-editor';

export default function HeaderPage() {
    return <HeaderEditor />;
}
