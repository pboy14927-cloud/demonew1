
'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { ChevronDown, Upload, Settings, Monitor, Tablet, Smartphone, Search, Moon, Sun, Home, User, MessageSquare, Menu as MenuIcon, Twitter as TwitterIcon, Facebook, Instagram, Linkedin, Youtube } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import ColorPicker from '@/components/admin/color-picker';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { getHeaderSettings, updateHeaderSettings, HeaderSettings, BarSettings, SlotSettings, HeaderElement, SlotName, getBrandingSettings, BrandingSettings, SocialIconStyleSettings } from '@/lib/data';
import Image from 'next/image';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Slider } from '@/components/ui/slider';
import { Separator } from '@/components/ui/separator';


const popularFonts = [
    'Inter', 'Roboto', 'Open Sans', 'Lato', 'Montserrat', 'Oswald', 'Raleway', 'Poppins', 'Nunito', 'Merriweather'
];

type BarSettingsProps = {
    title: string;
    settings: BarSettings;
    onSettingsChange: (settings: BarSettings) => void;
    slotSettings: SlotSettings;
    onSlotChange: (slot: SlotName, element: HeaderElement) => void;
};


const BarSettingsPanel = ({ title, settings, onSettingsChange, slotSettings, onSlotChange }: BarSettingsProps) => {

    const handleChange = (key: keyof BarSettings, value: any) => {
        onSettingsChange({ ...settings, [key]: value });
    };

    const handleVisibilityChange = (slot: SlotName, device: 'desktop' | 'tablet' | 'mobile', value: boolean) => {
        const newVis = {
            ...settings.slotVisibility[slot],
            [device]: value
        };
        const newSlotVisibility = {
            ...settings.slotVisibility,
            [slot]: newVis
        };
        handleChange('slotVisibility', newSlotVisibility);
    };

    const slotLabels: Record<SlotName, string> = {
        left: 'Left',
        centerLeft: 'Center Left',
        center: 'Center',
        centerRight: 'Center Right',
        right: 'Right'
    };

    return (
        <div className="border p-4 rounded-md bg-muted/30">
             <Tabs defaultValue="layout">
                <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="layout">Layout</TabsTrigger>
                    <TabsTrigger value="styling">Styling</TabsTrigger>
                </TabsList>
                <TabsContent value="layout" className="pt-4 space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label>Height (px)</Label>
                            <Input type="number" value={settings.height || 60} onChange={(e) => handleChange('height', parseInt(e.target.value))} />
                        </div>
                        <div className="space-y-2">
                            <Label>Layout</Label>
                            <Select value={settings.layout || '5-columns'} onValueChange={(value) => handleChange('layout', value)}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="5-columns">5 Columns (Default)</SelectItem>
                                    <SelectItem value="space-between">Space Between</SelectItem>
                                    <SelectItem value="center-logo">Center Logo</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {(Object.keys(slotLabels) as SlotName[]).map(pos => (
                             <div className="space-y-2" key={pos}>
                                <Label>{slotLabels[pos]}</Label>
                                <div className="flex gap-2">
                                     <Select value={slotSettings[pos]} onValueChange={(value: HeaderElement) => onSlotChange(pos, value)}>
                                        <SelectTrigger><SelectValue /></SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="none">None</SelectItem>
                                            <SelectItem value="site-logo">Site Logo</SelectItem>
                                            <SelectItem value="main-navigation">Main Navigation</SelectItem>
                                            <SelectItem value="off-canvas-trigger">Off-Canvas Trigger</SelectItem>
                                            <SelectItem value="login-register">Login/Register Button</SelectItem>
                                            <SelectItem value="current-date">Current Date</SelectItem>
                                            <SelectItem value="current-time">Current Time</SelectItem>
                                            <SelectItem value="social-icons">Social Icons</SelectItem>
                                            <SelectItem value="search-form">Search Form</SelectItem>
                                            <SelectItem value="theme-switcher">Theme Switcher</SelectItem>
                                            <SelectItem value="cta-button">CTA Button</SelectItem>
                                            <SelectItem value="social-theme">Social &amp; Theme Switcher</SelectItem>
                                            <SelectItem value="header-ad">Header Ad</SelectItem>
                                            <SelectItem value="custom-html">Custom HTML</SelectItem>
                                        </SelectContent>
                                    </Select>
                                    <Popover>
                                        <PopoverTrigger asChild>
                                            <Button variant="ghost" size="icon"><Settings className="h-4 w-4"/></Button>
                                        </PopoverTrigger>
                                        <PopoverContent className="w-auto p-4">
                                            <div className="space-y-4">
                                                <h4 className="font-semibold text-sm">Device Visibility</h4>
                                                <div className="space-y-2">
                                                    <div className="flex items-center justify-between gap-4">
                                                        <Label htmlFor={`desktop-vis-${pos}`} className="flex items-center gap-2 font-normal"><Monitor className="h-4 w-4" /> Desktop</Label>
                                                        <Switch id={`desktop-vis-${pos}`} checked={settings.slotVisibility[pos]?.desktop ?? true} onCheckedChange={c => handleVisibilityChange(pos, 'desktop', c)} />
                                                    </div>
                                                     <div className="flex items-center justify-between gap-4">
                                                        <Label htmlFor={`tablet-vis-${pos}`} className="flex items-center gap-2 font-normal"><Tablet className="h-4 w-4" /> Tablet</Label>
                                                        <Switch id={`tablet-vis-${pos}`} checked={settings.slotVisibility[pos]?.tablet ?? true} onCheckedChange={c => handleVisibilityChange(pos, 'tablet', c)} />
                                                    </div>
                                                     <div className="flex items-center justify-between gap-4">
                                                        <Label htmlFor={`mobile-vis-${pos}`} className="flex items-center gap-2 font-normal"><Smartphone className="h-4 w-4" /> Mobile</Label>
                                                        <Switch id={`mobile-vis-${pos}`} checked={settings.slotVisibility[pos]?.mobile ?? true} onCheckedChange={c => handleVisibilityChange(pos, 'mobile', c)} />
                                                    </div>
                                                </div>
                                            </div>
                                        </PopoverContent>
                                    </Popover>
                                </div>
                            </div>
                        ))}
                    </div>
                </TabsContent>
                <TabsContent value="styling" className="pt-4 space-y-4">
                     <RadioGroup value={settings.backgroundType || 'solid'} onValueChange={(v: any) => handleChange('backgroundType', v)} className="flex gap-4">
                        <div className="flex items-center space-x-2"><RadioGroupItem value="solid" id={`bg-solid-${title.replace(' ','-')}`} /><Label htmlFor={`bg-solid-${title.replace(' ','-')}`}>Solid</Label></div>
                        <div className="flex items-center space-x-2"><RadioGroupItem value="gradient" id={`bg-gradient-${title.replace(' ','-')}`} /><Label htmlFor={`bg-gradient-${title.replace(' ','-')}`}>Gradient</Label></div>
                    </RadioGroup>
                    {settings.backgroundType === 'solid' ? (
                        <ColorPicker label="Background Color" color={settings.backgroundColor || ''} onChange={(color) => handleChange('backgroundColor', color)} />
                    ) : (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <ColorPicker label="Gradient Start" color={settings.gradientStart || ''} onChange={(color) => handleChange('gradientStart', color)} />
                            <ColorPicker label="Gradient End" color={settings.gradientEnd || ''} onChange={(color) => handleChange('gradientEnd', color)} />
                        </div>
                    )}
                     <ColorPicker label="Text Color" color={settings.textColor || ''} onChange={(color) => handleChange('textColor', color)} />
                     <ColorPicker label="Link Color" color={settings.linkColor || ''} onChange={(color) => handleChange('linkColor', color)} />
                     <ColorPicker label="Link Hover Color" color={settings.linkHoverColor || ''} onChange={(color) => handleChange('linkHoverColor', color)} />
                </TabsContent>
             </Tabs>
        </div>
    )
}

const renderElement = (element: HeaderElement, settings: HeaderSettings, branding: BrandingSettings | null) => {
    const SocialIcon = ({ platform }: { platform: string }) => {
        switch (platform.toLowerCase()) {
            case 'twitter': return <TwitterIcon className="h-4 w-4" />;
            case 'facebook': return <Facebook className="h-4 w-4" />;
            case 'instagram': return <Instagram className="h-4 w-4" />;
            case 'linkedin': return <Linkedin className="h-4 w-4" />;
            case 'youtube': return <Youtube className="h-4 w-4" />;
            default: return <Home className="h-4 w-4" />;
        }
    };
    
    switch(element) {
        case 'site-logo':
             return (
                <div className="flex items-center gap-2">
                     {branding?.logoUrl ? (
                        <Image src={branding.logoUrl} alt={branding.websiteTitle} width={branding.logoWidth || 150} height={40} className="h-auto max-h-12 w-auto" />
                    ) : (
                        <h2 className="text-xl font-bold">{branding?.websiteTitle}</h2>
                    )}
                </div>
            );
        case 'main-navigation':
            return (
                <nav className="flex items-center gap-4">
                    <a href="#" className="text-sm font-medium hover:underline" style={{color: 'var(--link-color)'}} onMouseOver={e => e.currentTarget.style.color = 'var(--link-hover-color)'} onMouseOut={e => e.currentTarget.style.color = 'var(--link-color)'}>Home</a>
                    <a href="#" className="text-sm font-medium hover:underline" style={{color: 'var(--link-color)'}} onMouseOver={e => e.currentTarget.style.color = 'var(--link-hover-color)'} onMouseOut={e => e.currentTarget.style.color = 'var(--link-color)'}>About</a>
                    <a href="#" className="text-sm font-medium hover:underline" style={{color: 'var(--link-color)'}} onMouseOver={e => e.currentTarget.style.color = 'var(--link-hover-color)'} onMouseOut={e => e.currentTarget.style.color = 'var(--link-color)'}>Contact</a>
                </nav>
            );
         case 'off-canvas-trigger':
            return <Button variant="ghost" size="icon"><MenuIcon /></Button>
        case 'login-register':
            return <Button variant="ghost" size="sm">Login/Register</Button>;
        case 'current-date':
            return <span className="text-xs">{new Date().toLocaleDateString()}</span>;
         case 'current-time':
             return <span className="text-xs">{new Date().toLocaleTimeString()}</span>
        case 'social-icons':
            const socialSettings = settings.mainHeader?.styling?.socialIcons;
            if (!socialSettings || !branding?.socialLinks || branding.socialLinks.length === 0) {
                 return (
                    <div className="flex gap-1">
                        <Button variant="ghost" size="icon"><Facebook/></Button>
                        <Button variant="ghost" size="icon"><TwitterIcon/></Button>
                        <Button variant="ghost" size="icon"><Instagram/></Button>
                    </div>
                )
            }
            return (
                 <div className="flex gap-1">
                    {branding.socialLinks.map(link => (
                         <Button asChild key={link.id} variant="ghost" size="icon" className="social-icon h-8 w-8"
                            style={{ 
                                color: socialSettings.textColor, 
                                backgroundColor: socialSettings.backgroundColor 
                            }}
                            onMouseEnter={e => {
                                e.currentTarget.style.color = socialSettings.hoverTextColor || '';
                                e.currentTarget.style.backgroundColor = socialSettings.hoverBackgroundColor || '';
                            }}
                            onMouseLeave={e => {
                                e.currentTarget.style.color = socialSettings.textColor || '';
                                e.currentTarget.style.backgroundColor = socialSettings.backgroundColor || '';
                            }}
                         >
                             <a href={link.url} target="_blank" rel="noopener noreferrer">
                                <SocialIcon platform={link.platform} />
                            </a>
                         </Button>
                    ))}
                </div>
            )
        case 'search-form':
            return (
                <div className="relative search-form-container" style={{'--search-icon-color': settings.searchForm?.textColor} as React.CSSProperties}>
                    <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4" />
                    <Input 
                        placeholder="Search..." 
                        className="h-8 w-48 pl-8" 
                        style={{ 
                            backgroundColor: settings?.searchForm?.backgroundColor, 
                            color: settings?.searchForm?.textColor,
                            borderColor: settings?.searchForm?.borderColor,
                        }} 
                    />
                </div>
            );
        case 'theme-switcher':
            return <div className="flex items-center gap-1 border p-0.5 rounded-full"><Button size="icon" className="h-6 w-6 rounded-full"><Sun/></Button><Button size="icon" variant="ghost" className="h-6 w-6 rounded-full"><Moon/></Button></div>
        case 'social-theme':
            return (
                 <div className="flex items-center gap-2">
                    {renderElement('theme-switcher', settings, branding)}
                    {renderElement('off-canvas-trigger', settings, branding)}
                </div>
            )
         case 'header-ad':
            return <div className="bg-muted/50 p-2 text-xs h-full w-full flex items-center justify-center"><Image src="https://placehold.co/468x60.png" data-ai-hint="advertisement" alt="advertisement" width={468} height={60}/></div>;
         case 'custom-html':
             return <div className="text-xs">[Custom HTML]</div>
        case 'cta-button':
             if (settings?.ctaButton?.text && settings.ctaButton.url) {
                const ctaStyles: React.CSSProperties = {
                    fontFamily: settings.ctaButton.fontFamily,
                    fontSize: `${settings.ctaButton.fontSize}px`,
                    fontWeight: settings.ctaButton.fontWeight,
                    color: settings.ctaButton.textColor,
                    border: `${settings.ctaButton.borderWidth}px solid ${settings.ctaButton.borderColor || 'transparent'}`,
                    borderRadius: `${settings.ctaButton.borderRadius}px`,
                };
                 if (settings.ctaButton.backgroundType === 'gradient') {
                     ctaStyles.background = `linear-gradient(to right, ${settings.ctaButton.gradientStart}, ${settings.ctaButton.gradientEnd})`;
                 } else {
                     ctaStyles.backgroundColor = settings.ctaButton.backgroundColor;
                 }
                 
                return (
                    <Button asChild size="sm" className="cta-button"
                        style={ctaStyles}
                        onMouseEnter={e => {
                            if(settings.ctaButton.hoverBackgroundColor) {
                                e.currentTarget.style.background = ''; // remove gradient if it exists
                                e.currentTarget.style.backgroundColor = settings.ctaButton.hoverBackgroundColor;
                            }
                            if(settings.ctaButton.hoverTextColor) e.currentTarget.style.color = settings.ctaButton.hoverTextColor;
                            if(settings.ctaButton.hoverBorderColor) e.currentTarget.style.borderColor = settings.ctaButton.hoverBorderColor;
                        }}
                        onMouseLeave={e => {
                            e.currentTarget.style.background = ctaStyles.background || '';
                            e.currentTarget.style.backgroundColor = ctaStyles.backgroundColor || '';
                            e.currentTarget.style.color = ctaStyles.color || '';
                            e.currentTarget.style.borderColor = ctaStyles.borderColor || 'transparent';
                        }}
                    >
                        <a href={settings.ctaButton.url} target={settings.ctaButton.openInNewTab ? '_blank' : '_self'}>
                            {settings.ctaButton.text}
                        </a>
                    </Button>
                );
            }
            return null;
        default:
            if (element === 'none') return null;
            return <div className="text-muted-foreground text-xs"></div>;
    }
}


export default function HeaderEditor() {
    const { toast } = useToast();
    const [settings, setSettings] = useState<HeaderSettings | null>(null);
    const [branding, setBranding] = useState<BrandingSettings | null>(null);

    useEffect(() => {
        getHeaderSettings().then(setSettings);
        getBrandingSettings().then(setBranding);
    }, []);
    
    if (!settings || !branding) {
        return <div>Loading header settings...</div>
    }
    
    const handleSettingsChange = <K extends keyof HeaderSettings>(key: K, value: HeaderSettings[K]) => {
        setSettings(prev => prev ? { ...prev, [key]: value } : null);
    };

    const handleBarSettingsChange = (barName: 'topBar' | 'mainHeader' | 'bottomBar', newBarSettings: BarSettings) => {
        setSettings(prev => prev ? { ...prev, [barName]: newBarSettings } : null);
    }
    
    const handleSlotChange = (barSlotsName: 'topBarSlots' | 'mainHeaderSlots' | 'bottomBarSlots', slot: SlotName, element: HeaderElement) => {
        setSettings(prev => {
            if (!prev) return null;
            return {
                ...prev,
                [barSlotsName]: {
                    ...prev[barSlotsName],
                    [slot]: element
                }
            };
        });
    };

    const handleOffCanvasChange = (key: keyof HeaderSettings['offCanvas'], value: any) => {
        setSettings(prev => prev ? { ...prev, offCanvas: { ...prev.offCanvas, [key]: value } } : null);
    };

    const handleCtaChange = (key: keyof HeaderSettings['ctaButton'], value: any) => {
        setSettings(prev => prev ? { ...prev, ctaButton: { ...prev.ctaButton, [key]: value } } : null);
    };
    
    const handleSearchChange = (key: keyof HeaderSettings['searchForm'], value: any) => {
        setSettings(prev => prev ? { ...prev, searchForm: { ...prev.searchForm, [key]: value } } : null);
    };
    
    const handleSocialIconsChange = (key: keyof SocialIconStyleSettings, value: any) => {
        if (!settings) return;
        const newStyling = {
            ...settings.mainHeader.styling,
            socialIcons: {
                ...(settings.mainHeader.styling.socialIcons || {}),
                [key]: value,
            },
        };
        handleBarSettingsChange('mainHeader', { ...settings.mainHeader, styling: newStyling });
    };


    const handleSaveChanges = async () => {
        if (!settings) return;
        try {
            await updateHeaderSettings(settings);
            toast({
                title: "Header settings saved!",
                description: "Your changes have been saved successfully.",
            });
        } catch (error) {
            toast({
                variant: "destructive",
                title: "Error saving settings",
                description: "There was an issue saving your header settings.",
            });
        }
    };
    
    const getBarStyles = (barSettings: BarSettings): React.CSSProperties => {
        const styles: React.CSSProperties & { [key: string]: string } = {
            height: `${barSettings.height}px`,
            color: barSettings.textColor,
            '--link-color': barSettings.linkColor,
            '--link-hover-color': barSettings.linkHoverColor,
        };

        if (barSettings.backgroundType === 'gradient') {
            styles.background = `linear-gradient(to right, ${barSettings.gradientStart}, ${barSettings.gradientEnd})`;
        } else {
             styles.backgroundColor = barSettings.backgroundColor;
        }

        return styles;
    };
    
    
    const renderBar = (barSettings: BarSettings, slotSettings: SlotSettings) => {
        const justifyContent = barSettings.layout === 'space-between' ? 'justify-between' : 'flex-start';
        
        return (
            <div 
                className="p-2 border-b flex items-center"
                style={{ ...getBarStyles(barSettings) }}
            >
               <div className="container flex items-center w-full" style={{justifyContent}}>
                {barSettings.layout === 'space-between' ? (
                    <>
                        <div className="flex items-center gap-x-4">{renderElement(slotSettings.left, settings, branding)}{renderElement(slotSettings.centerLeft, settings, branding)}</div>
                        <div className="flex items-center gap-x-4">{renderElement(slotSettings.center, settings, branding)}</div>
                        <div className="flex items-center gap-x-4">{renderElement(slotSettings.centerRight, settings, branding)}{renderElement(slotSettings.right, settings, branding)}</div>
                    </>
                ) : barSettings.layout === 'center-logo' ? (
                     <>
                        <div className="flex-1 flex justify-start items-center gap-x-4">{renderElement(slotSettings.left, settings, branding)}{renderElement(slotSettings.centerLeft, settings, branding)}</div>
                        <div className="flex-shrink-0">{renderElement(slotSettings.center, settings, branding)}</div>
                        <div className="flex-1 flex justify-end items-center gap-x-4">{renderElement(slotSettings.centerRight, settings, branding)}{renderElement(slotSettings.right, settings, branding)}</div>
                    </>
                ) : (
                    <div className="flex items-center justify-between w-full">
                        <div className="flex items-center gap-x-4">{renderElement(slotSettings.left, settings, branding)}{renderElement(slotSettings.centerLeft, settings, branding)}</div>
                        <div className="flex items-center gap-x-4">{renderElement(slotSettings.center, settings, branding)}</div>
                        <div className="flex items-center gap-x-4">{renderElement(slotSettings.centerRight, settings, branding)}{renderElement(slotSettings.right, settings, branding)}</div>
                    </div>
               )}
               </div>
            </div>
        )
    }


    return (
        <div className="p-6">
            <div className="flex items-center justify-between pb-6">
                <h1 className="text-2xl font-semibold">Header Editor</h1>
                <Button onClick={handleSaveChanges}>Save Changes</Button>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
                <div className="lg:col-span-2">
                    <Card>
                        <CardHeader>
                            <CardTitle>Header Preview</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="w-full border rounded-lg bg-background">
                               {settings.topBar.enabled && renderBar(settings.topBar, settings.topBarSlots)}
                               {settings.mainHeader.enabled && renderBar(settings.mainHeader, settings.mainHeaderSlots)}
                               {settings.bottomBar.enabled && renderBar(settings.bottomBar, settings.bottomBarSlots)}
                            </div>
                        </CardContent>
                    </Card>
                </div>
                <div className="lg:col-span-1 space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>Header Settings</CardTitle>
                        </CardHeader>
                        <CardContent>
                             <Tabs defaultValue="layout">
                                <TabsList className="grid w-full grid-cols-2">
                                    <TabsTrigger value="layout">Layout</TabsTrigger>
                                    <TabsTrigger value="more">More</TabsTrigger>
                                </TabsList>
                                <TabsContent value="layout" className="pt-6 space-y-6">
                                    <div className="space-y-2">
                                        <Label>Sticky Header Section</Label>
                                         <Select value={settings.stickySection || 'none'} onValueChange={(v) => handleSettingsChange('stickySection', v)}>
                                            <SelectTrigger>
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="none">None</SelectItem>
                                                <SelectItem value="top">Top Bar</SelectItem>
                                                <SelectItem value="main">Main Header</SelectItem>
                                                <SelectItem value="bottom">Bottom Bar</SelectItem>
                                            </SelectContent>
                                        </Select>
                                        <p className="text-xs text-muted-foreground">
                                            Choose which header section remains visible when scrolling.
                                        </p>
                                    </div>
                                    <div className="space-y-2">
                                        <Collapsible>
                                            <div className="flex items-center justify-between rounded-lg border p-3">
                                                <Label htmlFor="enable-top-bar" className="font-semibold">Top Bar</Label>
                                                <div className="flex items-center gap-2">
                                                    <Switch id="enable-top-bar" checked={settings.topBar.enabled} onCheckedChange={(checked) => handleBarSettingsChange('topBar', {...settings.topBar, enabled: checked})} />
                                                    <CollapsibleTrigger asChild>
                                                        <Button variant="ghost" size="icon" className="h-8 w-8"><ChevronDown className="h-4 w-4"/></Button>
                                                    </CollapsibleTrigger>
                                                </div>
                                            </div>
                                            <CollapsibleContent className="py-2">
                                                <BarSettingsPanel title="Top Bar" settings={settings.topBar} onSettingsChange={(s) => handleBarSettingsChange('topBar', s)} slotSettings={settings.topBarSlots} onSlotChange={(slot, el) => handleSlotChange('topBarSlots', slot, el)}/>
                                            </CollapsibleContent>
                                        </Collapsible>
                                         <Collapsible>
                                            <div className="flex items-center justify-between rounded-lg border p-3">
                                                <Label htmlFor="enable-main-header" className="font-semibold">Main Header</Label>
                                                 <div className="flex items-center gap-2">
                                                    <Switch id="enable-main-header" checked={settings.mainHeader.enabled} onCheckedChange={(checked) => handleBarSettingsChange('mainHeader', {...settings.mainHeader, enabled: checked})} />
                                                    <CollapsibleTrigger asChild>
                                                        <Button variant="ghost" size="icon" className="h-8 w-8"><ChevronDown className="h-4 w-4"/></Button>
                                                     </CollapsibleTrigger>
                                                </div>
                                            </div>
                                            <CollapsibleContent className="py-2">
                                                 <BarSettingsPanel title="Main Header" settings={settings.mainHeader} onSettingsChange={(s) => handleBarSettingsChange('mainHeader', s)} slotSettings={settings.mainHeaderSlots} onSlotChange={(slot, el) => handleSlotChange('mainHeaderSlots', slot, el)} />
                                            </CollapsibleContent>
                                        </Collapsible>
                                         <Collapsible>
                                            <div className="flex items-center justify-between rounded-lg border p-3">
                                                <Label htmlFor="enable-bottom-bar" className="font-semibold">Bottom Bar</Label>
                                                 <div className="flex items-center gap-2">
                                                    <Switch id="enable-bottom-bar" checked={settings.bottomBar.enabled} onCheckedChange={(checked) => handleBarSettingsChange('bottomBar', {...settings.bottomBar, enabled: checked})} />
                                                    <CollapsibleTrigger asChild>
                                                        <Button variant="ghost" size="icon" className="h-8 w-8"><ChevronDown className="h-4 w-4"/></Button>
                                                    </CollapsibleTrigger>
                                                </div>
                                            </div>
                                            <CollapsibleContent className="py-2">
                                                 <BarSettingsPanel title="Bottom Bar" settings={settings.bottomBar} onSettingsChange={(s) => handleBarSettingsChange('bottomBar', s)} slotSettings={settings.bottomBarSlots} onSlotChange={(slot, el) => handleSlotChange('bottomBarSlots', slot, el)} />
                                            </CollapsibleContent>
                                        </Collapsible>
                                    </div>
                                </TabsContent>
                                <TabsContent value="more" className="pt-6">
                                     <Tabs defaultValue="off-canvas">
                                        <TabsList className="grid w-full grid-cols-4">
                                            <TabsTrigger value="off-canvas">Off-Canvas</TabsTrigger>
                                            <TabsTrigger value="cta">CTA</TabsTrigger>
                                            <TabsTrigger value="social">Social</TabsTrigger>
                                            <TabsTrigger value="search">Search</TabsTrigger>
                                        </TabsList>
                                        <TabsContent value="off-canvas" className="pt-4 space-y-4">
                                            <div className="flex items-center justify-between rounded-lg border p-3">
                                                <Label htmlFor="enable-off-canvas" className="font-semibold">Enable Off-Canvas Menu</Label>
                                                <Switch id="enable-off-canvas" checked={settings.offCanvas?.enabled ?? true} onCheckedChange={(c) => handleOffCanvasChange('enabled', c)} />
                                            </div>
                                            <div className="space-y-2">
                                                <Label htmlFor="off-canvas-menu">Menu to Display</Label>
                                                <Select value={settings.offCanvas?.menu || 'primary'} onValueChange={(v) => handleOffCanvasChange('menu', v)}>
                                                    <SelectTrigger id="off-canvas-menu"><SelectValue /></SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="primary">Primary Menu</SelectItem>
                                                        <SelectItem value="secondary">Secondary Menu</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                            <div className="space-y-2">
                                                <Label htmlFor="off-canvas-position">Position</Label>
                                                <Select value={settings.offCanvas?.position || 'left'} onValueChange={(v) => handleOffCanvasChange('position', v)}>
                                                    <SelectTrigger id="off-canvas-position"><SelectValue /></SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="left">Left</SelectItem>
                                                        <SelectItem value="right">Right</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                            <div className="space-y-2">
                                                <div className="flex items-center justify-between rounded-lg border p-3">
                                                    <Label htmlFor="show-search" className="font-normal">Show Search Bar</Label>
                                                    <Switch id="show-search" checked={settings.offCanvas?.showSearch ?? true} onCheckedChange={(c) => handleOffCanvasChange('showSearch', c)} />
                                                </div>
                                                <div className="flex items-center justify-between rounded-lg border p-3">
                                                    <Label htmlFor="show-social" className="font-normal">Show Social Links</Label>
                                                    <Switch id="show-social" checked={settings.offCanvas?.showSocial ?? true} onCheckedChange={(c) => handleOffCanvasChange('showSocial', c)} />
                                                </div>
                                                <div className="flex items-center justify-between rounded-lg border p-3">
                                                    <Label htmlFor="show-newsletter" className="font-normal">Show Newsletter Form</Label>
                                                    <Switch id="show-newsletter" checked={settings.offCanvas?.showNewsletter ?? false} onCheckedChange={(c) => handleOffCanvasChange('showNewsletter', c)} />
                                                </div>
                                                <div className="flex items-center justify-between rounded-lg border p-3">
                                                    <Label htmlFor="show-popular" className="font-normal">Show Popular Posts</Label>
                                                    <Switch id="show-popular" checked={settings.offCanvas?.showPopular ?? false} onCheckedChange={(c) => handleOffCanvasChange('showPopular', c)} />
                                                </div>
                                                <div className="flex items-center justify-between rounded-lg border p-3">
                                                    <Label htmlFor="show-latest" className="font-normal">Show Latest Posts</Label>
                                                    <Switch id="show-latest" checked={settings.offCanvas?.showLatest ?? true} onCheckedChange={(c) => handleOffCanvasChange('showLatest', c)} />
                                                </div>
                                            </div>
                                            <div className="space-y-2">
                                                <Label htmlFor="custom-content-top">Custom Content (Top)</Label>
                                                <Textarea
                                                    id="custom-content-top"
                                                    placeholder="HTML is allowed"
                                                    value={settings.offCanvas?.customContentTop || ''}
                                                    onChange={(e) => handleOffCanvasChange('customContentTop', e.target.value)}
                                                />
                                            </div>
                                            <div className="space-y-2">
                                                <Label htmlFor="custom-content-bottom">Custom Content (Bottom)</Label>
                                                <Textarea
                                                    id="custom-content-bottom"
                                                    placeholder="HTML is allowed"
                                                    value={settings.offCanvas?.customContentBottom || ''}
                                                    onChange={(e) => handleOffCanvasChange('customContentBottom', e.target.value)}
                                                />
                                            </div>
                                        </TabsContent>
                                        <TabsContent value="cta" className="pt-4 space-y-4">
                                            <div className="space-y-2">
                                                <Label htmlFor="cta-text">Button Text</Label>
                                                <Input id="cta-text" value={settings.ctaButton?.text || ''} onChange={(e) => handleCtaChange('text', e.target.value)} placeholder="Join us"/>
                                            </div>
                                            <div className="space-y-2">
                                                <Label htmlFor="cta-url">Button URL</Label>
                                                <Input id="cta-url" value={settings.ctaButton?.url || ''} onChange={(e) => handleCtaChange('url', e.target.value)} placeholder="https://example.com" />
                                            </div>
                                            <div className="flex items-center justify-between rounded-lg border p-3">
                                                <Label htmlFor="cta-new-tab" className="font-normal">Open in New Tab</Label>
                                                <Switch id="cta-new-tab" checked={settings.ctaButton?.openInNewTab ?? true} onCheckedChange={(c) => handleCtaChange('openInNewTab', c)} />
                                            </div>
                                            
                                            <Collapsible>
                                                <CollapsibleTrigger className="font-semibold text-sm">Styling</CollapsibleTrigger>
                                                <CollapsibleContent className="pt-4 space-y-4">
                                                    <div className="grid grid-cols-2 gap-4">
                                                        <div className="space-y-2"><Label>Font Family</Label><Select value={settings.ctaButton?.fontFamily || 'Inter'} onValueChange={(v) => handleCtaChange('fontFamily', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{popularFonts.map(font => <SelectItem key={font} value={font}>{font}</SelectItem>)}</SelectContent></Select></div>
                                                        <div className="space-y-2"><Label>Font Size (px)</Label><Input type="number" value={settings.ctaButton?.fontSize || 14} onChange={(e) => handleCtaChange('fontSize', parseInt(e.target.value))} /></div>
                                                    </div>
                                                    <div className="grid grid-cols-2 gap-4">
                                                            <div className="space-y-2"><Label>Font Weight</Label><Select value={settings.ctaButton?.fontWeight || '500'} onValueChange={(v) => handleCtaChange('fontWeight', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="400">Normal</SelectItem><SelectItem value="500">Medium</SelectItem><SelectItem value="600">Semi-Bold</SelectItem><SelectItem value="700">Bold</SelectItem></SelectContent></Select></div>
                                                            <ColorPicker label="Text Color" color={settings.ctaButton?.textColor || '#ffffff'} onChange={(c) => handleCtaChange('textColor', c)} />
                                                    </div>

                                                    <Separator />
                                                    <h4 className="font-medium text-sm">Background</h4>
                                                    <RadioGroup value={settings.ctaButton?.backgroundType || 'solid'} onValueChange={(v:any) => handleCtaChange('backgroundType', v)} className="flex gap-4">
                                                        <div className="flex items-center space-x-2"><RadioGroupItem value="solid" id="cta-bg-solid" /><Label htmlFor="cta-bg-solid">Solid</Label></div>
                                                        <div className="flex items-center space-x-2"><RadioGroupItem value="gradient" id="cta-bg-gradient" /><Label htmlFor="cta-bg-gradient">Gradient</Label></div>
                                                    </RadioGroup>
                                                    {settings.ctaButton?.backgroundType === 'solid' ? (
                                                        <ColorPicker label="Background Color" color={settings.ctaButton.backgroundColor || '#007bff'} onChange={(c) => handleCtaChange('backgroundColor', c)} />
                                                    ) : (
                                                        <div className="grid grid-cols-2 gap-4">
                                                            <ColorPicker label="Gradient Start" color={settings.ctaButton.gradientStart || '#007bff'} onChange={(c) => handleCtaChange('gradientStart', c)} />
                                                            <ColorPicker label="Gradient End" color={settings.ctaButton.gradientEnd || '#0056b3'} onChange={(c) => handleCtaChange('gradientEnd', c)} />
                                                        </div>
                                                    )}
                                                        <Separator />
                                                    <h4 className="font-medium text-sm">Hover State</h4>
                                                    <ColorPicker label="Hover BG Color" color={settings.ctaButton?.hoverBackgroundColor || ''} onChange={(c) => handleCtaChange('hoverBackgroundColor', c)} />
                                                    <ColorPicker label="Hover Text Color" color={settings.ctaButton?.hoverTextColor || ''} onChange={(c) => handleCtaChange('hoverTextColor', c)} />

                                                        <Separator />
                                                    <h4 className="font-medium text-sm">Border</h4>
                                                    <ColorPicker label="Border Color" color={settings.ctaButton?.borderColor || '#007bff'} onChange={(c) => handleCtaChange('borderColor', c)} />
                                                     <ColorPicker label="Hover Border Color" color={settings.ctaButton?.hoverBorderColor || ''} onChange={(c) => handleCtaChange('hoverBorderColor', c)} />
                                                        <div className="grid grid-cols-2 gap-4">
                                                        <div className="space-y-2"><Label>Border Width (px)</Label><Input type="number" value={settings.ctaButton?.borderWidth || 0} onChange={(e) => handleCtaChange('borderWidth', parseInt(e.target.value))} /></div>
                                                        <div className="space-y-2"><Label>Border Radius (px)</Label><Slider value={[settings.ctaButton?.borderRadius || 8]} onValueChange={(v) => handleCtaChange('borderRadius', v[0])} max={50} step={1} /></div>
                                                    </div>

                                                </CollapsibleContent>
                                            </Collapsible>
                                        </TabsContent>
                                         <TabsContent value="social" className="pt-4 space-y-4">
                                              <h4 className="font-medium text-sm">Social Icons Styling</h4>
                                              <RadioGroup value={settings.mainHeader.styling.socialIcons?.style || 'official'} onValueChange={(v:any) => handleSocialIconsChange('style', v)} className="flex gap-4">
                                                  <div className="flex items-center space-x-2"><RadioGroupItem value="official" id="social-official" /><Label htmlFor="social-official">Official</Label></div>
                                                  <div className="flex items-center space-x-2"><RadioGroupItem value="custom" id="social-custom" /><Label htmlFor="social-custom">Custom</Label></div>
                                              </RadioGroup>
                                              
                                               {settings.mainHeader.styling.socialIcons?.style === 'custom' && (
                                                   <div className="space-y-4 pl-6 border-l ml-2">
                                                        <ColorPicker label="Icon Color" color={settings.mainHeader.styling.socialIcons?.textColor || ''} onChange={(c) => handleSocialIconsChange('textColor', c)} />
                                                        <ColorPicker label="Background Color" color={settings.mainHeader.styling.socialIcons?.backgroundColor || ''} onChange={(c) => handleSocialIconsChange('backgroundColor', c)} />
                                                        <Separator />
                                                        <h4 className="font-medium text-sm">Hover State</h4>
                                                        <ColorPicker label="Hover Icon Color" color={settings.mainHeader.styling.socialIcons?.hoverTextColor || ''} onChange={(c) => handleSocialIconsChange('hoverTextColor', c)} />
                                                        <ColorPicker label="Hover BG Color" color={settings.mainHeader.styling.socialIcons?.hoverBackgroundColor || ''} onChange={(c) => handleSocialIconsChange('hoverBackgroundColor', c)} />
                                                    </div>
                                               )}
                                         </TabsContent>
                                        <TabsContent value="search" className="pt-4 space-y-4">
                                            <ColorPicker label="Background Color" color={settings.searchForm?.backgroundColor || '#f0f0f0'} onChange={(color) => handleSearchChange('backgroundColor', color)} />
                                            <ColorPicker label="Text Color" color={settings.searchForm?.textColor || '#000000'} onChange={(color) => handleSearchChange('textColor', color)} />
                                            <ColorPicker label="Border Color" color={settings.searchForm?.borderColor || '#e0e0e0'} onChange={(color) => handleSearchChange('borderColor', color)} />
                                        </TabsContent>
                                     </Tabs>
                                </TabsContent>
                            </Tabs>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}
