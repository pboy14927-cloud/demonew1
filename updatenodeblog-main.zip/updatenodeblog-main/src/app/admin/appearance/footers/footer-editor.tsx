

'use client';

import { useState, CSSProperties, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Switch } from '@/components/ui/switch';
import { ChevronDown, Facebook, Twitter, Instagram, Tag, Rss, Mail, Shield } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import ColorPicker from '@/components/admin/color-picker';
import { useToast } from '@/hooks/use-toast';
import { FooterSettings, getFooterSettings, updateFooterSettings, FooterBarSettings, FooterElement, SlotName, FooterSlotSettings, FooterStyling, getPublishedPosts, getCategories, getTags, getBrandingSettings, getMenus, Post, Category, Tag, BrandingSettings, Menu, SocialIconStyleSettings } from '@/lib/data';
import Link from 'next/link';
import { SocialIcon } from '@/components/blog/sidebar';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import Image from 'next/image';
import FooterLink from '@/components/footer-link';
import { Separator } from '@/components/ui/separator';


const popularFonts = [
    'Inter', 'Roboto', 'Open Sans', 'Lato', 'Montserrat', 'Oswald', 'Raleway', 'Poppins', 'Nunito', 'Merriweather'
];


const FooterBarSettingsPanel = ({ title, settings, onSettingsChange }: { title: string, settings: FooterBarSettings, onSettingsChange: (settings: FooterBarSettings) => void }) => {
    
    const handleStylingChange = (prop: keyof FooterStyling, value: any) => {
        onSettingsChange({
            ...settings,
            styling: {
                ...settings.styling,
                [prop]: value,
            },
        });
    };
    
    const handleSlotChange = (slot: SlotName, prop: keyof FooterSlotSettings, value: any) => {
        onSettingsChange({
            ...settings,
            slots: {
                ...settings.slots,
                [slot]: {
                    ...settings.slots[slot],
                    [prop]: value,
                }
            }
        });
    }

    const handleSocialIconStyleChange = (prop: keyof SocialIconStyleSettings, value: any) => {
        const newStyling = {
            ...settings.styling,
            socialIconStyles: {
                ...settings.styling.socialIconStyles,
                [prop]: value,
            }
        };
        onSettingsChange({ ...settings, styling: newStyling });
    }
    
    const slotLabels: Record<SlotName, string> = {
        left: 'Left',
        centerLeft: 'Center Left',
        center: 'Center',
        centerRight: 'Center Right',
        right: 'Right'
    };

    return (
        <Collapsible>
            <div className="flex items-center justify-between rounded-lg border p-3">
                <Label htmlFor={`enable-${title}`} className="font-semibold">{title}</Label>
                <div className="flex items-center gap-2">
                    <Switch id={`enable-${title}`} checked={settings.enabled} onCheckedChange={(checked) => onSettingsChange({...settings, enabled: checked})} />
                    <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8"><ChevronDown className="h-4 w-4"/></Button>
                    </CollapsibleTrigger>
                </div>
            </div>
            <CollapsibleContent className="py-2">
                 <div className="border p-4 rounded-md bg-muted/30">
                     <Tabs defaultValue="layout">
                        <TabsList className="grid w-full grid-cols-2">
                            <TabsTrigger value="layout">Layout</TabsTrigger>
                            <TabsTrigger value="styling">Styling</TabsTrigger>
                        </TabsList>
                         <TabsContent value="layout" className="pt-4 space-y-4">
                            <div className="space-y-2">
                                <Label>Layout</Label>
                                <Select value={settings.layout} onValueChange={(v) => onSettingsChange({...settings, layout: v})}>
                                    <SelectTrigger><SelectValue /></SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="5-columns">5 Columns (Default)</SelectItem>
                                        <SelectItem value="4-columns">4 Columns</SelectItem>
                                        <SelectItem value="3-columns">3 Columns</SelectItem>
                                        <SelectItem value="2-columns">2 Columns</SelectItem>
                                        <SelectItem value="1-column">1 Column</SelectItem>
                                        <SelectItem value="space-between">Space Between</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            {(Object.keys(slotLabels) as SlotName[]).map(pos => (
                                <div key={pos} className="space-y-3 border p-3 rounded-md">
                                    <h4 className="font-medium text-sm">{slotLabels[pos]}</h4>
                                    <div className="space-y-2">
                                        <Label>Element Type</Label>
                                        <Select value={settings.slots[pos].elementType} onValueChange={(v: FooterElement) => handleSlotChange(pos, 'elementType', v)}>
                                            <SelectTrigger><SelectValue /></SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="none">None</SelectItem>
                                                <SelectItem value="site-logo">Site Logo</SelectItem>
                                                <SelectItem value="text-widget">About Text</SelectItem>
                                                <SelectItem value="logo-with-about">Logo with About</SelectItem>
                                                <SelectItem value="social-icons">Social Icons</SelectItem>
                                                <SelectItem value="copyright">Copyright Text</SelectItem>
                                                <SelectItem value="footer-navigation">Footer Navigation</SelectItem>
                                                <SelectItem value="recent-posts">Recent Posts</SelectItem>
                                                <SelectItem value="popular-posts">Popular Posts</SelectItem>
                                                <SelectItem value="categories">Categories</SelectItem>
                                                <SelectItem value="tag-cloud">Tag Cloud</SelectItem>
                                                <SelectItem value="newsletter-form">Newsletter Form</SelectItem>
                                                <SelectItem value="custom-html">Custom HTML</SelectItem>
                                                <SelectItem value="footer-ad">Footer Ad</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    {settings.slots[pos].elementType !== 'none' && settings.slots[pos].elementType !== 'site-logo' && (
                                    <div className="space-y-2">
                                        <Label>Widget Title</Label>
                                        <Input value={settings.slots[pos].widgetTitle} onChange={(e) => handleSlotChange(pos, 'widgetTitle', e.target.value)} />
                                    </div>
                                    )}
                                </div>
                            ))}
                         </TabsContent>
                         <TabsContent value="styling" className="pt-4 space-y-4">
                             <RadioGroup value={settings.styling.backgroundType} onValueChange={(v: any) => handleStylingChange('backgroundType', v)} className="flex gap-4">
                                <div className="flex items-center space-x-2"><RadioGroupItem value="solid" id={`bg-solid-${title.replace(' ','-')}`} /><Label htmlFor={`bg-solid-${title.replace(' ','-')}`}>Solid</Label></div>
                                <div className="flex items-center space-x-2"><RadioGroupItem value="gradient" id={`bg-gradient-${title.replace(' ','-')}`} /><Label htmlFor={`bg-gradient-${title.replace(' ','-')}`}>Gradient</Label></div>
                            </RadioGroup>
                            {settings.styling.backgroundType === 'gradient' ? (
                                <div className="grid grid-cols-2 gap-4">
                                    <ColorPicker label="Gradient Start" color={settings.styling.gradientStart} onChange={(color) => handleStylingChange('gradientStart', color)} />
                                    <ColorPicker label="Gradient End" color={settings.styling.gradientEnd} onChange={(color) => handleStylingChange('gradientEnd', color)} />
                                </div>
                            ) : (
                                <ColorPicker label="Background Color" color={settings.styling.backgroundColor} onChange={(color) => handleStylingChange('backgroundColor', color)} />
                            )}
                            <ColorPicker label="Text Color" color={settings.styling.textColor} onChange={(color) => handleStylingChange('textColor', color)} />
                            <ColorPicker label="Link Color" color={settings.styling.linkColor} onChange={(color) => handleStylingChange('linkColor', color)} />
                            <ColorPicker label="Link Hover Color" color={settings.styling.linkHoverColor} onChange={(color) => handleStylingChange('linkHoverColor', color)} />
                            
                             <div className="space-y-2 pt-4 border-t">
                                <Label>Font Family</Label>
                                <Select value={settings.styling.fontFamily} onValueChange={(v) => handleStylingChange('fontFamily', v)}>
                                    <SelectTrigger><SelectValue /></SelectTrigger>
                                    <SelectContent>
                                        {popularFonts.map(font => <SelectItem key={font} value={font} style={{fontFamily: font}}>{font}</SelectItem>)}
                                    </SelectContent>
                                </Select>
                            </div>
                             <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label>Font Size (px)</Label>
                                    <Input type="number" value={settings.styling.fontSize} onChange={(e) => handleStylingChange('fontSize', parseInt(e.target.value))} />
                                </div>
                                <div className="space-y-2">
                                    <Label>Font Weight</Label>
                                    <Select value={settings.styling.fontWeight} onValueChange={(v) => handleStylingChange('fontWeight', v)}>
                                        <SelectTrigger><SelectValue /></SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="300">Light</SelectItem>
                                            <SelectItem value="400">Normal</SelectItem>
                                            <SelectItem value="500">Medium</SelectItem>
                                            <SelectItem value="600">Semi-Bold</SelectItem>
                                            <SelectItem value="700">Bold</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                            </div>
                            
                            <Separator />
                            <h4 className="font-semibold text-sm">Social Icons</h4>
                            <RadioGroup value={settings.styling.socialIconStyles?.style || 'official'} onValueChange={(v:any) => handleSocialIconStyleChange('style', v)} className="flex gap-4">
                                <div className="flex items-center space-x-2"><RadioGroupItem value="official" id={`social-official-${title}`} /><Label htmlFor={`social-official-${title}`}>Official</Label></div>
                                <div className="flex items-center space-x-2"><RadioGroupItem value="custom" id={`social-custom-${title}`} /><Label htmlFor={`social-custom-${title}`}>Custom</Label></div>
                            </RadioGroup>
                            {settings.styling.socialIconStyles?.style === 'custom' && (
                                <div className="space-y-4 pl-6 border-l ml-2">
                                    <ColorPicker label="Icon Color" color={settings.styling.socialIconStyles.iconColor || ''} onChange={(c) => handleSocialIconStyleChange('iconColor', c)} />
                                    <ColorPicker label="Background Color" color={settings.styling.socialIconStyles.backgroundColor || ''} onChange={(c) => handleSocialIconStyleChange('backgroundColor', c)} />
                                    <ColorPicker label="Hover Icon Color" color={settings.styling.socialIconStyles.hoverIconColor || ''} onChange={(c) => handleSocialIconStyleChange('hoverIconColor', c)} />
                                    <ColorPicker label="Hover BG Color" color={settings.styling.socialIconStyles.hoverBackgroundColor || ''} onChange={(c) => handleSocialIconStyleChange('hoverBackgroundColor', c)} />
                                </div>
                            )}

                         </TabsContent>
                     </Tabs>
                </div>
            </CollapsibleContent>
        </Collapsible>
    )
}


export default function FooterEditor() {
    const { toast } = useToast();
    const [settings, setSettings] = useState<FooterSettings | null>(null);
    const [menus, setMenus] = useState<Menu[]>([]);
    const [branding, setBranding] = useState<BrandingSettings | null>(null);
    const [posts, setPosts] = useState<Post[]>([]);
    const [categories, setCategories] = useState<Category[]>([]);
    const [tags, setTags] = useState<Tag[]>([]);

    useEffect(() => {
        getFooterSettings().then(setSettings);
        getMenus().then(setMenus);
        getBrandingSettings().then(setBranding);
        getPublishedPosts().then(setPosts);
        getCategories().then(setCategories);
        getTags().then(setTags);
    }, []);

    const handleSettingsChange = <K extends keyof FooterSettings>(key: K, value: FooterSettings[K]) => {
        setSettings(prev => prev ? { ...prev, [key]: value } : null);
    };

    const handleBarSettingsChange = (barName: 'topFooter' | 'mainFooter' | 'bottomFooter', newBarSettings: FooterBarSettings) => {
        setSettings(prev => prev ? { ...prev, [barName]: newBarSettings } : null);
    }

    const handleSaveChanges = async () => {
        if (!settings) return;
        try {
            await updateFooterSettings(settings);
            toast({
                title: "Footer settings saved!",
                description: "Your changes have been saved successfully.",
            });
        } catch (error) {
             toast({
                variant: "destructive",
                title: "Error saving settings",
                description: "There was an issue saving your footer settings.",
            });
        }
    };
  
    if (!settings || !branding || !menus || !posts || !categories || !tags) {
        return <div>Loading...</div>
    }

    const { topFooter, mainFooter, bottomFooter, copyrightText, aboutText, customHtml, numPosts, numCategories, numTags, footerNavMenu } = settings;

  const getBarStyles = (styling: FooterStyling): CSSProperties => {
        const styles: CSSProperties & { [key: string]: string } = {
            '--text-color': styling.textColor,
            '--link-color': styling.linkColor,
            '--link-hover-color': styling.linkHoverColor,
            fontFamily: styling.fontFamily,
            fontSize: `${styling.fontSize}px`,
            fontWeight: styling.fontWeight,
            color: styling.textColor
        };

        if (styling.backgroundType === 'gradient') {
            styles.background = `linear-gradient(to right, ${styling.gradientStart}, ${styling.gradientEnd})`;
        } else {
            styles.backgroundColor = styling.backgroundColor;
        }
        return styles;
    };
    
    const renderSlot = (slot: FooterSlotSettings) => {
        switch(slot.elementType) {
            case 'site-logo':
                return branding.logoUrl ? <Image src={branding.logoUrl} alt="logo" width={branding.logoWidth || 150} height={40} className="h-10 w-auto" /> : <div className="h-10 bg-gray-300 rounded w-32" />
            case 'text-widget':
                return (
                    <div className="space-y-2">
                        <h4 className="font-semibold">{slot.widgetTitle}</h4>
                        <p className="text-sm opacity-80">{aboutText}</p>
                    </div>
                )
            case 'logo-with-about':
                 return (
                    <div className="space-y-2">
                         {branding.logoUrl ? <Image src={branding.logoUrl} alt="logo" width={branding.logoWidth || 150} height={40} className="h-10 w-auto" /> : <div className="h-10 bg-gray-300 rounded w-32" />}
                        <p className="text-sm opacity-80">{aboutText}</p>
                    </div>
                )
            case 'social-icons':
                 return (
                    <div className="space-y-2">
                        <h4 className="font-semibold">{slot.widgetTitle}</h4>
                        <div className="flex space-x-2">
                           {branding.socialLinks.map(link => (
                                <Button key={link.id} asChild variant="outline" size="icon" style={{color: 'var(--link-color)'}}><a href={link.url} target="_blank"><SocialIcon platform={link.platform} /></a></Button>
                           ))}
                        </div>
                    </div>
                )
             case 'copyright':
                return (
                    <p className="text-sm opacity-80">
                        {copyrightText.replace('[year]', new Date().getFullYear().toString())}
                    </p>
                )
             case 'footer-navigation':
                 const footerMenu = menus.find(m => m.id === settings.footerNavMenu || m.locations.includes('footer'));
                return (
                    <nav className="flex flex-nowrap items-center gap-x-6">
                        {footerMenu?.items.map(item => (
                            <FooterLink key={item.id} href={item.url}>{item.label}</FooterLink>
                        ))}
                    </nav>
                )
             case 'recent-posts':
                return (
                    <div className="space-y-2">
                        <h4 className="font-semibold">{slot.widgetTitle}</h4>
                        <ul className="text-sm space-y-1">
                             {posts.slice(0, numPosts).map(post => (
                                <li key={post.id}><FooterLink href={`/${post.slug}`}>{post.title}</FooterLink></li>
                            ))}
                        </ul>
                    </div>
                )
            case 'popular-posts':
                 return (
                    <div className="space-y-2">
                        <h4 className="font-semibold">{slot.widgetTitle}</h4>
                        <ul className="text-sm space-y-1">
                            {posts.slice(0, numPosts).map(post => (
                                <li key={post.id}><FooterLink href={`/${post.slug}`}>{post.title}</FooterLink></li>
                            ))}
                        </ul>
                    </div>
                )
             case 'categories':
                 return (
                    <div className="space-y-2">
                        <h4 className="font-semibold">{slot.widgetTitle}</h4>
                        <ul className="text-sm space-y-1">
                           {categories.slice(0, numCategories).map(cat => (
                                <li key={cat.id}><FooterLink href={`/category/${cat.slug}`}>{cat.name}</FooterLink></li>
                           ))}
                        </ul>
                    </div>
                 )
             case 'tag-cloud':
                return (
                    <div className="space-y-2">
                        <h4 className="font-semibold">{slot.widgetTitle}</h4>
                        <div className="flex flex-wrap gap-2">
                           {tags.slice(0, numTags).map(tag => (
                               <Button asChild key={tag.id} size="sm" variant="outline" className="text-xs" style={{color: 'var(--link-color)'}}><Link href={`/tag/${tag.slug}`}>{tag.name}</Link></Button>
                           ))}
                        </div>
                    </div>
                )
             case 'newsletter-form':
                return (
                    <div className="space-y-2">
                        <h4 className="font-semibold">{slot.widgetTitle}</h4>
                        <div className="flex gap-2">
                            <Input placeholder="Email address" className="bg-background/50 text-foreground" />
                            <Button variant="secondary" className="text-foreground">Subscribe</Button>
                        </div>
                    </div>
                )
            case 'custom-html':
                 return (
                    <div className="space-y-2">
                        <h4 className="font-semibold">{slot.widgetTitle}</h4>
                        <div dangerouslySetInnerHTML={{ __html: customHtml }} />
                    </div>
                )
            case 'footer-ad':
                return (
                    <div className="space-y-2">
                        <h4 className="font-semibold">{slot.widgetTitle}</h4>
                        <div className="p-4 bg-muted/50 rounded-md text-center">
                            <Image src="https://placehold.co/300x250.png" data-ai-hint="advertisement" alt="advertisement" width={300} height={250} />
                        </div>
                    </div>
                )
            default:
                return null;
        }
    }


  return (
    <div className="p-6">
      <div className="flex items-center justify-between pb-6">
        <h1 className="text-2xl font-semibold">Footer Editor</h1>
        <Button onClick={handleSaveChanges}>Save Changes</Button>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
            <Card>
                <CardHeader>
                    <CardTitle>Footer Preview</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="bg-background/80 rounded-lg overflow-hidden border">
                       {topFooter.enabled && (
                            <div className="p-8" style={getBarStyles(topFooter.styling)}>
                                <div className={`grid gap-8 grid-cols-1 sm:grid-cols-2 md:grid-cols-${topFooter.layout.split('-')[0]}`}>
                                    {Object.values(topFooter.slots).map((slot, i) => (
                                        <div key={i}>
                                            {renderSlot(slot)}
                                        </div>
                                    ))}
                                </div>
                            </div>
                       )}
                       {mainFooter.enabled && (
                            <div className="p-8 border-t" style={getBarStyles(mainFooter.styling)}>
                                <div className={`grid gap-8 grid-cols-1 sm:grid-cols-2 md:grid-cols-${mainFooter.layout.split('-')[0]}`}>
                                    {Object.values(mainFooter.slots).map((slot, i) => (
                                        <div key={i}>
                                            {renderSlot(slot)}
                                        </div>
                                    ))}
                                </div>
                            </div>
                       )}
                       {bottomFooter.enabled && (
                             <div className="p-4 border-t flex justify-between items-center" style={getBarStyles(bottomFooter.styling)}>
                                {renderSlot(bottomFooter.slots.left)}
                                {renderSlot(bottomFooter.slots.right)}
                            </div>
                       )}
                    </div>
                </CardContent>
            </Card>
        </div>
        <div className="space-y-6">
           <Card>
            <CardHeader>
                <CardTitle>Footer Settings</CardTitle>
            </CardHeader>
             <CardContent className="space-y-2">
                <FooterBarSettingsPanel title="Top Footer" settings={topFooter} onSettingsChange={(s) => handleBarSettingsChange('topFooter', s)} />
                <FooterBarSettingsPanel title="Main Footer" settings={mainFooter} onSettingsChange={(s) => handleBarSettingsChange('mainFooter', s)} />
                <FooterBarSettingsPanel title="Bottom Footer" settings={bottomFooter} onSettingsChange={(s) => handleBarSettingsChange('bottomFooter', s)} />
             </CardContent>
          </Card>
           <Card>
            <CardHeader>
                <CardTitle>Content Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                 <div className="space-y-2">
                    <Label htmlFor="about-text">About Text</Label>
                    <Textarea 
                        id="about-text" 
                        value={aboutText}
                        onChange={(e) => handleSettingsChange('aboutText', e.target.value)}
                    />
                </div>
                <div className="space-y-2">
                    <Label htmlFor="custom-html">Custom HTML</Label>
                    <Textarea 
                        id="custom-html" 
                        value={customHtml}
                        onChange={(e) => handleSettingsChange('customHtml', e.target.value)}
                    />
                </div>
                <div className="space-y-2">
                    <Label htmlFor="num-posts">Number of Posts in Widgets</Label>
                    <Input id="num-posts" type="number" value={numPosts} onChange={e => handleSettingsChange('numPosts', parseInt(e.target.value))} />
                </div>
                <div className="space-y-2">
                    <Label htmlFor="num-categories">Number of Categories in Widget</Label>
                    <Input id="num-categories" type="number" value={numCategories} onChange={e => handleSettingsChange('numCategories', parseInt(e.target.value))} />
                </div>
                 <div className="space-y-2">
                    <Label htmlFor="num-tags">Number of Tags in Widget</Label>
                    <Input id="num-tags" type="number" value={numTags} onChange={e => handleSettingsChange('numTags', parseInt(e.target.value))} />
                </div>
                 <div className="space-y-2">
                    <Label htmlFor="footer-nav">Footer Nav Menu</Label>
                    <Select value={footerNavMenu} onValueChange={(v) => handleSettingsChange('footerNavMenu', v)}>
                        <SelectTrigger><SelectValue/></SelectTrigger>
                        <SelectContent>
                             {menus.map(menu => (
                                <SelectItem key={menu.id} value={menu.id}>{menu.name}</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
                <CardTitle>Copyright</CardTitle>
            </CardHeader>
            <CardContent>
                <div className="space-y-2">
                    <Label htmlFor="copyright-text">Copyright Text</Label>
                    <Textarea 
                        id="copyright-text" 
                        value={copyrightText}
                        onChange={(e) => handleSettingsChange('copyrightText', e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground">Use `[year]` to display the current year.</p>
                </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

