

import React from 'react';
import FooterEditor from './footer-editor';

export default function FooterPage() {
    return <FooterEditor />;
}
