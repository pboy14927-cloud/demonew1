
'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { UploadCloud, Plus, Trash2, Loader2 } from 'lucide-react';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { getBrandingSettings, updateBrandingSettings, BrandingSettings, Media } from '@/lib/data';
import MediaLibraryModal from '@/components/admin/media-library-modal';
import { Skeleton } from '@/components/ui/skeleton';

export default function BrandingPage() {
    const { toast } = useToast();
    const [settings, setSettings] = useState<BrandingSettings | null>(null);
    const [isMediaDialogOpen, setIsMediaDialogOpen] = useState(false);
    const [mediaTarget, setMediaTarget] = useState<'logoUrl' | 'faviconUrl' | null>(null);
    const [isSaving, setIsSaving] = useState(false);

    useEffect(() => {
        getBrandingSettings().then(setSettings);
    }, []);

    const handleInputChange = (key: keyof BrandingSettings, value: any) => {
        setSettings(prev => prev ? { ...prev, [key]: value } : null);
    };

    const handleSaveChanges = async () => {
        if (!settings) return;
        setIsSaving(true);
        try {
            await updateBrandingSettings(settings);
            toast({
                title: "Settings Saved",
                description: "Your branding settings have been saved successfully.",
            });
        } catch (error) {
            toast({
                variant: 'destructive',
                title: 'Error Saving Settings',
                description: 'There was a problem saving your settings.'
            })
        } finally {
            setIsSaving(false);
        }
    }
    
    const handleAddSocialLink = () => {
        const newLinks = [...(settings?.socialLinks || []), { id: `link-${Date.now()}`, platform: '', url: '' }];
        handleInputChange('socialLinks', newLinks);
    };

    const handleRemoveSocialLink = (id: string) => {
        if (!settings) return;
        const newLinks = settings.socialLinks.filter(link => link.id !== id);
        handleInputChange('socialLinks', newLinks);
    };

    const handleSocialLinkChange = (id: string, field: 'platform' | 'url', value: string) => {
        if (!settings) return;
        const newLinks = settings.socialLinks.map(link => link.id === id ? { ...link, [field]: value } : link);
        handleInputChange('socialLinks', newLinks);
    };

    const openMediaLibrary = (target: 'logoUrl' | 'faviconUrl') => {
        setMediaTarget(target);
        setIsMediaDialogOpen(true);
    }
    
    const handleMediaSelect = (media: Media) => {
        if (mediaTarget) {
            handleInputChange(mediaTarget, media.url);
        }
        setIsMediaDialogOpen(false);
        setMediaTarget(null);
    }

    if (!settings) {
        return (
             <main className="p-6">
                <div className="flex items-center justify-between pb-6">
                    <Skeleton className="h-8 w-64" />
                    <Skeleton className="h-10 w-32" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <div className="space-y-6 lg:col-span-2">
                        <Card><CardHeader><Skeleton className="h-48 w-full" /></CardHeader></Card>
                    </div>
                    <div className="space-y-6 lg:col-span-1">
                        <Card><CardHeader><Skeleton className="h-64 w-full" /></CardHeader></Card>
                    </div>
                </div>
            </main>
        )
    }

    return (
        <>
            <main className="p-6">
                <div className="flex items-center justify-between pb-6">
                    <h1 className="text-2xl font-semibold">Website Branding</h1>
                    <Button onClick={handleSaveChanges} disabled={isSaving}>
                        {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Save Changes
                    </Button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <div className="space-y-6 lg:col-span-2">
                        <Card>
                            <CardHeader>
                                <CardTitle>General Settings</CardTitle>
                                <CardDescription>Manage your blog's main settings.</CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-6">
                                <div className="space-y-2">
                                    <Label htmlFor="website-title">Website Title</Label>
                                    <Input id="website-title" value={settings.websiteTitle} onChange={(e) => handleInputChange('websiteTitle', e.target.value)} />
                                    <p className="text-sm text-muted-foreground">This is the title of your website, it will appear in the browser tab.</p>
                                </div>
                                <div className="flex items-center justify-between rounded-lg border p-4">
                                    <div>
                                        <Label htmlFor="show-title-homepage">Show Website Title on Homepage</Label>
                                        <p className="text-sm text-muted-foreground">Toggle visibility of the main title on the homepage.</p>
                                    </div>
                                    <Switch id="show-title-homepage" checked={settings.showTitleOnHomepage} onCheckedChange={(checked) => handleInputChange('showTitleOnHomepage', checked)} />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="website-description">Website Description</Label>
                                    <Textarea id="website-description" value={settings.websiteDescription} onChange={(e) => handleInputChange('websiteDescription', e.target.value)} />
                                    <p className="text-sm text-muted-foreground">A short description of your website for search engines.</p>
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="meta-keywords">Meta Keywords</Label>
                                    <Textarea id="meta-keywords" value={settings.metaKeywords} onChange={(e) => handleInputChange('metaKeywords', e.target.value)} />
                                    <p className="text-sm text-muted-foreground">Comma-separated keywords that describe your website.</p>
                                </div>
                            </CardContent>
                        </Card>
                    </div>

                    <div className="space-y-6 lg:col-span-1">
                         <Card>
                            <CardHeader>
                                <CardTitle>Logo & Favicon</CardTitle>
                                <CardDescription>Upload your logo and favicon.</CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-6">
                                <div className="space-y-2">
                                    <Label htmlFor="logo-url">Logo</Label>
                                    {settings.logoUrl && <img src={settings.logoUrl} alt="logo preview" style={{ width: `${settings.logoWidth || 150}px`, height: 'auto' }} className="my-2 border p-1 rounded-md" />}
                                    <div className="flex items-center gap-2">
                                        <Input id="logo-url" value={settings.logoUrl} onChange={(e) => handleInputChange('logoUrl', e.target.value)} />
                                        <Button variant="outline" size="icon" onClick={() => openMediaLibrary('logoUrl')}><UploadCloud className="h-4 w-4" /></Button>
                                    </div>
                                    <p className="text-sm text-muted-foreground">The URL for your site's logo. You can also upload one.</p>
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="logo-width">Logo Width (in pixels)</Label>
                                    <Input id="logo-width" type="number" value={settings.logoWidth} onChange={(e) => handleInputChange('logoWidth', parseInt(e.target.value) || 0)} className="max-w-xs"/>
                                    <p className="text-sm text-muted-foreground">Adjust the display width of your logo. Height will be adjusted automatically.</p>
                                </div>
                                 <div className="space-y-2">
                                    <Label htmlFor="favicon-url">Favicon</Label>
                                     {settings.faviconUrl && <img src={settings.faviconUrl} alt="favicon preview" width={32} height={32} className="w-8 h-8 my-2 border p-1 rounded-md" />}
                                    <div className="flex items-center gap-2">
                                        <Input id="favicon-url" value={settings.faviconUrl} onChange={(e) => handleInputChange('faviconUrl', e.target.value)} />
                                        <Button variant="outline" size="icon" onClick={() => openMediaLibrary('faviconUrl')}><UploadCloud className="h-4 w-4" /></Button>
                                    </div>
                                    <p className="text-sm text-muted-foreground">The URL for your site's favicon. You can also upload one.</p>
                                </div>
                            </CardContent>
                        </Card>

                        <Card>
                            <CardHeader>
                                <CardTitle>Social Links</CardTitle>
                                <CardDescription>Enter the full URLs for your social media profiles.</CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                {settings.socialLinks.map((link, index) => (
                                    <div key={link.id} className="space-y-2 border p-3 rounded-md">
                                        <div className="flex justify-end">
                                            <Button type="button" variant="ghost" size="icon" className="h-6 w-6" onClick={() => handleRemoveSocialLink(link.id)}>
                                                <Trash2 className="h-4 w-4 text-destructive"/>
                                            </Button>
                                        </div>
                                        <div className="space-y-2">
                                            <Label>Platform</Label>
                                            <Select value={link.platform} onValueChange={(v) => handleSocialLinkChange(link.id, 'platform', v)}>
                                                <SelectTrigger><SelectValue placeholder="Select a platform" /></SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="twitter">Twitter</SelectItem>
                                                    <SelectItem value="facebook">Facebook</SelectItem>
                                                    <SelectItem value="instagram">Instagram</SelectItem>
                                                    <SelectItem value="linkedin">LinkedIn</SelectItem>
                                                    <SelectItem value="youtube">YouTube</SelectItem>
                                                    <SelectItem value="custom">Custom</SelectItem>
                                                </SelectContent>
                                            </Select>
                                            {link.platform === 'custom' && (
                                                <Input placeholder="Custom Platform Name" className="mt-2"/>
                                            )}
                                        </div>
                                        <div className="space-y-2">
                                            <Label>URL</Label>
                                            <Input
                                                type="url"
                                                value={link.url}
                                                onChange={(e) => handleSocialLinkChange(link.id, 'url', e.target.value)}
                                                placeholder="https://..."
                                            />
                                        </div>
                                    </div>
                                ))}
                                <Button variant="outline" className="w-full" type="button" onClick={handleAddSocialLink}>
                                    <Plus className="mr-2 h-4 w-4" /> Add New Social Link
                                </Button>
                            </CardContent>
                        </Card>
                        
                        <Card>
                            <CardHeader>
                                <CardTitle>Contact Information</CardTitle>
                                <CardDescription>This information will be displayed in your website footer.</CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                 <div className="space-y-2">
                                    <Label htmlFor="address">Address</Label>
                                    <Input id="address" value={settings.address} onChange={(e) => handleInputChange('address', e.target.value)} />
                                </div>
                                 <div className="space-y-2">
                                    <Label htmlFor="phone">Phone</Label>
                                    <Input id="phone" type="tel" value={settings.phone} onChange={(e) => handleInputChange('phone', e.target.value)} />
                                </div>
                                 <div className="space-y-2">
                                    <Label htmlFor="email">Email</Label>
                                    <Input id="email" type="email" value={settings.email} onChange={(e) => handleInputChange('email', e.target.value)} />
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                </div>
            </main>
            {isMediaDialogOpen && (
              <MediaLibraryModal isOpen={isMediaDialogOpen} onOpenChange={setIsMediaDialogOpen} onSelect={handleMediaSelect} />
            )}
        </>
    )
}
