

'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle, XCircle, GripVertical, Settings, Upload } from "lucide-react";
import Link from 'next/link';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
    Accordion,
    AccordionContent,
    AccordionItem,
    AccordionTrigger,
} from '@/components/ui/accordion';
import {
    getBlogArchiveSettings,
    getCategoryArchiveSettings,
    getSinglePostSettings,
    getSidebarSettings,
    updateBlogArchiveSettings,
    updateCategoryArchiveSettings,
    updateSinglePostSettings,
    updateSidebarSettings,
    BlogArchiveSettings,
    SidebarSettings as SidebarSettingsType,
    SinglePostSettings,
    LayoutElement,
    SocialButtonStyleSettings,
    getThemeSettings,
    updateThemeSettings,
    ColorTheme
} from '@/lib/data';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import ColorPicker from '@/components/admin/color-picker';
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors, DragEndEvent } from '@dnd-kit/core';
import { arrayMove, SortableContext, sortableKeyboardCoordinates, useSortable, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { Skeleton } from '@/components/ui/skeleton';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import Image from 'next/image';
import { Checkbox } from '@/components/ui/checkbox';

const popularFonts = [
    'Inter', 'Roboto', 'Open Sans', 'Lato', 'Montserrat', 'Oswald', 'Raleway', 'Poppins', 'Nunito', 'Merriweather'
];

type ColorName = keyof Omit<ColorTheme, 'customCss'>;

const colorLabels: Record<ColorName, string> = {
    background: 'Background',
    foreground: 'Foreground',
    primary: 'Primary',
    primaryForeground: 'Primary Foreground',
    secondary: 'Secondary',
    secondaryForeground: 'Secondary Foreground',
    muted: 'Muted',
    mutedForeground: 'Muted Foreground',
    accent: 'Accent',
    accentForeground: 'Accent Foreground',
    destructive: 'Destructive',
    destructiveForeground: 'Destructive Foreground',
    border: 'Border',
    input: 'Input',
    ring: 'Ring',
};

const TypographyControls = ({ title }: { title: string }) => (
    <AccordionItem value={title.toLowerCase().replace(' ', '-')}>
        <AccordionTrigger className="text-base">{title}</AccordionTrigger>
        <AccordionContent className="space-y-4">
            <div className="space-y-2">
                <Label>Color</Label>
                <Input type="color" className="w-full h-10" />
            </div>
            <div className="space-y-2">
                <Label>Font Family</Label>
                <Select>
                    <SelectTrigger><SelectValue placeholder="Select a font" /></SelectTrigger>
                    <SelectContent>
                        {popularFonts.map(font => <SelectItem key={font} value={font} style={{fontFamily: font}}>{font}</SelectItem>)}
                    </SelectContent>
                </Select>
            </div>
             <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                    <Label>Font Size</Label>
                    <Input placeholder="e.g., 16px, 1rem" />
                </div>
                 <div className="space-y-2">
                    <Label>Font Weight</Label>
                    <Select>
                        <SelectTrigger><SelectValue placeholder="Select a weight" /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="300">Light</SelectItem>
                            <SelectItem value="400">Normal</SelectItem>
                            <SelectItem value="500">Medium</SelectItem>
                            <SelectItem value="600">Semi-Bold</SelectItem>
                            <SelectItem value="700">Bold</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
            </div>
        </AccordionContent>
    </AccordionItem>
);

const WidgetPreview = ({ widget }: { widget: string }) => {
    switch (widget.toLowerCase()) {
        case 'search':
            return <p className="text-sm text-muted-foreground italic">Search Widget</p>;
        case 'recent posts':
            return <p className="text-sm text-muted-foreground italic">Recent Posts Widget</p>;
        case 'categories':
             return <p className="text-sm text-muted-foreground italic">Categories Widget</p>;
        case 'most commented':
            return <p className="text-sm text-muted-foreground italic">Most Commented Widget</p>;
        case 'newsletter':
            return <p className="text-sm text-muted-foreground italic">Newsletter Widget</p>;
        case 'follow us':
             return <p className="text-sm text-muted-foreground italic">Follow Us Widget</p>;
        default:
            return <p className="text-sm text-muted-foreground italic">{widget}</p>;
    }
}

const SidebarPreview = ({ widgets }: { widgets: string[] }) => {
    return (
        <div className="w-1/4 bg-card p-4 rounded-lg border sticky top-6 space-y-6">
            {widgets.map((widget, index) => (
                <div key={`${widget}-${index}`} className="p-4 rounded-lg border bg-background">
                    <h5 className="font-bold mb-4 capitalize">{widget}</h5>
                    <WidgetPreview widget={widget} />
                </div>
            ))}
        </div>
    )
}

const SinglePostPreview = ({ settings }: { settings: any }) => (
    <div className="border rounded-lg bg-muted/30 p-4 h-[800px] overflow-y-auto">
        {settings.showReadingProgressBar && (
             <div className="sticky top-0 z-10 -mx-4 -mt-4 mb-4">
                 <Progress value={45} className="h-1 rounded-none" />
             </div>
        )}
        <div className="bg-background rounded-lg p-4 md:p-8 mx-auto max-w-3xl">
            {settings.layout.find((el: any) => el.id === 'featured-image' && el.visible) && (
                <Image 
                    src="https://placehold.co/1200x600.png"
                    data-ai-hint="blog post" 
                    alt="Featured Image"
                    width={settings.featuredImageWidth || 1200}
                    height={settings.featuredImageHeight || 600} 
                    className="w-full h-auto rounded-lg mb-6"
                />
            )}
            <h1 className="text-2xl md:text-3xl font-bold font-headline mb-4">The Future of Content Creation</h1>
             {settings.layout.find((el: any) => el.id === 'author-meta' && el.visible) && (
                <div className="flex items-center gap-4 mb-6">
                    <Avatar><AvatarImage src="https://placehold.co/100x100.png" data-ai-hint="person face" /><AvatarFallback>A</AvatarFallback></Avatar>
                    <div>
                        <p className="font-semibold">Admin</p>
                        <p className="text-sm text-muted-foreground">May 28, 2024 · 5 min read</p>
                    </div>
                </div>
            )}
            <div className="prose prose-sm max-w-none">
                <p>This is where the main content of the blog post would go. It's a placeholder to give you a feel for the layout and how your settings will affect the final look.</p>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed non risus. Suspendisse lectus tortor, dignissim sit amet, adipiscing nec, ultricies sed, dolor. Cras elementum ultrices diam. Maecenas ligula massa, varius a, semper congue, euismod non, mi.</p>
            </div>
             {settings.layout.find((el: any) => el.id === 'tags' && el.visible) && (
                <div className="mt-6 flex flex-wrap items-center gap-2">
                    <p className="text-sm">Tags: <span className="text-primary hover:underline">Technology</span>, <span className="text-primary hover:underline">AI</span>, <span className="text-primary hover:underline">Future</span></p>
                </div>
            )}
             {settings.layout.find((el: any) => el.id === 'author-box' && el.visible) && (
                <div className="mt-8 pt-6 border-t flex items-center gap-4">
                    <Avatar className="h-16 w-16"><AvatarImage src="https://placehold.co/100x100.png" data-ai-hint="person face" /><AvatarFallback>A</AvatarFallback></Avatar>
                    <div>
                        <h4 className="font-semibold">About Admin</h4>
                        <p className="text-sm text-muted-foreground">The author's bio would appear here. This is a great place to share a little bit about who wrote the post.</p>
                    </div>
                </div>
            )}
            {settings.layout.find((el: any) => el.id === 'related-posts' && el.visible) && (
                <div className="mt-8 pt-6 border-t">
                    <h4 className="font-semibold text-lg mb-4">Related Posts</h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {[...Array(settings.numRelatedPosts)].map((_, i) => (
                             <div key={i} className="flex items-center gap-3">
                                 <Image src="https://placehold.co/100x100.png" alt="Related post thumbnail" data-ai-hint="related content" width={100} height={100} className="w-16 h-16 rounded-md"/>
                                <p className="text-sm font-medium hover:text-primary leading-tight"><a href="#">Related Post Title {i+1}</a></p>
                             </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    </div>
);


const BlogArchivePreview = ({ settings }: { settings: any }) => {
    const PostCard = () => (
        <div className={cn("bg-background rounded-lg border overflow-hidden", settings.layout === 'list' && 'flex gap-4')}>
             {settings.showFeaturedImage && (
                <Image 
                    src="https://placehold.co/600x400.png" 
                    alt="Blog Post"
                    width={600}
                    height={400}
                    data-ai-hint="blog post" 
                    className={cn(
                        "object-cover w-full",
                        (settings.layout === 'grid' || settings.layout === 'masonry') ? 'aspect-video' : 'aspect-square w-1/3'
                    )}
                />
             )}
            <div className="p-4 flex flex-col">
                 <h3 className="font-bold text-lg font-headline">Blog Post Title</h3>
                 {(settings.showAuthor || settings.showDate || settings.showCategories) && (
                    <div className="text-xs text-muted-foreground mt-1 mb-2 space-x-2">
                        {settings.showAuthor && <span>by Admin</span>}
                        {settings.showAuthor && settings.showDate && <span>•</span>}
                        {settings.showDate && <span>May 28, 2024</span>}
                         {settings.showDate && settings.showCategories && <span>•</span>}
                        {settings.showCategories && <span>Technology</span>}
                    </div>
                 )}
                 {settings.showExcerpt && <p className="text-sm text-muted-foreground mt-2 line-clamp-3">{('This is an excerpt of the blog post content. It gives a brief summary to entice readers. The length can be controlled in the settings.').substring(0, settings.excerptLength) + '...'}</p>}
            </div>
        </div>
    );
    
    const numColumns = parseInt(settings.columns || '2', 10);
    const gridColsClassMap: { [key: number]: string } = {
        1: 'sm:grid-cols-1',
        2: 'sm:grid-cols-2',
        3: 'sm:grid-cols-3',
        4: 'sm:grid-cols-4',
    };
    const gridColsClass = gridColsClassMap[numColumns] || 'sm:grid-cols-2';


    return (
        <div className="border rounded-lg bg-muted/30 p-4 h-[800px] overflow-y-auto">
            <div className={cn(
                "grid gap-6",
                (settings.layout === 'grid' || settings.layout === 'masonry') && gridColsClass,
                settings.layout === 'list' && 'grid-cols-1',
                settings.layout === 'classic' && 'grid-cols-1',
            )}>
               {[...Array(settings.postsPerPage || 4)].map((_, i) => <PostCard key={i} />)}
            </div>
            <div className="flex justify-center mt-8">
              {settings.paginationStyle === 'numbered' ? (
                  <div className="flex items-center gap-2">
                      <Button variant="outline" size="sm">Prev</Button>
                      <Button variant="outline" size="sm">1</Button>
                      <Button variant="secondary" size="sm">2</Button>
                      <Button variant="outline" size="sm">3</Button>
                      <Button variant="outline" size="sm">Next</Button>
                  </div>
              ) : (
                  <Button>Load More</Button>
              )}
            </div>
        </div>
    )
}

const SettingToggle = ({ id, label, description, checked, onCheckedChange }: { id: string, label: string, description?: string, checked: boolean, onCheckedChange: (checked: boolean) => void }) => (
    <div className="flex items-start justify-between rounded-lg border p-3 bg-background">
        <div className="space-y-0.5">
            <Label htmlFor={id} className="text-base font-normal">{label}</Label>
            {description && <p className="text-xs text-muted-foreground">{description}</p>}
        </div>
        <Switch id={id} checked={checked} onCheckedChange={onCheckedChange} />
    </div>
)

const elementLabels: Record<string, string> = {
    'breadcrumbs': 'Breadcrumbs',
    'category-badge': 'Category Badge',
    'title': 'Post Title',
    'excerpt': 'Post Excerpt',
    'author-meta': 'Author Meta',
    'top-share': 'Top Share Buttons',
    'featured-image': 'Featured Image',
    'content': 'Post Content',
    'post-reactions': 'Post Reactions',
    'tags': 'Tags Section',
    'bottom-share': 'Bottom Share Buttons',
    'author-box': 'Author Box',
    'related-posts': 'Related Posts',
    'comments': 'Comments Section',
};

const SortableLayoutItem = ({ item, onVisibilityChange }: { item: LayoutElement, onVisibilityChange: (id: string, visible: boolean) => void }) => {
    const { attributes, listeners, setNodeRef, transform, transition } = useSortable({id: item.id});

    const style = {
        transform: CSS.Transform.toString(transform),
        transition,
    };

    return (
        <div ref={setNodeRef} style={style} {...attributes} className="p-3 bg-background border rounded-md shadow-sm flex items-center justify-between">
            <div className="flex items-center gap-2">
                <span {...listeners} className="cursor-move">
                    <GripVertical className="h-5 w-5 text-muted-foreground" />
                </span>
                <span className="font-medium">{elementLabels[item.id] || item.id}</span>
            </div>
            <Switch checked={item.visible} onCheckedChange={(checked) => onVisibilityChange(item.id, checked)} />
        </div>
    );
};

const SocialButtonCustomization = ({ title, settings, onSettingsChange }: { title: string, settings: SocialButtonStyleSettings, onSettingsChange: (newSettings: SocialButtonStyleSettings) => void }) => {

    const handleStyleChange = (key: keyof SocialButtonStyleSettings, value: any) => {
        onSettingsChange({ ...settings, [key]: value });
    };
    
    const handleGradientChange = (key: 'from' | 'to' | 'direction', value: string) => {
        onSettingsChange({ ...settings, gradient: { ...settings.gradient, [key]: value } });
    }

    return (
        <AccordionItem value={title.toLowerCase().replace(' ', '-')}>
            <AccordionTrigger className="text-base">{title}</AccordionTrigger>
            <AccordionContent className="pt-4 space-y-4">
                <RadioGroup value={settings.style} onValueChange={(v) => handleStyleChange('style', v)} className="flex gap-4">
                    <div className="flex items-center space-x-2"><RadioGroupItem value="official" id={`${title}-official`} /><Label htmlFor={`${title}-official`}>Official Colors</Label></div>
                    <div className="flex items-center space-x-2"><RadioGroupItem value="custom" id={`${title}-custom`} /><Label htmlFor={`${title}-custom`}>Custom</Label></div>
                </RadioGroup>
                 
                {settings.style === 'custom' && (
                    <div className="space-y-4 pl-6 border-l ml-2">
                         <div className="space-y-2">
                            <Label>Shape</Label>
                            <Select value={settings.shape} onValueChange={(v) => handleStyleChange('shape', v)}>
                                <SelectTrigger><SelectValue/></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="default">Default</SelectItem>
                                    <SelectItem value="rounded">Rounded</SelectItem>
                                    <SelectItem value="circle">Circle</SelectItem>
                                </SelectContent>
                            </Select>
                         </div>
                         <ColorPicker label="Icon Color" color={settings.iconColor} onChange={(c) => handleStyleChange('iconColor', c)} />
                         <ColorPicker label="Border Color" color={settings.borderColor} onChange={(c) => handleStyleChange('borderColor', c)} />
                          <div className="space-y-2">
                             <Label>Border Width (px)</Label>
                             <Input type="number" value={settings.borderWidth} onChange={(e) => handleStyleChange('borderWidth', parseInt(e.target.value))} />
                         </div>

                         <div className="space-y-2">
                            <Label>Background Type</Label>
                            <RadioGroup value={settings.backgroundType} onValueChange={(v) => handleStyleChange('backgroundType', v)} className="flex gap-4">
                                <div className="flex items-center space-x-2"><RadioGroupItem value="solid" id={`${title}-bg-solid`} /><Label htmlFor={`${title}-bg-solid`}>Solid</Label></div>
                                <div className="flex items-center space-x-2"><RadioGroupItem value="gradient" id={`${title}-bg-gradient`} /><Label htmlFor={`${title}-bg-gradient`}>Gradient</Label></div>
                            </RadioGroup>
                         </div>
                         {settings.backgroundType === 'solid' ? (
                             <ColorPicker label="Background Color" color={settings.backgroundColor} onChange={(c) => handleStyleChange('backgroundColor', c)} />
                         ) : (
                            <div className="space-y-4 rounded-md border p-4">
                                <h4 className="text-sm font-medium">Gradient Options</h4>
                                <ColorPicker label="From" color={settings.gradient.from} onChange={(c) => handleGradientChange('from', c)} />
                                <ColorPicker label="To" color={settings.gradient.to} onChange={(c) => handleGradientChange('to', c)} />
                                <div className="space-y-2">
                                    <Label>Direction</Label>
                                    <Select value={settings.gradient.direction} onValueChange={(v) => handleGradientChange('direction', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="to right">Left to Right</SelectItem><SelectItem value="to bottom">Top to Bottom</SelectItem></SelectContent></Select>
                                </div>
                            </div>
                         )}
                    </div>
                )}

            </AccordionContent>
        </AccordionItem>
    );
}

const ArchiveSettingsPanel = ({ title, settings, onSettingsChange }: { title: string, settings: BlogArchiveSettings, onSettingsChange: (key: keyof BlogArchiveSettings, value: any) => void }) => (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1 space-y-4">
            <div className="space-y-2">
                <Label>Layout</Label>
                <Select value={settings.layout} onValueChange={(v) => onSettingsChange('layout', v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="grid">Grid</SelectItem>
                        <SelectItem value="masonry">Masonry</SelectItem>
                        <SelectItem value="list">List</SelectItem>
                        <SelectItem value="classic">Classic</SelectItem>
                    </SelectContent>
                </Select>
            </div>
             {(settings.layout === 'grid' || settings.layout === 'masonry') && (
                <div className="space-y-2">
                    <Label>Number of Columns</Label>
                    <Select value={String(settings.columns)} onValueChange={(v) => onSettingsChange('columns', v)}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="1">1</SelectItem>
                            <SelectItem value="2">2</SelectItem>
                            <SelectItem value="3">3</SelectItem>
                            <SelectItem value="4">4</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
            )}
             <div className="space-y-2">
                <Label htmlFor="posts-per-page">Posts per Page</Label>
                <Input id="posts-per-page" type="number" value={settings.postsPerPage} onChange={(e) => onSettingsChange('postsPerPage', e.target.value)} />
            </div>
            <div className="space-y-2">
                <Label>Pagination Style</Label>
                <Select value={settings.paginationStyle} onValueChange={(v) => onSettingsChange('paginationStyle', v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="numbered">Numbered</SelectItem>
                        <SelectItem value="load-more">Load More</SelectItem>
                    </SelectContent>
                </Select>
            </div>
            <SettingToggle id={`ba-image-${title}`} label="Show Featured Image" checked={settings.showFeaturedImage} onCheckedChange={(c) => onSettingsChange('showFeaturedImage', c)} />
            <SettingToggle id={`ba-author-${title}`} label="Show Author" checked={settings.showAuthor} onCheckedChange={(c) => onSettingsChange('showAuthor', c)} />
            <SettingToggle id={`ba-date-${title}`} label="Show Date" checked={settings.showDate} onCheckedChange={(c) => onSettingsChange('showDate', c)} />
            <SettingToggle id={`ba-cats-${title}`} label="Show Categories" checked={settings.showCategories} onCheckedChange={(c) => onSettingsChange('showCategories', c)} />
            <SettingToggle id={`ba-excerpt-${title}`} label="Show Excerpt" checked={settings.showExcerpt} onCheckedChange={(c) => onSettingsChange('showExcerpt', c)} />
            {settings.showExcerpt && (
                <div className="space-y-2">
                    <Label htmlFor={`excerpt-length-${title}`}>Excerpt Length</Label>
                    <Input id={`excerpt-length-${title}`} type="number" value={settings.excerptLength} onChange={(e) => onSettingsChange('excerptLength', e.target.value)} />
                </div>
            )}
        </div>
        <div className="md:col-span-2">
             <Card>
                <CardHeader><CardTitle>Preview</CardTitle></CardHeader>
                <CardContent>
                    <BlogArchivePreview settings={settings} />
                </CardContent>
            </Card>
        </div>
    </div>
);

const allWidgets = ['Search', 'Recent Posts', 'Categories', 'Most Commented', 'Tag Cloud', 'Follow Us', 'Subscribe', 'Advertisement'];

const SortableWidget = ({ id, onRemove }: { id: string, onRemove: (id: string) => void }) => {
     const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id });

    const style = {
        transform: CSS.Transform.toString(transform),
        transition,
    };

    return (
        <div ref={setNodeRef} style={style} {...attributes} className="p-2 bg-background border rounded-md shadow-sm flex items-center justify-between">
            <div className="flex items-center gap-2">
                <span {...listeners} className="cursor-move">
                    <GripVertical className="h-5 w-5 text-muted-foreground" />
                </span>
                <span className="font-medium text-sm">{id}</span>
            </div>
            <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => onRemove(id)}>
                <XCircle className="h-4 w-4 text-destructive" />
            </Button>
        </div>
    )
};


const SidebarSettingsPanel = ({ settings, onSettingsChange }: { settings: SidebarSettingsType, onSettingsChange: (key: keyof SidebarSettingsType, value: any) => void }) => {
    
    const sensors = useSensors(
        useSensor(PointerSensor),
        useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
    );

    const handleDragEnd = (event: DragEndEvent, sidebar: 'leftWidgets' | 'rightWidgets') => {
        const { active, over } = event;
        if (over && active.id !== over.id) {
            const oldIndex = settings[sidebar].indexOf(active.id as string);
            const newIndex = settings[sidebar].indexOf(over.id as string);
            onSettingsChange(sidebar, arrayMove(settings[sidebar], oldIndex, newIndex));
        }
    };

    const handleAddWidget = (sidebar: 'leftWidgets' | 'rightWidgets', widget: string) => {
        if (!settings[sidebar].includes(widget)) {
            onSettingsChange(sidebar, [...settings[sidebar], widget]);
        }
    };

    const handleRemoveWidget = (sidebar: 'leftWidgets' | 'rightWidgets', widget: string) => {
        onSettingsChange(sidebar, settings[sidebar].filter(w => w !== widget));
    };

    const handleSocialIconChange = (key: keyof SocialButtonStyleSettings, value: any) => {
        onSettingsChange('socialIconStyle', { ...settings.socialIconStyle, [key]: value });
    };
    
    const handleWidgetTitleChange = (widgetKey: string, newTitle: string) => {
        onSettingsChange('widgetTitles', {
            ...settings.widgetTitles,
            [widgetKey]: newTitle,
        });
    };

    const renderWidgetList = (sidebar: 'leftWidgets' | 'rightWidgets') => {
        const activeWidgets = settings[sidebar] || [];
        const availableWidgets = allWidgets.filter(w => !activeWidgets.includes(w));
        return (
            <div className="grid grid-cols-2 gap-6">
                <div>
                    <Label className="font-semibold">Active Widgets</Label>
                    <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={(e) => handleDragEnd(e, sidebar)}>
                        <SortableContext items={activeWidgets} strategy={verticalListSortingStrategy}>
                            <div className="mt-2 space-y-2 border p-2 rounded-md min-h-[200px]">
                                {activeWidgets.map(widget => (
                                    <SortableWidget key={widget} id={widget} onRemove={() => handleRemoveWidget(sidebar, widget)} />
                                ))}
                                {activeWidgets.length === 0 && <p className="text-xs text-muted-foreground text-center py-4">Drag or add widgets here.</p>}
                            </div>
                        </SortableContext>
                    </DndContext>
                </div>
                 <div>
                    <Label className="font-semibold">Available Widgets</Label>
                     <div className="mt-2 space-y-2 border p-2 rounded-md min-h-[200px] bg-muted/50">
                        {availableWidgets.map(widget => (
                             <Button key={widget} size="sm" variant="ghost" className="w-full justify-start" onClick={() => handleAddWidget(sidebar, widget)}>{widget}</Button>
                        ))}
                    </div>
                </div>
            </div>
        )
    };

    return (
         <Tabs defaultValue="left" className="w-full">
            <TabsList>
                <TabsTrigger value="left">Left Sidebar</TabsTrigger>
                <TabsTrigger value="right">Right Sidebar</TabsTrigger>
                <TabsTrigger value="widgets">Widget Settings</TabsTrigger>
            </TabsList>
            <TabsContent value="left" className="pt-4">
                 {renderWidgetList('leftWidgets')}
            </TabsContent>
            <TabsContent value="right" className="pt-4">
                 {renderWidgetList('rightWidgets')}
            </TabsContent>
            <TabsContent value="widgets" className="pt-4 space-y-6">
                 <Card>
                    <CardHeader>
                        <CardTitle className="text-base">Widget Titles</CardTitle>
                        <CardDescription>Customize the titles for your sidebar widgets.</CardDescription>
                    </CardHeader>
                    <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {allWidgets.map(widget => (
                            <div key={widget} className="space-y-2">
                                <Label htmlFor={`widget-title-${widget}`}>{widget}</Label>
                                <Input 
                                    id={`widget-title-${widget}`} 
                                    value={settings.widgetTitles?.[widget] || widget}
                                    onChange={(e) => handleWidgetTitleChange(widget, e.target.value)}
                                />
                            </div>
                        ))}
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle className="text-base">Content Widgets</CardTitle>
                        <CardDescription>Control how many items appear in content-based widgets.</CardDescription>
                    </CardHeader>
                    <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div className="space-y-2">
                            <Label htmlFor="num-recent">Recent Posts</Label>
                            <Input id="num-recent" type="number" value={settings.numRecentPosts} onChange={(e) => onSettingsChange('numRecentPosts', parseInt(e.target.value))} />
                        </div>
                         <div className="space-y-2">
                            <Label htmlFor="num-commented">Most Commented</Label>
                            <Input id="num-commented" type="number" value={settings.numMostCommented} onChange={(e) => onSettingsChange('numMostCommented', parseInt(e.target.value))} />
                        </div>
                         <div className="space-y-2">
                            <Label htmlFor="num-cats">Categories</Label>
                            <Input id="num-cats" type="number" value={settings.numCategories} onChange={(e) => onSettingsChange('numCategories', parseInt(e.target.value))} />
                        </div>
                         <div className="space-y-2">
                            <Label htmlFor="num-tags">Tags</Label>
                            <Input id="num-tags" type="number" value={settings.numTags} onChange={(e) => onSettingsChange('numTags', parseInt(e.target.value))} />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="skip-posts">Post Offset</Label>
                            <Input id="skip-posts" type="number" value={settings.skipPosts} onChange={(e) => onSettingsChange('skipPosts', parseInt(e.target.value))} />
                            <p className="text-xs text-muted-foreground">Skip this many posts from the start of the list.</p>
                        </div>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle className="text-base">Newsletter Widget</CardTitle>
                        <CardDescription>Customize the text in the newsletter subscription widget.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="space-y-2">
                            <Label htmlFor="newsletter-title">Title</Label>
                            <Input id="newsletter-title" value={settings.newsletterTitle} onChange={(e) => onSettingsChange('newsletterTitle', e.target.value)} />
                        </div>
                         <div className="space-y-2">
                            <Label htmlFor="newsletter-description">Description</Label>
                            <Textarea id="newsletter-description" value={settings.newsletterDescription} onChange={(e) => onSettingsChange('newsletterDescription', e.target.value)} />
                        </div>
                    </CardContent>
                </Card>
                 <Card>
                    <CardHeader>
                        <CardTitle className="text-base">Social Icon Styling</CardTitle>
                    </CardHeader>
                    <CardContent>
                         <SocialButtonCustomization title="Follow Us Icons" settings={settings.socialIconStyle} onSettingsChange={(newSettings) => onSettingsChange('socialIconStyle', newSettings)} />
                    </CardContent>
                </Card>
            </TabsContent>
         </Tabs>
    );
};


export default function AppearancePage() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [sidebarSettings, setSidebarSettings] = useState<SidebarSettingsType | null>(null);
  const [singlePostSettings, setSinglePostSettings] = useState<SinglePostSettings | null>(null);
  const [blogArchiveSettings, setBlogArchiveSettings] = useState<BlogArchiveSettings | null>(null);
  const [categoryArchiveSettings, setCategoryArchiveSettings] = useState<BlogArchiveSettings | null>(null);
  const [themeSettings, setThemeSettings] = useState<ColorTheme | null>(null);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
        const [sidebarData, singlePostData, blogArchiveData, categoryArchiveData, themeData] = await Promise.all([
            getSidebarSettings(),
            getSinglePostSettings(),
            getBlogArchiveSettings(),
            getCategoryArchiveSettings(),
            getThemeSettings()
        ]);
        setSidebarSettings(sidebarData);
        setSinglePostSettings(singlePostData);
        setBlogArchiveSettings(blogArchiveData);
        setCategoryArchiveSettings(categoryArchiveData);
        setThemeSettings(themeData);
    } catch (error) {
        toast({ variant: 'destructive', title: "Error loading settings" });
    } finally {
        setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    loadData();
  }, [loadData]);
  
  
  const handleBlogArchiveSettingChange = (key: keyof BlogArchiveSettings, value: any) => {
    if (!blogArchiveSettings) return;
    if (key === 'excerptLength' || key === 'postsPerPage') {
        const numValue = parseInt(value, 10);
        setBlogArchiveSettings(prev => prev ? ({...prev, [key]: isNaN(numValue) ? 0 : numValue}) : null);
    } else {
        setBlogArchiveSettings(prev => prev ? ({...prev, [key]: value}) : null);
    }
  }

  const handleCategoryArchiveSettingChange = (key: keyof BlogArchiveSettings, value: any) => {
    if (!categoryArchiveSettings) return;
    if (key === 'excerptLength' || key === 'postsPerPage') {
        const numValue = parseInt(value, 10);
        setCategoryArchiveSettings(prev => prev ? ({...prev, [key]: isNaN(numValue) ? 0 : numValue}) : null);
    } else {
        setCategoryArchiveSettings(prev => prev ? ({...prev, [key]: value}) : null);
    }
  }


  const handleSinglePostSettingChange = (key: keyof SinglePostSettings, value: any) => {
     if (!singlePostSettings) return;
     const numKeys: (keyof SinglePostSettings)[] = ['numRelatedPosts', 'featuredImageWidth', 'featuredImageHeight'];
     if (numKeys.includes(key as any)) {
        const numValue = parseInt(value, 10);
        setSinglePostSettings(prev => prev ? ({...prev, [key]: isNaN(numValue) ? 0 : numValue}) : null);
    } else {
        setSinglePostSettings(prev => prev ? ({...prev, [key]: value}) : null);
    }
  }

  const handleSidebarSettingChange = (key: keyof SidebarSettingsType, value: any) => {
      setSidebarSettings(prev => prev ? ({ ...prev, [key]: value }) : null);
  };
  
   const handleThemeSettingChange = (colorName: ColorName, value: string) => {
        setThemeSettings(prev => (prev ? { ...prev, [colorName]: value } : null));
    };

    const handleCustomCssChange = (css: string) => {
        setThemeSettings(prev => (prev ? { ...prev, customCss: css } : null));
    };


  const handleLayoutElementVisibilityChange = (id: string, visible: boolean) => {
    if (!singlePostSettings) return;
    setSinglePostSettings(prev => {
        if(!prev || !prev.layout) return null;
        const newLayout = prev.layout.map(item => 
            item.id === id ? { ...item, visible } : item
        );
        return { ...prev, layout: newLayout };
    });
  }
  
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  function handleDragEnd(event: DragEndEvent) {
    const {active, over} = event;
    
    if (over && active.id !== over.id && singlePostSettings?.layout) {
      setSinglePostSettings(prev => {
        if (!prev || !prev.layout) return prev;
        const oldIndex = prev.layout.findIndex(item => item.id === active.id);
        const newIndex = prev.layout.findIndex(item => item.id === over.id);
        if (oldIndex !== -1 && newIndex !== -1) {
            return { ...prev, layout: arrayMove(prev.layout, oldIndex, newIndex) };
        }
        return prev;
      });
    }
  }

  const handleSaveChanges = () => {
    if (!blogArchiveSettings || !singlePostSettings || !sidebarSettings || !categoryArchiveSettings || !themeSettings) return;
    updateBlogArchiveSettings(blogArchiveSettings);
    updateCategoryArchiveSettings(categoryArchiveSettings);
    updateSinglePostSettings(singlePostSettings);
    updateSidebarSettings(sidebarSettings);
    updateThemeSettings(themeSettings);

    toast({
        title: "Settings Saved",
        description: "Your appearance settings have been saved successfully.",
    });
  };

  if (loading) {
      return (
          <div className="p-6">
              <div className="flex items-center justify-between pb-6">
                  <Skeleton className="h-8 w-64" />
                  <Skeleton className="h-10 w-24" />
              </div>
              <Card>
                  <CardHeader><Skeleton className="h-6 w-1/3" /></CardHeader>
                  <CardContent><Skeleton className="h-64 w-full" /></CardContent>
              </Card>
          </div>
      );
  }

  if (!blogArchiveSettings || !singlePostSettings || !sidebarSettings || !categoryArchiveSettings || !singlePostSettings.layout || !themeSettings) {
      return (
          <div className="p-6 text-center">
              <p className="text-destructive">Failed to load appearance settings. Please try refreshing the page.</p>
          </div>
      )
  }

  return (
    <>
      <main className="p-6">
        <div className='flex items-center justify-between pb-4'>
          <div>
            <h1 className="text-2xl font-semibold">Appearance</h1>
            <p className="text-muted-foreground">Manage your site's appearance and layout.</p>
          </div>
          <Button onClick={handleSaveChanges}>Save &amp; Publish</Button>
        </div>
        
        <Tabs defaultValue="layout">
            <TabsList>
                <TabsTrigger value="layout">Layout</TabsTrigger>
                <TabsTrigger value="theme-colors">Theme &amp; Colors</TabsTrigger>
                <TabsTrigger value="ads">Ads</TabsTrigger>
            </TabsList>
            <TabsContent value="layout">
                <Card>
                    <CardHeader>
                        <CardTitle>Layout Settings</CardTitle>
                        <CardDescription>Manage your site layout here.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Accordion type="multiple" className="w-full" defaultValue={['header', 'footer', 'sidebars', 'blog-archive', 'category-archive', 'single-post']}>
                             <AccordionItem value="header">
                                <AccordionTrigger className="text-base font-semibold">HEADER</AccordionTrigger>
                                <AccordionContent>
                                    <Button asChild variant="secondary">
                                        <Link href="/admin/appearance/headers">Edit Header <ArrowRight className="ml-2"/></Link>
                                    </Button>
                                </AccordionContent>
                            </AccordionItem>
                             <AccordionItem value="footer">
                                <AccordionTrigger className="text-base font-semibold">FOOTER</AccordionTrigger>
                                <AccordionContent>
                                    <Button asChild variant="secondary">
                                        <Link href="/admin/appearance/footers">Edit Footer <ArrowRight className="ml-2"/></Link>
                                    </Button>
                                </AccordionContent>
                            </AccordionItem>
                            <AccordionItem value="sidebars">
                                <AccordionTrigger className="text-base font-semibold">SIDEBARS</AccordionTrigger>
                                <AccordionContent>
                                    <p className="text-sm text-muted-foreground mb-4">Control which widgets appear in your sidebars and in what order. The visibility of the sidebars themselves can be controlled per page type (e.g., in the Single Post section below).</p>
                                    <SidebarSettingsPanel settings={sidebarSettings} onSettingsChange={handleSidebarSettingChange} />
                                </AccordionContent>
                            </AccordionItem>
                            <AccordionItem value="blog-archive">
                                <AccordionTrigger className="text-base font-semibold">MAIN BLOG LAYOUT</AccordionTrigger>
                                <AccordionContent>
                                    <ArchiveSettingsPanel title="main-blog" settings={blogArchiveSettings} onSettingsChange={handleBlogArchiveSettingChange} />
                                </AccordionContent>
                            </AccordionItem>
                             <AccordionItem value="category-archive">
                                <AccordionTrigger className="text-base font-semibold">CATEGORY &amp; TAG ARCHIVE LAYOUT</AccordionTrigger>
                                <AccordionContent>
                                    <ArchiveSettingsPanel title="category-archive" settings={categoryArchiveSettings} onSettingsChange={handleCategoryArchiveSettingChange} />
                                </AccordionContent>
                            </AccordionItem>
                            <AccordionItem value="single-post">
                                <AccordionTrigger className="text-base font-semibold">SINGLE POST</AccordionTrigger>
                                <AccordionContent>
                                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                        <div className="md:col-span-1 space-y-3">
                                            <Accordion type="multiple" defaultValue={['structure']}>
                                                <AccordionItem value="structure">
                                                    <AccordionTrigger>Structure</AccordionTrigger>
                                                    <AccordionContent className="pt-4 space-y-3">
                                                         <p className="text-sm text-muted-foreground">Drag and drop to reorder the elements on your single post pages. Use the toggles to show or hide elements.</p>
                                                         {singlePostSettings && singlePostSettings.layout ? (
                                                            <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
                                                                <SortableContext items={singlePostSettings.layout.map(item => item.id)} strategy={verticalListSortingStrategy}>
                                                                    <div className="space-y-2">
                                                                        {singlePostSettings.layout.map(item => <SortableLayoutItem key={item.id} item={item} onVisibilityChange={handleLayoutElementVisibilityChange} />)}
                                                                    </div>
                                                                </SortableContext>
                                                            </DndContext>
                                                        ) : <p>Loading layout...</p>}
                                                    </AccordionContent>
                                                </AccordionItem>
                                                <AccordionItem value="social-buttons">
                                                    <AccordionTrigger>Social Buttons</AccordionTrigger>
                                                    <AccordionContent className="pt-4 space-y-3">
                                                          <SocialButtonCustomization 
                                                            title="Share Buttons"
                                                            settings={singlePostSettings.shareButtons}
                                                            onSettingsChange={(newShareSettings) => handleSinglePostSettingChange('shareButtons', newShareSettings)}
                                                          />
                                                           <SocialButtonCustomization 
                                                            title="Follow Us Buttons"
                                                            settings={singlePostSettings.followButtons}
                                                            onSettingsChange={(newFollowSettings) => handleSinglePostSettingChange('followButtons', newFollowSettings)}
                                                          />
                                                    </AccordionContent>
                                                </AccordionItem>
                                            </Accordion>
                                            
                                            <h4 className="font-semibold text-lg pt-4 border-t">Sidebars</h4>
                                             <SettingToggle id="sp-left-sidebar" label="Show Left Sidebar" checked={singlePostSettings.showLeftSidebar} onCheckedChange={(c) => handleSinglePostSettingChange('showLeftSidebar', c)} />
                                              <SettingToggle id="sp-right-sidebar" label="Show Right Sidebar" checked={singlePostSettings.showRightSidebar} onCheckedChange={(c) => handleSinglePostSettingChange('showRightSidebar', c)} />

                                            <h4 className="font-semibold text-lg pt-4 border-t">Featured Image</h4>
                                             <div className="grid grid-cols-2 gap-2">
                                                <div className="space-y-1">
                                                    <Label htmlFor="sp-img-width">Width</Label>
                                                    <Input id="sp-img-width" type="number" value={singlePostSettings.featuredImageWidth || undefined} onChange={(e) => handleSinglePostSettingChange('featuredImageWidth', parseInt(e.target.value))} />
                                                </div>
                                                <div className="space-y-1">
                                                    <Label htmlFor="sp-img-height">Height</Label>
                                                    <Input id="sp-img-height" type="number" value={singlePostSettings.featuredImageHeight || undefined} onChange={(e) => handleSinglePostSettingChange('featuredImageHeight', parseInt(e.target.value))} />
                                                </div>
                                            </div>

                                            <h4 className="font-semibold text-lg pt-4 border-t">Related Posts</h4>
                                            <div className="border p-3 rounded-lg bg-background space-y-4">
                                                <SettingToggle id="sp-related" label="Show Related Posts" checked={singlePostSettings.showRelatedPosts} onCheckedChange={(c) => handleSinglePostSettingChange('showRelatedPosts', c)} />
                                                {singlePostSettings.showRelatedPosts && (
                                                    <div className="space-y-2">
                                                         <div className="space-y-1">
                                                            <Label>Layout</Label>
                                                            <Select value={singlePostSettings.relatedPostsLayout} onValueChange={(v) => handleSinglePostSettingChange('relatedPostsLayout', v)}>
                                                                <SelectTrigger><SelectValue /></SelectTrigger>
                                                                <SelectContent>
                                                                    <SelectItem value="grid">Grid</SelectItem>
                                                                    <SelectItem value="list">List</SelectItem>
                                                                </SelectContent>
                                                            </Select>
                                                        </div>
                                                        <div className="space-y-1">
                                                            <Label>Number of Posts</Label>
                                                            <Input type="number" value={singlePostSettings.numRelatedPosts} onChange={(e) => handleSinglePostSettingChange('numRelatedPosts', e.target.value)} />
                                                        </div>
                                                    </div>
                                                )}
                                            </div>

                                             <h4 className="font-semibold text-lg pt-4 border-t">Other Settings</h4>
                                              <div className="border p-3 rounded-lg bg-background space-y-2">
                                                  <SettingToggle id="sp-sticky-share" label="Show Sticky Share Buttons" checked={singlePostSettings.showStickyShare} onCheckedChange={(c) => handleSinglePostSettingChange('showStickyShare', c)} />
                                                  {singlePostSettings.showStickyShare && (
                                                      <div className="space-y-2 pl-4">
                                                          <Label>Position</Label>
                                                          <Select value={singlePostSettings.stickySharePosition} onValueChange={(v) => handleSinglePostSettingChange('stickySharePosition', v)}>
                                                              <SelectTrigger><SelectValue /></SelectTrigger>
                                                              <SelectContent>
                                                                  <SelectItem value="left">Left</SelectItem>
                                                                  <SelectItem value="right">Right</SelectItem>
                                                              </SelectContent>
                                                          </Select>
                                                      </div>
                                                  )}
                                                  <SettingToggle id="sp-reactions" label="Show Post Reactions" checked={singlePostSettings.showPostReactions} onCheckedChange={(c) => handleSinglePostSettingChange('showPostReactions', c)} />
                                                  <SettingToggle id="sp-follow-us" label="Show 'Follow Us' Buttons" checked={singlePostSettings.showFollowUs} onCheckedChange={(c) => handleSinglePostSettingChange('showFollowUs', c)} />
                                                  <SettingToggle id="sp-drop-cap" label="Enable Drop Cap" description="Make the first letter of the post larger." checked={singlePostSettings.enableDropCap} onCheckedChange={(c) => handleSinglePostSettingChange('enableDropCap', c)} />
                                              </div>

                                        </div>
                                        <div className="md:col-span-2">
                                            <Card>
                                                <CardHeader><CardTitle>Preview</CardTitle></CardHeader>
                                                <CardContent>
                                                    <SinglePostPreview settings={singlePostSettings} />
                                                </CardContent>
                                            </Card>
                                        </div>
                                    </div>
                                </AccordionContent>
                            </AccordionItem>
                        </Accordion>
                    </CardContent>
                </Card>
            </TabsContent>
            <TabsContent value="theme-colors">
                <Card>
                    <CardHeader>
                        <CardTitle>Styling Options</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <Accordion type="multiple" defaultValue={['colors']} className="w-full">
                            <AccordionItem value="colors">
                                <AccordionTrigger className="text-lg">Theme Colors</AccordionTrigger>
                                <AccordionContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-4 pt-4">
                                     {(Object.keys(colorLabels) as ColorName[]).map(key => (
                                        <ColorPicker 
                                            key={key}
                                            label={colorLabels[key]}
                                            color={themeSettings[key]}
                                            onChange={(color) => handleThemeSettingChange(key, color)}
                                        />
                                     ))}
                                </AccordionContent>
                            </AccordionItem>
                            <AccordionItem value="general-typography">
                                <AccordionTrigger className="text-lg">General Typography</AccordionTrigger>
                                <AccordionContent>
                                    <Accordion type="multiple" defaultValue={['body-text']} className="w-full">
                                        <TypographyControls title="Body Text" />
                                        <TypographyControls title="Links" />
                                        <TypographyControls title="Heading 1" />
                                        <TypographyControls title="Heading 2" />
                                        <TypographyControls title="Heading 3" />
                                        <TypographyControls title="Heading 4" />
                                        <TypographyControls title="Heading 5" />
                                        <TypographyControls title="Heading 6" />
                                    </Accordion>
                                </AccordionContent>
                            </AccordionItem>
                            <AccordionItem value="custom-css">
                                <AccordionTrigger className="text-lg">Custom CSS</AccordionTrigger>
                                <AccordionContent className="pt-4">
                                    <Card>
                                        <CardHeader>
                                            <CardTitle>Custom CSS</CardTitle>
                                            <CardDescription>Add your own custom CSS to the site. This will be added to the &lt;head&gt; section of the site.</CardDescription>
                                        </CardHeader>
                                        <CardContent>
                                            <Textarea 
                                                placeholder="/* Your custom CSS here */" 
                                                rows={10}
                                                value={themeSettings.customCss || ''}
                                                onChange={(e) => handleCustomCssChange(e.target.value)}
                                                className="font-mono"
                                            />
                                        </CardContent>
                                    </Card>
                                </AccordionContent>
                            </AccordionItem>
                        </Accordion>
                    </CardContent>
                </Card>
            </TabsContent>
            <TabsContent value="ads">
                <Card>
                    <CardHeader>
                        <CardTitle>Ad Settings</CardTitle>
                        <CardDescription>Manage your ad placements here. (This feature is under construction)</CardDescription>
                    </CardHeader>
                </Card>
            </TabsContent>
        </Tabs>
      </main>
    </>
  );
}
