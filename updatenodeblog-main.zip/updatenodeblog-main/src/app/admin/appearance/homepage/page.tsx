
'use client';

import React, { useState, useMemo, useEffect, CSSProperties } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PlusCircle, Trash2, GripVertical, Settings, Plus, ChevronsUpDown, FileText, Video, Image as ImageIcon, Newspaper, Mail, Flame, ExternalLink, LayoutGrid, Star, List, Space, Code, Minus, Heart, Trophy, Sparkles, Eye, Sidebar as SidebarIcon, BadgeDollarSign, Heading, GalleryHorizontal, MoreHorizontal, Check, Pilcrow } from 'lucide-react';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
  DragStartEvent,
  UniqueIdentifier,
  DragOverlay,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { cn } from '@/lib/utils';
import { Block, BlockType, getHomepageLayout, updateHomepageLayout, getCategories as fetchCategories, Category, Post, User, getPostById, getAllContent as fetchAllContent } from '@/lib/data';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import Link from 'next/link';
import { useToast } from '@/hooks/use-toast';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import PostCard from '@/components/blog/post-card';
import { Separator } from '@/components/ui/separator';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';
import ColorPicker from '@/components/admin/color-picker';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import HomepageBuilder from '@/components/homepage-builder';
import { Checkbox } from '@/components/ui/checkbox';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { Badge } from '@/components/ui/badge';

const availableWidgets = [
    'Search', 'Recent Posts', 'Categories', 'Follow Us', 'Tag Cloud', 'Newsletter', 'Most Commented', 'Advertisement'
];

const blockInfo: Record<string, { name: string, description: string, isContainer?: boolean, category?: 'Structure' | 'Grids' | 'List-Based' | 'Utility' | 'Digiotic Blocks' }> = {
    // Digiotic Blocks
    'news-focus-block': { name: 'News Focus Block', description: 'A main story with a list of related articles.', category: 'Digiotic Blocks' },
    'focus-grid-block': { name: 'Focus Grid Block', description: 'A large post with a grid of smaller posts on the side.', category: 'Digiotic Blocks' },
    'highlights-block': { name: 'Highlights Block', description: 'A row of highlighted posts.', category: 'Digiotic Blocks' },
    'large-block': { name: 'Large Block', description: 'A single, large featured post.', category: 'Digiotic Blocks' },
    'overlay-block': { name: 'Overlay Block', description: 'A post where the title overlays the featured image.', category: 'Digiotic Blocks' },
    'featured-area-grids': { name: 'Featured Area Grids', description: 'A complex grid of featured posts from different categories.', category: 'Digiotic Blocks' },
    'category-tabs': { name: 'Category Tabs', description: 'Display posts from multiple categories in tabs.', category: 'Digiotic Blocks' },
    'paginated-block': { name: 'Paginated Block', description: 'A list or grid of posts with pagination.', category: 'Digiotic Blocks' },
    'custom-block': { name: 'Custom Block', description: 'A highly customizable block with multiple layouts.', category: 'Digiotic Blocks' },
    'carousel-block': { name: 'Carousel Block', description: 'A sliding carousel to showcase multiple posts.', category: 'Digiotic Blocks' },
    'image-gallery': { name: 'Image Gallery', description: 'A gallery of images.', category: 'Digiotic Blocks' },
    'video': { name: 'Video', description: 'Embed a video.', category: 'Digiotic Blocks' },
    // Structure
    'section': { name: 'Section', description: 'A full-width container for other blocks.', isContainer: true, category: 'Structure' },
    'two-column': { name: 'Two-Column Layout', description: 'A layout with two equal columns.', isContainer: true, category: 'Structure' },
    'three-column': { name: 'Three-Column Layout', description: 'A layout with three equal columns.', isContainer: true, category: 'Structure' },
    'four-column': { name: 'Four-Column Layout', description: 'A layout with four equal columns.', isContainer: true, category: 'Structure' },
    'five-column': { name: 'Five-Column Layout', description: 'A layout with five equal columns.', isContainer: true, category: 'Structure' },
    'six-column': { name: 'Six-Column Layout', description: 'A layout with six equal columns.', isContainer: true, category: 'Structure' },
    'seven-column': { name: 'Seven-Column Layout', description: 'A layout with seven equal columns.', isContainer: true, category: 'Structure' },
    'eight-column': { name: 'Eight-Column Layout', description: 'A layout with eight equal columns.', isContainer: true, category: 'Structure' },
    'sidebar-left': { name: 'Sidebar Left', description: 'Content with a sidebar on the left.', isContainer: true, category: 'Structure' },
    'sidebar-right': { name: 'Sidebar Right', description: 'Content with a sidebar on the right.', isContainer: true, category: 'Structure' },
    'accordion': { name: 'Accordion', description: 'A collapsible content area.', isContainer: true, category: 'Structure' },
    'accordion-item': { name: 'Accordion Item', description: 'A single item within an accordion.', isContainer: true, category: 'Structure' },
    'sidebar': { name: 'Sidebar', description: 'A container for widgets.', category: 'Structure' },
    // Grids
    'classic-grid': { name: 'Classic Grid', description: 'A standard grid of posts.', category: 'Grids' },
    'masonry-grid': { name: 'Masonry Grid', description: 'An offset grid of posts.', category: 'Grids' },
    'metro-grid': { name: 'Metro Grid', description: 'A modern, metro-style grid.', category: 'Grids' },
    'pinterest-style': { name: 'Pinterest Style', description: 'A pinterest-style layout for posts.', category: 'Grids' },
    'full-width-grid': { name: 'Full Width Grid', description: 'A full-width grid of posts.', category: 'Grids' },
    // List-Based
    'list-block': { name: 'List Block', description: 'A clean, simple list of posts.', category: 'List-Based' },
    'small-list-block': { name: 'Small List Block', description: 'A compact list of post titles.', category: 'List-Based' },
    'classic-list': { name: 'Classic List', description: 'A standard list of posts.', category: 'List-Based' },
    'compact-list': { name: 'Compact List', description: 'A dense list of posts.', category: 'List-Based' },
    'numbered-list': { name: 'Numbered List', description: 'A numbered list of posts.', category: 'List-Based' },
    'timeline': { name: 'Timeline', description: 'A chronological list of posts.', category: 'List-Based' },
    // Utility
    'spacer': { name: 'Spacer', description: 'Add empty space between blocks.', category: 'Utility' },
    'divider': { name: 'Divider', description: 'A customizable horizontal line to separate content.', category: 'Utility' },
    'custom-html': { name: 'Custom HTML', description: 'Insert custom HTML code.', category: 'Utility' },
    'block-heading': { name: 'Block Heading', description: 'A styled heading for a section of blocks.', category: 'Utility' },
    'breadcrumbs': { name: 'Breadcrumbs', description: 'Navigation links showing the path to the current page.', category: 'Utility' },
    'social-icons': { name: 'SmartMag Social Icons', description: 'Display social media icons with various styles.', category: 'Utility' },
    'ads-codes': { name: 'Ads / Codes', description: 'Insert advertisement code or custom HTML snippets.', category: 'Utility' },
    'newsletter-form-digiotic': { name: 'Newsletter Form', description: 'A form for newsletter subscriptions.', category: 'Utility' },
};


// Block helper functions moved from data.ts to be co-located with the component
function findBlock(blocks: Block[], id: string): Block | undefined {
    for (const block of blocks) {
        if (block.id === id) return block;
        if (block.children) {
            const found = findBlock(block.children, id);
            if (found) return found;
        }
    }
    return undefined;
}

function findContainer(blocks: Block[], id: string): Block | null {
    if (id === null) return null;

    for (const block of blocks) {
        if (block.children?.some(child => child.id === id)) {
            return block;
        }
        if (block.children) {
            const found = findContainer(block.children, id);
            if(found) return found;
        }
    }
    return null; // Root
}

const updateBlock = (blocks: Block[], updatedBlock: Block): Block[] => {
    return blocks.map(block => {
        if (block.id === updatedBlock.id) {
            return updatedBlock;
        }
        if (block.children) {
            return { ...block, children: updateBlock(block.children, updatedBlock) };
        }
        return block;
    });
};

const removeBlock = (blocks: Block[], id: string): Block[] => {
    return blocks.reduce((acc, block) => {
        if (block.id === id) {
            return acc; // Skip adding it
        }
        if (block.children) {
            block.children = removeBlock(block.children, id);
        }
        acc.push(block);
        return acc;
    }, [] as Block[]);
};

const addBlockToContainer = (blocks: Block[], parentId: string | null, type: BlockType): Block[] => {
    const newBlock: Block = { id: `${type}-${Date.now()}`, type, settings: {}, styles: {} };
    
    if (blockInfo[type]?.isContainer) {
        let childCount = 1;
        let childType: BlockType = 'section'; // Default child type for containers
        let children: Block[] = [];

        switch (type) {
            case 'sidebar-left':
                children = [
                    { id: `col-sidebar-${Date.now()}`, type: 'section', settings: {}, children: [ { id: `sidebar-${Date.now()}`, type: 'sidebar', settings: { widgets: ['Search', 'Recent Posts', 'Categories'] } }] },
                    { id: `col-main-${Date.now()}`, type: 'section', settings: {}, children: [] },
                ];
                break;
            case 'sidebar-right':
                children = [
                    { id: `col-main-${Date.now()}`, type: 'section', settings: {}, children: [] },
                    { id: `col-sidebar-${Date.now()}`, type: 'section', settings: {}, children: [ { id: `sidebar-${Date.now()}`, type: 'sidebar', settings: { widgets: ['Search', 'Recent Posts', 'Categories'] } }] },
                ];
                break;
            case 'two-column': childCount = 2; break;
            case 'three-column': childCount = 3; break;
            case 'four-column': childCount = 4; break;
            case 'five-column': childCount = 5; break;
            case 'six-column': childCount = 6; break;
            case 'seven-column': childCount = 7; break;
            case 'eight-column': childCount = 8; break;
            case 'accordion':
                childType = 'accordion-item';
                break;
        }
        
        if (children.length === 0) { // If not a special sidebar case
             children = Array.from({ length: childCount }, (_, i) => ({
                id: `${childType}-${Date.now()}-${i}`,
                type: childType,
                settings: childType === 'accordion-item' ? { title: `Accordion Item ${i + 1}` } : {},
                children: []
            }));
        }
        newBlock.children = children;

    } else if (type === 'sidebar') {
        newBlock.settings = { widgets: ['Search', 'Recent Posts', 'Categories'] };
    }

    if (parentId === null) {
        return [...blocks, newBlock];
    }
    
    return blocks.map(block => {
        if (block.id === parentId) {
             if (!block.children) block.children = [];
             return { ...block, children: [...block.children, newBlock] };
        }
        if (block.children) {
             return { ...block, children: addBlockToContainer(block.children, parentId, type) };
        }
        return block;
    });
};


const popularFonts = [
    'Inter', 'Roboto', 'Open Sans', 'Lato', 'Montserrat', 'Oswald', 'Raleway', 'Poppins', 'Nunito', 'Merriweather'
];

const AddBlockButton = ({ onAddBlock, parentId }: { onAddBlock: (type: BlockType, parentId: string | null) => void, parentId: string | null }) => {
    return (
        <Popover>
            <PopoverTrigger asChild>
                <Button size="sm" variant="outline" className="h-8 w-8 p-0">
                    <Plus className="h-4 w-4" />
                </Button>
            </PopoverTrigger>
            <PopoverContent className="w-64 p-2 max-h-[300px] overflow-y-auto">
                <div className="space-y-1">
                    <p className="text-xs font-semibold text-muted-foreground px-2">Content Blocks</p>
                     {Object.entries(blockInfo).filter(([, { isContainer }]) => !isContainer).map(([type, { name }]) => (
                         <Button
                            key={type}
                            variant="ghost"
                            className="w-full justify-start"
                            onClick={() => onAddBlock(type as BlockType, parentId)}
                        >
                            {name}
                        </Button>
                    ))}
                </div>
            </PopoverContent>
        </Popover>
    )
}

const HomepageBlock = ({ block, onRemove, onAddBlock, onUpdate, allCategories, allContent, parentId }: { block: Block; onRemove: (id: string) => void; onAddBlock: (type: BlockType, parentId: string | null) => void; onUpdate: (block: Block) => void; allCategories: Category[]; allContent: Post[]; parentId: string | null; }) => {
    
    const blockMeta = blockInfo[block.type];

    if (!blockMeta) {
        return (
            <div className="p-3 bg-destructive/10 border-destructive border rounded-lg shadow-sm text-destructive">
                 <div className="flex items-center gap-2">
                    <div>
                        <p className="font-bold">Unknown Block Type: "{block.type}"</p>
                        <p className="text-xs">This block is not supported. It may be from an old version. Please remove it.</p>
                    </div>
                     <Button variant="destructive" size="sm" className="ml-auto" onClick={() => onRemove(block.id)}>Remove</Button>
                </div>
            </div>
        )
    }

    const {
        attributes,
        listeners,
        setNodeRef,
        transform,
        transition,
        isDragging,
    } = useSortable({id: block.id, data: {type: 'block', block}});
    
    const style = {
        transform: CSS.Transform.toString(transform),
        transition,
        opacity: isDragging ? 0.5 : 1,
    };

    const handleSettingsChange = (settingKey: string, value: any) => {
        onUpdate({
            ...block,
            settings: {
                ...block.settings,
                [settingKey]: value,
            }
        });
    }

    const handleStyleChange = (styleKey: string, value: any) => {
        onUpdate({
            ...block,
            styles: {
                ...block.styles,
                [styleKey]: value,
            }
        });
    }
    
     const handleWidgetToggle = (widgetName: string) => {
        const currentWidgets = block.settings?.widgets || [];
        const newWidgets = currentWidgets.includes(widgetName)
            ? currentWidgets.filter((w: string) => w !== widgetName)
            : [...currentWidgets, widgetName];
        handleSettingsChange('widgets', newWidgets);
    };

    const renderBlockContent = () => {
        if (blockMeta.isContainer) {
            if (block.type === 'accordion') {
                return (
                     <Accordion type="multiple" className="w-full space-y-2">
                        {(block.children || []).map(child => (
                           <AccordionItem key={child.id} value={child.id} className="border rounded-md bg-background/50">
                               <div className="flex items-center px-4 py-2 hover:no-underline">
                                    <HomepageBlock 
                                        key={child.id}
                                        block={child}
                                        onRemove={onRemove}
                                        onAddBlock={onAddBlock}
                                        onUpdate={onUpdate}
                                        allCategories={allCategories}
                                        allContent={allContent}
                                        parentId={block.id}
                                    />
                               </div>
                               <AccordionContent className="p-4 border-t">
                                 <div className="min-h-[80px] border-2 border-dashed rounded-md flex flex-col p-4 gap-4">
                                     <SortableContext items={(child.children || []).map(c => c.id)} strategy={verticalListSortingStrategy}>
                                       {(child.children || []).map(grandchild => (
                                           <HomepageBlock 
                                                key={grandchild.id}
                                                block={grandchild}
                                                onRemove={onRemove}
                                                onAddBlock={onAddBlock}
                                                onUpdate={onUpdate}
                                                allCategories={allCategories}
                                                allContent={allContent}
                                                parentId={child.id}
                                           />
                                       ))}
                                   </SortableContext>
                                    <div className="flex justify-center mt-auto">
                                        <AddBlockButton onAddBlock={onAddBlock} parentId={child.id} />
                                   </div>
                               </div>
                               </AccordionContent>
                           </AccordionItem>
                        ))}
                         <div className="flex justify-center mt-2">
                           <Button variant="outline" size="sm" onClick={() => onAddBlock('accordion-item', block.id)}>
                             <Plus className="mr-2 h-4 w-4" /> Add Item
                           </Button>
                         </div>
                    </Accordion>
                )
            }
            return (
                 <div className="pt-4">
                    <SortableContext items={(block.children || []).map(c => c.id)} strategy={verticalListSortingStrategy}>
                        <div className={cn(
                            "space-y-3",
                            block.type.includes('column') && 'grid gap-4',
                            block.type.includes('sidebar') && 'grid gap-4',
                            block.type === 'two-column' && 'sm:grid-cols-2',
                            block.type === 'three-column' && 'sm:grid-cols-3',
                            block.type === 'four-column' && 'sm:grid-cols-2 md:grid-cols-4',
                            block.type === 'five-column' && 'sm:grid-cols-2 md:grid-cols-5',
                            block.type === 'six-column' && 'sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6',
                            block.type === 'seven-column' && 'sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-7',
                            block.type === 'eight-column' && 'sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-8',
                            block.type === 'sidebar-left' && 'md:grid-cols-[1fr_3fr]',
                            block.type === 'sidebar-right' && 'md:grid-cols-[3fr_1fr]',
                        )}>
                           {(block.children || []).map(child => (
                               <div key={child.id} className="min-h-[80px] border-2 border-dashed rounded-md flex flex-col p-4 gap-4 bg-background/50">
                                   <p className="text-sm text-muted-foreground text-center">Column</p>
                                   <SortableContext items={(child.children || []).map(c => c.id)} strategy={verticalListSortingStrategy}>
                                       {(child.children || []).map(grandchild => (
                                           <HomepageBlock 
                                                key={grandchild.id}
                                                block={grandchild}
                                                onRemove={onRemove}
                                                onAddBlock={onAddBlock}
                                                onUpdate={onUpdate}
                                                allCategories={allCategories}
                                                allContent={allContent}
                                                parentId={child.id}
                                           />
                                       ))}
                                   </SortableContext>
                                    <div className="flex justify-center mt-auto">
                                        <AddBlockButton onAddBlock={onAddBlock} parentId={child.id} />
                                   </div>
                               </div>
                           ))}
                        </div>
                    </SortableContext>
                </div>
            )
        }
        
        const renderContentPlaceholder = (icon: React.ReactNode, text: string) => (
             <div className="flex items-center gap-3 p-2">
                {icon}
                <p className="text-sm text-muted-foreground">{text}</p>
            </div>
        );

        switch (block.type) {
            case 'category-tabs': return renderContentPlaceholder(<List className="h-5 w-5 text-muted-foreground" />, block.settings?.title || 'Category Tabs');
            case 'news-focus-block': return renderContentPlaceholder(<Newspaper className="h-5 w-5 text-muted-foreground" />, block.settings?.title || 'News Focus Block');
            case 'focus-grid-block': return renderContentPlaceholder(<LayoutGrid className="h-5 w-5 text-muted-foreground" />, block.settings?.title || 'Focus Grid Block');
            case 'highlights-block': return renderContentPlaceholder(<Sparkles className="h-5 w-5 text-muted-foreground" />, block.settings?.title || 'Highlights Block');
            case 'large-block': return renderContentPlaceholder(<FileText className="h-5 w-5 text-muted-foreground" />, block.settings?.title || 'Large Block');
            case 'overlay-block': return renderContentPlaceholder(<ImageIcon className="h-5 w-5 text-muted-foreground" />, block.settings?.title || 'Overlay Block');
            case 'featured-area-grids': return renderContentPlaceholder(<LayoutGrid className="h-5 w-5 text-muted-foreground" />, block.settings?.title || 'Featured Area Grids');
            case 'block-heading': return renderContentPlaceholder(<Heading className="h-5 w-5 text-muted-foreground" />, block.settings?.title || 'Block Heading');
            case 'breadcrumbs': return renderContentPlaceholder(<ChevronsUpDown className="h-5 w-5 text-muted-foreground" />, 'Breadcrumbs');
            case 'social-icons': return renderContentPlaceholder(<Heart className="h-5 w-5 text-muted-foreground" />, block.settings?.title || 'SmartMag Social Icons');
            case 'ads-codes': return renderContentPlaceholder(<BadgeDollarSign className="h-5 w-5 text-muted-foreground" />, 'Ads / Codes');
            // Original Blocks
            case 'image-gallery':
                return renderContentPlaceholder(<ImageIcon className="h-5 w-5 text-muted-foreground" />, 'Image Gallery Block');
            case 'video':
                return renderContentPlaceholder(<Video className="h-5 w-5 text-muted-foreground" />, block.settings?.url || 'Video Block');
            case 'classic-grid':
                return renderContentPlaceholder(<LayoutGrid className="h-5 w-5 text-muted-foreground" />, 'Classic Grid');
            case 'masonry-grid':
                return renderContentPlaceholder(<LayoutGrid className="h-5 w-5 text-muted-foreground" />, 'Masonry Grid');
            case 'metro-grid':
                return renderContentPlaceholder(<LayoutGrid className="h-5 w-5 text-muted-foreground" />, 'Metro Grid');
            case 'pinterest-style':
                return renderContentPlaceholder(<LayoutGrid className="h-5 w-5 text-muted-foreground" />, 'Pinterest Style');
            case 'full-width-grid':
                return renderContentPlaceholder(<LayoutGrid className="h-5 w-5 text-muted-foreground" />, 'Full Width Grid');
             case 'carousel-block':
                 return renderContentPlaceholder(<GalleryHorizontal className="h-5 w-5 text-muted-foreground" />, block.settings?.title || 'Carousel Block');
            case 'list-block': 
                return renderContentPlaceholder(<List className="h-5 w-5 text-muted-foreground" />, block.settings?.title || 'List Block');
            case 'small-list-block':
                 return renderContentPlaceholder(<List className="h-5 w-5 text-muted-foreground" />, block.settings?.title || 'Small List Block');
            case 'classic-list':
                return renderContentPlaceholder(<List className="h-5 w-5 text-muted-foreground" />, 'Classic List');
            case 'compact-list':
                return renderContentPlaceholder(<List className="h-5 w-5 text-muted-foreground" />, 'Compact List');
            case 'numbered-list':
                return renderContentPlaceholder(<List className="h-5 w-5 text-muted-foreground" />, 'Numbered List');
            case 'timeline':
                return renderContentPlaceholder(<List className="h-5 w-5 text-muted-foreground" />, 'Timeline');
            case 'paginated-block':
                return renderContentPlaceholder(<MoreHorizontal className="h-5 w-5 text-muted-foreground" />, block.settings?.title || 'Paginated Block');
            case 'spacer':
                return renderContentPlaceholder(<Space className="h-5 w-5 text-muted-foreground" />, 'Spacer');
            case 'divider':
                return renderContentPlaceholder(<Minus className="h-5 w-5 text-muted-foreground" />, 'Divider');
            case 'custom-html':
                return renderContentPlaceholder(<Code className="h-5 w-5 text-muted-foreground" />, 'Custom HTML');
            case 'sidebar':
                return renderContentPlaceholder(<SidebarIcon className="h-5 w-5 text-muted-foreground" />, 'Sidebar');
            case 'custom-block':
                return renderContentPlaceholder(<LayoutGrid className="h-5 w-5 text-muted-foreground" />, block.settings?.title || 'Custom Block');
            case 'newsletter-form-digiotic':
                 return renderContentPlaceholder(<Pilcrow className="h-5 w-5 text-muted-foreground" />, block.settings?.title || 'Newsletter Form');
            default:
                return renderContentPlaceholder(<FileText className="h-5 w-5 text-muted-foreground" />, 'Content block placeholder');
        }
    }
    
    const renderSettings = () => {
        const typographySettings = (sectionName: string, title: string, styleSubKey?: keyof Block['styles']) => {
            const currentStyles = styleSubKey ? block.styles?.[styleSubKey] || {} : block.styles || {};
            const handleStyleUpdate = (key: string, value: any) => {
                if (styleSubKey) {
                    onUpdate({ ...block, styles: { ...block.styles, [styleSubKey]: { ...block.styles?.[styleSubKey], [key]: value } } });
                } else {
                    handleStyleChange(key, value);
                }
            }

            return (
                 <AccordionItem value={sectionName}>
                    <AccordionTrigger>{title}</AccordionTrigger>
                    <AccordionContent className="space-y-4 pt-4">
                        <div className="space-y-2"><Label>Font Family</Label><Select value={currentStyles.fontFamily || 'Inter'} onValueChange={(v) => handleStyleUpdate('fontFamily', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{popularFonts.map(font => <SelectItem key={font} value={font} style={{fontFamily: font}}>{font}</SelectItem>)}</SelectContent></Select></div>
                        <div className="grid grid-cols-2 gap-2">
                            <div className="space-y-2"><Label>Font Size (px)</Label><Input type="number" value={currentStyles.fontSize || ''} placeholder="16" onChange={(e) => handleStyleUpdate('fontSize', parseInt(e.target.value) || undefined)} /></div>
                            <div className="space-y-2"><Label>Font Weight</Label><Select value={currentStyles.fontWeight || 'normal'} onValueChange={(v) => handleStyleUpdate('fontWeight', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="300">Light</SelectItem><SelectItem value="400">Normal</SelectItem><SelectItem value="500">Medium</SelectItem><SelectItem value="600">Semi-Bold</SelectItem><SelectItem value="700">Bold</SelectItem></SelectContent></Select></div>
                        </div>
                        <ColorPicker label="Text Color" color={currentStyles.color || ''} onChange={(c) => handleStyleUpdate('color', c)} />
                        <ColorPicker label="Hover Color" color={currentStyles.hoverColor || ''} onChange={(c) => handleStyleUpdate('hoverColor', c)} />
                    </AccordionContent>
                </AccordionItem>
            );
        };
        
         const badgeStyling = (sectionName: string, title: string, styleSubKey: keyof Block['styles']) => {
            const currentStyles = block.styles?.[styleSubKey] || {};
            const handleStyleUpdate = (key: string, value: any) => {
                onUpdate({ ...block, styles: { ...block.styles, [styleSubKey]: { ...block.styles?.[styleSubKey], [key]: value } } });
            }

            return (
                <AccordionItem value={sectionName}>
                    <AccordionTrigger>{title}</AccordionTrigger>
                    <AccordionContent className="space-y-4 pt-4">
                        <h4 className="font-semibold pt-2 border-t text-sm">Background</h4>
                        <RadioGroup value={currentStyles.backgroundType || 'gradient'} onValueChange={(v:any) => handleStyleUpdate('backgroundType', v)} className="flex gap-4">
                             <div className="flex items-center space-x-2"><RadioGroupItem value="solid" id={`bg-solid-${styleSubKey}`} /><Label htmlFor={`bg-solid-${styleSubKey}`}>Solid</Label></div>
                            <div className="flex items-center space-x-2"><RadioGroupItem value="gradient" id={`bg-gradient-${styleSubKey}`} /><Label htmlFor={`bg-gradient-${styleSubKey}`}>Gradient</Label></div>
                        </RadioGroup>

                        {currentStyles.backgroundType === 'solid' ? (
                            <ColorPicker label="Background Color" color={currentStyles.backgroundColor || ''} onChange={(c) => handleStyleUpdate('backgroundColor', c)} />
                        ) : (
                            <div className="grid grid-cols-2 gap-4">
                                <ColorPicker label="Gradient Start" color={currentStyles.gradient?.from || ''} onChange={(c) => handleStyleUpdate('gradient', {...currentStyles.gradient, from: c})} />
                                <ColorPicker label="Gradient End" color={currentStyles.gradient?.to || ''} onChange={(c) => handleStyleUpdate('gradient', {...currentStyles.gradient, to: c})} />
                            </div>
                        )}
                        
                        <h4 className="font-semibold pt-2 border-t text-sm">Border</h4>
                        <ColorPicker label="Border Color" color={currentStyles.borderColor || ''} onChange={(c) => handleStyleUpdate('borderColor', c)} />
                        <div className="grid grid-cols-2 gap-2">
                            <div className="space-y-2"><Label>Border Width (px)</Label><Input type="number" value={currentStyles.borderWidth || 0} onChange={(e) => handleStyleUpdate('borderWidth', parseInt(e.target.value))} /></div>
                            <div className="space-y-2"><Label>Border Radius (px)</Label><Input type="number" value={currentStyles.borderRadius || 0} onChange={(e) => handleStyleUpdate('borderRadius', parseInt(e.target.value))} /></div>
                        </div>
                        <div className="space-y-2"><Label>Padding (px)</Label><Input type="number" value={currentStyles.padding || 0} onChange={(e) => handleStyleUpdate('padding', parseInt(e.target.value))} /></div>
                    </AccordionContent>
                </AccordionItem>
            )
        };

        const cardElementStyling = (
             <AccordionItem value="card-element-styling">
                <AccordionTrigger>Card Elements</AccordionTrigger>
                <AccordionContent className="space-y-2 pt-4">
                     <Accordion type="multiple" className="w-full">
                        <AccordionItem value="category-element">
                            <AccordionTrigger className="text-sm">Category</AccordionTrigger>
                            <AccordionContent className="pt-4 space-y-4">
                                <div className="flex items-center justify-between rounded-lg border p-3">
                                    <Label htmlFor={`show-cat-${block.id}`} className="font-normal text-sm">Show Category</Label>
                                    <Switch id={`show-cat-${block.id}`} checked={block.settings?.showCategory ?? true} onCheckedChange={(v) => handleSettingsChange('showCategory', v)} />
                                </div>
                                 <Accordion type="multiple" className="w-full">
                                    {typographySettings('category-text-styles', 'Typography', 'categoryTextStyles')}
                                    {badgeStyling('badge-styling', 'Badge Styling', 'categoryBadgeStyles')}
                                </Accordion>
                            </AccordionContent>
                        </AccordionItem>
                         <AccordionItem value="title-element">
                            <AccordionTrigger className="text-sm">Title</AccordionTrigger>
                            <AccordionContent className="pt-4 space-y-4">
                                 <div className="flex items-center justify-between rounded-lg border p-3">
                                    <Label htmlFor={`show-title-${block.id}`} className="font-normal text-sm">Show Title</Label>
                                    <Switch id={`show-title-${block.id}`} checked={block.settings?.showTitle ?? true} onCheckedChange={(v) => handleSettingsChange('showTitle', v)} />
                                </div>
                                {typographySettings('title-element-styles', 'Typography', 'titleStyles')}
                            </AccordionContent>
                        </AccordionItem>
                        <AccordionItem value="excerpt-element">
                            <AccordionTrigger className="text-sm">Excerpt</AccordionTrigger>
                             <AccordionContent className="pt-4 space-y-4">
                                <div className="flex items-center justify-between rounded-lg border p-3">
                                    <Label htmlFor={`show-excerpt-${block.id}`} className="font-normal text-sm">Show Excerpt</Label>
                                    <Switch id={`show-excerpt-${block.id}`} checked={block.settings?.showExcerpt ?? true} onCheckedChange={(v) => handleSettingsChange('showExcerpt', v)} />
                                </div>
                                 <div className="space-y-2">
                                     <Label>Excerpt Word Count</Label>
                                     <Input type="number" value={block.settings?.excerptLength || 20} onChange={(e) => handleSettingsChange('excerptLength', parseInt(e.target.value))} />
                                 </div>
                                {typographySettings('excerpt-element-styles', 'Typography', 'excerptStyles')}
                            </AccordionContent>
                        </AccordionItem>
                        <AccordionItem value="author-element">
                            <AccordionTrigger className="text-sm">Author</AccordionTrigger>
                            <AccordionContent className="pt-4 space-y-4">
                                <div className="flex items-center justify-between rounded-lg border p-3">
                                    <Label htmlFor={`show-author-${block.id}`} className="font-normal text-sm">Show Author</Label>
                                    <Switch id={`show-author-${block.id}`} checked={block.settings?.showAuthor ?? true} onCheckedChange={(v) => handleSettingsChange('showAuthor', v)} />
                                </div>
                                {typographySettings('author-styles', 'Typography', 'authorStyles')}
                            </AccordionContent>
                        </AccordionItem>
                        <AccordionItem value="date-element">
                            <AccordionTrigger className="text-sm">Date</AccordionTrigger>
                            <AccordionContent className="pt-4 space-y-4">
                                <div className="flex items-center justify-between rounded-lg border p-3">
                                    <Label htmlFor={`show-date-${block.id}`} className="font-normal text-sm">Show Date</Label>
                                    <Switch id={`show-date-${block.id}`} checked={block.settings?.showDate ?? true} onCheckedChange={(v) => handleSettingsChange('showDate', v)} />
                                </div>
                                {typographySettings('date-styles', 'Typography', 'dateStyles')}
                            </AccordionContent>
                        </AccordionItem>
                         <AccordionItem value="readmore-element">
                            <AccordionTrigger className="text-sm">Read More Button</AccordionTrigger>
                            <AccordionContent className="pt-4 space-y-4">
                                <div className="flex items-center justify-between rounded-lg border p-3">
                                    <Label htmlFor={`show-readmore-${block.id}`} className="font-normal text-sm">Show Read More Button</Label>
                                    <Switch id={`show-readmore-${block.id}`} checked={block.settings?.showReadMore ?? true} onCheckedChange={(v) => handleSettingsChange('showReadMore', v)} />
                                </div>
                                {badgeStyling('readmore-styles', 'Button Styling', 'readMoreStyles')}
                            </AccordionContent>
                        </AccordionItem>
                     </Accordion>
                </AccordionContent>
             </AccordionItem>
        );

        const cardStyling = (
             <AccordionItem value="card-styling">
                <AccordionTrigger>Card Styling</AccordionTrigger>
                <AccordionContent className="space-y-4 pt-4">
                    <ColorPicker label="Background Color" color={block.styles?.cardBackgroundColor || '#ffffff'} onChange={(c) => handleStyleChange('cardBackgroundColor', c)} />
                     <div className="space-y-2">
                        <Label>Border Radius (px)</Label>
                        <Slider defaultValue={[block.styles?.cardBorderRadius || 8]} max={32} step={1} onValueChange={(v) => handleStyleChange('cardBorderRadius', v[0])} />
                    </div>
                     <div className="space-y-2">
                        <Label>Shadow</Label>
                        <Select value={block.styles?.cardShadow || 'none'} onValueChange={(v) => handleStyleChange('cardShadow', v)}>
                            <SelectTrigger><SelectValue /></SelectTrigger>
                            <SelectContent>
                                <SelectItem value="none">None</SelectItem>
                                <SelectItem value="shadow-sm">Small</SelectItem>
                                <SelectItem value="shadow-md">Medium</SelectItem>
                                <SelectItem value="shadow-lg">Large</SelectItem>
                                <SelectItem value="shadow-xl">Extra Large</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                     <div className="space-y-2">
                        <Label>Spacing between cards (px)</Label>
                        <Input type="number" value={block.styles?.spacing || 16} onChange={(e) => handleStyleChange('spacing', parseInt(e.target.value))} />
                    </div>
                </AccordionContent>
             </AccordionItem>
        );
        

        const commonPostSettings = (
             <>
                <div className="space-y-2"><Label>Category</Label><Select value={block.settings?.category || 'all'} onValueChange={(v) => handleSettingsChange('category', v)}><SelectTrigger><SelectValue placeholder="Select a category" /></SelectTrigger><SelectContent><SelectItem value="all">All</SelectItem>{allCategories.map(cat => <SelectItem key={cat.slug} value={cat.slug}>{cat.name}</SelectItem>)}</SelectContent></Select></div>
                <div className="space-y-2"><Label>Number of Posts</Label><Input type="number" value={block.settings?.count || 5} onChange={(e) => handleSettingsChange('count', parseInt(e.target.value))} /></div>
                <div className="space-y-2"><Label>Order</Label><Select value={block.settings?.order || 'latest'} onValueChange={(v) => handleSettingsChange('order', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="latest">Latest</SelectItem><SelectItem value="popular">Popular</SelectItem><SelectItem value="most_commented">Most Commented</SelectItem></SelectContent></Select></div>
                <div className="space-y-2"><Label>Skip Posts (Offset)</Label><Input type="number" value={block.settings?.skipPosts || 0} onChange={(e) => handleSettingsChange('skipPosts', parseInt(e.target.value))} placeholder="0" /><p className="text-xs text-muted-foreground">Number of posts to skip from the beginning.</p></div>
            </>
        );
        
        const contentTab = (children: React.ReactNode) => (
            <TabsContent value="content" className="pt-4">
                <div className="max-h-[450px] overflow-y-auto pr-2 space-y-4">
                    <div className="space-y-2"><Label>Block Title</Label><Input value={block.settings?.title || ''} onChange={(e) => handleSettingsChange('title', e.target.value)} /></div>
                    {children}
                </div>
            </TabsContent>
        );

        const stylingTab = (children: React.ReactNode) => (
            <TabsContent value="styling" className="pt-4">
                <div className="max-h-[450px] overflow-y-auto pr-2">
                    <Accordion type="multiple" className="w-full space-y-2">
                        {typographySettings('title-typography', 'Block Title')}
                        {cardElementStyling}
                        {children}
                    </Accordion>
                </div>
            </TabsContent>
        );
        
        const gridSettings = (
            <>
                <div className="space-y-2"><Label>Number of Columns</Label><Select value={block.settings?.columns || '3'} onValueChange={(v) => handleSettingsChange('columns', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{[1,2,3,4, 5, 6].map(n => <SelectItem key={n} value={String(n)}>{n}</SelectItem>)}</SelectContent></Select></div>
                {commonPostSettings}
            </>
        );

        const listSettings = (
             <>
                <div className="space-y-2"><Label>Number of Columns</Label><Select value={block.settings?.columns || '1'} onValueChange={(v) => handleSettingsChange('columns', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{[1,2,3,4].map(n => <SelectItem key={n} value={String(n)}>{n}</SelectItem>)}</SelectContent></Select></div>
                {commonPostSettings}
            </>
        );
        
        const customBlockSettings = (
             <div className="space-y-4">
                <div className="space-y-2">
                    <Label>Layout Pattern</Label>
                    <Select value={block.settings?.layout || 'large-left-small-right'} onValueChange={(v) => handleSettingsChange('layout', v)}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="large-left-small-right">Large Left, Small Right (Vertical)</SelectItem>
                            <SelectItem value="large-right-small-left">Large Right, Small Left (Vertical)</SelectItem>
                            <SelectItem value="large-left-small-grid">Large Left, Small Right (Grid)</SelectItem>
                            <SelectItem value="large-right-small-grid">Large Right, Small Left (Grid)</SelectItem>
                            <SelectItem value="large-top-small-grid">Large Top, Small Below (Grid)</SelectItem>
                            <SelectItem value="mixed-grid">Mixed Size Grid</SelectItem>
                            <SelectItem value="overlay-large-left-small-right">Overlay: Large Left, Small Right</SelectItem>
                            <SelectItem value="overlay-large-right-small-left">Overlay: Large Right, Small Left</SelectItem>
                            <SelectItem value="overlay-large-top-small-bottom">Overlay: Large Top, Small Bottom</SelectItem>
                            <SelectItem value="overlay-large-bottom-small-top">Overlay: Large Bottom, Small Top</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
                 <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2"><Label>Large Posts Count</Label><Input type="number" value={block.settings?.largePostCount || 1} onChange={(e) => handleSettingsChange('largePostCount', parseInt(e.target.value))} /></div>
                    <div className="space-y-2"><Label>Large Post Columns</Label><Input type="number" value={block.settings?.largePostColumns || 1} onChange={(e) => handleSettingsChange('largePostColumns', parseInt(e.target.value))} /></div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2"><Label>Small Posts Count</Label><Input type="number" value={block.settings?.smallPostCount || 3} onChange={(e) => handleSettingsChange('smallPostCount', parseInt(e.target.value))} /></div>
                    <div className="space-y-2"><Label>Small Post Columns</Label><Input type="number" value={block.settings?.smallPostColumns || 2} onChange={(e) => handleSettingsChange('smallPostColumns', parseInt(e.target.value))} /></div>
                </div>
                {commonPostSettings}
             </div>
        );

         const carouselSettings = (
            <>
                <div className="space-y-2">
                    <Label>Slides to Show</Label>
                    <Input type="number" value={block.settings?.slidesToShow || 3} onChange={(e) => handleSettingsChange('slidesToShow', parseInt(e.target.value))} />
                </div>
                 <div className="space-y-2">
                    <Label>Card Height (px)</Label>
                    <Input type="number" placeholder="Auto" value={block.settings?.cardHeight || ''} onChange={(e) => handleSettingsChange('cardHeight', parseInt(e.target.value))} />
                </div>
                <div className="flex items-center justify-between rounded-lg border p-3">
                    <Label htmlFor="carousel-loop" className="font-normal">Loop</Label>
                    <Switch id="carousel-loop" checked={block.settings?.loop} onCheckedChange={(v) => handleSettingsChange('loop', v)} />
                </div>
                 <div className="flex items-center justify-between rounded-lg border p-3">
                    <Label htmlFor="carousel-autoplay" className="font-normal">Autoplay</Label>
                    <Switch id="carousel-autoplay" checked={block.settings?.autoplay} onCheckedChange={(v) => handleSettingsChange('autoplay', v)} />
                </div>
                {commonPostSettings}
            </>
        );

        const paginatedSettings = (
            <>
                <div className="space-y-2">
                    <Label>Layout</Label>
                    <Select value={block.settings?.layout || 'grid'} onValueChange={(v) => handleSettingsChange('layout', v)}>
                        <SelectTrigger><SelectValue/></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="grid">Grid</SelectItem>
                            <SelectItem value="list">List</SelectItem>
                            <SelectItem value="classic">Classic</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
                {block.settings?.layout === 'grid' && (
                    <div className="space-y-2"><Label>Number of Columns</Label><Select value={block.settings?.columns || '3'} onValueChange={(v) => handleSettingsChange('columns', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{[1,2,3,4].map(n => <SelectItem key={n} value={String(n)}>{n}</SelectItem>)}</SelectContent></Select></div>
                )}
                 <div className="space-y-2">
                    <Label>Posts Per Page</Label>
                    <Input type="number" value={block.settings?.postsPerPage || 6} onChange={(e) => handleSettingsChange('postsPerPage', parseInt(e.target.value))} />
                </div>
                 <div className="space-y-2">
                    <Label>Pagination Style</Label>
                    <Select value={block.settings?.paginationStyle || 'numbered'} onValueChange={(v) => handleSettingsChange('paginationStyle', v)}>
                        <SelectTrigger><SelectValue/></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="numbered">Numbered</SelectItem>
                            <SelectItem value="load-more">Load More Button</SelectItem>
                            <SelectItem value="infinite-scroll">Infinite Scroll</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
                {commonPostSettings}
            </>
        );

        const categoryTabsSettings = (
            <div className="space-y-4">
                <div className="space-y-2">
                    <Label>Select Categories</Label>
                    <Popover>
                        <PopoverTrigger asChild>
                            <Button variant="outline" className="w-full justify-start h-auto min-h-10">
                                {block.settings?.categories?.length > 0 ? (
                                    <div className="flex flex-wrap gap-1">
                                        {allCategories.filter(c => block.settings.categories.includes(c.id)).map(c => <Badge key={c.id}>{c.name}</Badge>)}
                                    </div>
                                ) : 'Select categories...'}
                            </Button>
                        </PopoverTrigger>
                        <PopoverContent className="p-0 w-80">
                            <Command>
                                <CommandInput placeholder="Search categories..." />
                                <CommandList>
                                    <CommandEmpty>No results found.</CommandEmpty>
                                    <CommandGroup>
                                        {allCategories.map(cat => (
                                            <CommandItem key={cat.id} onSelect={() => {
                                                const selected = block.settings?.categories || [];
                                                const newSelected = selected.includes(cat.id) ? selected.filter((id: string) => id !== cat.id) : [...selected, cat.id];
                                                handleSettingsChange('categories', newSelected);
                                            }}>
                                                <Check className={cn("mr-2 h-4 w-4", (block.settings?.categories || []).includes(cat.id) ? "opacity-100" : "opacity-0")} />
                                                {cat.name}
                                            </CommandItem>
                                        ))}
                                    </CommandGroup>
                                </CommandList>
                            </Command>
                        </PopoverContent>
                    </Popover>
                </div>
                <div className="space-y-2"><Label>Posts per Tab</Label><Input type="number" value={block.settings?.count || 5} onChange={(e) => handleSettingsChange('count', parseInt(e.target.value))} /></div>
                <div className="space-y-2"><Label>Layout</Label><Select value={block.settings?.layout || 'grid'} onValueChange={(v) => handleSettingsChange('layout', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="grid">Grid</SelectItem><SelectItem value="list">List</SelectItem></SelectContent></Select></div>
                {block.settings?.layout === 'grid' && (
                    <div className="space-y-2"><Label>Number of Columns</Label><Select value={block.settings?.columns || '3'} onValueChange={(v) => handleSettingsChange('columns', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{[1,2,3,4, 5, 6].map(n => <SelectItem key={n} value={String(n)}>{n}</SelectItem>)}</SelectContent></Select></div>
                )}
            </div>
        )
        
        const digioticBlocksContent: Record<string, React.ReactNode> = {
            'large-block': commonPostSettings,
            'overlay-block': <><div className="space-y-2"><Label>Block Height (px)</Label><Input type="number" placeholder="Auto" value={block.settings?.blockHeight || ''} onChange={(e) => handleSettingsChange('blockHeight', parseInt(e.target.value))} /></div>{commonPostSettings}</>,
            'news-focus-block': commonPostSettings,
            'focus-grid-block': commonPostSettings,
            'highlights-block': commonPostSettings,
            'featured-area-grids': (
                <div className="space-y-4">
                    <div className="space-y-2"><Label>Area A Category (Large)</Label><Select value={block.settings?.areaA || 'all'} onValueChange={(v) => handleSettingsChange('areaA', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">All Categories</SelectItem>{allCategories.map(c => <SelectItem key={c.id} value={c.slug}>{c.name}</SelectItem>)}</SelectContent></Select></div>
                    <div className="space-y-2"><Label>Area B Category (Small Top)</Label><Select value={block.settings?.areaB || 'all'} onValueChange={(v) => handleSettingsChange('areaB', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">All Categories</SelectItem>{allCategories.map(c => <SelectItem key={c.id} value={c.slug}>{c.name}</SelectItem>)}</SelectContent></Select></div>
                    <div className="space-y-2"><Label>Area C Category (Small Bottom)</Label><Select value={block.settings?.areaC || 'all'} onValueChange={(v) => handleSettingsChange('areaC', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">All Categories</SelectItem>{allCategories.map(c => <SelectItem key={c.id} value={c.slug}>{c.name}</SelectItem>)}</SelectContent></Select></div>
                    <div className="space-y-2"><Label>Number of Posts</Label><Input type="number" value={block.settings?.count || 4} onChange={(e) => handleSettingsChange('count', parseInt(e.target.value))} /></div>
                    <div className="space-y-2"><Label>Skip Posts (Offset)</Label><Input type="number" value={block.settings?.skipPosts || 0} onChange={(e) => handleSettingsChange('skipPosts', parseInt(e.target.value))} placeholder="0" /></div>
                </div>
            ),
             'category-tabs': categoryTabsSettings,
             'carousel-block': carouselSettings,
             'paginated-block': paginatedSettings,
             'custom-block': customBlockSettings,
             'image-gallery': <div className="space-y-2"><Label>Number of Columns</Label><Select value={block.settings?.columns || '4'} onValueChange={(v) => handleSettingsChange('columns', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{[2,3,4,5,6].map(n => <SelectItem key={n} value={String(n)}>{n}</SelectItem>)}</SelectContent></Select></div>,
             'video': <div className="space-y-2"><Label>Video URL</Label><Input type="url" value={block.settings?.url || ''} onChange={(e) => handleSettingsChange('url', e.target.value)} placeholder="https://www.youtube.com/watch?v=..." /></div>,
        }
        
        const utilityBlockSettings: Record<string, React.ReactNode> = {
            'spacer': <div className="space-y-2"><Label>Height (px)</Label><Input type="number" value={block.settings?.height || 20} onChange={(e) => handleSettingsChange('height', parseInt(e.target.value))} /></div>,
            'divider': <div className="space-y-4">
                <div className="space-y-2"><Label>Style</Label><Select value={block.styles?.borderStyle || 'solid'} onValueChange={(v) => handleStyleChange('borderStyle', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="solid">Solid</SelectItem><SelectItem value="dashed">Dashed</SelectItem><SelectItem value="dotted">Dotted</SelectItem></SelectContent></Select></div>
                <ColorPicker label="Color" color={block.styles?.borderColor || '#e5e7eb'} onChange={(c) => handleStyleChange('borderColor', c)} />
                <div className="space-y-2"><Label>Width (%)</Label><Slider defaultValue={[block.styles?.width || 100]} max={100} step={5} onValueChange={(v) => handleStyleChange('width', v[0])} /></div>
                <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2"><Label>Top Margin (px)</Label><Input type="number" value={block.styles?.marginTop || 16} onChange={(e) => handleStyleChange('marginTop', parseInt(e.target.value))} /></div>
                    <div className="space-y-2"><Label>Bottom Margin (px)</Label><Input type="number" value={block.styles?.marginBottom || 16} onChange={(e) => handleStyleChange('marginBottom', parseInt(e.target.value))} /></div>
                </div>
            </div>,
            'custom-html': <div className="space-y-2"><Label>Custom HTML</Label><Textarea value={block.settings?.html || ''} onChange={(e) => handleSettingsChange('html', e.target.value)} rows={8} /></div>,
             'block-heading': (
                <div className="space-y-4">
                    <div className="space-y-2"><Label>Title</Label><Input value={block.settings?.title || ''} onChange={(e) => handleSettingsChange('title', e.target.value)} /></div>
                    <div className="space-y-2"><Label>Sub-Title</Label><Input value={block.settings?.subtitle || ''} onChange={(e) => handleSettingsChange('subtitle', e.target.value)} /></div>
                    <div className="space-y-2"><Label>URL</Label><Input type="url" value={block.settings?.url || ''} onChange={(e) => handleSettingsChange('url', e.target.value)} /></div>
                </div>
            ),
            'ads-codes': <div className="space-y-2"><Label>Ads/Codes HTML</Label><Textarea value={block.settings?.html || ''} onChange={(e) => handleSettingsChange('html', e.target.value)} rows={6} /></div>,
             'newsletter-form-digiotic': (
                <div className="space-y-4">
                     <div className="space-y-2"><Label>Title</Label><Input value={block.settings?.title || ''} onChange={(e) => handleSettingsChange('title', e.target.value)} /></div>
                      <div className="space-y-2"><Label>Description</Label><Textarea value={block.settings?.description || ''} onChange={(e) => handleSettingsChange('description', e.target.value)} /></div>
                </div>
            )
        };
        
        if (blockInfo[block.type]?.category === 'Utility') {
            return <PopoverContent className="w-96 max-h-[500px] overflow-y-auto"><div className="space-y-4">{utilityBlockSettings[block.type] || <p>No settings for this block.</p>}</div></PopoverContent>
        }
        
        const structureStyling = (
             <AccordionItem value="section-styling">
                <AccordionTrigger>Section Styling</AccordionTrigger>
                <AccordionContent className="space-y-4 pt-4">
                     <ColorPicker label="Background Color" color={block.styles?.backgroundColor || ''} onChange={(c) => handleStyleChange('backgroundColor', c)} />
                    <div className="grid grid-cols-2 gap-2">
                        <div className="space-y-2"><Label>Padding Top (px)</Label><Input type="number" value={block.styles?.paddingTop || 0} onChange={(e) => handleStyleChange('paddingTop', parseInt(e.target.value))} /></div>
                        <div className="space-y-2"><Label>Padding Bottom (px)</Label><Input type="number" value={block.styles?.paddingBottom || 0} onChange={(e) => handleStyleChange('paddingBottom', parseInt(e.target.value))} /></div>
                    </div>
                </AccordionContent>
             </AccordionItem>
        )

        if (blockInfo[block.type]?.isContainer) {
            return (
                 <PopoverContent className="w-96">
                     <Tabs defaultValue="styling" className="w-full">
                        <TabsList className="grid w-full grid-cols-1">
                            <TabsTrigger value="styling">Styling</TabsTrigger>
                        </TabsList>
                        <TabsContent value="styling" className="pt-4 max-h-[450px] overflow-y-auto pr-2"><Accordion type="multiple" className="w-full space-y-2">{block.type === 'accordion-item' ? <div className="p-4"><Label>Title</Label><Input value={block.settings?.title || ''} onChange={e => handleSettingsChange('title', e.target.value)} /></div> : structureStyling}</Accordion></TabsContent>
                    </Tabs>
                </PopoverContent>
            )
        }

        if (block.type === 'sidebar') {
             return (
                <PopoverContent className="w-96">
                    <div className="space-y-4">
                        <h4 className="font-medium leading-none">Sidebar Settings</h4>
                        <p className="text-sm text-muted-foreground">Customize the options for this block.</p>
                        <Tabs defaultValue="content" className="w-full">
                            <TabsList className="grid w-full grid-cols-2">
                                <TabsTrigger value="content">Content</TabsTrigger>
                                <TabsTrigger value="styling">Styling</TabsTrigger>
                            </TabsList>
                            <TabsContent value="content" className="pt-4 max-h-[450px] overflow-y-auto pr-2 space-y-4">
                                <h4 className="font-medium">Widgets</h4>
                                <div className="space-y-2">
                                    {availableWidgets.map(widget => (
                                        <div key={widget} className="flex items-center space-x-2">
                                            <Checkbox
                                                id={`widget-${widget.replace(/\s+/g, '-')}`}
                                                checked={(block.settings?.widgets || []).includes(widget)}
                                                onCheckedChange={() => handleWidgetToggle(widget)}
                                            />
                                            <Label htmlFor={`widget-${widget.replace(/\s+/g, '-')}`} className="font-normal">
                                                {widget}
                                            </Label>
                                        </div>
                                    ))}
                                </div>
                            </TabsContent>
                            <TabsContent value="styling" className="pt-4 max-h-[450px] overflow-y-auto pr-2 space-y-4">
                                <p className="text-sm text-muted-foreground">Styling options for the sidebar container.</p>
                                <ColorPicker label="Background Color" color={block.styles?.backgroundColor || ''} onChange={(c) => handleStyleChange('backgroundColor', c)} />
                                <div className="space-y-2">
                                    <Label>Padding (px)</Label>
                                    <Input type="number" value={block.styles?.paddingTop || 16} onChange={(e) => {
                                        handleStyleChange('paddingTop', parseInt(e.target.value));
                                        handleStyleChange('paddingBottom', parseInt(e.target.value));
                                        handleStyleChange('paddingLeft', parseInt(e.target.value));
                                        handleStyleChange('paddingRight', parseInt(e.target.value));
                                    }} />
                                </div>
                            </TabsContent>
                        </Tabs>
                    </div>
                </PopoverContent>
            );
        }

        if(blockInfo[block.type]?.category === 'Digiotic Blocks') {
            return (
                <PopoverContent className="w-96">
                    <Tabs defaultValue="content" className="w-full">
                        <TabsList className="grid w-full grid-cols-2">
                            <TabsTrigger value="content">Content</TabsTrigger>
                            <TabsTrigger value="styling">Styling</TabsTrigger>
                        </TabsList>
                        {contentTab(digioticBlocksContent[block.type] || <p>No settings.</p>)}
                        {stylingTab(cardStyling)}
                    </Tabs>
                </PopoverContent>
            )
        }
        
        if(blockInfo[block.type]?.category === 'Grids') {
            return (
                 <PopoverContent className="w-96">
                     <Tabs defaultValue="content" className="w-full"><TabsList className="grid w-full grid-cols-2"><TabsTrigger value="content">Content</TabsTrigger><TabsTrigger value="styling">Styling</TabsTrigger></TabsList>{contentTab(gridSettings)}{stylingTab(cardStyling)}</Tabs>
                 </PopoverContent>
            );
        }
        
         if(blockInfo[block.type]?.category === 'List-Based') {
            return (
                 <PopoverContent className="w-96">
                     <Tabs defaultValue="content" className="w-full"><TabsList className="grid w-full grid-cols-2"><TabsTrigger value="content">Content</TabsTrigger><TabsTrigger value="styling">Styling</TabsTrigger></TabsList>{contentTab(listSettings)}{stylingTab(cardStyling)}</Tabs>
                 </PopoverContent>
            );
        }

        return (
             <PopoverContent className="w-96">
                 <div className="space-y-4">
                     <h4 className="font-medium leading-none">{blockInfo[block.type]?.name} Settings</h4>
                     <p className="text-sm text-muted-foreground">
                       Customize the options for this block.
                     </p>
                    <Tabs defaultValue="content" className="w-full"><TabsList className="grid w-full grid-cols-2"><TabsTrigger value="content">Content</TabsTrigger><TabsTrigger value="styling">Styling</TabsTrigger></TabsList>{contentTab(commonPostSettings)}{stylingTab(cardStyling)}</Tabs>
                </div>
            </PopoverContent>
        )
    }

    if(block.type === 'accordion-item') {
        return (
             <div className="flex w-full items-center gap-2" ref={setNodeRef} {...attributes}>
                <div className="flex flex-1 items-center gap-2">
                    <button {...listeners} className="cursor-grab p-1.5 -ml-1.5 rounded hover:bg-muted">
                        <GripVertical className="h-5 w-5" />
                    </button>
                    <AccordionTrigger className="p-0 hover:no-underline flex-1 text-left">
                        <Input
                          value={block.settings?.title || 'Accordion Item'}
                          onChange={(e) => handleSettingsChange('title', e.target.value)}
                          className="font-medium text-sm border-none p-0 h-auto focus-visible:ring-0"
                        />
                    </AccordionTrigger>
                 </div>
                 <Button variant="ghost" size="icon" onClick={() => onRemove(block.id)}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
            </div>
        )
    }

    return (
        <div ref={setNodeRef} style={style} {...attributes} className={cn("p-3 bg-background border rounded-lg shadow-sm", blockMeta.isContainer && 'p-4')}>
             <div className="flex items-center gap-2">
                <button {...listeners} className="cursor-grab p-1.5 -ml-1.5 rounded hover:bg-muted">
                    <GripVertical className="h-5 w-5" />
                </button>
                <div className="flex-1">
                    <p className="font-semibold">{blockMeta.name}</p>
                    {renderBlockContent()}
                </div>
                <div className="flex items-center gap-1">
                     <Popover>
                        <PopoverTrigger asChild>
                           <Button variant="ghost" size="icon"><Settings className="h-4 w-4" /></Button>
                        </PopoverTrigger>
                         {renderSettings()}
                     </Popover>
                    <Button variant="ghost" size="icon" onClick={() => onRemove(block.id)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                </div>
             </div>
        </div>
    )
}

const AddBlockPanel = ({ onAddBlock }: { onAddBlock: (type: BlockType, parentId: string | null) => void}) => {
    
    const blockGroups = useMemo(() => {
        const groups: Record<string, any[]> = {
            'Digiotic Blocks': [],
            'Grids': [],
            'List-Based': [],
            'Structure': [],
            'Utility': [],
        };
        Object.entries(blockInfo).forEach(([type, info]) => {
            const category = info.category || 'Utility';
            if (groups[category]) {
                groups[category].push({ type, ...info });
            }
        });
        return groups;
    }, []);

    return (
        <Card>
            <CardHeader>
                <CardTitle>Add Blocks</CardTitle>
                <CardDescription>Click to add a new block to your layout.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
                 <Accordion type="multiple" defaultValue={Object.keys(blockGroups).map(k => k.toLowerCase())} className="w-full">
                    {Object.entries(blockGroups).map(([groupName, blocks]) => (
                        blocks.length > 0 &&
                        <AccordionItem key={groupName} value={groupName.toLowerCase()}>
                            <AccordionTrigger className="text-base font-semibold">{groupName}</AccordionTrigger>
                            <AccordionContent className="pt-2 space-y-2">
                                {blocks.map(({ type, name, description }) => (
                                    <Button 
                                        key={type} 
                                        variant="outline" 
                                        className="w-full justify-start h-auto p-3" 
                                        onClick={() => onAddBlock(type as BlockType, null)}
                                    >
                                        <PlusCircle className="mr-3 h-5 w-5" />
                                        <div className="text-left">
                                            <p className="font-semibold">{name}</p>
                                            <p className="text-xs text-muted-foreground font-normal">{description}</p>
                                        </div>
                                    </Button>
                                ))}
                            </AccordionContent>
                        </AccordionItem>
                    ))}
                </Accordion>
            </CardContent>
        </Card>
    );
}

export default function HomepageDesignerPage() {
    const [blocks, setBlocks] = useState<Block[] | null>(null);
    const [activeBlock, setActiveBlock] = useState<Block | null>(null);
    const [allCategories, setAllCategories] = useState<Category[]>([]);
    const [allContent, setAllContent] = useState<Post[]>([]);
    const { toast } = useToast();
    
    useEffect(() => {
        const loadInitialData = async () => {
            const [layoutData, categoriesData, contentData] = await Promise.all([
                getHomepageLayout(),
                fetchCategories(),
                fetchAllContent(),
            ]);
            setBlocks(Array.isArray(layoutData) ? layoutData : []);
            setAllCategories(categoriesData);
            setAllContent(contentData.filter(c => c.status === 'published'));
        };
        loadInitialData();
    }, []);

    const sensors = useSensors(
        useSensor(PointerSensor),
        useSensor(KeyboardSensor, {
            coordinateGetter: sortableKeyboardCoordinates,
        })
    );
    
    const handleAddBlock = (type: BlockType, parentId: string | null) => {
        setBlocks(prev => {
            if (!prev) return [];
            return addBlockToContainer(prev, parentId, type)
        });
    };
    
    const handleRemoveBlock = (id: string) => {
        setBlocks(prev => prev ? removeBlock(prev, id) : []);
    };

    const handleUpdateBlock = (block: Block) => {
        setBlocks(prev => prev ? updateBlock(prev, block) : []);
    }
    
    const handleSaveLayout = () => {
        if (blocks) {
            updateHomepageLayout(blocks);
            toast({
                title: "Homepage Saved!",
                description: "Your new homepage layout is now live.",
            });
        }
    }

    const handleDragStart = (event: DragStartEvent) => {
        const { active } = event;
        const block = findBlock(blocks || [], active.id as string)
        if(block) {
            setActiveBlock(block);
        }
    }

    const handleDragEnd = (event: DragEndEvent) => {
        const { active, over } = event;
        setActiveBlock(null);
        
        if (!over || !blocks) return;

        const activeId = active.id;
        const overId = over.id;

        if (activeId === overId) return;

        setBlocks(prev => {
            if (!prev) return [];
            let newBlocks = JSON.parse(JSON.stringify(prev)); // Deep copy to avoid mutation issues
            
            const activeItem = findBlock(newBlocks, activeId as string);
            if (!activeItem) return prev;

            // Remove from old parent
            const sourceContainer = findContainer(newBlocks, activeId as string);
            if (sourceContainer && sourceContainer.children) {
                const itemIndex = sourceContainer.children.findIndex(b => b.id === activeId);
                if (itemIndex > -1) {
                    sourceContainer.children.splice(itemIndex, 1);
                }
            } else { // It's a root item
                const itemIndex = newBlocks.findIndex(b => b.id === activeId);
                if (itemIndex > -1) {
                     newBlocks.splice(itemIndex, 1);
                }
            }
            
            // Add to new parent/position
            const destBlock = findBlock(newBlocks, overId as string);
            if(destBlock && blockInfo[destBlock.type]?.isContainer && destBlock.children) {
                 // Dropped on a container, add to its children
                 destBlock.children.push(activeItem);
            } else {
                 // Dropped on another block, insert before or after
                 const destParent = findContainer(newBlocks, overId as string);
                 if (destParent && destParent.children) {
                    const overIndex = destParent.children.findIndex(b => b.id === overId);
                    if (overIndex > -1) {
                       destParent.children.splice(overIndex, 0, activeItem);
                    }
                 } else { // It's a root item
                      const overIndex = newBlocks.findIndex(b => b.id === overId);
                      if(overIndex > -1) {
                        newBlocks.splice(overIndex, 0, activeItem);
                      }
                 }
            }

            return newBlocks;
        });
    }

  if (blocks === null) {
      return <div>Loading homepage designer...</div>;
  }

  return (
    <main className="p-6">
      <div className="flex items-center justify-between pb-6">
        <h1 className="text-2xl font-semibold">Homepage Builder</h1>
        <div className="flex gap-2">
            <Button variant="outline" asChild>
                <Link href="/" target="_blank">
                    <Eye className="mr-2" />
                    View Page
                </Link>
            </Button>
            <Button onClick={handleSaveLayout}>Save &amp; Publish</Button>
        </div>
      </div>
        <DndContext
            sensors={sensors}
            collisionDetection={closestCenter}
            onDragStart={handleDragStart}
            onDragEnd={handleDragEnd}
        >
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
            <div className="lg:col-span-2">
                <Card className="min-h-[600px]">
                    <CardHeader>
                        <CardTitle>Homepage Layout</CardTitle>
                        <CardDescription>Drag and drop blocks to reorder your homepage.</CardDescription>
                    </CardHeader>
                    <CardContent>
                            <SortableContext
                                items={blocks.map(b => b.id)}
                                strategy={verticalListSortingStrategy}
                            >
                                <div className="space-y-4">
                                    {blocks.length > 0 ? blocks.map(block => (
                                        <HomepageBlock 
                                            key={block.id} 
                                            block={block}
                                            onRemove={handleRemoveBlock}
                                            onAddBlock={handleAddBlock}
                                            onUpdate={handleUpdateBlock}
                                            allCategories={allCategories}
                                            allContent={allContent}
                                            parentId={null}
                                        />
                                    )) : (
                                        <div className="text-center py-16 border-2 border-dashed rounded-lg">
                                            <p className="text-muted-foreground">Your homepage is empty.</p>
                                            <p className="text-muted-foreground">Add a block from the right panel to get started.</p>
                                        </div>
                                    )}
                                </div>
                            </SortableContext>
                    </CardContent>
                </Card>
            </div>
            <div className="lg:col-span-1 space-y-6">
                <AddBlockPanel onAddBlock={handleAddBlock} />
            </div>
        </div>
        <DragOverlay>
            {activeBlock ? <div className="p-3 bg-primary/20 border rounded-lg shadow-sm"><p className="font-semibold">{activeBlock.settings?.title || blockInfo[activeBlock.type]?.name}</p></div> : null}
        </DragOverlay>
        </DndContext>
    </main>
  );
}
