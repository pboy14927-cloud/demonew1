
'use client';

import React, { useState, useMemo, useEffect } from 'react';
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { getPages, getUsers, Post, User, updatePostStatus, deletePost } from "@/lib/data";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { MoreHorizontal, MessageSquare } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from '@/hooks/use-toast';
import { DataTablePagination } from '@/components/admin/data-table-pagination';

type PageWithSelectionAndAuthor = Post & { selected?: boolean; authorName?: string };

export default function AdminPagesPage() {
  const [allPages, setAllPages] = useState<PageWithSelectionAndAuthor[]>([]);
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState('');
  const [bulkAction, setBulkAction] = useState('');
  const [itemToDelete, setItemToDelete] = useState<string | null>(null);
  const { toast } = useToast();
  
  // Pagination State
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const fetchPages = async () => {
    const [pages, users] = await Promise.all([getPages(true), getUsers()]);
    setAllPages(pages.map(page => ({ ...page, selected: false })));
    setAllUsers(users);
  };
  
  useEffect(() => {
    fetchPages();
  }, []);

  const pagesWithAuthors = useMemo(() => {
    const userMap = new Map(allUsers.map(user => [user.id, user.name]));
    return allPages.map(page => ({
      ...page,
      authorName: userMap.get(page.authorId) || 'Unknown'
    }));
  }, [allPages, allUsers]);

  const filteredPages = useMemo(() => {
    return pagesWithAuthors
      .filter((page) => {
        if (statusFilter === "all") return page.status !== 'trash';
        return page.status === statusFilter;
      })
      .filter((page) => {
        const lowerCaseSearch = searchTerm.toLowerCase();
        return (
          page.title.toLowerCase().includes(lowerCaseSearch) ||
          (page.authorName && page.authorName.toLowerCase().includes(lowerCaseSearch))
        )
      });
  }, [pagesWithAuthors, statusFilter, searchTerm]);

  const paginatedPages = useMemo(() => {
      const startIndex = (page - 1) * pageSize;
      return filteredPages.slice(startIndex, startIndex + pageSize);
  }, [filteredPages, page, pageSize]);

  const totalPages = Math.ceil(filteredPages.length / pageSize);
  
  useEffect(() => {
    // Reset to page 1 when filters or search term changes
    setPage(1);
  }, [statusFilter, searchTerm, pageSize]);

  const statusCounts = useMemo(() => {
    const counts = { all: 0, published: 0, draft: 0, trash: 0 };
    for (const page of allPages) {
       if (page.isPage) {
        if(page.status !== 'trash') counts.all++;
        if (page.status in counts) {
          // @ts-ignore
          counts[page.status]++;
        }
      }
    }
    return counts;
  }, [allPages]);


  const handleStatusChange = async (status: 'published' | 'draft' | 'trash', pageIds: string[]) => {
     try {
        await Promise.all(pageIds.map(id => updatePostStatus(id, status)));
        toast({ title: "Pages updated" });
        fetchPages();
    } catch(e) {
        toast({ variant: 'destructive', title: "Error updating pages" });
    }
  };
  
   const handleDeletePermanently = async (pageIds: string[]) => {
    try {
        await Promise.all(pageIds.map(id => deletePost(id)));
        toast({ title: "Pages permanently deleted" });
        fetchPages();
    } catch(e) {
        toast({ variant: 'destructive', title: "Error deleting pages" });
    }
    setItemToDelete(null); // Close dialog
  };


  const applyBulkAction = () => {
    const selectedIds = allPages.filter(p => p.selected).map(p => p.id);
    if(selectedIds.length === 0 || !bulkAction) return;

    if(bulkAction === 'edit') {
        // In a real app, you might show a modal for bulk editing
        alert(`Editing pages: ${selectedIds.join(', ')}`);
    } else if (bulkAction === 'trash') {
        handleStatusChange('trash', selectedIds);
    } else if (bulkAction === 'delete_permanently') {
        setItemToDelete('bulk'); // Special key for bulk deletion confirmation
    } else if (bulkAction === 'restore') {
        handleStatusChange('draft', selectedIds);
    }
    setBulkAction('');
  };

  const toggleSelectAll = (checked: boolean) => {
     setAllPages(pages => pages.map(p => {
        if(paginatedPages.some(fp => fp.id === p.id)) {
            return {...p, selected: checked }
        }
        return p;
     }));
  }

  const toggleSelect = (pageId: string) => {
     setAllPages(pages => pages.map(p => p.id === pageId ? { ...p, selected: !p.selected } : p));
  }
  
  const confirmBulkDelete = () => {
      const selectedIds = allPages.filter(p => p.selected).map(p => p.id);
      handleDeletePermanently(selectedIds);
  }

  const selectedCount = paginatedPages.filter(p => p.selected).length;
  const isAllSelected = selectedCount > 0 && selectedCount === paginatedPages.length;
  const isIndeterminate = selectedCount > 0 && selectedCount < paginatedPages.length;


  return (
    <>
      <main className="p-6">
        <div className='flex items-center justify-between pb-4'>
            <h1 className="text-2xl font-semibold">Pages</h1>
            <Button asChild>
                <Link href="/admin/pages/new">Add New</Link>
            </Button>
        </div>
        <div className="flex items-center space-x-2 pb-4">
            <button onClick={() => setStatusFilter('all')} className={`px-3 py-1 text-sm ${statusFilter === 'all' ? 'border-b-2 border-primary text-primary' : 'text-muted-foreground'}`}>
                All ({statusCounts.all})
            </button>
            <button onClick={() => setStatusFilter('published')} className={`px-3 py-1 text-sm ${statusFilter === 'published' ? 'border-b-2 border-primary text-primary' : 'text-muted-foreground'}`}>
                Published ({statusCounts.published})
            </button>
            <button onClick={() => setStatusFilter('draft')} className={`px-3 py-1 text-sm ${statusFilter === 'draft' ? 'border-b-2 border-primary text-primary' : 'text-muted-foreground'}`}>
                Draft ({statusCounts.draft})
            </button>
             <button onClick={() => setStatusFilter('trash')} className={`px-3 py-1 text-sm ${statusFilter === 'trash' ? 'border-b-2 border-primary text-primary' : 'text-muted-foreground'}`}>
                Trash ({statusCounts.trash})
            </button>
        </div>
        <div className="flex items-center justify-between pb-4">
            <div className="flex items-center space-x-2">
                 <Select value={bulkAction} onValueChange={setBulkAction}>
                    <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Bulk actions" />
                    </SelectTrigger>
                    <SelectContent>
                       {statusFilter === 'trash' ? (
                          <>
                            <SelectItem value="restore">Restore</SelectItem>
                            <SelectItem value="delete_permanently">Delete Permanently</SelectItem>
                          </>
                        ) : (
                          <>
                            <SelectItem value="edit">Edit</SelectItem>
                            <SelectItem value="trash">Move to Trash</SelectItem>
                          </>
                        )}
                    </SelectContent>
                </Select>
                <Button variant="secondary" onClick={applyBulkAction}>Apply</Button>
            </div>
            <div className="w-full max-w-sm">
                <Input 
                    placeholder="Search pages..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>
        </div>

        <DataTablePagination
            currentPage={page}
            totalPages={totalPages}
            onPageChange={setPage}
            pageSize={pageSize}
            onPageSizeChange={setPageSize}
            itemCount={filteredPages.length}
        />

        <div className="border rounded-lg mt-4">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[40px]">
                   <Checkbox 
                        checked={isAllSelected}
                        onCheckedChange={(checked) => toggleSelectAll(Boolean(checked))}
                        aria-label="Select all"
                        data-state={isIndeterminate ? 'indeterminate' : (isAllSelected ? 'checked' : 'unchecked')}
                    />
                </TableHead>
                <TableHead>Title</TableHead>
                <TableHead>Author</TableHead>
                <TableHead>Comments</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>
                  <span className="sr-only">Actions</span>
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginatedPages.map((page) => {
                const authorName = page.authorName || 'Unknown';
                const pageDate = new Date(page.createdAt).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric',
                });
                return (
                  <TableRow key={page.id} data-state={page.selected ? "selected" : "deselected"} className="group">
                    <TableCell>
                        <Checkbox 
                            checked={!!page.selected}
                            onCheckedChange={() => toggleSelect(page.id)}
                            aria-label={`Select page "${page.title}"`}
                        />
                    </TableCell>
                    <TableCell className="font-medium">
                        <Link href={`/admin/pages/edit/${page.id}`} className="hover:text-primary">{page.title}</Link>
                         {page.status !== 'published' && <span className="text-muted-foreground text-xs"> &mdash; {page.status.charAt(0).toUpperCase() + page.status.slice(1)}</span>}
                         <div className="text-xs text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity">
                            {page.status === 'trash' ? (
                                <>
                                  <button onClick={() => handleStatusChange('draft', [page.id])} className="text-primary hover:underline">Restore</button> | 
                                  <button onClick={() => setItemToDelete(page.id)} className="text-destructive hover:underline px-1">Delete Permanently</button>
                                </>
                            ) : (
                                <>
                                  <Link href={`/admin/pages/edit/${page.id}`} className="text-primary hover:underline">Edit</Link> | 
                                  <button onClick={() => handleStatusChange('trash', [page.id])} className="text-destructive hover:underline px-1">Trash</button> | 
                                  <Link href={`/${page.slug}`} target="_blank" className="hover:underline px-1">View</Link>
                                </>
                            )}
                         </div>
                    </TableCell>
                    <TableCell>{authorName}</TableCell>
                    <TableCell>
                        <Link href="#" className="flex items-center gap-1 text-primary hover:underline">
                            <MessageSquare className="h-4 w-4" />
                            0
                        </Link>
                    </TableCell>
                    <TableCell>{pageDate}</TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button aria-haspopup="true" size="icon" variant="ghost">
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">Toggle menu</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                           <DropdownMenuItem asChild><Link href={`/admin/pages/edit/${page.id}`}>Edit</Link></DropdownMenuItem>
                           <DropdownMenuItem asChild><Link href={`/${page.slug}`} target="_blank">View</Link></DropdownMenuItem>
                           <DropdownMenuSeparator />
                           {page.status !== 'trash' ? (
                            <DropdownMenuItem className="text-destructive" onClick={() => handleStatusChange('trash', [page.id])}>
                                Move to Trash
                            </DropdownMenuItem>
                           ) : (
                            <>
                              <DropdownMenuItem onClick={() => handleStatusChange('draft', [page.id])}>
                                  Restore
                              </DropdownMenuItem>
                              <DropdownMenuItem className="text-destructive" onClick={() => setItemToDelete(page.id)}>
                                  Delete Permanently
                              </DropdownMenuItem>
                            </>
                           )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
        <DataTablePagination
            currentPage={page}
            totalPages={totalPages}
            onPageChange={setPage}
            pageSize={pageSize}
            onPageSizeChange={setPageSize}
            itemCount={filteredPages.length}
        />
      </main>
      <AlertDialog open={itemToDelete !== null} onOpenChange={(open) => !open && setItemToDelete(null)}>
          <AlertDialogContent>
              <AlertDialogHeader>
              <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
              <AlertDialogDescription>
                  This action cannot be undone. This will permanently delete the page(s) and remove the data from our servers.
              </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
              <AlertDialogCancel onClick={() => setItemToDelete(null)}>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={() => {
                  if (itemToDelete === 'bulk') {
                      confirmBulkDelete();
                  } else if (itemToDelete) {
                      handleDeletePermanently([itemToDelete]);
                  }
              }}>
                  Delete
              </AlertDialogAction>
              </AlertDialogFooter>
          </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

    