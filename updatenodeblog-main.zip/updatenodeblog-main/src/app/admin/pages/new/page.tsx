

'use server';

import ContentEditor from "@/components/editor/content-editor";
import { getAllUsers } from "@/lib/data";

export default async function NewPage() {
  const allUsers = await getAllUsers();

  return (
    <ContentEditor 
      title="Add New Page"
      allUsers={allUsers}
      allPages={[]} // Optimize: Pass an empty array initially.
    />
  );
}
