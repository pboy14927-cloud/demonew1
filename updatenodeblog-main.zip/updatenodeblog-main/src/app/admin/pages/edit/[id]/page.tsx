

'use server';

import ContentEditor from "@/components/editor/content-editor";
import { getAllContent, getAllUsers } from "@/lib/data";
import { notFound } from "next/navigation";

type EditPageProps = {
    params: {
        id: string;
    }
}

export default async function EditPage({ params }: EditPageProps) {
  const allContent = await getAllContent();
  const page = allContent.find(p => p.id === params.id && p.isPage);

  if (!page) {
    notFound();
  }

  // Optimize: No longer pass allPages to the editor.
  // The editor will handle fetching parent pages if needed.
  const allUsers = await getAllUsers();
  
  return (
    <ContentEditor 
        post={page} 
        title="Edit Page"
        allUsers={allUsers}
        allPages={[]} 
    />
  );
}
