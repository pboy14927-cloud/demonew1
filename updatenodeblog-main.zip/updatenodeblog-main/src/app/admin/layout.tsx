
import AdminHeader from "@/app/admin/admin-header";
import AdminSidebar from "@/components/admin/admin-sidebar";
import { SidebarProvider } from "@/components/ui/sidebar";
import { getSettings } from "@/lib/data";
import type { Metadata } from 'next';

export async function generateMetadata(): Promise<Metadata> {
  const settings = await getSettings();
  const siteTitle = settings.siteTitle || 'Digiotic';

  return {
    title: {
      default: `Dashboard - ${siteTitle}`,
      template: `%s - ${siteTitle}`,
    },
  };
}


export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <SidebarProvider>
        <div className="flex flex-col flex-1 h-screen overflow-y-hidden">
            <AdminHeader />
            <div className="flex flex-1 overflow-y-hidden">
                <AdminSidebar />
                <main className="flex-1 overflow-y-auto">
                    {children}
                </main>
            </div>
        </div>
    </SidebarProvider>
  );
}
