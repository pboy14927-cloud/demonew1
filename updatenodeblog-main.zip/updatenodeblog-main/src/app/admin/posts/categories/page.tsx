
'use client';

import React, { useState, useMemo, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { getCategories, getPosts, deleteCategory, Category, createCategory } from '@/lib/data';
import Link from 'next/link';
import { useToast } from '@/hooks/use-toast';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';

export default function CategoriesPage() {
    const [categories, setCategories] = useState<Category[]>([]);
    const [posts, setPosts] = useState<any[]>([]);
    const [name, setName] = useState('');
    const [slug, setSlug] = useState('');
    const [parent, setParent] = useState('none');
    const [description, setDescription] = useState('');
    const { toast } = useToast();
    const [itemToDelete, setItemToDelete] = useState<Category | null>(null);

    const fetchAndSetCategories = async () => {
        const fetchedCategories = await getCategories();
        setCategories(fetchedCategories);
    };

    useEffect(() => {
        const fetchData = async () => {
            await fetchAndSetCategories();
            setPosts(await getPosts());
        }
        fetchData();
    }, []);

    const handleAddCategory = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!name) return;
        try {
             const response = await fetch('/api/categories', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    name,
                    slug,
                    description,
                    parent: parent === 'none' ? null : parent,
                }),
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || 'Failed to create category');
            }
            
            setName('');
            setSlug('');
            setParent('none');
            setDescription('');
            await fetchAndSetCategories();
            toast({ title: 'Category created' });
        } catch (error: any) {
            toast({ variant: 'destructive', title: 'Error creating category', description: error.message });
        }
    };

    const handleDeleteCategory = async () => {
        if (!itemToDelete) return;
        try {
            await deleteCategory(itemToDelete.id);
            await fetchAndSetCategories();
            toast({ title: 'Category deleted' });
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error deleting category' });
        } finally {
            setItemToDelete(null);
        }
    }

    const categoryCounts = useMemo(() => {
        const counts: { [key: string]: number } = {};
        for (const post of posts) {
            for (const categoryName of post.categories) {
                counts[categoryName] = (counts[categoryName] || 0) + 1;
            }
        }
        return counts;
    }, [posts]);


    return (
        <AlertDialog onOpenChange={(open) => !open && setItemToDelete(null)}>
            <main className="p-6">
                <h1 className="text-2xl font-semibold mb-6">Categories</h1>
                <div className="grid gap-6 md:grid-cols-12">
                    <div className="md:col-span-4">
                        <Card>
                            <CardHeader>
                                <CardTitle className="text-lg">Add New Category</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <form onSubmit={handleAddCategory} className="space-y-4">
                                    <div className="space-y-2">
                                        <Label htmlFor="name">Name</Label>
                                        <Input id="name" value={name} onChange={e => setName(e.target.value)} required />
                                        <p className="text-xs text-muted-foreground">The name is how it appears on your site.</p>
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="slug">Slug</Label>
                                        <Input id="slug" value={slug} onChange={e => setSlug(e.target.value)} />
                                        <p className="text-xs text-muted-foreground">The “slug” is the URL-friendly version of the name. It is usually all lower-case and contains only letters, numbers, and hyphens.</p>
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="parent">Parent Category</Label>
                                        <Select value={parent} onValueChange={setParent}>
                                            <SelectTrigger id="parent">
                                                <SelectValue placeholder="None" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="none">None</SelectItem>
                                                {categories.filter(c => !c.parent).map(c => (
                                                    <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                        <p className="text-xs text-muted-foreground">Categories, unlike tags, can have a hierarchy. You might have a Jazz category, and under that have children categories for Bebop and Big Band. Totally optional.</p>
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="description">Description</Label>
                                        <Textarea id="description" value={description} onChange={e => setDescription(e.target.value)} />
                                        <p className="text-xs text-muted-foreground">The description is not prominent by default; however, some themes may show it.</p>
                                    </div>
                                    <Button type="submit">Add New Category</Button>
                                </form>
                            </CardContent>
                        </Card>
                    </div>
                    <div className="md:col-span-8">
                        <div className="border rounded-lg">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Name</TableHead>
                                        <TableHead>Description</TableHead>
                                        <TableHead>Slug</TableHead>
                                        <TableHead>Count</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {categories.map(category => (
                                        <TableRow key={category.id} className="group">
                                            <TableCell className="font-medium">
                                                <Link href={`/admin/posts/categories/edit/${category.id}`} className="text-primary hover:underline">{category.name}</Link>
                                                <div className="text-xs text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity space-x-1">
                                                    <Link href={`/admin/posts/categories/edit/${category.id}`} className="text-primary hover:underline">Edit</Link> | 
                                                    <AlertDialogTrigger asChild>
                                                        <button onClick={() => setItemToDelete(category)} className="text-destructive hover:underline px-1">Delete</button>
                                                    </AlertDialogTrigger> | 
                                                    <Link href={`/category/${category.slug}`} target="_blank" className="hover:underline px-1">View</Link>
                                                </div>
                                            </TableCell>
                                            <TableCell>{category.description || '—'}</TableCell>
                                            <TableCell>{category.slug}</TableCell>
                                            <TableCell>
                                                <Link href="#" className="text-primary hover:underline">{categoryCounts[category.name] || 0}</Link>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </div>
                    </div>
                </div>
                {itemToDelete && (
                    <AlertDialogContent>
                        <AlertDialogHeader>
                            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                            <AlertDialogDescription>
                                This action cannot be undone. This will permanently delete the "{itemToDelete?.name}" category.
                            </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={handleDeleteCategory}>Delete</AlertDialogAction>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                )}
            </main>
        </AlertDialog>
    );
}

