
'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { getCategories, getCategoryById, updateCategory, Category } from '@/lib/data';
import { useToast } from '@/hooks/use-toast';
import { useParams, useRouter } from 'next/navigation';
import { ArrowLeft } from 'lucide-react';
import Link from 'next/link';

export default function EditCategoryPage() {
    const params = useParams();
    const router = useRouter();
    const id = params.id as string;

    const [category, setCategory] = useState<Category | null>(null);
    const [allCategories, setAllCategories] = useState<Category[]>([]);
    const { toast } = useToast();

    const fetchCategoryData = useCallback(async () => {
        const [cat, allCats] = await Promise.all([
            getCategoryById(id),
            getCategories()
        ]);
        if(cat) {
            setCategory(cat);
            setAllCategories(allCats.filter(c => c.id !== cat.id)); // Exclude self from parent list
        }
    }, [id]);

    useEffect(() => {
        fetchCategoryData();
    }, [fetchCategoryData]);

    const handleInputChange = (field: keyof Category, value: string) => {
        setCategory(prev => prev ? { ...prev, [field]: value } : null);
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!category) return;
        try {
            await updateCategory(id, {
                name: category.name,
                slug: category.slug,
                description: category.description,
                parent: category.parent === 'none' ? undefined : category.parent,
            });
            toast({ title: 'Category updated successfully!' });
            router.push('/admin/posts/categories');
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error updating category' });
        }
    };

    if (!category) {
        return <div>Loading...</div>;
    }

    return (
        <main className="p-6">
            <div className="mb-6">
                <Button asChild variant="outline" size="sm">
                    <Link href="/admin/posts/categories">
                        <ArrowLeft className="mr-2 h-4 w-4" />
                        Back to Categories
                    </Link>
                </Button>
            </div>
            <h1 className="text-2xl font-semibold mb-6">Edit Category</h1>
            <div className="grid gap-6 md:grid-cols-2">
                <Card>
                    <CardHeader>
                        <CardTitle className="text-lg">{category.name}</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div className="space-y-2">
                                <Label htmlFor="name">Name</Label>
                                <Input id="name" value={category.name} onChange={e => handleInputChange('name', e.target.value)} required />
                                <p className="text-xs text-muted-foreground">The name is how it appears on your site.</p>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="slug">Slug</Label>
                                <Input id="slug" value={category.slug} onChange={e => handleInputChange('slug', e.target.value)} />
                                <p className="text-xs text-muted-foreground">The “slug” is the URL-friendly version of the name. It is usually all lower-case and contains only letters, numbers, and hyphens.</p>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="parent">Parent Category</Label>
                                <Select value={category.parent || 'none'} onValueChange={(value) => handleInputChange('parent', value)}>
                                    <SelectTrigger id="parent">
                                        <SelectValue placeholder="None" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="none">None</SelectItem>
                                        {allCategories.map(c => (
                                            <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                                <p className="text-xs text-muted-foreground">Categories, unlike tags, can have a hierarchy.</p>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="description">Description</Label>
                                <Textarea id="description" value={category.description || ''} onChange={e => handleInputChange('description', e.target.value)} />
                                <p className="text-xs text-muted-foreground">The description is not prominent by default; however, some themes may show it.</p>
                            </div>
                            <Button type="submit">Update Category</Button>
                        </form>
                    </CardContent>
                </Card>
            </div>
        </main>
    );
}

