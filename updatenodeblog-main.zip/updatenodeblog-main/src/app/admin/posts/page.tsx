
'use client';

import React, { useState, useMemo, useEffect } from 'react';
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { getPosts, getUsers, Post, User, updatePostStatus, deletePost } from "@/lib/data";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { MoreHorizontal, MessageSquare } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from '@/hooks/use-toast';
import { DataTablePagination } from '@/components/admin/data-table-pagination';


type PostWithSelectionAndAuthor = Post & { selected?: boolean, authorName?: string };

export default function AdminPostsPage() {
  const [allPosts, setAllPosts] = useState<PostWithSelectionAndAuthor[]>([]);
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState('');
  const [bulkAction, setBulkAction] = useState('');
  const [itemToDelete, setItemToDelete] = useState<string | null>(null);
  const { toast } = useToast();
  
  // Pagination State
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);


  const fetchData = async () => {
    try {
      const [posts, users] = await Promise.all([getPosts(true), getUsers()]);
      setAllPosts(posts.map(post => ({ ...post, selected: false })));
      setAllUsers(users);
    } catch (error) {
      console.error("Failed to fetch data:", error);
      toast({ variant: 'destructive', title: 'Error fetching data' });
    }
  };
  
  useEffect(() => {
    fetchData();
  }, []);

  const postsWithAuthors = useMemo(() => {
    const userMap = new Map(allUsers.map(user => [user.id, user.name]));
    return allPosts.map(post => ({
        ...post,
        authorName: userMap.get(post.authorId) || 'Unknown'
    }));
  }, [allPosts, allUsers]);

  const filteredPosts = useMemo(() => {
    return postsWithAuthors
      .filter((post) => {
        if (statusFilter === "all") return post.status !== 'trash';
        return post.status === statusFilter;
      })
      .filter((post) => {
        const lowerCaseSearch = searchTerm.toLowerCase();
        return (
          post.title.toLowerCase().includes(lowerCaseSearch) ||
          (post.authorName && post.authorName.toLowerCase().includes(lowerCaseSearch))
        )
      });
  }, [postsWithAuthors, statusFilter, searchTerm]);
  
  const paginatedPosts = useMemo(() => {
      const startIndex = (page - 1) * pageSize;
      return filteredPosts.slice(startIndex, startIndex + pageSize);
  }, [filteredPosts, page, pageSize]);

  const totalPages = Math.ceil(filteredPosts.length / pageSize);

  useEffect(() => {
    // Reset to page 1 when filters or search term changes
    setPage(1);
  }, [statusFilter, searchTerm, pageSize]);


  const statusCounts = useMemo(() => {
    const counts = { all: 0, published: 0, draft: 0, trash: 0 };
    for (const post of allPosts) {
      if(post.status !== 'trash') counts.all++;
      if (post.status in counts) {
        // @ts-ignore
        counts[post.status]++;
      }
    }
    return counts;
  }, [allPosts]);


  const handleStatusChange = async (status: 'published' | 'draft' | 'trash', postIds: string[]) => {
    try {
        await Promise.all(postIds.map(id => updatePostStatus(id, status)));
        toast({ title: "Posts updated" });
        fetchData();
    } catch(e) {
        toast({ variant: 'destructive', title: "Error updating posts" });
    }
  };
  
  const handleDeletePermanently = async (postIds: string[]) => {
    try {
        await Promise.all(postIds.map(id => deletePost(id)));
        toast({ title: "Posts permanently deleted" });
        fetchData();
    } catch(e) {
        toast({ variant: 'destructive', title: "Error deleting posts" });
    }
    setItemToDelete(null); // Close dialog
  };
  
  const applyBulkAction = () => {
    const selectedIds = allPosts.filter(p => p.selected).map(p => p.id);
    if(selectedIds.length === 0 || !bulkAction) return;

    if(bulkAction === 'edit') {
        // In a real app, you might show a modal for bulk editing or redirect
        alert(`Bulk editing is not implemented yet. Selected IDs: ${selectedIds.join(', ')}`);
    } else if (bulkAction === 'trash') {
        handleStatusChange('trash', selectedIds);
    } else if (bulkAction === 'delete_permanently') {
        setItemToDelete('bulk'); // Special key for bulk deletion confirmation
    } else if (bulkAction === 'restore') {
        handleStatusChange('draft', selectedIds);
    }

    setBulkAction('');
  };

  const confirmBulkDelete = () => {
      const selectedIds = allPosts.filter(p => p.selected).map(p => p.id);
      handleDeletePermanently(selectedIds);
  }


  const toggleSelectAll = (checked: boolean) => {
     setAllPosts(posts => posts.map(p => {
        if(paginatedPosts.some(fp => fp.id === p.id)) {
            return {...p, selected: checked }
        }
        return p;
     }));
  }

  const toggleSelect = (postId: string) => {
     setAllPosts(posts => posts.map(p => p.id === postId ? { ...p, selected: !p.selected } : p));
  }

  const selectedCount = paginatedPosts.filter(p => p.selected).length;
  const isAllSelected = selectedCount > 0 && selectedCount === paginatedPosts.length;
  const isIndeterminate = selectedCount > 0 && selectedCount < paginatedPosts.length;


  return (
    <>
      <main className="p-6">
        <div className='flex items-center justify-between pb-4'>
            <h1 className="text-2xl font-semibold">Posts</h1>
            <Button asChild>
                <Link href="/admin/posts/new">Add New</Link>
            </Button>
        </div>
        <div className="flex items-center space-x-2 pb-4">
            <button onClick={() => setStatusFilter('all')} className={`px-3 py-1 text-sm ${statusFilter === 'all' ? 'border-b-2 border-primary text-primary' : 'text-muted-foreground'}`}>
                All ({statusCounts.all})
            </button>
            <button onClick={() => setStatusFilter('published')} className={`px-3 py-1 text-sm ${statusFilter === 'published' ? 'border-b-2 border-primary text-primary' : 'text-muted-foreground'}`}>
                Published ({statusCounts.published})
            </button>
            <button onClick={() => setStatusFilter('draft')} className={`px-3 py-1 text-sm ${statusFilter === 'draft' ? 'border-b-2 border-primary text-primary' : 'text-muted-foreground'}`}>
                Draft ({statusCounts.draft})
            </button>
             <button onClick={() => setStatusFilter('trash')} className={`px-3 py-1 text-sm ${statusFilter === 'trash' ? 'border-b-2 border-primary text-primary' : 'text-muted-foreground'}`}>
                Trash ({statusCounts.trash})
            </button>
        </div>
        <div className="flex items-center justify-between pb-4">
            <div className="flex items-center space-x-2">
                 <Select value={bulkAction} onValueChange={setBulkAction}>
                    <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Bulk actions" />
                    </SelectTrigger>
                    <SelectContent>
                        {statusFilter === 'trash' ? (
                          <>
                            <SelectItem value="restore">Restore</SelectItem>
                            <SelectItem value="delete_permanently">Delete Permanently</SelectItem>
                          </>
                        ) : (
                          <>
                            <SelectItem value="edit">Edit</SelectItem>
                            <SelectItem value="trash">Move to Trash</SelectItem>
                          </>
                        )}
                    </SelectContent>
                </Select>
                <Button variant="secondary" onClick={applyBulkAction}>Apply</Button>
            </div>
            <div className="w-full max-w-sm">
                <Input 
                    placeholder="Search posts..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>
        </div>
         <DataTablePagination
          currentPage={page}
          totalPages={totalPages}
          onPageChange={setPage}
          pageSize={pageSize}
          onPageSizeChange={setPageSize}
          itemCount={filteredPosts.length}
        />

        <div className="border rounded-lg mt-4">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[40px]">
                   <Checkbox 
                        checked={isAllSelected} 
                        onCheckedChange={(checked) => toggleSelectAll(!!checked)}
                        aria-label="Select all"
                        data-state={isIndeterminate ? 'indeterminate' : (isAllSelected ? 'checked' : 'unchecked')}
                    />
                </TableHead>
                <TableHead>Title</TableHead>
                <TableHead>Author</TableHead>
                <TableHead>Categories</TableHead>
                <TableHead>Tags</TableHead>
                <TableHead>Comments</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>
                  <span className="sr-only">Actions</span>
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginatedPosts.map((post) => {
                const authorName = post.authorName || 'Unknown';
                const postDate = new Date(post.createdAt).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric',
                });
                return (
                  <TableRow key={post.id} data-state={post.selected ? "selected" : "deselected"} className="group">
                    <TableCell>
                        <Checkbox 
                            checked={!!post.selected}
                            onCheckedChange={() => toggleSelect(post.id)}
                            aria-label={`Select post "${post.title}"`}
                        />
                    </TableCell>
                    <TableCell className="font-medium">
                        <Link href={`/admin/posts/edit/${post.id}`} className="hover:text-primary">{post.title}</Link>
                         {post.status !== 'published' && <span className="text-muted-foreground text-xs"> &mdash; {post.status.charAt(0).toUpperCase() + post.status.slice(1)}</span>}
                         <div className="text-xs text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity">
                            {post.status === 'trash' ? (
                                <>
                                  <button onClick={() => handleStatusChange('draft', [post.id])} className="text-primary hover:underline">Restore</button> | 
                                  <button onClick={() => setItemToDelete(post.id)} className="text-destructive hover:underline px-1">Delete Permanently</button>
                                </>
                            ) : (
                                <>
                                    <Link href={`/admin/posts/edit/${post.id}`} className="text-primary hover:underline">Edit</Link> | 
                                    <button onClick={() => handleStatusChange('trash', [post.id])} className="text-destructive hover:underline px-1">Trash</button> | 
                                    <Link href={`/${post.slug}`} target="_blank" className="hover:underline px-1">View</Link>
                                </>
                            )}
                         </div>
                    </TableCell>
                    <TableCell>{authorName}</TableCell>
                     <TableCell>
                        {post.categories.map((category, index) => (
                          <React.Fragment key={category}>
                            <Link href="#" className="text-primary hover:underline">{category}</Link>
                            {index < post.categories.length - 1 && ', '}
                          </React.Fragment>
                        ))}
                    </TableCell>
                     <TableCell className="space-x-1">
                        {post.tags.map(tag => (
                            <Badge key={tag} variant="secondary">{tag}</Badge>
                        ))}
                    </TableCell>
                     <TableCell>
                        <Link href="#" className="flex items-center gap-1 text-primary hover:underline">
                            <MessageSquare className="h-4 w-4" />
                            0
                        </Link>
                    </TableCell>
                    <TableCell>{postDate}</TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button aria-haspopup="true" size="icon" variant="ghost">
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">Toggle menu</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                           <DropdownMenuItem asChild><Link href={`/admin/posts/edit/${post.id}`}>Edit</Link></DropdownMenuItem>
                           <DropdownMenuItem asChild><Link href={`/${post.slug}`} target="_blank">View</Link></DropdownMenuItem>
                           <DropdownMenuSeparator />
                           {post.status !== 'trash' ? (
                            <DropdownMenuItem className="text-destructive" onClick={() => handleStatusChange('trash', [post.id])}>
                                Move to Trash
                            </DropdownMenuItem>
                           ) : (
                            <>
                                <DropdownMenuItem onClick={() => handleStatusChange('draft', [post.id])}>
                                    Restore
                                </DropdownMenuItem>
                                <DropdownMenuItem className="text-destructive" onClick={() => setItemToDelete(post.id)}>
                                    Delete Permanently
                                </DropdownMenuItem>
                            </>
                           )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
        <DataTablePagination
          currentPage={page}
          totalPages={totalPages}
          onPageChange={setPage}
          pageSize={pageSize}
          onPageSizeChange={setPageSize}
          itemCount={filteredPosts.length}
        />
      </main>
      <AlertDialog open={itemToDelete !== null} onOpenChange={(open) => !open && setItemToDelete(null)}>
          <AlertDialogContent>
              <AlertDialogHeader>
              <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
              <AlertDialogDescription>
                  This action cannot be undone. This will permanently delete the post(s) and remove the data from our servers.
              </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
              <AlertDialogCancel onClick={() => setItemToDelete(null)}>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={() => {
                  if (itemToDelete === 'bulk') {
                      confirmBulkDelete();
                  } else if (itemToDelete) {
                      handleDeletePermanently([itemToDelete]);
                  }
              }}>
                  Delete
              </AlertDialogAction>
              </AlertDialogFooter>
          </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

    