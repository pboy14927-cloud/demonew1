
'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { getTagById, updateTag, Tag } from '@/lib/data';
import { useToast } from '@/hooks/use-toast';
import { useParams, useRouter } from 'next/navigation';
import { ArrowLeft } from 'lucide-react';
import Link from 'next/link';

export default function EditTagPage() {
    const params = useParams();
    const router = useRouter();
    const id = params.id as string;

    const [tag, setTag] = useState<Tag | null>(null);
    const { toast } = useToast();

    const fetchTagData = useCallback(async () => {
        const tagData = await getTagById(id);
        if (tagData) {
            setTag(tagData);
        }
    }, [id]);

    useEffect(() => {
        fetchTagData();
    }, [fetchTagData]);

    const handleInputChange = (field: keyof Tag, value: string) => {
        setTag(prev => prev ? { ...prev, [field]: value } : null);
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!tag) return;
        try {
            await updateTag(id, {
                name: tag.name,
                slug: tag.slug,
                description: tag.description,
            });
            toast({ title: 'Tag updated successfully!' });
            router.push('/admin/posts/tags');
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error updating tag' });
        }
    };

    if (!tag) {
        return <div>Loading...</div>;
    }

    return (
        <main className="p-6">
            <div className="mb-6">
                <Button asChild variant="outline" size="sm">
                    <Link href="/admin/posts/tags">
                        <ArrowLeft className="mr-2 h-4 w-4" />
                        Back to Tags
                    </Link>
                </Button>
            </div>
            <h1 className="text-2xl font-semibold mb-6">Edit Tag</h1>
            <div className="grid gap-6 md:grid-cols-2">
                <Card>
                    <CardHeader>
                        <CardTitle className="text-lg">{tag.name}</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div className="space-y-2">
                                <Label htmlFor="name">Name</Label>
                                <Input id="name" value={tag.name} onChange={e => handleInputChange('name', e.target.value)} required />
                                <p className="text-xs text-muted-foreground">The name is how it appears on your site.</p>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="slug">Slug</Label>
                                <Input id="slug" value={tag.slug} onChange={e => handleInputChange('slug', e.target.value)} />
                                <p className="text-xs text-muted-foreground">The “slug” is the URL-friendly version of the name. It is usually all lower-case and contains only letters, numbers, and hyphens.</p>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="description">Description</Label>
                                <Textarea id="description" value={tag.description || ''} onChange={e => handleInputChange('description', e.target.value)} />
                                <p className="text-xs text-muted-foreground">The description is not prominent by default; however, some themes may show it.</p>
                            </div>
                            <Button type="submit">Update Tag</Button>
                        </form>
                    </CardContent>
                </Card>
            </div>
        </main>
    );
}
