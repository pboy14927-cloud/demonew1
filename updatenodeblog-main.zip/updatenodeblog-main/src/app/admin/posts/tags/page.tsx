
'use client';

import React, { useState, useMemo, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { getTags, getPosts, Tag, createTag, deleteTag } from '@/lib/data';
import Link from 'next/link';
import { useToast } from '@/hooks/use-toast';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';


export default function TagsPage() {
    const [tags, setTags] = useState<Tag[]>([]);
    const [posts, setPosts] = useState<any[]>([]);
    const [name, setName] = useState('');
    const [slug, setSlug] = useState('');
    const [description, setDescription] = useState('');
    const { toast } = useToast();
    const [itemToDelete, setItemToDelete] = useState<Tag | null>(null);

    const fetchTags = async () => {
        setTags(await getTags());
    }

    useEffect(() => {
        const fetchData = async () => {
            await fetchTags();
            setPosts(await getPosts());
        }
        fetchData();
    }, []);

    const handleAddTag = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!name) return;
        try {
            await createTag({
                name,
                slug: slug,
                description,
            });
            setName('');
            setSlug('');
            setDescription('');
            await fetchTags();
            toast({ title: 'Tag created' });
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error creating tag' });
        }
    };
    
    const handleDeleteTag = async () => {
        if (!itemToDelete) return;
        try {
            await deleteTag(itemToDelete.id);
            await fetchTags();
            toast({ title: 'Tag deleted' });
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error deleting tag' });
        } finally {
            setItemToDelete(null);
        }
    };

    const tagCounts = useMemo(() => {
        const counts: { [key: string]: number } = {};
        posts.forEach(post => {
            post.tags.forEach((tagName: string) => {
                counts[tagName] = (counts[tagName] || 0) + 1;
            });
        });
        return counts;
    }, [posts]);


    return (
        <AlertDialog onOpenChange={(open) => !open && setItemToDelete(null)}>
            <main className="p-6">
                 <h1 className="text-2xl font-semibold mb-6">Tags</h1>
                <div className="grid gap-6 md:grid-cols-12">
                    <div className="md:col-span-4">
                        <Card>
                            <CardHeader>
                                <CardTitle className="text-lg">Add New Tag</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <form onSubmit={handleAddTag} className="space-y-4">
                                    <div className="space-y-2">
                                        <Label htmlFor="name">Name</Label>
                                        <Input id="name" value={name} onChange={e => setName(e.target.value)} required />
                                        <p className="text-xs text-muted-foreground">The name is how it appears on your site.</p>
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="slug">Slug</Label>
                                        <Input id="slug" value={slug} onChange={e => setSlug(e.target.value)} />
                                        <p className="text-xs text-muted-foreground">The “slug” is the URL-friendly version of the name. It is usually all lower-case and contains only letters, numbers, and hyphens.</p>
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="description">Description</Label>
                                        <Textarea id="description" value={description} onChange={e => setDescription(e.target.value)} />
                                        <p className="text-xs text-muted-foreground">The description is not prominent by default; however, some themes may show it.</p>
                                    </div>
                                    <Button type="submit">Add New Tag</Button>
                                </form>
                            </CardContent>
                        </Card>
                    </div>
                    <div className="md:col-span-8">
                        <div className="border rounded-lg">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Name</TableHead>
                                        <TableHead>Description</TableHead>
                                        <TableHead>Slug</TableHead>
                                        <TableHead>Count</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {tags.map(tag => (
                                        <TableRow key={tag.id} className="group">
                                            <TableCell className="font-medium">
                                                <Link href={`/admin/posts/tags/edit/${tag.id}`} className="text-primary hover:underline">{tag.name}</Link>
                                                <div className="text-xs text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity space-x-1">
                                                    <Link href={`/admin/posts/tags/edit/${tag.id}`} className="text-primary hover:underline">Edit</Link> | 
                                                    <AlertDialogTrigger asChild>
                                                        <button onClick={() => setItemToDelete(tag)} className="text-destructive hover:underline px-1">Delete</button>
                                                    </AlertDialogTrigger> | 
                                                    <Link href={`/tag/${tag.slug}`} target="_blank" className="hover:underline px-1">View</Link>
                                                </div>
                                            </TableCell>
                                            <TableCell>{tag.description || '—'}</TableCell>
                                            <TableCell>{tag.slug}</TableCell>
                                            <TableCell>
                                                <Link href="#" className="text-primary hover:underline">{tagCounts[tag.name] || 0}</Link>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </div>
                    </div>
                </div>
                 {itemToDelete && (
                    <AlertDialogContent>
                        <AlertDialogHeader>
                            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                            <AlertDialogDescription>
                                This action cannot be undone. This will permanently delete the "{itemToDelete?.name}" tag.
                            </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={handleDeleteTag}>Delete</AlertDialogAction>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                )}
            </main>
        </AlertDialog>
    );
}
