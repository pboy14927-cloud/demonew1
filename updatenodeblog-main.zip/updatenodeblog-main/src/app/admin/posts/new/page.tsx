
'use client';

import ContentEditor from "@/components/editor/content-editor";
import { getAllUsers, User } from "@/lib/data";
import { useSession } from "next-auth/react";
import { useState, useEffect } from "react";
import { Skeleton } from "@/components/ui/skeleton";

export default function NewPostPage() {
  const { data: session, status } = useSession();
  const [allUsers, setAllUsers] = useState<User[]>([]);

  useEffect(() => {
    async function fetchUsers() {
      const users = await getAllUsers();
      setAllUsers(users);
    }
    fetchUsers();
  }, []);

  if (status === 'loading' || allUsers.length === 0) {
    return (
        <div className="p-6">
            <h1 className="text-2xl font-semibold mb-6">Add New Post</h1>
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                <div className="lg:col-span-9 space-y-6">
                    <Skeleton className="h-24" />
                    <Skeleton className="h-[400px]" />
                </div>
                <div className="lg:col-span-3 space-y-6">
                    <Skeleton className="h-48" />
                    <Skeleton className="h-32" />
                    <Skeleton className="h-48" />
                </div>
            </div>
        </div>
    );
  }
  
  const currentUserId = (session?.user as any)?.id;

  return (
    <ContentEditor 
        title="Add New Post"
        allUsers={allUsers}
        allPages={[]}
        authorId={currentUserId}
    />
  );
}
