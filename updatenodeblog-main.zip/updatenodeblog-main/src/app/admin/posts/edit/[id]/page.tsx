

'use server';
import ContentEditor from "@/components/editor/content-editor";
import { getPosts, getAllUsers } from "@/lib/data";
import { notFound } from "next/navigation";

type EditPostProps = {
    params: {
        id: string;
    }
}

export default async function EditPost({ params }: EditPostProps) {
  const posts = await getPosts();
  const post = posts.find(p => p.id === params.id);

  if (!post) {
    notFound();
  }

  const allUsers = await getAllUsers();

  return (
    <ContentEditor 
        post={post} 
        title="Edit Post"
        allUsers={allUsers}
        allPages={[]} // Optimize: Pass an empty array initially.
    />
  );
}
