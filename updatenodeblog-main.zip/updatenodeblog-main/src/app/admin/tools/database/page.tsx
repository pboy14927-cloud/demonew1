
'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { CheckCircle, XCircle, Loader2, Database, Upload, FileUp, DatabaseZap, ImportIcon } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useToast } from '@/hooks/use-toast';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Label } from '@/components/ui/label';

type ConnectionStatus = 'unknown' | 'connected' | 'error';
type TableStatus = 'unknown' | 'created' | 'missing';

const tableNames = ['users', 'posts', 'categories', 'tags', 'comments', 'settings', 'media'];

export default function DatabaseToolsPage() {
    const { toast } = useToast();
    const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>('unknown');
    const [isCheckingConnection, setIsCheckingConnection] = useState(true);
    const [tableStatuses, setTableStatuses] = useState<Record<string, TableStatus>>({});
    const [isCheckingTables, setIsCheckingTables] = useState(true);

    const [isUpdating, setIsUpdating] = useState(false);
    const [isImporting, setIsImporting] = useState(false);
    const [file, setFile] = useState<File | null>(null);

    const checkConnection = useCallback(async () => {
        setIsCheckingConnection(true);
        try {
            const response = await fetch('/api/database/check-connection');
            if (response.ok) {
                setConnectionStatus('connected');
            } else {
                setConnectionStatus('error');
            }
        } catch (error) {
            setConnectionStatus('error');
        } finally {
            setIsCheckingConnection(false);
        }
    }, []);

    const checkTables = useCallback(async () => {
        setIsCheckingTables(true);
        try {
            const response = await fetch('/api/database/check-tables');
            const data = await response.json();
            if (response.ok) {
                const statuses: Record<string, TableStatus> = {};
                tableNames.forEach(name => {
                    statuses[name] = data.tables.includes(name) ? 'created' : 'missing';
                });
                setTableStatuses(statuses);
            }
        } catch (error) {
            console.error("Failed to check tables:", error);
        } finally {
            setIsCheckingTables(false);
        }
    }, []);


    useEffect(() => {
        checkConnection();
        checkTables();
    }, [checkConnection, checkTables]);

    const handleUpdateTables = async () => {
        setIsUpdating(true);
        toast({ title: "Updating Database...", description: "This may take a moment. Please wait."});
        try {
            const response = await fetch('/api/database/update-schema', { method: 'POST' });
            const result = await response.json();

            if (!response.ok) {
                 throw new Error(result.message || 'Failed to update database tables.');
            }
            toast({ title: "Success", description: result.message });
            checkTables(); // Re-check tables after update
        } catch(error: any) {
            toast({ variant: 'destructive', title: 'Error', description: error.message });
        } finally {
            setIsUpdating(false);
        }
    };
    
    const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
        const files = event.target.files;
        if (files && files.length > 0) {
            if (files[0].name.endsWith('.sql')) {
                setFile(files[0]);
            } else {
                 toast({ variant: 'destructive', title: 'Invalid File Type', description: 'Please upload a valid .sql file.' });
            }
        }
    }

    const handleImportDatabase = async () => {
        if (!file) {
            toast({ title: "No file selected."});
            return;
        }

        setIsImporting(true);
         try {
            const formData = new FormData();
            formData.append('file', file);
            
            const response = await fetch('/api/import', {
                method: 'POST',
                body: formData,
            });
            const result = await response.json();
            
             if (!response.ok) {
                throw new Error(result.message || 'Failed to import database.');
            }
            toast({ title: "Success", description: result.message });
            checkTables(); // Re-check tables after import

        } catch(error: any) {
            toast({ variant: 'destructive', title: 'Error', description: error.message });
        } finally {
            setIsImporting(false);
        }
    }

    const renderStatus = (status: TableStatus) => {
        if (isCheckingTables) {
            return <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />;
        }
        if (status === 'created') {
            return <div className="flex items-center gap-2 text-green-600"><CheckCircle className="h-4 w-4" /> Created</div>;
        }
        return <div className="flex items-center gap-2 text-destructive"><XCircle className="h-4 w-4" /> Missing</div>;
    }


    return (
        <main className="p-6">
            <h1 className="text-2xl font-semibold mb-6">Database Tools</h1>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>Database Connection</CardTitle>
                            <CardDescription>Check the status of your database connection.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            {isCheckingConnection ? (
                                <div className="flex items-center gap-2 text-muted-foreground">
                                    <Loader2 className="h-5 w-5 animate-spin" /> Checking connection...
                                </div>
                            ) : connectionStatus === 'connected' ? (
                                <div className="flex items-center gap-2 text-green-600 font-semibold">
                                    <CheckCircle className="h-5 w-5" /> Connected
                                </div>
                            ) : (
                                 <div className="flex items-center gap-2 text-destructive font-semibold">
                                    <XCircle className="h-5 w-5" /> Connection Failed
                                </div>
                            )}
                        </CardContent>
                        <CardFooter>
                            <Button onClick={checkConnection} disabled={isCheckingConnection}>
                                 {isCheckingConnection && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                Check Again
                            </Button>
                        </CardFooter>
                    </Card>
                    <Card>
                        <CardHeader>
                            <CardTitle>Actions</CardTitle>
                            <CardDescription>Perform database maintenance tasks.</CardDescription>
                        </CardHeader>
                         <CardContent className="space-y-4">
                            <div className="border rounded-lg p-4 flex items-center justify-between">
                                <div>
                                    <h4 className="font-semibold">Update Database Tables</h4>
                                    <p className="text-sm text-muted-foreground">Create missing tables and update existing ones.</p>
                                </div>
                                 <Button onClick={handleUpdateTables} disabled={isUpdating}>
                                    {isUpdating && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                    <DatabaseZap className="mr-2 h-4 w-4" /> Update
                                </Button>
                            </div>
                             <div className="border rounded-lg p-4 flex items-center justify-between">
                                <div>
                                    <h4 className="font-semibold">Import Database</h4>
                                    <p className="text-sm text-muted-foreground">Import a MySQL database from a .sql file.</p>
                                </div>
                                <AlertDialog>
                                    <AlertDialogTrigger asChild>
                                        <Button variant="outline"><ImportIcon className="mr-2 h-4 w-4" /> Import</Button>
                                    </AlertDialogTrigger>
                                    <AlertDialogContent>
                                        <AlertDialogHeader>
                                            <AlertDialogTitle>Import Database</AlertDialogTitle>
                                             <Alert variant="destructive" className="my-4">
                                                <AlertTitle>Warning!</AlertTitle>
                                                <AlertDescription>
                                                    This will overwrite all existing content, users, and settings on your site. Please backup your current database first.
                                                </AlertDescription>
                                            </Alert>
                                            <AlertDialogDescription>
                                                Select a .sql file to import. This will replace your current database.
                                            </AlertDialogDescription>
                                        </AlertDialogHeader>
                                        <div className="py-4">
                                            <Label htmlFor="sql-file" className="mb-2 block">SQL File</Label>
                                            <Input id="sql-file" type="file" accept=".sql" onChange={handleFileSelect} />
                                             {file && <p className="text-sm text-muted-foreground mt-2">Selected: {file.name}</p>}
                                        </div>
                                        <AlertDialogFooter>
                                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                                            <AlertDialogAction onClick={handleImportDatabase} disabled={isImporting || !file}>
                                                {isImporting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                                Import Now
                                            </AlertDialogAction>
                                        </AlertDialogFooter>
                                    </AlertDialogContent>
                                </AlertDialog>
                            </div>
                         </CardContent>
                    </Card>
                </div>
                 <Card>
                    <CardHeader>
                        <CardTitle>Database Tables</CardTitle>
                        <CardDescription>Check if all required database tables are present.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="border rounded-lg">
                           <Table>
                               <TableHeader>
                                   <TableRow>
                                       <TableHead>Table Name</TableHead>
                                       <TableHead>Status</TableHead>
                                   </TableRow>
                               </TableHeader>
                               <TableBody>
                                   {tableNames.map(name => (
                                       <TableRow key={name}>
                                           <TableCell className="font-medium">{name}</TableCell>
                                           <TableCell>{renderStatus(tableStatuses[name] || 'unknown')}</TableCell>
                                       </TableRow>
                                   ))}
                               </TableBody>
                           </Table>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </main>
    );
}
