
'use server';

import { NextResponse } from 'next/server';
import { getUserIdFromSession } from '@/lib/data';
import { query } from '@/lib/mysql';
import fs from 'fs/promises';
import path from 'path';

// Helper function to check if a column exists in a table
async function columnExists(tableName: string, columnName: string): Promise<boolean> {
  const dbName = process.env.DB_NAME;
  const sql = `
    SELECT * 
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?
  `;
  const results: any[] = await query(sql, [dbName, tableName, columnName]);
  return results.length > 0;
}

async function getColumnType(tableName: string, columnName: string): Promise<string | null> {
    const dbName = process.env.DB_NAME;
    const sql = `
        SELECT COLUMN_TYPE, EXTRA
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?
    `;
    const results: any[] = await query(sql, [dbName, tableName, columnName]);
    if (results.length > 0) {
        return `${results[0].COLUMN_TYPE} ${results[0].EXTRA}`.trim();
    }
    return null;
}


export async function POST(request: Request) {
  const userId = await getUserIdFromSession();
  if (!userId) {
      return NextResponse.json({ message: 'Unauthorized' }, { status: 401 });
  }
  
  try {
    // 1. Run the initial schema to ensure tables exist
    const schemaPath = path.join(process.cwd(), 'schema.sql');
    const schemaSql = await fs.readFile(schemaPath, 'utf-8');
    const statements = schemaSql.split(/;\s*$/m).filter(s => s.trim().length > 0);

    for (const statement of statements) {
      // The schema should use "CREATE TABLE IF NOT EXISTS"
      await query(statement);
    }
    
    // 2. Perform alterations for existing tables to add missing columns
    let alterationsMade = 0;
    const alterations = [
      { table: 'users', column: 'username', definition: 'VARCHAR(255) NOT NULL UNIQUE AFTER `id`' },
      { table: 'users', column: 'bio', definition: 'TEXT' },
      { table: 'users', column: 'website', definition: 'VARCHAR(255)' },
      { table: 'users', column: 'socialLinks', definition: 'JSON' },
      { table: 'users', column: 'firstName', definition: 'VARCHAR(255)' },
      { table: 'users', column: 'lastName', definition: 'VARCHAR(255)' },
      { table: 'users', column: 'avatar', definition: 'VARCHAR(255)' },
      { table: 'comments', column: 'guestName', definition: 'VARCHAR(255)' },
      { table: 'comments', column: 'guestEmail', definition: 'VARCHAR(255)' },
      { table: 'posts', column: 'likes', definition: 'INT DEFAULT 0' },
      { table: 'posts', column: 'parent', definition: 'VARCHAR(255) NULL DEFAULT NULL' },
      { table: 'posts', column: 'isPartnerContent', definition: 'BOOLEAN DEFAULT FALSE' },
      { table: 'media', column: 'sizes', definition: 'JSON NULL' },
      { table: 'media', column: 'url', definition: 'LONGTEXT NULL DEFAULT NULL' },
    ];

    for (const alt of alterations) {
        if (!await columnExists(alt.table, alt.column)) {
            console.log(`Column ${alt.column} does not exist in ${alt.table}. Adding it.`);
            await query(`ALTER TABLE \`${alt.table}\` ADD COLUMN \`${alt.column}\` ${alt.definition}`);
            alterationsMade++;
        }
    }
    
    // 3. Modify existing columns to ensure correct type and properties
    const modifications = [
        { table: 'posts', column: 'content', type: 'longtext', definition: 'LONGTEXT NULL DEFAULT NULL' },
        { table: 'media', column: 'data', type: 'longblob', definition: 'LONGBLOB' },
        { table: 'posts', column: 'parent', type: 'varchar(255)', definition: 'VARCHAR(255) NULL DEFAULT NULL' },
        { table: 'users', column: 'id', type: 'int', definition: 'INT AUTO_INCREMENT PRIMARY KEY' },
    ];
    
    for (const mod of modifications) {
        if (await columnExists(mod.table, mod.column)) {
            const currentType = await getColumnType(mod.table, mod.column);
            // A simple check to see if we need to modify. This could be more robust.
            if (currentType && !currentType.toLowerCase().includes(mod.type)) {
                console.log(`Column ${mod.column} in ${mod.table} is not of type ${mod.type}. Modifying it.`);
                await query(`ALTER TABLE \`${mod.table}\` MODIFY COLUMN \`${mod.column}\` ${mod.definition}`);
                alterationsMade++;
            }
        }
    }
    
    if (alterationsMade > 0) {
        return NextResponse.json({ message: `Database schema updated successfully. ${alterationsMade} changes applied.` }, { status: 200 });
    } else {
        return NextResponse.json({ message: 'Database schema is already up to date.' }, { status: 200 });
    }

  } catch (error: any) {
    console.error('Schema update error:', error);
    return NextResponse.json({ message: `An internal server error occurred: ${error.message}` }, { status: 500 });
  }
}
