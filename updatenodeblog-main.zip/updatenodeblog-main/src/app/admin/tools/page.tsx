
'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from 'next/link';
import { ArrowRight, Download, Upload, Database, RefreshCw } from "lucide-react";

export default function ToolsPage() {

    return (
        <>
            <main className="p-6">
                <h1 className="text-2xl font-semibold mb-6">Tools</h1>

                 <p className="max-w-2xl text-muted-foreground mb-6">
                    Tools for importing and exporting your content, as well as other advanced options for managing your site.
                 </p>

                <div className="grid gap-6 sm:grid-cols-1 lg:grid-cols-2 max-w-4xl">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2"><Upload /> Import</CardTitle>
                            <CardDescription>Import posts, pages, and comments from other platforms like Blogger or another WordPress site.</CardDescription>
                        </CardHeader>
                        <CardFooter>
                            <Button asChild variant="secondary">
                                <Link href="/admin/tools/import">Run Importer <ArrowRight /></Link>
                            </Button>
                        </CardFooter>
                    </Card>
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2"><Download /> Export</CardTitle>
                            <CardDescription>Export your content into a portable XML file. This allows you to move your content to another site or platform.</CardDescription>
                        </CardHeader>
                         <CardFooter>
                             <Button asChild variant="secondary">
                                <Link href="/admin/tools/export">Export Content <ArrowRight /></Link>
                            </Button>
                        </CardFooter>
                    </Card>
                     <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2"><Database /> Database</CardTitle>
                            <CardDescription>Perform advanced database operations. Be careful, these actions can be destructive.</CardDescription>
                        </CardHeader>
                         <CardFooter>
                             <Button asChild variant="secondary">
                                <Link href="/admin/tools/database">Database Tools <ArrowRight /></Link>
                            </Button>
                        </CardFooter>
                    </Card>
                    <Card className="border-destructive">
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2 text-destructive"><RefreshCw /> Reset Site</CardTitle>
                            <CardDescription>This tool will reset your site to its default state, deleting all content, users, and settings.</CardDescription>
                        </CardHeader>
                         <CardFooter>
                             <Button asChild variant="destructive">
                                <Link href="/admin/tools/reset">Reset Site <ArrowRight /></Link>
                            </Button>
                        </CardFooter>
                    </Card>
                </div>
            </main>
        </>
    );
}
