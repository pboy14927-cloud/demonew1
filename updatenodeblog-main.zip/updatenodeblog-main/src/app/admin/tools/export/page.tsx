
'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { getCategories, getUsers, User, Category, getPosts, getPages } from '@/lib/data';
import { useToast } from '@/hooks/use-toast';

export default function ExportPage() {
    const { toast } = useToast();
    const [exportType, setExportType] = useState('all');
    const [categories, setCategories] = useState<Category[]>([]);
    const [authors, setAuthors] = useState<User[]>([]);

    useEffect(() => {
        getCategories().then(setCategories);
        getUsers().then(setAuthors);
    }, []);

    const handleDownload = async () => {
        toast({
            title: "Preparing Export...",
            description: "Your file will be downloaded shortly.",
        });

        let dataToExport: any = {};
        const allPosts = await getPosts();
        const allPages = await getPages();

        switch (exportType) {
            case 'all':
                dataToExport = {
                    posts: allPosts,
                    pages: allPages,
                    categories: categories,
                    users: authors,
                };
                break;
            case 'posts':
                dataToExport = { posts: allPosts };
                break;
            case 'pages':
                dataToExport = { pages: allPages };
                break;
            case 'media':
                // In a real scenario, you'd export media file data
                dataToExport = { message: "Media export is not yet fully implemented." };
                break;
        }

        const jsonString = `data:text/json;charset=utf-8,${encodeURIComponent(
            JSON.stringify(dataToExport, null, 2)
        )}`;
        const link = document.createElement("a");
        link.href = jsonString;
        link.download = `contentdock-export-${exportType}-${new Date().toISOString().split('T')[0]}.json`;

        link.click();
    };

    return (
        <>
            <main className="p-6">
                <div className="max-w-4xl">
                    <h1 className="text-2xl font-semibold mb-2">Export</h1>
                    <p className="text-muted-foreground mb-6">
                        When you click the button below WordPress will create an XML file for you to save to your computer.
                        <br />
                        This format, which is called WordPress eXtended RSS or WXR, will contain your posts, pages, comments, custom fields, terms, navigation menus, and custom posts.
                        <br />
                        Once you’ve saved the download file, you can use the Import function in another WordPress installation to import the content from this site.
                    </p>

                    <Card>
                        <CardHeader>
                            <CardTitle className="text-lg">Choose what to export</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <form onSubmit={(e) => { e.preventDefault(); handleDownload(); }}>
                                <RadioGroup value={exportType} onValueChange={setExportType} className="space-y-4">
                                    <div className="flex items-center space-x-2">
                                        <RadioGroupItem value="all" id="export-all" />
                                        <Label htmlFor="export-all" className="font-bold text-base">All content</Label>
                                    </div>
                                    <p className="pl-6 text-sm text-muted-foreground -mt-2">
                                        This will contain all of your posts, pages, comments, custom fields, terms, navigation menus, and custom posts.
                                    </p>
                                    
                                    <div className="flex items-center space-x-2">
                                        <RadioGroupItem value="posts" id="export-posts" />
                                        <Label htmlFor="export-posts" className="font-bold text-base">Posts</Label>
                                    </div>
                                    <div className={`pl-6 space-y-4 ${exportType === 'posts' ? 'block' : 'hidden'}`}>
                                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                            <div>
                                                <Label htmlFor="post-category">Categories:</Label>
                                                <Select>
                                                    <SelectTrigger id="post-category"><SelectValue placeholder="All" /></SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="all">All</SelectItem>
                                                        {categories.map(cat => <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>)}
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                             <div>
                                                <Label htmlFor="post-author">Authors:</Label>
                                                <Select>
                                                    <SelectTrigger id="post-author"><SelectValue placeholder="All" /></SelectTrigger>
                                                    <SelectContent>
                                                         <SelectItem value="all">All</SelectItem>
                                                         {authors.map(author => <SelectItem key={author.id} value={author.id}>{author.name}</SelectItem>)}
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                        </div>
                                         <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                            <div>
                                                <Label htmlFor="post-start-date">Start date:</Label>
                                                <Select>
                                                    <SelectTrigger id="post-start-date"><SelectValue placeholder="— Select —" /></SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="0">January 2024</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                             <div>
                                                <Label htmlFor="post-end-date">End date:</Label>
                                                <Select>
                                                    <SelectTrigger id="post-end-date"><SelectValue placeholder="— Select —" /></SelectTrigger>
                                                    <SelectContent>
                                                         <SelectItem value="0">January 2024</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                        </div>
                                         <div>
                                            <Label htmlFor="post-status">Status:</Label>
                                            <Select>
                                                <SelectTrigger id="post-status"><SelectValue placeholder="All" /></SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="all">All</SelectItem>
                                                    <SelectItem value="publish">Published</SelectItem>
                                                    <SelectItem value="draft">Draft</SelectItem>
                                                    <SelectItem value="pending">Pending</SelectItem>
                                                    <SelectItem value="private">Private</SelectItem>
                                                    <SelectItem value="trash">Trash</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </div>
                                    </div>

                                    <div className="flex items-center space-x-2">
                                        <RadioGroupItem value="pages" id="export-pages" />
                                        <Label htmlFor="export-pages" className="font-bold text-base">Pages</Label>
                                    </div>
                                     <div className={`pl-6 space-y-4 ${exportType === 'pages' ? 'block' : 'hidden'}`}>
                                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                             <div>
                                                <Label htmlFor="page-author">Authors:</Label>
                                                <Select>
                                                    <SelectTrigger id="page-author"><SelectValue placeholder="All" /></SelectTrigger>
                                                    <SelectContent>
                                                         <SelectItem value="all">All</SelectItem>
                                                          {authors.map(author => <SelectItem key={author.id} value={author.id}>{author.name}</SelectItem>)}
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                        </div>
                                         <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                            <div>
                                                <Label htmlFor="page-start-date">Start date:</Label>
                                                <Select>
                                                    <SelectTrigger id="page-start-date"><SelectValue placeholder="— Select —" /></SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="0">January 2024</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                             <div>
                                                <Label htmlFor="page-end-date">End date:</Label>
                                                <Select>
                                                    <SelectTrigger id="page-end-date"><SelectValue placeholder="— Select —" /></SelectTrigger>
                                                    <SelectContent>
                                                         <SelectItem value="0">January 2024</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                        </div>
                                         <div>
                                            <Label htmlFor="page-status">Status:</Label>
                                            <Select>
                                                <SelectTrigger id="page-status"><SelectValue placeholder="All" /></SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="all">All</SelectItem>
                                                    <SelectItem value="publish">Published</SelectItem>
                                                    <SelectItem value="draft">Draft</SelectItem>
                                                    <SelectItem value="pending">Pending</SelectItem>
                                                    <SelectItem value="private">Private</SelectItem>
                                                    <SelectItem value="trash">Trash</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </div>
                                    </div>

                                    <div className="flex items-center space-x-2">
                                        <RadioGroupItem value="media" id="export-media" />
                                        <Label htmlFor="export-media" className="font-bold text-base">Media</Label>
                                    </div>
                                    <div className={`pl-6 space-y-4 ${exportType === 'media' ? 'block' : 'hidden'}`}>
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                            <div>
                                                <Label htmlFor="media-start-date">Start date:</Label>
                                                <Select>
                                                    <SelectTrigger id="media-start-date"><SelectValue placeholder="— Select —" /></SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="0">January 2024</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                             <div>
                                                <Label htmlFor="media-end-date">End date:</Label>
                                                <Select>
                                                    <SelectTrigger id="media-end-date"><SelectValue placeholder="— Select —" /></SelectTrigger>
                                                    <SelectContent>
                                                         <SelectItem value="0">January 2024</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                        </div>
                                    </div>

                                </RadioGroup>

                                <div className="mt-6">
                                    <Button type="submit">Download Export File</Button>
                                </div>
                            </form>
                        </CardContent>
                    </Card>
                </div>
            </main>
        </>
    );
}
