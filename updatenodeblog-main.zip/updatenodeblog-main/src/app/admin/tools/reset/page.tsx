
'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Terminal, Loader2, Trash2 } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation';

type ResetType = 'posts' | 'pages' | 'partner-content' | 'taxonomies' | 'media' | 'settings' | 'all';

export default function ResetToolPage() {
    const [confirmationText, setConfirmationText] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [activeReset, setActiveReset] = useState<ResetType | null>(null);
    const { toast } = useToast();
    const router = useRouter();

    const handleReset = async () => {
        if (!activeReset) return;
        setIsLoading(true);
        try {
            const response = await fetch('/api/tools/reset', { 
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ type: activeReset }),
            });
            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.message || 'Failed to perform reset.');
            }

            toast({
                title: 'Reset Successful',
                description: result.message,
            });
            
            // Optionally refresh the page or redirect
            router.refresh();

        } catch (error: any) {
            toast({
                variant: 'destructive',
                title: 'Error During Reset',
                description: error.message,
            });
        } finally {
            setIsLoading(false);
            setConfirmationText('');
            setActiveReset(null);
        }
    };

    const confirmationPhrases: Record<ResetType, string> = {
        posts: "RESET POSTS",
        pages: "RESET PAGES",
        "partner-content": "RESET PARTNER CONTENT",
        taxonomies: "RESET TAXONOMIES",
        media: "RESET MEDIA",
        settings: "RESET SETTINGS",
        all: "FACTORY RESET"
    };

    const isConfirmationValid = activeReset ? confirmationText === confirmationPhrases[activeReset] : false;

    const ResetCard = ({ type, title, description, children, buttonText, buttonVariant = 'destructive' }: { type: ResetType, title: string, description: string, children?: React.ReactNode, buttonText: string, buttonVariant?: "destructive" | "default" | "secondary" | "outline" | "ghost" | "link" | null | undefined }) => (
        <Card>
            <CardHeader>
                <CardTitle className="text-lg">{title}</CardTitle>
                <CardDescription>{description}</CardDescription>
            </CardHeader>
            {children && <CardContent>{children}</CardContent>}
            <CardFooter>
                 <AlertDialogTrigger asChild>
                    <Button variant={buttonVariant} onClick={() => setActiveReset(type)}>
                        <Trash2 className="mr-2 h-4 w-4" />{buttonText}
                    </Button>
                </AlertDialogTrigger>
            </CardFooter>
        </Card>
    );

    return (
        <main className="p-6">
            <h1 className="text-2xl font-semibold mb-6">Site Reset Tools</h1>
             <Alert variant="destructive" className="mb-6 max-w-4xl">
                <Terminal className="h-4 w-4" />
                <AlertTitle>Warning: These are destructive actions!</AlertTitle>
                <AlertDescription>
                   Each tool below will permanently delete specific parts of your site's data. These actions cannot be undone. Please be certain before proceeding. Your administrator account will not be deleted.
                </AlertDescription>
            </Alert>
            <AlertDialog onOpenChange={(open) => !open && setActiveReset(null)}>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <ResetCard
                        type="posts"
                        title="Reset Posts"
                        description="Permanently delete all posts from the database. Pages and other content types will not be affected."
                        buttonText="Delete All Posts"
                    />
                     <ResetCard
                        type="pages"
                        title="Reset Pages"
                        description="Permanently delete all pages from the database. Posts and other content types will not be affected."
                        buttonText="Delete All Pages"
                    />
                     <ResetCard
                        type="partner-content"
                        title="Reset Partner Content"
                        description="Permanently delete all content specifically marked as 'Partner Content'."
                        buttonText="Delete Partner Content"
                    />
                      <ResetCard
                        type="taxonomies"
                        title="Reset Categories & Tags"
                        description="Permanently delete all categories and tags. This will not delete the posts themselves."
                        buttonText="Delete Categories & Tags"
                    />
                     <ResetCard
                        type="media"
                        title="Reset Media Library"
                        description="Permanently delete all media records from the database and all files from the uploads folder."
                        buttonText="Delete All Media"
                    />
                     <ResetCard
                        type="settings"
                        title="Reset All Settings"
                        description="Reset all appearance, SEO, permalink, and other settings to their original defaults."
                        buttonText="Reset All Settings"
                    />
                     <Card className="col-span-full bg-destructive/10 border-destructive">
                        <CardHeader>
                            <CardTitle className="text-lg text-destructive-foreground">Factory Reset</CardTitle>
                            <CardDescription className="text-destructive-foreground/80">
                                This will perform all of the above actions at once. It will wipe all content, media, and settings, returning the site to a clean slate. Your admin account will not be affected.
                            </CardDescription>
                        </CardHeader>
                        <CardFooter>
                            <AlertDialogTrigger asChild>
                                <Button variant="destructive" onClick={() => setActiveReset('all')}>
                                    <Trash2 className="mr-2 h-4 w-4" />Perform Factory Reset
                                </Button>
                            </AlertDialogTrigger>
                        </CardFooter>
                     </Card>
                </div>

                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                        <AlertDialogDescription>
                            This is your final confirmation. This action is irreversible. To proceed, please type "{activeReset ? confirmationPhrases[activeReset] : ''}" in the box below.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <div className="py-4">
                        <Label htmlFor="reset-confirmation">Type confirmation phrase</Label>
                        <Input 
                            id="reset-confirmation" 
                            value={confirmationText}
                            onChange={(e) => setConfirmationText(e.target.value)}
                            autoComplete="off"
                            autoFocus
                        />
                    </div>
                    <AlertDialogFooter>
                        <AlertDialogCancel onClick={() => setConfirmationText('')}>Cancel</AlertDialogCancel>
                        <AlertDialogAction 
                            onClick={handleReset} 
                            disabled={!isConfirmationValid || isLoading}
                            className="bg-destructive hover:bg-destructive/90"
                        >
                            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            I understand, proceed with reset
                        </AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </main>
    );
}
