
'use client';

import React, { useState, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { UploadCloud, File as FileIcon, X, CheckCircle, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useRouter } from 'next/navigation';

export default function ImportPage() {
    const [file, setFile] = useState<File | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const { toast } = useToast();
    const router = useRouter();

    const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
        const files = event.target.files;
        if (files && files.length > 0) {
            const selectedFile = files[0];
            if (selectedFile.type === 'text/xml' || selectedFile.name.endsWith('.xml')) {
                setFile(selectedFile);
            } else {
                toast({
                    variant: 'destructive',
                    title: 'Invalid File Type',
                    description: 'Please upload a valid WordPress WXR (.xml) file.',
                });
            }
        }
    };

    const handleButtonClick = () => {
        if (isLoading) return;
        fileInputRef.current?.click();
    };

    const handleDrop = (event: React.DragEvent<HTMLDivElement>) => {
        event.preventDefault();
        event.stopPropagation();
        if (isLoading) return;
        const files = event.dataTransfer.files;
        if (files && files.length > 0) {
             if (files[0].type === 'text/xml' || files[0].name.endsWith('.xml')) {
                setFile(files[0]);
            } else {
                toast({
                    variant: 'destructive',
                    title: 'Invalid File Type',
                    description: 'Please upload a valid WXR (.xml) file.',
                });
            }
        }
    };

    const handleDragOver = (event: React.DragEvent<HTMLDivElement>) => {
        event.preventDefault();
        event.stopPropagation();
    };
    
    const handleRemoveFile = () => {
        setFile(null);
        if (fileInputRef.current) {
            fileInputRef.current.value = '';
        }
    }

    const handleUploadAndAnalyze = async () => {
        if (!file) return;
        setIsLoading(true);
        
        try {
            const formData = new FormData();
            formData.append('file', file);

            const response = await fetch('/api/import/analyze', {
                method: 'POST',
                body: formData,
            });

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.message || 'Failed to analyze the file.');
            }
            
            // Store results in session storage and redirect
            sessionStorage.setItem('importFilePath', result.filePath);
            sessionStorage.setItem('importAuthors', JSON.stringify(result.authors));
            sessionStorage.setItem('importOriginalName', file.name);
            sessionStorage.setItem('importFileType', file.type);
            
            router.push('/admin/tools/import/assign-authors');

        } catch (error: any) {
            toast({
                variant: 'destructive',
                title: 'File Error',
                description: error.message || 'Could not read or parse the XML file. Please ensure it is a valid WXR file.',
            });
             setIsLoading(false);
        }
    }

    return (
        <>
            <main className="p-6">
                <div className="max-w-4xl">
                    <h1 className="text-2xl font-semibold mb-2">Import</h1>
                    <Card>
                        <CardHeader>
                             <CardTitle className="text-lg">Import WordPress Data</CardTitle>
                             <CardDescription>
                                If you have content in a WordPress export file (WXR), you can import it here.
                             </CardDescription>
                        </CardHeader>
                        <CardContent>
                           <p className="text-sm mb-4">
                                Choose a WXR (.xml) file to upload, then click "Upload file and import".
                           </p>
                           <div 
                             className={cn("border-2 border-dashed border-muted-foreground/50 rounded-lg p-12 text-center", !isLoading && "cursor-pointer")}
                             onDrop={handleDrop}
                             onDragOver={handleDragOver}
                             onClick={handleButtonClick}
                           >
                            {file ? (
                                <div className="flex flex-col items-center justify-center gap-2">
                                    <FileIcon className="h-12 w-12 text-primary" />
                                    <p className="font-semibold">{file.name}</p>
                                    <p className="text-xs text-muted-foreground">{Math.round(file.size / 1024)} KB</p>
                                    {!isLoading && (
                                        <Button size="sm" variant="destructive" className="mt-2" onClick={(e) => { e.stopPropagation(); handleRemoveFile(); }}>
                                            <X className="mr-2 h-4 w-4" />
                                            Remove
                                        </Button>
                                    )}
                                </div>
                            ) : (
                              <div className="flex flex-col items-center justify-center space-y-4">
                                <UploadCloud className="h-12 w-12 text-muted-foreground" />
                                <p className="text-muted-foreground">Drag 'n' drop your WXR (.xml) file here.</p>
                                <Button type="button">Select File</Button>
                                <Input 
                                    type="file" 
                                    ref={fileInputRef} 
                                    className="hidden" 
                                    accept=".xml"
                                    onChange={handleFileSelect}
                                    disabled={isLoading}
                                />
                              </div>
                            )}
                            </div>
                             <p className="text-sm text-muted-foreground mt-4">Maximum upload file size: 1 GB.</p>
                             <Button className="mt-6" onClick={handleUploadAndAnalyze} disabled={!file || isLoading}>
                                {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                Upload file and import
                            </Button>
                        </CardContent>
                    </Card>
                </div>
            </main>
        </>
    );
}
