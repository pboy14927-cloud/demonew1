
'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import { getUsers, User } from '@/lib/data';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Loader2 } from 'lucide-react';
import { useSession } from 'next-auth/react';

type ImportAuthor = {
    login: string;
    displayName: string;
};

type AuthorMapping = Record<string, { type: 'create' | 'assign', value: string }>;

export default function AssignAuthorsPage() {
    const router = useRouter();
    const { toast } = useToast();
    const { data: session } = useSession();
    const [importAuthors, setImportAuthors] = useState<ImportAuthor[]>([]);
    const [existingUsers, setExistingUsers] = useState<User[]>([]);
    const [authorMapping, setAuthorMapping] = useState<AuthorMapping>({});
    const [importAttachments, setImportAttachments] = useState(true);
    const [isLoading, setIsLoading] = useState(false);
    const [isMounted, setIsMounted] = useState(false);

    useEffect(() => {
        setIsMounted(true);
        const authorsJson = sessionStorage.getItem('importAuthors');
        const filePath = sessionStorage.getItem('importFilePath');

        if (!authorsJson || !filePath) {
            toast({ variant: 'destructive', title: 'Error', description: 'Import data not found. Please start over.' });
            router.push('/admin/tools/import');
            return;
        }

        const authors: ImportAuthor[] = JSON.parse(authorsJson);
        setImportAuthors(authors);

        getUsers().then(users => {
            setExistingUsers(users);
            // Initialize mappings
            const initialMapping: AuthorMapping = {};
            const defaultAdmin = users.find(u => u.id === (session?.user as any)?.id) || users[0];

            authors.forEach(author => {
                initialMapping[author.login] = {
                    type: 'assign',
                    value: defaultAdmin?.id || ''
                };
            });
            setAuthorMapping(initialMapping);
        });
    }, [router, toast, session]);

    const handleMappingChange = (authorLogin: string, type: 'create' | 'assign', value: string) => {
        setAuthorMapping(prev => ({
            ...prev,
            [authorLogin]: { type, value }
        }));
    };
    
    const handleNewUserInputChange = (authorLogin: string, newUserName: string) => {
        if(authorMapping[authorLogin]?.type === 'create') {
            setAuthorMapping(prev => ({
                ...prev,
                [authorLogin]: { ...prev[authorLogin], value: newUserName }
            }));
        }
    }


    const handleSubmit = async () => {
        const filePath = sessionStorage.getItem('importFilePath');
        const originalName = sessionStorage.getItem('importOriginalName');
        const fileType = sessionStorage.getItem('importFileType');
        
        if (!filePath || !originalName || !fileType) {
            toast({ variant: 'destructive', title: 'Error', description: 'Import context lost. Please start over.' });
            router.push('/admin/tools/import');
            return;
        }
        setIsLoading(true);
        
        try {
            const formData = new FormData();
            formData.append('filePath', filePath);
            formData.append('originalName', originalName);
            formData.append('fileType', fileType);
            formData.append('authorMapping', JSON.stringify(authorMapping));
            formData.append('importAttachments', String(importAttachments));

            const response = await fetch('/api/import', {
                method: 'POST',
                body: formData,
            });

            const result = await response.json();

            if (response.status === 202) {
                 toast({
                    title: 'Import Started!',
                    description: result.message,
                    duration: 10000,
                 });
                 // Clear session storage
                 sessionStorage.removeItem('importFilePath');
                 sessionStorage.removeItem('importAuthors');
                 sessionStorage.removeItem('importOriginalName');
                 sessionStorage.removeItem('importFileType');
                 // Redirect to a safe page
                 router.push('/admin/posts');
            } else {
                 throw new Error(result.message || 'An unknown error occurred.');
            }

        } catch (error: any) {
            setIsLoading(false);
            toast({
                variant: 'destructive',
                title: 'Import Failed',
                description: error.message,
            });
        }
    };
    
    if (!isMounted) {
        return <div className="p-6">Loading importer...</div>;
    }

    return (
        <main className="p-6">
            <h1 className="text-2xl font-semibold mb-2">Import WordPress</h1>
            
            <Card className="max-w-4xl">
                <CardHeader>
                    <CardTitle>Assign Authors</CardTitle>
                    <CardDescription>
                         To make it simpler for you to edit and save the imported content, you may want to reassign the author of the imported item to an existing user of this site, such as your primary administrator account.
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    {importAuthors.map((author, index) => (
                        <div key={author.login} className="space-y-2 border-t pt-4">
                            <p className="font-semibold">{index + 1}. Import author: {author.displayName} ({author.login})</p>
                            <div className="pl-6 space-y-2">
                                <div>
                                    <Label htmlFor={`create-user-${author.login}`}>or create new user with login name:</Label>
                                    <Input 
                                        id={`create-user-${author.login}`}
                                        className="max-w-xs mt-1"
                                        onFocus={() => handleMappingChange(author.login, 'create', author.login)}
                                        onChange={(e) => handleNewUserInputChange(author.login, e.target.value)}
                                        placeholder={author.login}
                                    />
                                </div>
                                <div>
                                    <Label htmlFor={`assign-user-${author.login}`}>or assign posts to an existing user:</Label>
                                    <Select 
                                        onValueChange={(value) => handleMappingChange(author.login, 'assign', value)}
                                        defaultValue={authorMapping[author.login]?.value || ''}
                                    >
                                        <SelectTrigger id={`assign-user-${author.login}`} className="max-w-xs mt-1">
                                            <SelectValue placeholder="- Select -" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {existingUsers.map(user => (
                                                <SelectItem key={user.id} value={user.id}>{user.name} ({user.username})</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>
                            </div>
                        </div>
                    ))}
                    
                    <div className="space-y-4 border-t pt-6">
                        <h3 className="font-semibold text-lg">Import Attachments</h3>
                        <div className="flex items-center space-x-2">
                            <Checkbox 
                                id="import-attachments"
                                checked={importAttachments}
                                onCheckedChange={checked => setImportAttachments(Boolean(checked))}
                            />
                            <Label htmlFor="import-attachments">Download and import file attachments</Label>
                        </div>
                    </div>
                </CardContent>
                <CardFooter>
                    <Button onClick={handleSubmit} disabled={isLoading}>
                        {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Submit
                    </Button>
                </CardFooter>
            </Card>
        </main>
    );
}
