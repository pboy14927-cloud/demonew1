

'use client';

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import Link from 'next/link';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { CircleAlert, HelpCircle, Trash2, X, Plus, ChevronsUpDown, ExternalLink } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHeader, TableRow, TableHead } from '@/components/ui/table';
import { Tooltip, TooltipProvider, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip';
import { SitemapSettings, AdditionalPage, getSitemapSettings, updateSitemapSettings, getPosts, getPages, getCategories, getTags, Post, Page, Category, Tag } from '@/lib/data';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Command, CommandInput, CommandEmpty, CommandGroup, CommandItem, CommandList } from '@/components/ui/command';
import { Badge } from '@/components/ui/badge';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle';


const priorityOptions = Array.from({ length: 11 }, (_, i) => (i / 10).toFixed(1));
const frequencyOptions = ['always', 'hourly', 'daily', 'weekly', 'monthly', 'yearly', 'never'];

export default function SitemapsPage() {
    const { toast } = useToast();
    const [settings, setSettings] = useState<SitemapSettings | null>(null);
    const [newPage, setNewPage] = useState<Omit<AdditionalPage, 'id'>>({
        url: '',
        priority: '0.8',
        frequency: 'weekly',
        lastModified: new Date().toISOString().split('T')[0]
    });

    const [allPosts, setAllPosts] = useState<(Post | Page)[]>([]);
    const [allTerms, setAllTerms] = useState<(Category | Tag)[]>([]);

    useEffect(() => {
        const fetchData = async () => {
            setSettings(await getSitemapSettings());
            const posts = await getPosts();
            const pages = await getPages();
            setAllPosts([...posts, ...pages]);

            const categories = await getCategories();
            const tags = await getTags();
            setAllTerms([...categories, ...tags]);
        };
        fetchData();
    }, []);

    const handleSettingChange = (key: keyof SitemapSettings, value: any) => {
        setSettings(prev => prev ? { ...prev, [key]: value } : null);
    };
    
    const handleAdvancedSettingChange = (section: keyof SitemapSettings['priority'] | 'exclusions', key: string, value: any) => {
        if (!settings) return;
        
        let newSettings: SitemapSettings = { ...settings };
        // @ts-ignore
        if (typeof newSettings[section] === 'object' && newSettings[section] !== null) {
            // @ts-ignore
            newSettings[section] = {
                // @ts-ignore
                ...newSettings[section],
                [key]: value
            };
        }
        setSettings(newSettings);
    };

    const handleAddPage = () => {
        if (!newPage.url || !settings) return;
        try {
            new URL(newPage.url);
            const pageToAdd: AdditionalPage = { ...newPage, id: `page-${Date.now()}` };
            handleSettingChange('additionalPages', [...settings.additionalPages, pageToAdd]);
            setNewPage({ url: '', priority: '0.8', frequency: 'weekly', lastModified: new Date().toISOString().split('T')[0] });
        } catch (error) {
            toast({ variant: 'destructive', title: 'Invalid URL', description: 'Please enter a valid URL for the additional page.'})
        }
    };
    
    const handleRemovePage = (id: string) => {
        if (!settings) return;
        const newPages = settings.additionalPages.filter(p => p.id !== id);
        handleSettingChange('additionalPages', newPages);
    }
    
    const handleSaveChanges = async () => {
        if (!settings) return;
        try {
            await updateSitemapSettings(settings);
            toast({ title: 'Sitemap settings saved successfully' });
        } catch {
            toast({ variant: 'destructive', title: 'Error saving sitemap settings' });
        }
    };
    
    const handleToggleExclusion = (type: 'posts' | 'terms', id: string) => {
        if(!settings || !settings.exclusions) return;
        const currentExclusions = settings.exclusions[type] || [];
        const newExclusions = currentExclusions.includes(id) 
            ? currentExclusions.filter(i => i !== id)
            : [...currentExclusions, id];

        handleAdvancedSettingChange('exclusions', type, newExclusions);
    }

    const excludedPosts = useMemo(() => {
        if (!settings?.exclusions?.posts) return [];
        return allPosts.filter(p => settings.exclusions.posts.includes(p.id));
    }, [allPosts, settings]);

    const excludedTerms = useMemo(() => {
        if (!settings?.exclusions?.terms) return [];
        return allTerms.filter(t => settings.exclusions.terms.includes(t.id));
    }, [allTerms, settings]);


    if (!settings) {
        return (
             <main className="p-6">
                <div className="flex items-center justify-between pb-6">
                    <Skeleton className="h-8 w-48" />
                    <Skeleton className="h-10 w-24" />
                </div>
                <Card>
                    <CardHeader><Skeleton className="h-6 w-1/3" /></CardHeader>
                    <CardContent><Skeleton className="h-64 w-full" /></CardContent>
                </Card>
            </main>
        );
    }

    return (
        <main className="p-6">
            <div className="flex items-center justify-between pb-6">
                <h1 className="text-2xl font-semibold">Sitemaps</h1>
                <Button onClick={handleSaveChanges}>Save Changes</Button>
            </div>

            <div className="max-w-5xl">
                 <Alert className="mb-6 bg-yellow-50 border-yellow-200 text-yellow-800">
                    <CircleAlert className="h-4 w-4 text-yellow-600 !left-4 !top-4" />
                    <AlertTitle className="font-semibold">Connect to Google and keep them in sync.</AlertTitle>
                    <AlertDescription>
                        Digiotic SEO can now verify whether your site is correctly verified with Google Search Console and that your sitemaps have been submitted correctly. Connect with Google Search Console now to ensure your content is being added to Google as soon as possible for increased rankings. <a href="https://search.google.com/search-console" target="_blank" rel="noopener noreferrer" className="underline font-semibold">Connect to Google Search Console</a>
                    </AlertDescription>
                </Alert>
                <Card className="mb-6">
                    <CardHeader>
                        <CardTitle className="text-lg">General Sitemap</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-muted-foreground mb-4">
                            An XML Sitemap is a list of all your content that search engines use when they crawl your site. This is an essential part of SEO because it helps search engines seed when crawling your site. The XML Sitemap created by Digiotic SEO tells search engines where to find all of the content on your site.
                        </p>
                        <div className="flex items-center space-x-2 mb-4">
                            <Switch id="sitemap-enabled" checked={settings.enabled} onCheckedChange={(c) => handleSettingChange('enabled', c)} />
                            <Label htmlFor="sitemap-enabled" className="text-base">Enable Sitemap</Label>
                        </div>
                        <div className="flex items-center gap-4">
                            <Label>Preview</Label>
                            <Button asChild variant="outline">
                                <Link href="/sitemap.xml" target="_blank">Open Sitemap <ExternalLink className="ml-2 h-4 w-4" /></Link>
                            </Button>
                        </div>
                    </CardContent>
                </Card>
                <Accordion type="multiple" defaultValue={['sitemap-settings']} className="w-full space-y-6">
                    <Card>
                        <AccordionItem value="sitemap-settings" className="border-b-0">
                            <AccordionTrigger className="p-6 text-lg font-semibold hover:no-underline">
                                Sitemap Settings
                            </AccordionTrigger>
                            <AccordionContent className="px-6 pb-6 space-y-6 divide-y">
                                <div className="flex justify-between items-center pt-6">
                                    <Label htmlFor="sitemap-indexes" className="flex flex-col gap-1 max-w-lg">
                                        Enable Sitemap Indexes
                                        <span className="flex items-center gap-1 text-xs text-muted-foreground font-normal">
                                            Organize sitemap entries into distinct files in your sitemap. We recommend you enable this setting if your sitemap contains more than 1,000 URLs.
                                            <TooltipProvider>
                                                <Tooltip>
                                                    <TooltipTrigger asChild>
                                                        <HelpCircle className="h-4 w-4" />
                                                    </TooltipTrigger>
                                                    <TooltipContent>
                                                        <p>This will create a sitemap index file that links to other sitemap files.</p>
                                                    </TooltipContent>
                                                </Tooltip>
                                            </TooltipProvider>
                                        </span>
                                    </Label>
                                    <ToggleGroup type="single" value={settings.enableSitemapIndexes ? "enabled" : "disabled"} onValueChange={(value) => value && handleSettingChange('enableSitemapIndexes', value === 'enabled')} className="border rounded-md p-1 h-auto">
                                        <ToggleGroupItem value="disabled" className="px-3 py-1.5 text-sm h-auto data-[state=on]:bg-muted data-[state=on]:text-muted-foreground">Disabled</ToggleGroupItem>
                                        <ToggleGroupItem value="enabled" className="px-3 py-1.5 text-sm h-auto data-[state=on]:bg-primary data-[state=on]:text-primary-foreground">Enabled</ToggleGroupItem>
                                    </ToggleGroup>
                                </div>
                                <div className="flex justify-between items-center pt-6">
                                    <Label htmlFor="links-per-sitemap" className="flex flex-col gap-1 max-w-lg">
                                        Links Per Sitemap
                                        <p className="text-xs text-muted-foreground font-normal">Allows you to specify the maximum number of posts in a sitemap (up to 50,000).</p>
                                    </Label>
                                    <Input id="links-per-sitemap" type="number" value={settings.linksPerSitemap} onChange={(e) => handleSettingChange('linksPerSitemap', parseInt(e.target.value))} className="w-48" />
                                </div>
                                <div className="flex justify-between items-start pt-6">
                                    <Label className="flex flex-col gap-1 max-w-lg">
                                        Post Types
                                        <p className="text-xs text-muted-foreground font-normal">Select which Post Types appear in your sitemap.</p>
                                    </Label>
                                    <div className="space-y-2">
                                        <div className="flex items-center space-x-2">
                                            <Checkbox id="include-all-post-types" checked={settings.includeAllPostTypes} onCheckedChange={(c) => handleSettingChange('includeAllPostTypes', !!c)} />
                                            <Label htmlFor="include-all-post-types" className="font-normal">Include All Post Types</Label>
                                        </div>
                                        {!settings.includeAllPostTypes && (
                                            <div className="pl-6 space-y-2">
                                                <div className="flex items-center space-x-2">
                                                    <Checkbox id="include-posts" checked={settings.includePosts} onCheckedChange={(c) => handleSettingChange('includePosts', !!c)} />
                                                    <Label htmlFor="include-posts" className="font-normal">Posts</Label>
                                                </div>
                                                <div className="flex items-center space-x-2">
                                                    <Checkbox id="include-pages" checked={settings.includePages} onCheckedChange={(c) => handleSettingChange('includePages', !!c)} />
                                                    <Label htmlFor="include-pages" className="font-normal">Pages</Label>
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                </div>
                                <div className="flex justify-between items-start pt-6">
                                    <Label className="flex flex-col gap-1 max-w-lg">
                                        Taxonomies
                                        <p className="text-xs text-muted-foreground font-normal">Select which taxonomies appear in your sitemap.</p>
                                    </Label>
                                    <div className="space-y-2">
                                        <div className="flex items-center space-x-2">
                                            <Checkbox id="include-all-taxonomies" checked={settings.includeAllTaxonomies} onCheckedChange={(c) => handleSettingChange('includeAllTaxonomies', !!c)} />
                                            <Label htmlFor="include-all-taxonomies" className="font-normal">Include All Taxonomies</Label>
                                        </div>
                                        {!settings.includeAllTaxonomies && (
                                            <div className="pl-6 space-y-2">
                                                <div className="flex items-center space-x-2">
                                                    <Checkbox id="include-categories" checked={settings.includeCategories} onCheckedChange={(c) => handleSettingChange('includeCategories', !!c)} />
                                                    <Label htmlFor="include-categories" className="font-normal">Categories</Label>
                                                </div>
                                                <div className="flex items-center space-x-2">
                                                    <Checkbox id="include-tags" checked={settings.includeTags} onCheckedChange={(c) => handleSettingChange('includeTags', !!c)} />
                                                    <Label htmlFor="include-tags" className="font-normal">Tags</Label>
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                </div>
                                <div className="flex justify-between items-center pt-6">
                                    <Label htmlFor="date-archive-sitemap" className="flex flex-col gap-1 max-w-lg">Date Archive Sitemap <p className="text-xs text-muted-foreground font-normal">Include Date Archives in your sitemap.</p></Label>
                                    <ToggleGroup type="single" value={settings.dateArchiveSitemap ? "enabled" : "disabled"} onValueChange={(value) => value && handleSettingChange('dateArchiveSitemap', value === 'enabled')} className="border rounded-md p-1 h-auto">
                                        <ToggleGroupItem value="disabled" className="px-3 py-1.5 text-sm h-auto data-[state=on]:bg-muted data-[state=on]:text-muted-foreground">Disabled</ToggleGroupItem>
                                        <ToggleGroupItem value="enabled" className="px-3 py-1.5 text-sm h-auto data-[state=on]:bg-primary data-[state=on]:text-primary-foreground">Enabled</ToggleGroupItem>
                                    </ToggleGroup>
                                </div>
                                <div className="flex justify-between items-center pt-6">
                                    <Label htmlFor="author-sitemap" className="flex flex-col gap-1 max-w-lg">Author Sitemap <p className="text-xs text-muted-foreground font-normal">Include Author Archives in your sitemap.</p></Label>
                                    <ToggleGroup type="single" value={settings.authorSitemap ? "enabled" : "disabled"} onValueChange={(value) => value && handleSettingChange('authorSitemap', value === 'enabled')} className="border rounded-md p-1 h-auto">
                                        <ToggleGroupItem value="disabled" className="px-3 py-1.5 text-sm h-auto data-[state=on]:bg-muted data-[state=on]:text-muted-foreground">Disabled</ToggleGroupItem>
                                        <ToggleGroupItem value="enabled" className="px-3 py-1.5 text-sm h-auto data-[state=on]:bg-primary data-[state=on]:text-primary-foreground">Enabled</ToggleGroupItem>
                                    </ToggleGroup>
                                </div>
                            </AccordionContent>
                        </AccordionItem>
                    </Card>
                    <Card>
                        <AccordionItem value="additional-pages" className="border-b-0">
                            <AccordionTrigger className="p-6 text-lg font-semibold hover:no-underline">Additional Pages</AccordionTrigger>
                            <AccordionContent className="px-6 pb-6 space-y-4">
                                <p className="text-muted-foreground text-sm">You can add additional pages to your sitemap here, e.g. pages that are not part of your Next.js app but you want to include.</p>
                                <div className="flex gap-2 items-end border p-4 rounded-md">
                                    <div className="grid grid-cols-4 gap-4 flex-1">
                                        <div className="space-y-1 col-span-2">
                                            <Label htmlFor="page-url">Page URL</Label>
                                            <Input id="page-url" placeholder="https://example.com/some-page" value={newPage.url} onChange={e => setNewPage({ ...newPage, url: e.target.value })} />
                                        </div>
                                        <div className="space-y-1">
                                            <Label htmlFor="page-priority">Priority</Label>
                                            <Select value={newPage.priority} onValueChange={(v) => setNewPage({ ...newPage, priority: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{priorityOptions.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent></Select>
                                        </div>
                                        <div className="space-y-1">
                                            <Label htmlFor="page-frequency">Frequency</Label>
                                            <Select value={newPage.frequency} onValueChange={(v) => setNewPage({ ...newPage, frequency: v as any })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{frequencyOptions.map(f => <SelectItem key={f} value={f}>{f}</SelectItem>)}</SelectContent></Select>
                                        </div>
                                    </div>
                                    <Button onClick={handleAddPage}>Add Page</Button>
                                    <Button variant="secondary" onClick={() => toast({ title: "Coming soon!", description: "CSV Import will be available in a future update." })}>Import from CSV</Button>
                                </div>
                                {settings.additionalPages.length > 0 && (
                                    <div className="border rounded-md">
                                        <Table>
                                            <TableHeader><TableRow><TableHead>Page URL</TableHead><TableHead>Priority</TableHead><TableHead>Frequency</TableHead><TableHead>Last Modified</TableHead><TableHead></TableHead></TableRow></TableHeader>
                                            <TableBody>
                                                {settings.additionalPages.map((page, index) => (
                                                    <TableRow key={page.id}>
                                                        <TableCell>{page.url}</TableCell>
                                                        <TableCell>{page.priority}</TableCell>
                                                        <TableCell>{page.frequency}</TableCell>
                                                        <TableCell>{page.lastModified}</TableCell>
                                                        <TableCell>
                                                            <Button variant="ghost" size="icon" onClick={() => handleRemovePage(page.id)}>
                                                                <Trash2 className="h-4 w-4 text-destructive" />
                                                            </Button>
                                                        </TableCell>
                                                    </TableRow>
                                                ))}
                                            </TableBody>
                                        </Table>
                                    </div>
                                )}
                            </AccordionContent>
                        </AccordionItem>
                    </Card>
                    <Card>
                        <AccordionItem value="advanced-settings" className="border-b-0">
                            <AccordionTrigger className="p-6 text-lg font-semibold hover:no-underline">Advanced Settings</AccordionTrigger>
                            <AccordionContent className="px-6 pb-6 space-y-6 divide-y">
                                {settings.exclusions && <>
                                <div className="space-y-4 pt-6">
                                    <div className="grid grid-cols-3 gap-8">
                                        <Label className="col-span-1">Exclude Posts / Pages</Label>
                                        <div className="col-span-2">
                                            <Popover><PopoverTrigger asChild><Button variant="outline" role="combobox" className="w-full justify-between">Type to search...<ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" /></Button></PopoverTrigger>
                                                <PopoverContent className="w-[400px] p-0"><Command><CommandInput placeholder="Search posts or pages..." /><CommandList><CommandEmpty>No results found.</CommandEmpty><CommandGroup>
                                                    {allPosts.filter(p => !settings.exclusions.posts.includes(p.id)).map(p => (<CommandItem key={p.id} onSelect={() => handleToggleExclusion('posts', p.id)}>{p.title}</CommandItem>))}
                                                </CommandGroup></CommandList></Command></PopoverContent>
                                            </Popover>
                                            <div className="flex flex-wrap gap-2 mt-2">
                                                {excludedPosts.map(p => (<Badge key={p.id} variant="secondary">{p.title}<button onClick={() => handleToggleExclusion('posts', p.id)} className="ml-1 rounded-full p-0.5 hover:bg-destructive/50"><X className="h-3 w-3" /></button></Badge>))}
                                            </div>
                                        </div>
                                    </div>
                                    <div className="grid grid-cols-3 gap-8 mt-4 pt-6">
                                        <Label className="col-span-1">Exclude Terms</Label>
                                        <div className="col-span-2">
                                            <Popover><PopoverTrigger asChild><Button variant="outline" role="combobox" className="w-full justify-between">Type to search...<ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" /></Button></PopoverTrigger>
                                                <PopoverContent className="w-[400px] p-0"><Command><CommandInput placeholder="Search categories or tags..." /><CommandList><CommandEmpty>No results found.</CommandEmpty><CommandGroup>
                                                    {allTerms.filter(t => !settings.exclusions.terms.includes(t.id)).map(t => (<CommandItem key={t.id} onSelect={() => handleToggleExclusion('terms', t.id)}>{t.name}</CommandItem>))}
                                                </CommandGroup></CommandList></Command></PopoverContent>
                                            </Popover>
                                            <p className="text-xs text-muted-foreground mt-1">Any posts that are assigned to these terms will also be excluded from your sitemap.</p>
                                            <div className="flex flex-wrap gap-2 mt-2">
                                                {excludedTerms.map(t => (<Badge key={t.id} variant="secondary">{t.name}<button onClick={() => handleToggleExclusion('terms', t.id)} className="ml-1 rounded-full p-0.5 hover:bg-destructive/50"><X className="h-3 w-3" /></button></Badge>))}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                </>}
                                {settings.priority && (
                                <div className="space-y-4 pt-6">
                                    <h4 className="font-medium">Priority Score</h4>
                                    <div className="space-y-4">
                                        <div className="grid grid-cols-3 gap-x-8 gap-y-4 items-center">
                                            <Label>Home Page</Label>
                                            <Select value={settings.priority.homePage.priority} onValueChange={(v) => handleAdvancedSettingChange('priority', 'homePage', { ...settings.priority.homePage, priority: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{priorityOptions.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent></Select>
                                            <Select value={settings.priority.homePage.frequency} onValueChange={(v) => handleAdvancedSettingChange('priority', 'homePage', { ...settings.priority.homePage, frequency: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{frequencyOptions.map(f => <SelectItem key={f} value={f}>{f}</SelectItem>)}</SelectContent></Select>
                                        </div>
                                        <div className="grid grid-cols-3 gap-x-8 gap-y-4 items-center">
                                            <Label>Post Types</Label>
                                            <Select value={settings.priority.postTypes.priority} onValueChange={(v) => handleAdvancedSettingChange('priority', 'postTypes', { ...settings.priority.postTypes, priority: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{priorityOptions.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent></Select>
                                            <Select value={settings.priority.postTypes.frequency} onValueChange={(v) => handleAdvancedSettingChange('priority', 'postTypes', { ...settings.priority.postTypes, frequency: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{frequencyOptions.map(f => <SelectItem key={f} value={f}>{f}</SelectItem>)}</SelectContent></Select>
                                        </div>
                                        <div className="grid grid-cols-3 gap-x-8 gap-y-4 items-center">
                                            <Label>Taxonomies</Label>
                                            <Select value={settings.priority.taxonomies.priority} onValueChange={(v) => handleAdvancedSettingChange('priority', 'taxonomies', { ...settings.priority.taxonomies, priority: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{priorityOptions.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent></Select>
                                            <Select value={settings.priority.taxonomies.frequency} onValueChange={(v) => handleAdvancedSettingChange('priority', 'taxonomies', { ...settings.priority.taxonomies, frequency: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{frequencyOptions.map(f => <SelectItem key={f} value={f}>{f}</SelectItem>)}</SelectContent></Select>
                                        </div>
                                    </div>
                                </div>
                                )}
                                <div className="flex justify-between items-center pt-6">
                                    <Label htmlFor="include-images" className="flex flex-col gap-1 max-w-lg">Include Images<p className="text-xs text-muted-foreground font-normal">Include images in your sitemap.</p></Label>
                                    <ToggleGroup type="single" value={settings.includeImages ? 'yes' : 'no'} onValueChange={(value) => value && handleSettingChange('includeImages', value === 'yes')} className="border rounded-md p-1 h-auto">
                                        <ToggleGroupItem value="no" className="px-3 py-1.5 text-sm h-auto data-[state=on]:bg-muted data-[state=on]:text-muted-foreground">No</ToggleGroupItem>
                                        <ToggleGroupItem value="yes" className="px-3 py-1.5 text-sm h-auto data-[state=on]:bg-primary data-[state=on]:text-primary-foreground">Yes</ToggleGroupItem>
                                    </ToggleGroup>
                                </div>
                            </AccordionContent>
                        </AccordionItem>
                    </Card>
                </Accordion>
            </div>
        </main>
    );
}

