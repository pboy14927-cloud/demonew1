
'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { getWebmasterToolsSettings, WebmasterToolsSettings, updateWebmasterToolsSettings } from '@/lib/data';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';

export default function WebmasterToolsPage() {
    const { toast } = useToast();
    const [settings, setSettings] = useState<WebmasterToolsSettings | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        getWebmasterToolsSettings().then(data => {
            setSettings(data);
            setIsLoading(false);
        });
    }, []);

    const handleSettingChange = (key: keyof WebmasterToolsSettings, value: string) => {
        setSettings(prev => prev ? { ...prev, [key]: value } : null);
    };

    const handleSaveChanges = async () => {
        if (!settings) return;
        try {
            await updateWebmasterToolsSettings(settings);
            toast({ title: 'Settings saved successfully' });
        } catch {
            toast({ variant: 'destructive', title: 'Error saving settings' });
        }
    };

    if (isLoading) {
         return (
             <main className="p-6">
                <div className="flex items-center justify-between pb-6">
                    <Skeleton className="h-8 w-64" />
                    <Skeleton className="h-10 w-24" />
                </div>
                <div className="space-y-8 max-w-4xl">
                    <Card>
                        <CardHeader><Skeleton className="h-6 w-1/3" /></CardHeader>
                        <CardContent className="space-y-6">
                            <Skeleton className="h-10 w-full" />
                             <Skeleton className="h-10 w-full" />
                        </CardContent>
                    </Card>
                     <Card>
                        <CardHeader><Skeleton className="h-6 w-1/3" /></CardHeader>
                        <CardContent className="space-y-6">
                            <Skeleton className="h-10 w-full" />
                             <Skeleton className="h-10 w-full" />
                             <Skeleton className="h-10 w-full" />
                        </CardContent>
                    </Card>
                    <Card>
                        <CardHeader><Skeleton className="h-6 w-1/3" /></CardHeader>
                        <CardContent className="space-y-6">
                            <Skeleton className="h-24 w-full" />
                             <Skeleton className="h-24 w-full" />
                        </CardContent>
                    </Card>
                </div>
            </main>
        )
    }

    return (
        <main className="p-6">
            <div className="flex items-center justify-between pb-6">
                <h1 className="text-2xl font-semibold">Webmaster Tools</h1>
                <Button onClick={handleSaveChanges}>Save Changes</Button>
            </div>
            
            <div className="space-y-8 max-w-4xl">
                <Card>
                    <CardHeader>
                        <CardTitle>Analytics & Verification</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <div className="space-y-2">
                            <Label htmlFor="gtm-id">Google Tag Manager ID</Label>
                            <Input 
                                id="gtm-id" 
                                placeholder="GTM-XXXXXXX" 
                                value={settings?.googleTagManagerId || ''} 
                                onChange={(e) => handleSettingChange('googleTagManagerId', e.target.value)} 
                            />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="ga-id">Google Analytics ID</Label>
                            <Input 
                                id="ga-id" 
                                placeholder="G-XXXXXXXXXX" 
                                value={settings?.googleAnalyticsId || ''} 
                                onChange={(e) => handleSettingChange('googleAnalyticsId', e.target.value)} 
                            />
                            <p className="text-sm text-muted-foreground">This will be used if Google Tag Manager is not set.</p>
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle>Site Verification</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <div className="space-y-2">
                            <Label htmlFor="gsc-key">Google Search Console Key</Label>
                            <Input 
                                id="gsc-key" 
                                value={settings?.googleSearchConsoleKey || ''} 
                                onChange={(e) => handleSettingChange('googleSearchConsoleKey', e.target.value)} 
                            />
                        </div>
                         <div className="space-y-2">
                            <Label htmlFor="bing-key">Bing Webmaster Tools Key</Label>
                            <Input 
                                id="bing-key" 
                                value={settings?.bingKey || ''} 
                                onChange={(e) => handleSettingChange('bingKey', e.target.value)} 
                            />
                        </div>
                         <div className="space-y-2">
                            <Label htmlFor="yandex-key">Yandex Webmaster Key</Label>
                            <Input 
                                id="yandex-key" 
                                value={settings?.yandexKey || ''} 
                                onChange={(e) => handleSettingChange('yandexKey', e.target.value)} 
                            />
                        </div>
                    </CardContent>
                </Card>

                 <Card>
                    <CardHeader>
                        <CardTitle>Custom Scripts</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <div className="space-y-2">
                            <Label htmlFor="header-scripts">Scripts in Header</Label>
                            <Textarea 
                                id="header-scripts"
                                value={settings?.headerScripts || ''}
                                onChange={(e) => handleSettingChange('headerScripts', e.target.value)}
                                placeholder="<script> ... </script>"
                                rows={6}
                                className="font-mono"
                            />
                            <p className="text-sm text-muted-foreground">These scripts will be printed in the &lt;head&gt; section.</p>
                        </div>
                         <div className="space-y-2">
                            <Label htmlFor="footer-scripts">Scripts in Footer</Label>
                            <Textarea 
                                id="footer-scripts"
                                value={settings?.footerScripts || ''}
                                onChange={(e) => handleSettingChange('footerScripts', e.target.value)}
                                placeholder="<script> ... </script>"
                                rows={6}
                                className="font-mono"
                            />
                             <p className="text-sm text-muted-foreground">These scripts will be printed before the closing &lt;/body&gt; tag.</p>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </main>
    )
}
