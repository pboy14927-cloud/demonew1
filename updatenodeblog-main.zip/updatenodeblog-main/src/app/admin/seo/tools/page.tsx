
'use client';

import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Upload, Download, Trash2, Plus, Import, Radio, FileUp } from "lucide-react";
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { getRobotsTxtSettings, RobotsRule, updateRobotsTxtSettings, getBrandingSettings } from '@/lib/data';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';

type AiCrawler = 'all' | 'gpt' | 'ads' | 'gemini' | 'cc';

export default function SeoToolsPage() {
    const { toast } = useToast();
    const [settings, setSettings] = useState<{ enableCustomRobots: boolean, rules: RobotsRule[], blockInternalSearch: 'on' | 'off', blockedCrawlers: AiCrawler[] } | null>(null);
    const [siteUrl, setSiteUrl] = useState('');

    useEffect(() => {
        getRobotsTxtSettings().then(setSettings);
        getBrandingSettings().then(brandingSettings => {
            setSiteUrl(brandingSettings.siteUrl.endsWith('/') ? brandingSettings.siteUrl : `${brandingSettings.siteUrl}/`);
        });
    }, []);

    const handleSettingChange = useCallback((key: keyof typeof settings, value: any) => {
        setSettings(prev => prev ? { ...prev, [key]: value } : null);
    }, []);

    const handleAddRule = useCallback(() => {
        if (!settings) return;
        const newId = settings.rules.length > 0 ? Math.max(...settings.rules.map(r => r.id)) + 1 : 1;
        const newRules = [...settings.rules, { id: newId, userAgent: '*', directive: 'Disallow', value: '' }];
        handleSettingChange('rules', newRules);
    }, [settings, handleSettingChange]);

    const handleRemoveRule = useCallback((id: number) => {
        if (!settings) return;
        handleSettingChange('rules', settings.rules.filter(rule => rule.id !== id));
    }, [settings, handleSettingChange]);

    const handleRuleChange = useCallback((id: number, field: keyof Omit<RobotsRule, 'id'>, value: string) => {
        if (!settings) return;
        handleSettingChange('rules', settings.rules.map(rule => rule.id === id ? { ...rule, [field]: value } : rule));
    }, [settings, handleSettingChange]);
    
    const handleCrawlerBlockChange = useCallback((crawler: AiCrawler, checked: boolean) => {
        if (!settings) return;
        let currentBlocked = settings.blockedCrawlers || [];
        
        if (crawler === 'all') {
            if (checked) {
                currentBlocked = ['all', 'gpt', 'ads', 'gemini', 'cc'];
            } else {
                currentBlocked = [];
            }
        } else {
            if (checked) {
                currentBlocked = [...currentBlocked, crawler];
            } else {
                currentBlocked = currentBlocked.filter(c => c !== crawler && c !== 'all');
            }
            
            if (['gpt', 'ads', 'gemini', 'cc'].every(c => currentBlocked.includes(c as AiCrawler))) {
                 if(!currentBlocked.includes('all')) currentBlocked.push('all');
            } else {
                 currentBlocked = currentBlocked.filter(c => c !== 'all');
            }
        }
        
        handleSettingChange('blockedCrawlers', currentBlocked);

    }, [settings, handleSettingChange]);
    
    const handleSaveChanges = async () => {
        if (!settings) return;
        try {
            await updateRobotsTxtSettings(settings);
            toast({ title: "Settings saved!" });
        } catch (e) {
            toast({ title: "Error saving settings", variant: "destructive" });
        }
    }
    
    const robotsTxtPreview = useMemo(() => {
        if (!settings) return '';

        let contentLines: string[] = [];
        const userAgents: { [key:string]: {disallow: string[], allow: string[]} } = {};
        
        const addRule = (userAgent: string, directive: 'Allow' | 'Disallow', value: string) => {
            if (!userAgents[userAgent]) {
                userAgents[userAgent] = { allow: [], disallow: [] };
            }
            if(directive === 'Allow') userAgents[userAgent].allow.push(value);
            else userAgents[userAgent].disallow.push(value);
        };
        
        // Add custom rules
        if (settings.enableCustomRobots) {
            settings.rules.forEach(rule => {
                addRule(rule.userAgent, rule.directive, rule.value);
            });
        }
        
        // Add AI crawler blocks
        if (settings.blockedCrawlers?.includes('gpt')) addRule('GPTBot', 'Disallow', '/');
        if (settings.blockedCrawlers?.includes('ads')) addRule('AdsBot-Google', 'Disallow', '/');
        if (settings.blockedCrawlers?.includes('gemini')) {
            addRule('Google-Extended', 'Disallow', '/');
        }
        if (settings.blockedCrawlers?.includes('cc')) addRule('CCBot', 'Disallow', '/');

        // Block internal search
        if (settings.blockInternalSearch === 'on') {
            addRule('*', 'Disallow', '/?s=');
            addRule('*', 'Disallow', '/search/');
        }

        // Build the string
        for (const userAgent in userAgents) {
            contentLines.push(`User-agent: ${userAgent}`);
            userAgents[userAgent].disallow.forEach(value => contentLines.push(`Disallow: ${value}`));
            userAgents[userAgent].allow.forEach(value => contentLines.push(`Allow: ${value}`));
            contentLines.push('');
        }

        contentLines.push(`Sitemap: ${siteUrl}sitemap.xml`);

        return contentLines.join('\n');
    }, [settings, siteUrl]);

    if (!settings) {
        return (
             <main className="p-6">
                <div className="flex items-center justify-between pb-6">
                    <Skeleton className="h-8 w-32" />
                    <Skeleton className="h-10 w-24" />
                </div>
                <Card>
                    <CardHeader><Skeleton className="h-6 w-1/3" /></CardHeader>
                    <CardContent><Skeleton className="h-64 w-full" /></CardContent>
                </Card>
            </main>
        )
    }

    const { enableCustomRobots, rules, blockInternalSearch, blockedCrawlers } = settings;

    return (
        <main className="p-6">
            <div className="flex items-center justify-between pb-6">
                <h1 className="text-2xl font-semibold">Tools</h1>
                <Button onClick={handleSaveChanges}>Save Changes</Button>
            </div>
            
            <Tabs defaultValue="robots" className="w-full">
                <TabsList className="grid w-full grid-cols-2 max-w-sm">
                    <TabsTrigger value="robots">Robots.txt Editor</TabsTrigger>
                    <TabsTrigger value="import-export">Import/Export</TabsTrigger>
                </TabsList>
                
                <TabsContent value="robots">
                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between">
                           <div>
                             <CardTitle>Robots.txt Editor</CardTitle>
                            <CardDescription className="max-w-3xl mt-2">
                                The robots.txt editor in Digiotic SEO allows you to set up a robots.txt file for your site that will override the default. By creating a robots.txt file with Digiotic SEO you have greater control over the instructions you give web crawlers about your site.
                            </CardDescription>
                           </div>
                        </CardHeader>
                        <CardContent className="space-y-8">
                            <div>
                                <h3 className="font-semibold mb-2">Preview</h3>
                                <Button variant="outline" asChild>
                                    <a href="/robots.txt" target="_blank" rel="noopener noreferrer">Open Robots.txt</a>
                                </Button>
                            </div>

                            <div className="flex items-center gap-4 border-t pt-6">
                                <Label htmlFor="enable-custom-robots" className="font-semibold">Enable Custom Robots.txt</Label>
                                <Switch id="enable-custom-robots" checked={enableCustomRobots} onCheckedChange={(c) => handleSettingChange('enableCustomRobots', c)} />
                            </div>
                            
                            {enableCustomRobots && (
                                <div className='space-y-6'>
                                    <div className="space-y-4">
                                        <div className="grid grid-cols-[2fr_1fr_2fr_auto] gap-4 items-center px-2">
                                            <Label>User Agent</Label>
                                            <Label>Directive</Label>
                                            <Label>Value</Label>
                                            <div></div>
                                        </div>
                                        {rules.map(rule => (
                                            <div key={rule.id} className="grid grid-cols-[2fr_1fr_2fr_auto] gap-4 items-center">
                                                <Input 
                                                    value={rule.userAgent} 
                                                    onChange={(e) => handleRuleChange(rule.id, 'userAgent', e.target.value)}
                                                />
                                                <Select value={rule.directive} onValueChange={(value) => handleRuleChange(rule.id, 'directive', value)}>
                                                    <SelectTrigger><SelectValue /></SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="Allow">Allow</SelectItem>
                                                        <SelectItem value="Disallow">Disallow</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                                <Input 
                                                    value={rule.value}
                                                    onChange={(e) => handleRuleChange(rule.id, 'value', e.target.value)}
                                                />
                                                <Button variant="ghost" size="icon" onClick={() => handleRemoveRule(rule.id)}>
                                                    <Trash2 className="text-destructive h-4 w-4"/>
                                                </Button>
                                            </div>
                                        ))}
                                        <div className="flex gap-2">
                                            <Button variant="secondary" onClick={handleAddRule}><Plus className="mr-2"/> Add Rule</Button>
                                        </div>
                                    </div>
                                </div>
                            )}
                            <div className="space-y-4 border-t pt-6">
                                <Label className="font-semibold">Block AI Crawlers</Label>
                                <div className="grid grid-cols-2 gap-x-8 gap-y-2">
                                    <div className="flex items-center space-x-2">
                                        <Checkbox id="block-all" onCheckedChange={(c) => handleCrawlerBlockChange('all', c as boolean)} checked={blockedCrawlers?.includes('all')}/>
                                        <Label htmlFor="block-all" className="font-normal">All AI Crawlers</Label>
                                    </div>
                                    <div className="flex items-center space-x-2">
                                        <Checkbox id="block-gpt" onCheckedChange={(c) => handleCrawlerBlockChange('gpt', c as boolean)} checked={blockedCrawlers?.includes('gpt')}/>
                                        <Label htmlFor="block-gpt" className="font-normal">OpenAI GPTBot</Label>
                                    </div>
                                    <div className="flex items-center space-x-2">
                                        <Checkbox id="block-ads" onCheckedChange={(c) => handleCrawlerBlockChange('ads', c as boolean)} checked={blockedCrawlers?.includes('ads')}/>
                                        <Label htmlFor="block-ads" className="font-normal">Google AdsBot</Label>
                                    </div>
                                     <div className="flex items-center space-x-2">
                                        <Checkbox id="block-gemini" onCheckedChange={(c) => handleCrawlerBlockChange('gemini', c as boolean)} checked={blockedCrawlers?.includes('gemini')}/>
                                        <Label htmlFor="block-gemini" className="font-normal">Google Gemini & Vertex AI Bots</Label>
                                    </div>
                                    <div className="flex items-center space-x-2">
                                        <Checkbox id="block-cc" onCheckedChange={(c) => handleCrawlerBlockChange('cc', c as boolean)} checked={blockedCrawlers?.includes('cc')}/>
                                        <Label htmlFor="block-cc" className="font-normal">Common Crawl CCBot</Label>
                                    </div>
                                </div>
                            </div>
                            <div className="space-y-2 border-t pt-6">
                                <Label className="font-semibold">Block Crawling of Internal Site Search URLs</Label>
                                <ToggleGroup type="single" value={blockInternalSearch} onValueChange={(value: 'on' | 'off') => value && handleSettingChange('blockInternalSearch', value)}>
                                    <ToggleGroupItem value="off">Off</ToggleGroupItem>
                                    <ToggleGroupItem value="on">On</ToggleGroupItem>
                                </ToggleGroup>
                                <p className="text-xs text-muted-foreground mt-2">Add a 'disallow' rule to your robots.txt file to prevent crawling of URLs like ?s=, /search/ and /page/*/?s=.</p>
                            </div>
                            <div className="space-y-2 border-t pt-6">
                                <Label htmlFor="robots-preview" className="font-semibold">Custom Robots.txt Preview</Label>
                                <Textarea id="robots-preview" readOnly value={robotsTxtPreview} rows={12} className="font-mono text-xs bg-muted/50" />
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>
                
                <TabsContent value="import-export">
                    <div className="space-y-6">
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2"><FileUp className="h-5 w-5"/> Import / Restore Digiotic SEO Settings or Content</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="flex items-center gap-2">
                                        <Input type="text" readOnly placeholder="Import from a JSON, CSV or INI file..." className="flex-1"/>
                                        <Button variant="outline">Choose a File</Button>
                                    </div>
                                    <p className="text-xs text-muted-foreground mt-2">Imported will overwrite existing data and will not be merged.</p>
                                </CardContent>
                                <CardFooter>
                                    <Button>Import</Button>
                                </CardFooter>
                            </Card>
                             <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2"><Download className="h-5 w-5"/> Export Settings</CardTitle>
                                </CardHeader>
                                <CardContent className="grid grid-cols-2 gap-4">
                                    <div className="flex items-center space-x-2">
                                        <Checkbox id="export-all-settings" />
                                        <Label htmlFor="export-all-settings" className="font-normal">Export All Settings</Label>
                                    </div>
                                     <div className="flex items-center space-x-2">
                                        <Checkbox id="export-webmaster" />
                                        <Label htmlFor="export-webmaster" className="font-normal">Webmaster Tools</Label>
                                    </div>
                                    <div className="flex items-center space-x-2">
                                        <Checkbox id="export-advanced" />
                                        <Label htmlFor="export-advanced" className="font-normal">Advanced</Label>
                                    </div>
                                    <div className="flex items-center space-x-2">
                                        <Checkbox id="export-social" />
                                        <Label htmlFor="export-social" className="font-normal">Social Networks</Label>
                                    </div>
                                     <div className="flex items-center space-x-2">
                                        <Checkbox id="export-robots" />
                                        <Label htmlFor="export-robots" className="font-normal">Robots.txt</Label>
                                    </div>
                                     <div className="flex items-center space-x-2">
                                        <Checkbox id="export-rss" />
                                        <Label htmlFor="export-rss" className="font-normal">RSS Content</Label>
                                    </div>
                                    <div className="flex items-center space-x-2">
                                        <Checkbox id="export-search-appearance" />
                                        <Label htmlFor="export-search-appearance" className="font-normal">Search Appearance</Label>
                                    </div>
                                     <div className="flex items-center space-x-2">
                                        <Checkbox id="export-sitemaps" />
                                        <Label htmlFor="export-sitemaps" className="font-normal">Sitemaps</Label>
                                    </div>
                                </CardContent>
                                <CardFooter>
                                    <Button>Export Settings</Button>
                                </CardFooter>
                            </Card>
                        </div>
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2"><Import className="h-5 w-5"/> Import Settings From Other Plugins</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <Label htmlFor="import-plugin">Choose a plugin to import SEO data directly into Digiotic SEO.</Label>
                                <Select>
                                    <SelectTrigger id="import-plugin">
                                        <SelectValue placeholder="Select a plugin..."/>
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="yoast">Yoast SEO</SelectItem>
                                        <SelectItem value="rankmath">Rank Math</SelectItem>
                                        <SelectItem value="aioseo">AIOSEO</SelectItem>
                                        <SelectItem value="digiotic">Digiotic SEO</SelectItem>
                                    </SelectContent>
                                </Select>
                            </CardContent>
                            <CardFooter>
                                <Button>Import</Button>
                            </CardFooter>
                        </Card>
                         <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
                              <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2"><Download className="h-5 w-5"/> Export Content</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <Tabs defaultValue="post-types">
                                        <TabsList>
                                            <TabsTrigger value="post-types">Post Types</TabsTrigger>
                                            <TabsTrigger value="taxonomies">Taxonomies</TabsTrigger>
                                        </TabsList>
                                        <TabsContent value="post-types" className="pt-4 space-y-4">
                                             <div className="flex items-center space-x-2">
                                                <Checkbox id="export-all-post-types" />
                                                <Label htmlFor="export-all-post-types" className="font-normal">Export All Post Types</Label>
                                            </div>
                                             <div className="flex items-center space-x-2">
                                                <Checkbox id="export-posts" />
                                                <Label htmlFor="export-posts" className="font-normal">Posts</Label>
                                            </div>
                                            <div className="flex items-center space-x-2">
                                                <Checkbox id="export-pages" />
                                                <Label htmlFor="export-pages" className="font-normal">Pages</Label>
                                            </div>
                                            <div className="flex items-center space-x-2">
                                                <Checkbox id="export-attachments" />
                                                <Label htmlFor="export-attachments" className="font-normal">Attachments</Label>
                                            </div>
                                             <div>
                                                <Label className="font-semibold">Export As</Label>
                                                <RadioGroup defaultValue="json" className="flex gap-4 mt-2">
                                                    <div className="flex items-center space-x-2">
                                                        <RadioGroupItem value="json" id="export-json" />
                                                        <Label htmlFor="export-json" className="font-normal">JSON</Label>
                                                    </div>
                                                    <div className="flex items-center space-x-2">
                                                        <RadioGroupItem value="csv" id="export-csv" />
                                                        <Label htmlFor="export-csv" className="font-normal">CSV</Label>
                                                    </div>
                                                </RadioGroup>
                                             </div>
                                        </TabsContent>
                                        <TabsContent value="taxonomies">
                                            {/* Taxonomy export options would go here */}
                                            <p>Taxonomy export settings coming soon.</p>
                                        </TabsContent>
                                    </Tabs>
                                </CardContent>
                                <CardFooter>
                                    <Button>Export Content</Button>
                                </CardFooter>
                            </Card>
                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2"><Radio className="h-5 w-5"/> Backup Settings</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-sm text-muted-foreground">You have no saved backups.</p>
                                </CardContent>
                                <CardFooter>
                                    <Button>Create Backup</Button>
                                </CardFooter>
                            </Card>
                        </div>
                    </div>
                </TabsContent>
            </Tabs>
        </main>
    )
}
