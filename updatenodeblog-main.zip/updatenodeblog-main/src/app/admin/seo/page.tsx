

'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { ArrowRight, CheckCircle, XCircle, Settings, ExternalLink } from "lucide-react";
import { getWebmasterToolsSettings, WebmasterToolsSettings, getSitemapSettings, SitemapSettings, updateWebmasterToolsSettings } from '@/lib/data';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';

function WebmasterToolsForm() {
    const { toast } = useToast();
    const [settings, setSettings] = useState<WebmasterToolsSettings | null>(null);

    useEffect(() => {
        getWebmasterToolsSettings().then(setSettings);
    }, []);

    const handleSettingChange = (key: keyof WebmasterToolsSettings, value: any) => {
        setSettings(prev => prev ? { ...prev, [key]: value } : null);
    };

    const handleSaveChanges = useCallback(async () => {
        if (!settings) return;
        try {
            await updateWebmasterToolsSettings(settings);
            toast({ title: 'Settings saved successfully' });
        } catch {
            toast({ variant: 'destructive', title: 'Error saving settings' });
        }
    }, [settings, toast]);
    
    if (!settings) {
        return <Skeleton className="h-48 w-full" />
    }
    
    return (
        <div className="space-y-4">
            <div className="space-y-2">
                <Label htmlFor="gsc-key">Google Search Console Key</Label>
                <Input id="gsc-key" value={settings.googleSearchConsoleKey} onChange={(e) => handleSettingChange('googleSearchConsoleKey', e.target.value)} />
            </div>
            <div className="space-y-2">
                <Label htmlFor="bing-key">Bing Webmaster Tools Key</Label>
                <Input id="bing-key" value={settings.bingKey} onChange={(e) => handleSettingChange('bingKey', e.target.value)} />
            </div>
             <div className="space-y-2">
                <Label htmlFor="yandex-key">Yandex Webmaster Key</Label>
                <Input id="yandex-key" value={settings.yandexKey} onChange={(e) => handleSettingChange('yandexKey', e.target.value)} />
            </div>
            <Button onClick={handleSaveChanges}>Save Webmaster Tools</Button>
        </div>
    )
}

function ConfigurationWizard({ isOpen, onOpenChange }: {isOpen: boolean, onOpenChange: (open: boolean) => void}) {
    const [step, setStep] = useState(1);
    const steps = [
        { id: 1, title: 'Search Appearance' },
        { id: 2, title: 'Webmaster Tools' },
        { id: 3, title: 'XML Sitemaps' },
        { id: 4, title: 'Finished!' },
    ];
    return (
        <Dialog open={isOpen} onOpenChange={onOpenChange}>
            <DialogContent className="sm:max-w-[625px]">
                <DialogHeader>
                    <DialogTitle>First-time SEO configuration</DialogTitle>
                    <DialogDescription>
                        This quick wizard will help you configure the basic SEO settings for your site.
                    </DialogDescription>
                </DialogHeader>
                <div className="flex items-center space-x-4 my-4">
                    {steps.map((s, index) => (
                        <React.Fragment key={s.id}>
                            <div className="flex flex-col items-center">
                                <div className={`h-8 w-8 rounded-full flex items-center justify-center ${step >= s.id ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}>
                                    {step > s.id ? <CheckCircle className="h-5 w-5"/> : s.id}
                                </div>
                                <p className={`text-xs mt-1 ${step >= s.id ? 'font-semibold' : ''}`}>{s.title}</p>
                            </div>
                            {index < steps.length - 1 && <div className="flex-1 h-px bg-border" />}
                        </React.Fragment>
                    ))}
                </div>
                <div className="py-4">
                   {step === 1 && (
                       <div className="space-y-4">
                           <h3 className="font-semibold">Search Appearance</h3>
                           <p className="text-sm text-muted-foreground">This setting controls how your homepage appears in search results. You can change this later in the Search Appearance settings.</p>
                           <Label>Homepage Title</Label>
                           <Input defaultValue="My Awesome Site - Just another ContentDock site" />
                       </div>
                   )}
                   {step === 2 && (
                        <div className="space-y-4">
                            <h3 className="font-semibold">Webmaster Tools</h3>
                             <p className="text-sm text-muted-foreground">Verify your site with various webmaster tools to get more insights.</p>
                            <WebmasterToolsForm />
                        </div>
                   )}
                   {step === 3 && (
                        <div className="space-y-4">
                            <h3 className="font-semibold">XML Sitemaps</h3>
                            <div className="flex items-center space-x-2">
                                <Checkbox id="enable-sitemaps" defaultChecked />
                                <Label htmlFor="enable-sitemaps">Enable XML Sitemaps</Label>
                            </div>
                            <p className="text-sm text-muted-foreground">We highly recommend keeping sitemaps enabled as they help search engines like Google find your content.</p>
                        </div>
                   )}
                   {step === 4 && (
                       <div className="text-center py-8">
                           <h3 className="text-xl font-bold">Congratulations!</h3>
                           <p className="text-muted-foreground mt-2">You've completed the basic SEO setup. You can fine-tune more settings from the main dashboard.</p>
                       </div>
                   )}
                </div>
                <DialogFooter>
                    {step > 1 && <Button variant="outline" onClick={() => setStep(s => s - 1)}>Previous</Button>}
                    {step < steps.length ? (
                        <Button onClick={() => setStep(s => s + 1)}>Next</Button>
                    ) : (
                        <DialogClose asChild>
                            <Button>Finish</Button>
                        </DialogClose>
                    )}
                </DialogFooter>
            </DialogContent>
        </Dialog>
    )
}

export default function SeoDashboardPage() {
    const [webmasterSettings, setWebmasterSettings] = useState<WebmasterToolsSettings | null>(null);
    const [sitemapSettings, setSitemapSettings] = useState<SitemapSettings | null>(null);
    const [isWizardOpen, setIsWizardOpen] = useState(false);
    
    useEffect(() => {
        getWebmasterToolsSettings().then(setWebmasterSettings);
        getSitemapSettings().then(setSitemapSettings);
    }, []);

    const googleConnected = webmasterSettings && webmasterSettings.googleSearchConsoleKey;
    const bingConnected = webmasterSettings && webmasterSettings.bingKey;

  return (
    <>
      <main className="p-6">
         <div className="flex items-center justify-between pb-6">
            <h1 className="text-2xl font-semibold">Digiotic SEO Dashboard</h1>
            <Button asChild variant="outline"><Link href="/admin/settings"><Settings className="mr-2" /> All SEO Settings</Link></Button>
         </div>

         <div className="grid gap-6 sm:grid-cols-1 lg:grid-cols-2">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Welcome to Digiotic SEO</CardTitle>
                <CardDescription>This is your control center for all things SEO. Let's get your site ranking!</CardDescription>
              </CardHeader>
              <CardContent>
                 <Button onClick={() => setIsWizardOpen(true)}>Start SEO Configuration</Button>
              </CardContent>
            </Card>
            
            <Card>
                <CardHeader>
                    <CardTitle>Webmaster Tools</CardTitle>
                    <CardDescription>Verify your site with different webmaster tools to unlock valuable insights and improve your search engine visibility.</CardDescription>
                </CardHeader>
                <CardContent>
                     {webmasterSettings ? (
                        <div className="space-y-2">
                           <div className="flex items-center gap-2">
                                {googleConnected ? <CheckCircle className="text-green-500"/> : <XCircle className="text-destructive"/>}
                                <span className={googleConnected ? '' : 'text-muted-foreground'}>Google Search Console</span>
                           </div>
                            <div className="flex items-center gap-2">
                                {bingConnected ? <CheckCircle className="text-green-500"/> : <XCircle className="text-destructive"/>}
                                <span className={bingConnected ? '' : 'text-muted-foreground'}>Bing Webmaster Tools</span>
                           </div>
                        </div>
                     ) : <Skeleton className="h-12 w-full" /> }
                </CardContent>
                <CardFooter>
                    <Button asChild variant="secondary">
                        <Link href="/admin/seo/webmaster-tools">Configure Webmaster Tools <ArrowRight className="ml-2"/></Link>
                    </Button>
                </CardFooter>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Search Appearance</CardTitle>
                    <CardDescription>Control how your site appears in search results. Manage titles, meta descriptions, and social media settings for your content types.</CardDescription>
                </CardHeader>
                <CardFooter>
                    <Button asChild variant="secondary">
                        <Link href="/admin/seo/search-appearance">Configure Search Appearance <ArrowRight className="ml-2"/></Link>
                    </Button>
                </CardFooter>
            </Card>
            
            <Card>
                <CardHeader>
                    <CardTitle>XML Sitemaps</CardTitle>
                    <CardDescription>Enable and configure XML sitemaps to help search engines better index your site. A sitemap is crucial for SEO performance.</CardDescription>
                </CardHeader>
                <CardContent>
                     {sitemapSettings ? (
                         <div className="flex items-center gap-2">
                             {sitemapSettings.enabled ? <CheckCircle className="text-green-500"/> : <XCircle className="text-destructive"/>}
                             <span className={sitemapSettings.enabled ? '' : 'text-muted-foreground'}>XML Sitemap is {sitemapSettings.enabled ? 'Enabled' : 'Disabled'}</span>
                             {sitemapSettings.enabled && <Button asChild variant="link" size="sm"><Link href="/sitemap.xml" target="_blank">View Sitemap <ExternalLink className="ml-2 h-4 w-4"/></Link></Button>}
                        </div>
                     ) : <Skeleton className="h-8 w-full" />}
                </CardContent>
                <CardFooter>
                     <Button asChild variant="secondary">
                        <Link href="/admin/seo/sitemaps">Sitemap Settings <ArrowRight className="ml-2"/></Link>
                    </Button>
                </CardFooter>
            </Card>

             <Card>
                <CardHeader>
                    <CardTitle>Social Networks</CardTitle>
                    <CardDescription>Configure how your site appears when shared on social media like Facebook and X (formerly Twitter). Set default images and profiles.</CardDescription>
                </CardHeader>
                 <CardFooter>
                     <Button asChild variant="secondary">
                        <Link href="/admin/seo/search-appearance?tab=social">Social Settings <ArrowRight className="ml-2"/></Link>
                    </Button>
                </CardFooter>
            </Card>

             <Card>
                <CardHeader>
                    <CardTitle>Tools</CardTitle>
                    <CardDescription>Use our powerful tools to import and export your SEO settings, or edit your robots.txt and .htaccess files.</CardDescription>
                </CardHeader>
                 <CardFooter>
                     <Button asChild variant="secondary">
                        <Link href="/admin/seo/tools">SEO Tools <ArrowRight className="ml-2"/></Link>
                    </Button>
                </CardFooter>
            </Card>
         </div>
      </main>
      <ConfigurationWizard isOpen={isWizardOpen} onOpenChange={setIsWizardOpen} />
    </>
  );
}
