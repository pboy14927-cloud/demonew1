

'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { Toggle, ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle';
import { Upload } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Switch } from '@/components/ui/switch';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { getSeoSettings, SeoSettings, updateSeoSettings, Media, getBrandingSettings } from '@/lib/data';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';
import MediaLibraryModal from '@/components/admin/media-library-modal';

const SmartTag = ({ tag, variable, onClick }: { tag: string; variable: string; onClick: (tag: string) => void }) => (
    <Button
        type="button"
        variant="outline"
        size="sm"
        className="h-auto px-2 py-1 text-xs"
        onClick={() => onClick(variable)}
    >
        + {tag}
    </Button>
);


export default function SearchAppearancePage() {
    const { toast } = useToast();
    const [settings, setSettings] = useState<SeoSettings | null>(null);
    const [siteUrl, setSiteUrl] = useState('');
    const [siteTitle, setSiteTitle] = useState('');

    const [activeContentType, setActiveContentType] = useState('posts');
    const [activeTaxonomy, setActiveTaxonomy] = useState('categories');
    const [previewMode, setPreviewMode] = useState<'desktop' | 'mobile'>('desktop');
    const [isMediaDialogOpen, setIsMediaDialogOpen] = useState(false);
    const [mediaTarget, setMediaTarget] = useState<keyof SeoSettings['social'] | 'organizationLogo' | null>(null);

    useEffect(() => {
        const loadData = async () => {
            const seoData = await getSeoSettings();
            const brandingData = await getBrandingSettings();
            setSettings(seoData);
            setSiteUrl(brandingData.siteUrl || '');
            setSiteTitle(brandingData.websiteTitle || '');
        }
        loadData();
    }, []);

    const handleSettingChange = (key: keyof SeoSettings, value: any) => {
        setSettings(prev => prev ? { ...prev, [key]: value } : null);
    };
    
    const handleKnowledgeGraphChange = (key: keyof SeoSettings['knowledgeGraph'], value: any) => {
        setSettings(prev => {
            if (!prev) return null;
            return {
                ...prev,
                knowledgeGraph: {
                    ...prev.knowledgeGraph,
                    [key]: value
                }
            }
        });
    }

    const handleContentSettingChange = (type: 'posts' | 'pages', key: string, value: any) => {
        setSettings(prev => {
            if (!prev) return null;
            return {
                ...prev,
                contentTypes: {
                    ...prev.contentTypes,
                    [type]: {
                        // @ts-ignore
                        ...prev.contentTypes[type],
                        [key]: value
                    }
                }
            }
        });
    };
    
    const handleTaxonomySettingChange = (type: 'categories' | 'tags', key: string, value: any) => {
        setSettings(prev => {
            if (!prev) return null;
            return {
                ...prev,
                taxonomies: {
                    ...prev.taxonomies,
                    [type]: {
                        // @ts-ignore
                        ...prev.taxonomies[type],
                        [key]: value
                    }
                }
            }
        });
    };

    const handleSocialChange = (key: keyof SeoSettings['social'], value: any) => {
        setSettings(prev => prev ? ({ ...prev, social: { ...prev.social, [key]: value } }) : null);
    };
    
    const handleArchiveChange = (key: keyof SeoSettings['archives'], value: any) => {
        setSettings(prev => prev ? ({ ...prev, archives: { ...prev.archives, [key]: value } }) : null);
    };

    const handleInsertTag = (updateFn: (value: string) => void) => (tag: string) => {
        updateFn(tag);
    };

    const createTagInserter = (currentValue: string, setter: (value: string) => void) => (tag: string) => {
        setter(`${currentValue || ''} ${tag}`.trim());
    }

    const handleSaveChanges = async () => {
        if (!settings) return;
        try {
            await updateSeoSettings(settings);
            toast({ title: 'Settings saved successfully' });
        } catch {
            toast({ variant: 'destructive', title: 'Error saving settings' });
        }
    };

    const openMediaLibrary = (target: keyof SeoSettings['social'] | 'organizationLogo') => {
        setMediaTarget(target);
        setIsMediaDialogOpen(true);
    }
    
    const handleMediaSelect = (media: Media) => {
        if (mediaTarget) {
            if(mediaTarget === 'organizationLogo') {
                handleKnowledgeGraphChange('organizationLogo', media.url);
            } else {
                 handleSocialChange(mediaTarget, media.url);
            }
        }
        setIsMediaDialogOpen(false);
        setMediaTarget(null);
    }
    
    const replaceTags = (template: string | undefined | null, postData?: {title?: string, excerpt?: string}) => {
        if (!settings || !template) return '';
        let result = template;
        result = result.replace(/\{\{site_title\}\}/g, siteTitle);
        result = result.replace(/\{\{sep\}\}/g, settings.separator);
        result = result.replace(/\{\{tagline\}\}/g, settings.knowledgeGraph?.organizationDescription || '');
        if (postData) {
            result = result.replace(/\{\{post_title\}\}/g, postData.title || '');
            result = result.replace(/\{\{page_title\}\}/g, postData.title || '');
            result = result.replace(/\{\{term_title\}\}/g, postData.title || '');
            result = result.replace(/\{\{post_excerpt\}\}/g, postData.excerpt || '');
            result = result.replace(/\{\{page_excerpt\}\}/g, postData.excerpt || '');
            result = result.replace(/\{\{term_description\}\}/g, postData.excerpt || '');
        }
        return result;
    };


    if (!settings) {
        return (
             <main className="p-6">
                <div className="flex items-center justify-between pb-6">
                    <Skeleton className="h-8 w-64" />
                    <Skeleton className="h-10 w-24" />
                </div>
                <Card>
                    <CardHeader><Skeleton className="h-6 w-1/3" /></CardHeader>
                    <CardContent><Skeleton className="h-64 w-full" /></CardContent>
                </Card>
            </main>
        )
    }

    return (
        <main className="p-6">
            <div className="flex items-center justify-between pb-6">
                <h1 className="text-2xl font-semibold">Search Appearance</h1>
                <Button onClick={handleSaveChanges}>Save Changes</Button>
            </div>

            <Tabs defaultValue="global-settings" className="w-full">
                <TabsList className="grid w-full grid-cols-5 max-w-2xl">
                    <TabsTrigger value="global-settings">Global Settings</TabsTrigger>
                    <TabsTrigger value="content-types">Content Types</TabsTrigger>
                    <TabsTrigger value="social">Social</TabsTrigger>
                    <TabsTrigger value="taxonomies">Taxonomies</TabsTrigger>
                    <TabsTrigger value="archives">Archives</TabsTrigger>
                </TabsList>
                
                <TabsContent value="global-settings">
                    <Card>
                        <CardHeader>
                            <CardTitle>Global Settings</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-8">
                            <Card>
                                <CardContent className="pt-6 space-y-2">
                                     <Label htmlFor="title-separator">Title Separator</Label>
                                    <Select value={settings.separator} onValueChange={(v: string) => handleSettingChange('separator', v)}>
                                        <SelectTrigger id="title-separator" className="w-48">
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="-">-</SelectItem>
                                            <SelectItem value="–">–</SelectItem>
                                            <SelectItem value="—">—</SelectItem>
                                            <SelectItem value="|">|</SelectItem>
                                            <SelectItem value="*">*</SelectItem>
                                            <SelectItem value="»">»</SelectItem>
                                        </SelectContent>
                                    </Select>
                                    <p className="text-sm text-muted-foreground">Choose the separator that appears between your post title and site title.</p>
                                </CardContent>
                            </Card>

                            <Separator />
                            
                            <Card>
                                <CardHeader>
                                    <h3 className="text-lg font-semibold">Homepage</h3>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    <div>
                                        <Label>Google Preview</Label>
                                         <ToggleGroup type="single" value={previewMode} onValueChange={(value: 'desktop' | 'mobile') => value && setPreviewMode(value)} className="mb-2">
                                            <ToggleGroupItem value="desktop">Desktop result</ToggleGroupItem>
                                            <ToggleGroupItem value="mobile">Mobile result</ToggleGroupItem>
                                        </ToggleGroup>
                                        <div className={cn("p-4 border rounded-lg transition-all", previewMode === 'mobile' ? 'max-w-sm' : '')}>
                                            <p className="text-sm text-green-700">{siteUrl}</p>
                                            <p className="text-lg font-bold text-blue-600">{replaceTags(settings.homepageTitle)}</p>
                                            <p className="text-sm text-muted-foreground line-clamp-2">{replaceTags(settings.homepageDescription) || 'This is a sample meta description for your homepage.'}</p>
                                        </div>
                                    </div>

                                    <div className="space-y-4 mt-4">
                                        <div className="space-y-2">
                                            <Label htmlFor="homepage-title">Homepage SEO Title</Label>
                                            <div className="flex gap-1 flex-wrap">
                                                <SmartTag tag="Site Title" variable="{{site_title}}" onClick={createTagInserter(settings.homepageTitle, (v) => handleSettingChange('homepageTitle', v))} />
                                                <SmartTag tag="Separator" variable="{{sep}}" onClick={createTagInserter(settings.homepageTitle, (v) => handleSettingChange('homepageTitle', v))} />
                                                <SmartTag tag="Tagline" variable="{{tagline}}" onClick={createTagInserter(settings.homepageTitle, (v) => handleSettingChange('homepageTitle', v))} />
                                            </div>
                                            <Input id="homepage-title" value={settings.homepageTitle || ''} onChange={e => handleSettingChange('homepageTitle', e.target.value)} />
                                        </div>
                                        <div className="space-y-2">
                                            <Label htmlFor="homepage-description">Homepage Meta Description</Label>
                                            <div className="flex gap-1 flex-wrap">
                                                 <SmartTag tag="Site Title" variable="{{site_title}}" onClick={createTagInserter(settings.homepageDescription, (v) => handleSettingChange('homepageDescription', v))} />
                                                 <SmartTag tag="Separator" variable="{{sep}}" onClick={createTagInserter(settings.homepageDescription, (v) => handleSettingChange('homepageDescription', v))} />
                                                 <SmartTag tag="Tagline" variable="{{tagline}}" onClick={createTagInserter(settings.homepageDescription, (v) => handleSettingChange('homepageDescription', v))} />
                                            </div>
                                            <Textarea id="homepage-description" value={settings.homepageDescription || ''} onChange={e => handleSettingChange('homepageDescription', e.target.value)} />
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                            
                            <Separator />

                            <Card>
                                 <CardHeader>
                                    <h3 className="text-lg font-semibold">Knowledge Graph</h3>
                                 </CardHeader>
                                 <CardContent className="space-y-4">
                                    <div className="space-y-2">
                                        <Label>Person or Organization</Label>
                                        <RadioGroup value={settings.knowledgeGraph.type} onValueChange={(v: 'person' | 'organization') => handleKnowledgeGraphChange('type', v)} className="flex items-center gap-4">
                                            <div className="flex items-center space-x-2">
                                                <RadioGroupItem value="person" id="person"/>
                                                <Label htmlFor="person" className="font-normal">Person</Label>
                                            </div>
                                            <div className="flex items-center space-x-2">
                                                <RadioGroupItem value="organization" id="organization" />
                                                <Label htmlFor="organization" className="font-normal">Organization</Label>
                                            </div>
                                        </RadioGroup>
                                    </div>
                                    {settings.knowledgeGraph.type === 'organization' ? (
                                        <div className="space-y-4">
                                            <div className="space-y-2">
                                                <Label htmlFor="organization-name">Organization Name</Label>
                                                <Input id="organization-name" value={settings.knowledgeGraph.organizationName || ''} onChange={e => handleKnowledgeGraphChange('organizationName', e.target.value)} />
                                            </div>
                                            <div className="space-y-2">
                                                <Label htmlFor="organization-description">Organization Description</Label>
                                                <Textarea id="organization-description" value={settings.knowledgeGraph.organizationDescription || ''} onChange={e => handleKnowledgeGraphChange('organizationDescription', e.target.value)} />
                                            </div>
                                            <div className="space-y-2">
                                                <Label htmlFor="phone-number">Phone Number</Label>
                                                <Input id="phone-number" type="tel" value={settings.knowledgeGraph.phoneNumber || ''} onChange={e => handleKnowledgeGraphChange('phoneNumber', e.target.value)} />
                                            </div>
                                            <div className="space-y-2">
                                                <Label htmlFor="contact-email">Contact Email</Label>
                                                <Input id="contact-email" type="email" value={settings.knowledgeGraph.contactEmail || ''} onChange={e => handleKnowledgeGraphChange('contactEmail', e.target.value)} />
                                            </div>
                                            <div className="space-y-2">
                                                <Label htmlFor="organization-logo">Logo</Label>
                                                <div className="flex items-center gap-4">
                                                    {settings.knowledgeGraph.organizationLogo && <img src={settings.knowledgeGraph.organizationLogo} data-ai-hint="company logo" alt="Logo Preview" className="h-20 w-20 object-contain border rounded-md p-1" />}
                                                    <div className="w-full">
                                                        <Button type="button" variant="outline" className="w-full" onClick={() => openMediaLibrary('organizationLogo')}>
                                                            <Upload className="mr-2" /> 
                                                            Upload or Select Logo
                                                        </Button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    ) : (
                                        <div className="space-y-2">
                                            <Label htmlFor="user-name">Name</Label>
                                            <Input id="user-name" value={settings.knowledgeGraph.personName || ''} onChange={e => handleKnowledgeGraphChange('personName', e.target.value)} placeholder="Your full name" />
                                        </div>
                                    )}
                                </CardContent>
                            </Card>
                        </CardContent>
                    </Card>
                </TabsContent>
                
                <TabsContent value="content-types">
                   <Card>
                        <CardHeader>
                            <CardTitle>Content Type SEO Defaults</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                                <div className="md:col-span-1">
                                    <div className="flex flex-col space-y-1">
                                        <Button
                                            variant="ghost"
                                            onClick={() => setActiveContentType('posts')}
                                            className={cn("justify-start", activeContentType === 'posts' && 'bg-accent')}
                                        >
                                            Posts
                                        </Button>
                                        <Button
                                            variant="ghost"
                                            onClick={() => setActiveContentType('pages')}
                                            className={cn("justify-start", activeContentType === 'pages' && 'bg-accent')}
                                        >
                                            Pages
                                        </Button>
                                    </div>
                                </div>
                                <div className="md:col-span-3">
                                    {activeContentType === 'posts' && (
                                        <div className="space-y-6">
                                            <div className="flex items-center justify-between rounded-lg border p-4">
                                                <div>
                                                    <Label htmlFor="post-show-in-search">Show in Search Results</Label>
                                                    <p className="text-xs text-muted-foreground">Choose whether your Posts should be included in search results.</p>
                                                </div>
                                                <Switch id="post-show-in-search" checked={settings.contentTypes.posts.showInSearchResults} onCheckedChange={(c: boolean) => handleContentSettingChange('posts', 'showInSearchResults', c)} />
                                            </div>
                                            <div className="space-y-2">
                                                <Label htmlFor="post-title-template">Post Title</Label>
                                                 <div className="flex gap-1 flex-wrap">
                                                    <SmartTag tag="Post Title" variable="{{post_title}}" onClick={createTagInserter(settings.contentTypes.posts.titleTemplate, (v) => handleContentSettingChange('posts', 'titleTemplate', v))} />
                                                    <SmartTag tag="Site Title" variable="{{site_title}}" onClick={createTagInserter(settings.contentTypes.posts.titleTemplate, (v) => handleContentSettingChange('posts', 'titleTemplate', v))} />
                                                    <SmartTag tag="Separator" variable="{{sep}}" onClick={createTagInserter(settings.contentTypes.posts.titleTemplate, (v) => handleContentSettingChange('posts', 'titleTemplate', v))} />
                                                    <SmartTag tag="Tagline" variable="{{tagline}}" onClick={createTagInserter(settings.contentTypes.posts.titleTemplate, (v) => handleContentSettingChange('posts', 'titleTemplate', v))} />
                                                </div>
                                                <Input id="post-title-template" value={settings.contentTypes.posts.titleTemplate || ''} onChange={e => handleContentSettingChange('posts', 'titleTemplate', e.target.value)} />
                                            </div>
                                            <div className="space-y-2">
                                                <Label htmlFor="post-meta-description">Meta Description</Label>
                                                 <div className="flex gap-1 flex-wrap">
                                                    <SmartTag tag="Post Excerpt" variable="{{post_excerpt}}" onClick={createTagInserter(settings.contentTypes.posts.metaDescription, (v) => handleContentSettingChange('posts', 'metaDescription', v))} />
                                                    <SmartTag tag="Site Title" variable="{{site_title}}" onClick={createTagInserter(settings.contentTypes.posts.metaDescription, (v) => handleContentSettingChange('posts', 'metaDescription', v))} />
                                                    <SmartTag tag="Separator" variable="{{sep}}" onClick={createTagInserter(settings.contentTypes.posts.metaDescription, (v) => handleContentSettingChange('posts', 'metaDescription', v))} />
                                                    <SmartTag tag="Tagline" variable="{{tagline}}" onClick={createTagInserter(settings.contentTypes.posts.metaDescription, (v) => handleContentSettingChange('posts', 'metaDescription', v))} />
                                                </div>
                                                <Textarea id="post-meta-description" value={settings.contentTypes.posts.metaDescription || ''} onChange={e => handleContentSettingChange('posts', 'metaDescription', e.target.value)} />
                                            </div>
                                        </div>
                                    )}
                                    {activeContentType === 'pages' && (
                                        <div className="space-y-6">
                                            <div className="flex items-center justify-between rounded-lg border p-4">
                                                <div>
                                                    <Label htmlFor="page-show-in-search">Show in Search Results</Label>
                                                    <p className="text-xs text-muted-foreground">Choose whether your Pages should be included in search results.</p>
                                                </div>
                                                <Switch id="page-show-in-search" checked={settings.contentTypes.pages.showInSearchResults} onCheckedChange={(c: boolean) => handleContentSettingChange('pages', 'showInSearchResults', c)} />
                                            </div>
                                            <div className="space-y-2">
                                                <Label htmlFor="page-title-template">Page Title</Label>
                                                <div className="flex gap-1 flex-wrap">
                                                    <SmartTag tag="Page Title" variable="{{page_title}}" onClick={createTagInserter(settings.contentTypes.pages.titleTemplate, (v) => handleContentSettingChange('pages', 'titleTemplate', v))} />
                                                    <SmartTag tag="Site Title" variable="{{site_title}}" onClick={createTagInserter(settings.contentTypes.pages.titleTemplate, (v) => handleContentSettingChange('pages', 'titleTemplate', v))} />
                                                    <SmartTag tag="Separator" variable="{{sep}}" onClick={createTagInserter(settings.contentTypes.pages.titleTemplate, (v) => handleContentSettingChange('pages', 'titleTemplate', v))} />
                                                    <SmartTag tag="Tagline" variable="{{tagline}}" onClick={createTagInserter(settings.contentTypes.pages.titleTemplate, (v) => handleContentSettingChange('pages', 'titleTemplate', v))} />
                                                </div>
                                                <Input id="page-title-template" value={settings.contentTypes.pages.titleTemplate || ''} onChange={e => handleContentSettingChange('pages', 'titleTemplate', e.target.value)} />
                                            </div>
                                            <div className="space-y-2">
                                                <Label htmlFor="page-meta-description">Meta Description</Label>
                                                 <div className="flex gap-1 flex-wrap">
                                                    <SmartTag tag="Page Excerpt" variable="{{page_excerpt}}" onClick={createTagInserter(settings.contentTypes.pages.metaDescription, (v) => handleContentSettingChange('pages', 'metaDescription', v))} />
                                                    <SmartTag tag="Site Title" variable="{{site_title}}" onClick={createTagInserter(settings.contentTypes.pages.metaDescription, (v) => handleContentSettingChange('pages', 'metaDescription', v))} />
                                                    <SmartTag tag="Separator" variable="{{sep}}" onClick={createTagInserter(settings.contentTypes.pages.metaDescription, (v) => handleContentSettingChange('pages', 'metaDescription', v))} />
                                                    <SmartTag tag="Tagline" variable="{{tagline}}" onClick={createTagInserter(settings.contentTypes.pages.metaDescription, (v) => handleContentSettingChange('pages', 'metaDescription', v))} />
                                                </div>
                                                <Textarea id="page-meta-description" value={settings.contentTypes.pages.metaDescription || ''} onChange={e => handleContentSettingChange('pages', 'metaDescription', e.target.value)} />
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="social">
                    <Card>
                        <CardHeader>
                            <CardTitle>Social Settings</CardTitle>
                            <CardDescription>Configure how your site appears when shared on social media.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                           <Card>
                             <CardContent className="pt-6 space-y-2">
                                <Label htmlFor="og-image-url">Default Open Graph Image</Label>
                                <p className="text-sm text-muted-foreground">This image will be used when a post or page does not have its own featured image.</p>
                                {settings.social.ogImageUrl && <img src={settings.social.ogImageUrl} data-ai-hint="social media preview" alt="OG Image Preview" className="mt-2 rounded-md border max-w-sm" />}
                                <div className="flex items-center gap-2 mt-2">
                                    <Input id="og-image-url" value={settings.social.ogImageUrl || ''} onChange={e => handleSocialChange('ogImageUrl', e.target.value)} placeholder="https://example.com/default-social-image.jpg" />
                                    <Button type="button" variant="outline" onClick={() => openMediaLibrary('ogImageUrl')}><Upload className="mr-2 h-4 w-4" /> Upload</Button>
                                </div>
                             </CardContent>
                           </Card>
                            <Separator />
                            <Card>
                                <CardHeader><h3 className="text-lg font-semibold">Homepage Facebook Settings</h3></CardHeader>
                                <CardContent className="space-y-4">
                                     <div className="space-y-2">
                                        <Label htmlFor="fb-title">Facebook Title</Label>
                                        <Input id="fb-title" value={settings.social.facebookTitle || ''} onChange={e => handleSocialChange('facebookTitle', e.target.value)} placeholder="Your site's title for Facebook" />
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="fb-description">Facebook Description</Label>
                                        <Textarea id="fb-description" value={settings.social.facebookDescription || ''} onChange={e => handleSocialChange('facebookDescription', e.target.value)} placeholder="Your site's description for Facebook" />
                                    </div>
                                </CardContent>
                            </Card>
                            <Separator />
                            <Card>
                                 <CardHeader><h3 className="text-lg font-semibold">Homepage X (formerly Twitter) Settings</h3></CardHeader>
                                <CardContent className="space-y-4">
                                <div className="space-y-2">
                                    <Label htmlFor="twitter-title">X Title</Label>
                                    <Input id="twitter-title" value={settings.social.twitterTitle || ''} onChange={e => handleSocialChange('twitterTitle', e.target.value)} placeholder="Your site's title for X" />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="twitter-description">X Description</Label>
                                    <Textarea id="twitter-description" value={settings.social.twitterDescription || ''} onChange={e => handleSocialChange('twitterDescription', e.target.value)} placeholder="Your site's description for X" />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="twitter-image">X Image</Label>
                                    {settings.social.twitterImage && <img src={settings.social.twitterImage} data-ai-hint="social media preview" alt="Twitter Image Preview" className="mt-2 rounded-md border max-w-sm" />}
                                    <div className="flex items-center gap-2 mt-2">
                                        <Input id="twitter-image-url" value={settings.social.twitterImage || ''} onChange={e => handleSocialChange('twitterImage', e.target.value)} placeholder="https://example.com/default-twitter-image.jpg" />
                                        <Button type="button" variant="outline" onClick={() => openMediaLibrary('twitterImage')}><Upload className="mr-2 h-4 w-4" /> Upload</Button>
                                    </div>
                                </div>
                                </CardContent>
                            </Card>
                        </CardContent>
                    </Card>
                </TabsContent>
                <TabsContent value="taxonomies">
                     <Card>
                        <CardHeader>
                            <CardTitle>Taxonomy SEO Defaults</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                                <div className="md:col-span-1">
                                    <div className="flex flex-col space-y-1">
                                         <Button
                                            variant="ghost"
                                            onClick={() => setActiveTaxonomy('categories')}
                                            className={cn("justify-start", activeTaxonomy === 'categories' && 'bg-accent')}
                                        >
                                            Categories
                                        </Button>
                                         <Button
                                            variant="ghost"
                                            onClick={() => setActiveTaxonomy('tags')}
                                            className={cn("justify-start", activeTaxonomy === 'tags' && 'bg-accent')}
                                        >
                                            Tags
                                        </Button>
                                    </div>
                                </div>
                                <div className="md:col-span-3">
                                    {activeTaxonomy === 'categories' && (
                                        <div className="space-y-6">
                                            <div className="flex items-center justify-between rounded-lg border p-4">
                                                <div>
                                                    <Label htmlFor="cat-show-in-search">Show in Search Results</Label>
                                                    <p className="text-xs text-muted-foreground">Choose whether your Categories archives should be included in search results.</p>
                                                </div>
                                                <Switch id="cat-show-in-search" checked={settings.taxonomies.categories.showInSearchResults} onCheckedChange={(c: boolean) => handleTaxonomySettingChange('categories', 'showInSearchResults', c)} />
                                            </div>
                                            <div className="space-y-2">
                                                <Label htmlFor="category-title-template">Category Title</Label>
                                                <div className="flex gap-1 flex-wrap">
                                                    <SmartTag tag="Term Title" variable="{{term_title}}" onClick={createTagInserter(settings.taxonomies.categories.titleTemplate, (v) => handleTaxonomySettingChange('categories', 'titleTemplate', v))} />
                                                    <SmartTag tag="Category Name" variable="{{category_name}}" onClick={createTagInserter(settings.taxonomies.categories.titleTemplate, (v) => handleTaxonomySettingChange('categories', 'titleTemplate', v))} />
                                                    <SmartTag tag="Site Title" variable="{{site_title}}" onClick={createTagInserter(settings.taxonomies.categories.titleTemplate, (v) => handleTaxonomySettingChange('categories', 'titleTemplate', v))} />
                                                    <SmartTag tag="Separator" variable="{{sep}}" onClick={createTagInserter(settings.taxonomies.categories.titleTemplate, (v) => handleTaxonomySettingChange('categories', 'titleTemplate', v))} />
                                                </div>
                                                <Input id="category-title-template" value={settings.taxonomies.categories.titleTemplate || ''} onChange={e => handleTaxonomySettingChange('categories', 'titleTemplate', e.target.value)} />
                                            </div>
                                             <div className="space-y-2">
                                                <Label htmlFor="category-meta-description">Meta Description</Label>
                                                <div className="flex gap-1 flex-wrap">
                                                    <SmartTag tag="Term Description" variable="{{term_description}}" onClick={createTagInserter(settings.taxonomies.categories.metaDescription, (v) => handleTaxonomySettingChange('categories', 'metaDescription', v))} />
                                                </div>
                                                <Textarea id="category-meta-description" value={settings.taxonomies.categories.metaDescription || ''} onChange={e => handleTaxonomySettingChange('categories', 'metaDescription', e.target.value)} />
                                            </div>
                                        </div>
                                    )}
                                     {activeTaxonomy === 'tags' && (
                                        <div className="space-y-6">
                                            <div className="flex items-center justify-between rounded-lg border p-4">
                                                <div>
                                                    <Label htmlFor="tag-show-in-search">Show in Search Results</Label>
                                                    <p className="text-xs text-muted-foreground">Choose whether your Tags archives should be included in search results.</p>
                                                </div>
                                                <Switch id="tag-show-in-search" checked={settings.taxonomies.tags.showInSearchResults} onCheckedChange={(c: boolean) => handleTaxonomySettingChange('tags', 'showInSearchResults', c)} />
                                            </div>
                                            <div className="space-y-2">
                                                <Label htmlFor="tag-title-template">Tag Title</Label>
                                                 <div className="flex gap-1 flex-wrap">
                                                    <SmartTag tag="Term Title" variable="{{term_title}}" onClick={createTagInserter(settings.taxonomies.tags.titleTemplate, (v) => handleTaxonomySettingChange('tags', 'titleTemplate', v))} />
                                                     <SmartTag tag="Tag Name" variable="{{tag_name}}" onClick={createTagInserter(settings.taxonomies.tags.titleTemplate, (v) => handleTaxonomySettingChange('tags', 'titleTemplate', v))} />
                                                    <SmartTag tag="Site Title" variable="{{site_title}}" onClick={createTagInserter(settings.taxonomies.tags.titleTemplate, (v) => handleTaxonomySettingChange('tags', 'titleTemplate', v))} />
                                                    <SmartTag tag="Separator" variable="{{sep}}" onClick={createTagInserter(settings.taxonomies.tags.titleTemplate, (v) => handleTaxonomySettingChange('tags', 'titleTemplate', v))} />
                                                </div>
                                                <Input id="tag-title-template" value={settings.taxonomies.tags.titleTemplate || ''} onChange={e => handleTaxonomySettingChange('tags', 'titleTemplate', e.target.value)} />
                                            </div>
                                            <div className="space-y-2">
                                                <Label htmlFor="tag-meta-description">Meta Description</Label>
                                                 <div className="flex gap-1 flex-wrap">
                                                    <SmartTag tag="Term Description" variable="{{term_description}}" onClick={createTagInserter(settings.taxonomies.tags.metaDescription, (v) => handleTaxonomySettingChange('tags', 'metaDescription', v))} />
                                                </div>
                                                <Textarea id="tag-meta-description" value={settings.taxonomies.tags.metaDescription || ''} onChange={e => handleTaxonomySettingChange('tags', 'metaDescription', e.target.value)} />
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </CardContent>
                     </Card>
                </TabsContent>
                 <TabsContent value="archives">
                     <Card>
                        <CardHeader>
                            <CardTitle>Archives</CardTitle>
                             <CardDescription>Define the default SEO title structure for your author and date archives.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            <div className="space-y-2">
                                <Label htmlFor="author-archive-title">Author Archive Title</Label>
                                <div className="flex gap-1 flex-wrap mb-2">
                                    <SmartTag tag="Author Name" variable="{{author_name}}" onClick={createTagInserter(settings.archives.authorArchiveTitle, (v) => handleArchiveChange('authorArchiveTitle', v))} />
                                    <SmartTag tag="Site Title" variable="{{site_title}}" onClick={createTagInserter(settings.archives.authorArchiveTitle, (v) => handleArchiveChange('authorArchiveTitle', v))} />
                                    <SmartTag tag="Separator" variable="{{sep}}" onClick={createTagInserter(settings.archives.authorArchiveTitle, (v) => handleArchiveChange('authorArchiveTitle', v))} />
                                </div>
                                <Input id="author-archive-title" value={settings.archives.authorArchiveTitle || ''} onChange={e => handleArchiveChange('authorArchiveTitle', e.target.value)} />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="date-archive-title">Date Archive Title</Label>
                                <div className="flex gap-1 flex-wrap mb-2">
                                    <SmartTag tag="Date" variable="{{date}}" onClick={createTagInserter(settings.archives.dateArchiveTitle, (v) => handleArchiveChange('dateArchiveTitle', v))} />
                                    <SmartTag tag="Site Title" variable="{{site_title}}" onClick={createTagInserter(settings.archives.dateArchiveTitle, (v) => handleArchiveChange('dateArchiveTitle', v))} />
                                    <SmartTag tag="Separator" variable="{{sep}}" onClick={createTagInserter(settings.archives.dateArchiveTitle, (v) => handleArchiveChange('dateArchiveTitle', v))} />
                                </div>
                                <Input id="date-archive-title" value={settings.archives.dateArchiveTitle || ''} onChange={e => handleArchiveChange('dateArchiveTitle', e.target.value)} />
                            </div>
                        </CardContent>
                     </Card>
                </TabsContent>
            </Tabs>
             <MediaLibraryModal isOpen={isMediaDialogOpen} onOpenChange={setIsMediaDialogOpen} onSelect={handleMediaSelect} />
        </main>
    );
}
