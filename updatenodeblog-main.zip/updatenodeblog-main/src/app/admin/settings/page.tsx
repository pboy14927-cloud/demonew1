

'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { getPermalinkSettings, updatePermalinkSettings, PermalinkSettings } from '@/lib/data';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';

const PermalinkTag = ({ tag, onClick }: { tag: string; onClick: (tag: string) => void }) => (
    <Button
        type="button"
        variant="secondary"
        size="sm"
        className="h-auto px-2 py-1 text-xs"
        onClick={() => onClick(`%${tag}%/`)}
    >
        {tag}
    </Button>
);


export default function SettingsPage() {
  const { toast } = useToast();
  
  const [loading, setLoading] = useState(true);
  const [permalinks, setPermalinks] = useState<Partial<PermalinkSettings>>({});
  
  useEffect(() => {
    async function loadSettings() {
        setLoading(true);
        const permalinksData = await getPermalinkSettings();
        setPermalinks(permalinksData);
        setLoading(false);
    }
    loadSettings();
  }, []);
  
  const handlePermalinkChange = (key: keyof PermalinkSettings, value: any) => {
    setPermalinks(prev => ({ ...prev, [key]: value }));
  };

  const handleSaveChanges = () => {
    updatePermalinkSettings(permalinks as PermalinkSettings);
    
    toast({
        title: "Settings Saved",
        description: "Your changes have been saved successfully.",
    });
  };
  
  const handlePermalinkStructureChange = (value: string) => {
      setPermalinks(prev => ({ ...prev, structure: value }));
  };

  const handleCustomPermalinkInputChange = (value: string) => {
    // Ensure it starts and ends with a slash if it's not empty
    let newStructure = value;
    if (newStructure && !newStructure.startsWith('/')) {
        newStructure = `/${newStructure}`;
    }
    if (newStructure && !newStructure.endsWith('/') && !newStructure.includes('%post_id%')) {
         newStructure = `${newStructure}/`;
    }
    setPermalinks({ ...permalinks, structure: newStructure });
  };

  const handleInsertPermalinkTag = (tag: string) => {
    const currentStructure = permalinks.structure || '/';
    // Insert tag before the last character (which should be a slash)
    const newStructure = currentStructure.slice(0, -1) + tag;
    handleCustomPermalinkInputChange(newStructure);
  };
  
  if (loading) {
      return (
        <main className="p-6">
            <div className="space-y-6">
                <Skeleton className="h-10 w-1/2" />
                <Card>
                    <CardHeader><Skeleton className="h-8 w-1/4" /></CardHeader>
                    <CardContent className="space-y-6">
                        <Skeleton className="h-10 w-full" />
                        <Skeleton className="h-20 w-full" />
                        <Skeleton className="h-10 w-full" />
                    </CardContent>
                </Card>
            </div>
        </main>
      )
  }
  
  const isCustomStructure = !['/?p=%post_id%', '/%year%/%monthnum%/%day%/%postname%/', '/%year%/%monthnum%/%postname%/', '/archives/%post_id%', '/%postname%/'].includes(permalinks.structure || '');

  return (
    <>
      <main className="p-6">
        <form onSubmit={(e) => { e.preventDefault(); handleSaveChanges(); }}>
            <h1 className="text-2xl font-semibold mb-6">Settings</h1>
            <Card>
                <CardHeader>
                    <CardTitle>Permalink Settings</CardTitle>
                    <CardDescription>
                    Customize your URL structure. By default, ContentDock uses web-friendly URLs.
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <RadioGroup 
                        value={isCustomStructure ? 'custom' : (permalinks.structure || '')} 
                        onValueChange={handlePermalinkStructureChange} 
                        className="space-y-2"
                    >
                        <div className="flex items-center space-x-2">
                            <RadioGroupItem value="/?p=%post_id%" id="permalink-plain" />
                            <Label htmlFor="permalink-plain" className="font-normal w-full">Plain <code className="ml-4 bg-muted text-muted-foreground p-1 rounded">/?p=123</code></Label>
                        </div>
                            <div className="flex items-center space-x-2">
                            <RadioGroupItem value="/%year%/%monthnum%/%day%/%postname%/" id="permalink-day-name" />
                            <Label htmlFor="permalink-day-name" className="font-normal w-full">Day and name <code className="ml-4 bg-muted text-muted-foreground p-1 rounded">/2024/05/26/sample-post/</code></Label>
                        </div>
                            <div className="flex items-center space-x-2">
                            <RadioGroupItem value="/%year%/%monthnum%/%postname%/" id="permalink-month-name" />
                            <Label htmlFor="permalink-month-name" className="font-normal w-full">Month and name <code className="ml-4 bg-muted text-muted-foreground p-1 rounded">/2024/05/sample-post/</code></Label>
                        </div>
                            <div className="flex items-center space-x-2">
                            <RadioGroupItem value="/archives/%post_id%" id="permalink-numeric" />
                            <Label htmlFor="permalink-numeric" className="font-normal w-full">Numeric <code className="ml-4 bg-muted text-muted-foreground p-1 rounded">/archives/123</code></Label>
                        </div>
                            <div className="flex items-center space-x-2">
                            <RadioGroupItem value="/%postname%/" id="permalink-postname" />
                            <Label htmlFor="permalink-postname" className="font-normal w-full">Post name <code className="ml-4 bg-muted text-muted-foreground p-1 rounded">/sample-post/</code></Label>
                        </div>
                        <div className="flex items-start space-x-2 pt-2">
                            <RadioGroupItem value="custom" id="permalink-custom" />
                            <div className="w-full">
                                <Label htmlFor="permalink-custom-input" className="font-normal">Custom Structure</Label>
                                <Input 
                                    id="permalink-custom-input"
                                    className="mt-1 font-mono"
                                    value={permalinks.structure}
                                    onChange={(e) => handleCustomPermalinkInputChange(e.target.value)}
                                    onFocus={() => {
                                        if(!isCustomStructure) {
                                            handleCustomPermalinkInputChange('/%postname%/')
                                        }
                                    }}
                                />
                                <div className="flex flex-wrap gap-1 mt-2">
                                    <PermalinkTag tag="year" onClick={handleInsertPermalinkTag} />
                                    <PermalinkTag tag="monthnum" onClick={handleInsertPermalinkTag} />
                                    <PermalinkTag tag="day" onClick={handleInsertPermalinkTag} />
                                    <PermalinkTag tag="hour" onClick={handleInsertPermalinkTag} />
                                    <PermalinkTag tag="minute" onClick={handleInsertPermalinkTag} />
                                    <PermalinkTag tag="second" onClick={handleInsertPermalinkTag} />
                                    <PermalinkTag tag="post_id" onClick={(t) => handleInsertPermalinkTag('%post_id%')} />
                                    <PermalinkTag tag="postname" onClick={handleInsertPermalinkTag} />
                                    <PermalinkTag tag="category" onClick={handleInsertPermalinkTag} />
                                    <PermalinkTag tag="author" onClick={handleInsertPermalinkTag} />
                                </div>
                            </div>
                        </div>
                    </RadioGroup>

                    <div className="space-y-4 pt-4 border-t">
                        <h4 className="font-semibold">Optional</h4>
                        <p className="text-sm text-muted-foreground">If you like, you may enter custom structures for your category and tag URLs here. For example, using <code className="bg-muted text-muted-foreground p-1 rounded">topics</code> as your category base would make your category links like <code className="bg-muted text-muted-foreground p-1 rounded">/topics/uncategorized/</code>. If you leave these blank the defaults will be used.</p>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
                            <div className="md:col-span-1">
                                <Label htmlFor="category-base">Category base</Label>
                            </div>
                            <div className="md:col-span-2">
                                <Input id="category-base" value={permalinks.categoryBase || ''} onChange={e => handlePermalinkChange('categoryBase', e.target.value)} />
                            </div>
                        </div>
                         <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
                            <div className="md:col-span-1">
                                <Label htmlFor="tag-base">Tag base</Label>
                            </div>
                            <div className="md:col-span-2">
                                <Input id="tag-base" value={permalinks.tagBase || ''} onChange={e => handlePermalinkChange('tagBase', e.target.value)} />
                            </div>
                        </div>
                         <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
                            <div className="md:col-span-1">
                                <Label htmlFor="partner-content-base">Partner Content base</Label>
                            </div>
                            <div className="md:col-span-2">
                                <Input id="partner-content-base" value={permalinks.partnerContentBase || ''} onChange={e => handlePermalinkChange('partnerContentBase', e.target.value)} placeholder="partner-content"/>
                            </div>
                        </div>
                    </div>
                </CardContent>
            </Card>
          <div className="mt-8">
            <Button type="submit">Save Changes</Button>
          </div>
        </form>
      </main>
    </>
  );
}
