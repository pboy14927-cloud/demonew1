
'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { getPartnerPageSettings, getPartnerContent, PartnerPageSettings, Post, updatePartnerPageSettings } from '@/lib/data';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';


const popularFonts = [
    'Inter', 'Roboto', 'Open Sans', 'Lato', 'Montserrat', 'Oswald', 'Raleway', 'Poppins', 'Nunito', 'Merriweather'
];


export default function PartnerAdminPage() {
    const [settings, setSettings] = useState<PartnerPageSettings | null>(null);
    const [partnerContent, setPartnerContent] = useState<Post[]>([]);
    const { toast } = useToast();
    
    useEffect(() => {
        getPartnerPageSettings().then(setSettings);
        getPartnerContent().then(content => {
            // Filter for published content only
            setPartnerContent(content.filter(p => p.status === 'published'));
        });
    }, []);

    const handleSaveChanges = async () => {
        if (!settings) return;
        try {
            await updatePartnerPageSettings(settings);
            toast({
                title: 'Settings Saved',
                description: 'Your partner page settings have been updated.',
            });
        } catch (error) {
            toast({
                variant: 'destructive',
                title: 'Error Saving',
                description: 'There was a problem saving your settings.',
            });
        }
    }
    
    if (!settings) {
        return (
            <main className="p-6">
                 <div className="flex items-center justify-between pb-6">
                    <Skeleton className="h-8 w-64" />
                    <Skeleton className="h-10 w-24" />
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <Card><CardHeader><Skeleton className="h-40 w-full" /></CardHeader></Card>
                    <Card><CardHeader><Skeleton className="h-40 w-full" /></CardHeader></Card>
                </div>
            </main>
        )
    }
    
    const handleContentSelection = (id: string) => {
        setSettings(prev => {
            if (!prev) return null;
            const recommendedContentIds = prev.recommendedContentIds.includes(id)
                ? prev.recommendedContentIds.filter(contentId => contentId !== id)
                : [...prev.recommendedContentIds, id];
            return { ...prev, recommendedContentIds };
        });
    }
    
    const handleStyleChange = (section: keyof Omit<PartnerPageSettings, 'cardStyles'> | 'cardStyles', property: string, value: any, subSection?: keyof PartnerPageSettings['cardStyles']) => {
         setSettings(prev => {
            if (!prev) return null;
            if (section === 'cardStyles' && subSection) {
                 return {
                    ...prev,
                    cardStyles: {
                        ...prev.cardStyles,
                        [subSection]: {
                            // @ts-ignore
                            ...prev.cardStyles[subSection],
                            [property]: value
                        }
                    }
                 }
            }
             return {
                ...prev,
                [section as keyof PartnerPageSettings]: {
                    // @ts-ignore
                    ...prev[section],
                    [property]: value
                }
            }
        });
    };
    
    const handleGradientChange = (section: keyof Pick<PartnerPageSettings, 'titleStyles' | 'descriptionStyles' | 'recommendedContentStyles'> | keyof PartnerPageSettings['cardStyles'], property: 'from' | 'to' | 'direction', value: any) => {
      setSettings(prev => {
          if (!prev) return null;

          const sectionsWithGradient = ['titleStyles', 'descriptionStyles', 'recommendedContentStyles', 'categoryStyles', 'thumbnailOverlayGradient'];
          if (!sectionsWithGradient.includes(section)) return prev;

          // Type assertion to tell TypeScript that section is one of the keys that have a gradient property.
          const sectionKey = section as 'titleStyles' | 'descriptionStyles' | 'recommendedContentStyles' | 'categoryStyles' | 'thumbnailOverlayGradient';
          
          let newState = { ...prev };
          
          if (sectionKey === 'categoryStyles') {
               newState.cardStyles.categoryStyles.gradient = {
                    ...newState.cardStyles.categoryStyles.gradient,
                    [property]: value
               }
          } else if (sectionKey === 'thumbnailOverlayGradient') {
              newState.cardStyles.thumbnailOverlayGradient = {
                    ...newState.cardStyles.thumbnailOverlayGradient,
                    [property]: value
              }
          } else {
              // This handles titleStyles, descriptionStyles, recommendedContentStyles
              const pageSection = sectionKey as 'titleStyles' | 'descriptionStyles' | 'recommendedContentStyles';
              newState[pageSection].gradient = {
                    ...newState[pageSection].gradient,
                    [property]: value
              }
          }

          return newState;
      });
  };


  return (
    <main className="p-6">
      <div className="flex items-center justify-between pb-6">
        <h1 className="text-2xl font-semibold">Partner Page Settings</h1>
        <Button onClick={handleSaveChanges}>Save Changes</Button>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
        <div className="space-y-6">
            <Card>
                <CardHeader>
                <CardTitle>Page Content</CardTitle>
                <CardDescription>Manage the main title and description for your public partner page.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="partner-title">Title</Label>
                        <Input 
                            id="partner-title" 
                            value={settings.title}
                            onChange={(e) => setSettings({...settings, title: e.target.value})}
                        />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="partner-description">Description</Label>
                        <Textarea 
                            id="partner-description"
                            value={settings.description}
                            onChange={(e) => setSettings({...settings, description: e.target.value})}
                            rows={4}
                        />
                    </div>
                </CardContent>
            </Card>
            <Card>
                <CardHeader>
                    <CardTitle>Recommended Content</CardTitle>
                    <CardDescription>Select the partner-specific content you want to feature in the "Recommended for you" section.</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-2">
                        <Label htmlFor="recommended-title">Section Title</Label>
                        <Input 
                            id="recommended-title" 
                            value={(settings.recommendedContentStyles as any).title}
                            onChange={(e) => handleStyleChange('recommendedContentStyles', 'title', e.target.value)}
                        />
                    </div>
                    <div className="space-y-2 mt-4 max-h-60 overflow-y-auto border p-3 rounded-md">
                        {partnerContent.map(content => (
                            <div key={content.id} className="flex items-center space-x-2">
                                <Checkbox
                                    id={`content-${content.id}`}
                                    checked={settings.recommendedContentIds.includes(content.id)}
                                    onCheckedChange={() => handleContentSelection(content.id)}
                                />
                                <Label htmlFor={`content-${content.id}`} className="font-normal">{content.title}</Label>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>
            <Card>
                <CardHeader>
                    <CardTitle>Sidebar Settings</CardTitle>
                    <CardDescription>Control the visibility of sidebars on the partner page.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                     <div className="flex items-center justify-between rounded-lg border p-3">
                        <Label htmlFor="show-left-sidebar" className="font-normal">Show Left Sidebar</Label>
                        <Switch id="show-left-sidebar" checked={settings.showLeftSidebar} onCheckedChange={(checked) => setSettings({...settings, showLeftSidebar: checked})} />
                     </div>
                      <div className="flex items-center justify-between rounded-lg border p-3">
                        <Label htmlFor="show-right-sidebar" className="font-normal">Show Right Sidebar</Label>
                        <Switch id="show-right-sidebar" checked={settings.showRightSidebar} onCheckedChange={(checked) => setSettings({...settings, showRightSidebar: checked})} />
                     </div>
                </CardContent>
            </Card>
        </div>
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle>Page Styling</CardTitle>
                    <CardDescription>Customize the appearance of your page content.</CardDescription>
                </CardHeader>
                 <CardContent className="space-y-6">
                    <Accordion type="multiple" defaultValue={['title-styling']}>
                        <AccordionItem value="title-styling">
                             <AccordionTrigger className="text-lg font-semibold">Title Styling</AccordionTrigger>
                             <AccordionContent className="pt-4 space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-2">
                                        <Label>Font Family</Label>
                                        <Select value={settings.titleStyles.fontFamily} onValueChange={(v) => handleStyleChange('titleStyles', 'fontFamily', v)}>
                                            <SelectTrigger><SelectValue /></SelectTrigger>
                                            <SelectContent>
                                                {popularFonts.map(font => <SelectItem key={font} value={font} style={{fontFamily: font}}>{font}</SelectItem>)}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    <div className="space-y-2">
                                        <Label>Font Size (px)</Label>
                                        <Input type="number" value={settings.titleStyles.fontSize} onChange={(e) => handleStyleChange('titleStyles', 'fontSize', parseInt(e.target.value))} />
                                    </div>
                                    <div className="space-y-2">
                                        <Label>Font Weight</Label>
                                        <Select value={settings.titleStyles.fontWeight} onValueChange={(v) => handleStyleChange('titleStyles', 'fontWeight', v)}>
                                            <SelectTrigger><SelectValue /></SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="300">Light</SelectItem><SelectItem value="400">Normal</SelectItem><SelectItem value="500">Medium</SelectItem><SelectItem value="600">Semi-Bold</SelectItem><SelectItem value="700">Bold</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    <div className="space-y-2">
                                        <Label>Text Align</Label>
                                        <Select value={settings.titleStyles.textAlign} onValueChange={(v) => handleStyleChange('titleStyles', 'textAlign', v)}>
                                            <SelectTrigger><SelectValue /></SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="left">Left</SelectItem><SelectItem value="center">Center</SelectItem><SelectItem value="right">Right</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>
                                </div>
                                <div className="space-y-2">
                                    <Label>Color Type</Label>
                                    <RadioGroup value={settings.titleStyles.colorType} onValueChange={(v) => handleStyleChange('titleStyles', 'colorType', v)} className="flex gap-4">
                                        <div className="flex items-center space-x-2"><RadioGroupItem value="solid" id="title-solid" /><Label htmlFor="title-solid">Solid</Label></div>
                                        <div className="flex items-center space-x-2"><RadioGroupItem value="gradient" id="title-gradient" /><Label htmlFor="title-gradient">Gradient</Label></div>
                                    </RadioGroup>
                                </div>
                                {settings.titleStyles.colorType === 'solid' ? (
                                    <div className="space-y-2"><Label>Color</Label><Input type="color" value={settings.titleStyles.color} onChange={(e) => handleStyleChange('titleStyles', 'color', e.target.value)} className="h-10 w-full" /></div>
                                ) : (
                                    <div className="space-y-4 rounded-md border p-4">
                                        <h4 className="text-sm font-medium">Gradient Options</h4>
                                        <div className="grid grid-cols-2 gap-4">
                                            <div className="space-y-2"><Label>From</Label><Input type="color" value={settings.titleStyles.gradient.from} onChange={(e) => handleGradientChange('titleStyles', 'from', e.target.value)} className="h-10 w-full" /></div>
                                            <div className="space-y-2"><Label>To</Label><Input type="color" value={settings.titleStyles.gradient.to} onChange={(e) => handleGradientChange('titleStyles', 'to', e.target.value)} className="h-10 w-full" /></div>
                                        </div>
                                        <div className="space-y-2"><Label>Direction</Label><Select value={settings.titleStyles.gradient.direction} onValueChange={(v) => handleGradientChange('titleStyles', 'direction', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="to right">Left to Right</SelectItem><SelectItem value="to bottom">Top to Bottom</SelectItem><SelectItem value="to bottom right">Top-Left to Bottom-Right</SelectItem></SelectContent></Select></div>
                                    </div>
                                )}
                            </AccordionContent>
                        </AccordionItem>
                        <AccordionItem value="description-styling">
                             <AccordionTrigger className="text-lg font-semibold">Description Styling</AccordionTrigger>
                             <AccordionContent className="pt-4 space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-2"><Label>Font Family</Label><Select value={settings.descriptionStyles.fontFamily} onValueChange={(v) => handleStyleChange('descriptionStyles', 'fontFamily', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{popularFonts.map(font => <SelectItem key={font} value={font} style={{fontFamily: font}}>{font}</SelectItem>)}</SelectContent></Select></div>
                                    <div className="space-y-2"><Label>Font Size (px)</Label><Input type="number" value={settings.descriptionStyles.fontSize} onChange={(e) => handleStyleChange('descriptionStyles', 'fontSize', parseInt(e.target.value))} /></div>
                                    <div className="space-y-2"><Label>Font Weight</Label><Select value={settings.descriptionStyles.fontWeight} onValueChange={(v) => handleStyleChange('descriptionStyles', 'fontWeight', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="300">Light</SelectItem><SelectItem value="400">Normal</SelectItem><SelectItem value="500">Medium</SelectItem><SelectItem value="600">Semi-Bold</SelectItem><SelectItem value="700">Bold</SelectItem></SelectContent></Select></div>
                                    <div className="space-y-2"><Label>Text Align</Label><Select value={settings.descriptionStyles.textAlign} onValueChange={(v) => handleStyleChange('descriptionStyles', 'textAlign', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="left">Left</SelectItem><SelectItem value="center">Center</SelectItem><SelectItem value="right">Right</SelectItem></SelectContent></Select></div>
                                </div>
                                <div className="space-y-2"><Label>Color</Label><Input type="color" value={settings.descriptionStyles.color} onChange={(e) => handleStyleChange('descriptionStyles', 'color', e.target.value)} className="h-10 w-full" /></div>
                            </AccordionContent>
                        </AccordionItem>
                        <AccordionItem value="recommended-styling">
                             <AccordionTrigger className="text-lg font-semibold">Recommended Content Styling</AccordionTrigger>
                             <AccordionContent className="pt-4 space-y-4">
                                 <div className="grid grid-cols-2 gap-4">
                                     <div className="space-y-2"><Label>Font Family</Label><Select value={(settings.recommendedContentStyles as any).fontFamily} onValueChange={(v) => handleStyleChange('recommendedContentStyles', 'fontFamily', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{popularFonts.map(font => <SelectItem key={font} value={font} style={{fontFamily: font}}>{font}</SelectItem>)}</SelectContent></Select></div>
                                     <div className="space-y-2"><Label>Font Size (px)</Label><Input type="number" value={(settings.recommendedContentStyles as any).fontSize} onChange={(e) => handleStyleChange('recommendedContentStyles', 'fontSize', parseInt(e.target.value))} /></div>
                                     <div className="space-y-2"><Label>Font Weight</Label><Select value={(settings.recommendedContentStyles as any).fontWeight} onValueChange={(v) => handleStyleChange('recommendedContentStyles', 'fontWeight', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="300">Light</SelectItem><SelectItem value="400">Normal</SelectItem><SelectItem value="500">Medium</SelectItem><SelectItem value="600">Semi-Bold</SelectItem><SelectItem value="700">Bold</SelectItem></SelectContent></Select></div>
                                     <div className="space-y-2"><Label>Text Align</Label><Select value={(settings.recommendedContentStyles as any).textAlign} onValueChange={(v) => handleStyleChange('recommendedContentStyles', 'textAlign', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="left">Left</SelectItem><SelectItem value="center">Center</SelectItem><SelectItem value="right">Right</SelectItem></SelectContent></Select></div>
                                </div>
                                <div className="space-y-2"><Label>Color</Label><Input type="color" value={(settings.recommendedContentStyles as any).color} onChange={(e) => handleStyleChange('recommendedContentStyles', 'color', e.target.value)} className="h-10 w-full" /></div>
                             </AccordionContent>
                        </AccordionItem>
                        <AccordionItem value="card-styling">
                            <AccordionTrigger className="text-lg font-semibold">Card Styling</AccordionTrigger>
                            <AccordionContent className="pt-4 space-y-4">
                                
                                <Accordion type="multiple" defaultValue={['category']}>
                                    <AccordionItem value="category">
                                        <AccordionTrigger>Category</AccordionTrigger>
                                        <AccordionContent className="pt-4 space-y-4">
                                            <div className="grid grid-cols-2 gap-4">
                                                <div className="space-y-2"><Label>Font Family</Label><Select value={settings.cardStyles.categoryStyles.fontFamily} onValueChange={(v) => handleStyleChange('cardStyles', 'fontFamily', v, 'categoryStyles')}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{popularFonts.map(font => <SelectItem key={font} value={font} style={{fontFamily: font}}>{font}</SelectItem>)}</SelectContent></Select></div>
                                                <div className="space-y-2"><Label>Font Size (px)</Label><Input type="number" value={settings.cardStyles.categoryStyles.fontSize} onChange={(e) => handleStyleChange('cardStyles', 'fontSize', parseInt(e.target.value), 'categoryStyles')} /></div>
                                                <div className="space-y-2"><Label>Font Weight</Label><Select value={settings.cardStyles.categoryStyles.fontWeight} onValueChange={(v) => handleStyleChange('cardStyles', 'fontWeight', v, 'categoryStyles')}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="400">Normal</SelectItem><SelectItem value="500">Medium</SelectItem><SelectItem value="600">Semi-Bold</SelectItem><SelectItem value="700">Bold</SelectItem></SelectContent></Select></div>
                                                <div className="space-y-2"><Label>Text Align</Label><Select value={settings.cardStyles.categoryStyles.textAlign} onValueChange={(v) => handleStyleChange('cardStyles', 'textAlign', v, 'categoryStyles')}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="left">Left</SelectItem><SelectItem value="center">Center</SelectItem><SelectItem value="right">Right</SelectItem></SelectContent></Select></div>
                                            </div>
                                            <div className="space-y-2"><Label>Text Color</Label><Input type="color" value={settings.cardStyles.categoryStyles.color} onChange={(e) => handleStyleChange('cardStyles', 'color', e.target.value, 'categoryStyles')} className="h-10 w-full" /></div>
                                            <div className="space-y-2"><Label>Background Type</Label><RadioGroup value={settings.cardStyles.categoryStyles.backgroundType} onValueChange={(v) => handleStyleChange('cardStyles', 'backgroundType', v, 'categoryStyles')} className="flex gap-4"><div className="flex items-center space-x-2"><RadioGroupItem value="solid" id="cat-bg-solid" /><Label htmlFor="cat-bg-solid">Solid</Label></div><div className="flex items-center space-x-2"><RadioGroupItem value="gradient" id="cat-bg-gradient" /><Label htmlFor="cat-bg-gradient">Gradient</Label></div></RadioGroup></div>
                                            {settings.cardStyles.categoryStyles.backgroundType === 'solid' ? (<div className="space-y-2"><Label>Background Color</Label><Input type="color" value={settings.cardStyles.categoryStyles.backgroundColor} onChange={(e) => handleStyleChange('cardStyles', 'backgroundColor', e.target.value, 'categoryStyles')} className="h-10 w-full" /></div>)
                                            : (<div className="space-y-2 rounded-md border p-4"><div className="grid grid-cols-2 gap-4"><div className="space-y-1"><Label>From</Label><Input type="color" value={settings.cardStyles.categoryStyles.gradient.from} onChange={(e) => handleGradientChange('categoryStyles', 'from', e.target.value)} className="h-10 w-full" /></div><div className="space-y-1"><Label>To</Label><Input type="color" value={settings.cardStyles.categoryStyles.gradient.to} onChange={(e) => handleGradientChange('categoryStyles', 'to', e.target.value)} className="h-10 w-full" /></div></div></div>)}
                                        </AccordionContent>
                                    </AccordionItem>
                                     <AccordionItem value="title">
                                        <AccordionTrigger>Title</AccordionTrigger>
                                        <AccordionContent className="pt-4 space-y-4">
                                            <div className="grid grid-cols-2 gap-4">
                                                <div className="space-y-2"><Label>Font Family</Label><Select value={settings.cardStyles.titleStyles.fontFamily} onValueChange={(v) => handleStyleChange('cardStyles', 'fontFamily', v, 'titleStyles')}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{popularFonts.map(font => <SelectItem key={font} value={font} style={{fontFamily: font}}>{font}</SelectItem>)}</SelectContent></Select></div>
                                                <div className="space-y-2"><Label>Font Size (px)</Label><Input type="number" value={settings.cardStyles.titleStyles.fontSize} onChange={(e) => handleStyleChange('cardStyles', 'fontSize', parseInt(e.target.value), 'titleStyles')} /></div>
                                                <div className="space-y-2"><Label>Font Weight</Label><Select value={settings.cardStyles.titleStyles.fontWeight} onValueChange={(v) => handleStyleChange('cardStyles', 'fontWeight', v, 'titleStyles')}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="400">Normal</SelectItem><SelectItem value="500">Medium</SelectItem><SelectItem value="600">Semi-Bold</SelectItem><SelectItem value="700">Bold</SelectItem></SelectContent></Select></div>
                                            </div>
                                             <div className="grid grid-cols-2 gap-4">
                                                <div className="space-y-2"><Label>Text Color</Label><Input type="color" value={settings.cardStyles.titleStyles.color} onChange={(e) => handleStyleChange('cardStyles', 'color', e.target.value, 'titleStyles')} className="h-10 w-full" /></div>
                                                <div className="space-y-2"><Label>Hover Color</Label><Input type="color" value={settings.cardStyles.titleStyles.hoverColor} onChange={(e) => handleStyleChange('cardStyles', 'hoverColor', e.target.value, 'titleStyles')} className="h-10 w-full" /></div>
                                             </div>
                                        </AccordionContent>
                                    </AccordionItem>
                                     <AccordionItem value="excerpt">
                                        <AccordionTrigger>Excerpt</AccordionTrigger>
                                        <AccordionContent className="pt-4 space-y-4">
                                             <div className="grid grid-cols-2 gap-4">
                                                <div className="space-y-2"><Label>Font Family</Label><Select value={settings.cardStyles.excerptStyles.fontFamily} onValueChange={(v) => handleStyleChange('cardStyles', 'fontFamily', v, 'excerptStyles')}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{popularFonts.map(font => <SelectItem key={font} value={font} style={{fontFamily: font}}>{font}</SelectItem>)}</SelectContent></Select></div>
                                                <div className="space-y-2"><Label>Font Size (px)</Label><Input type="number" value={settings.cardStyles.excerptStyles.fontSize} onChange={(e) => handleStyleChange('cardStyles', 'fontSize', parseInt(e.target.value), 'excerptStyles')} /></div>
                                            </div>
                                             <div className="space-y-2"><Label>Text Color</Label><Input type="color" value={settings.cardStyles.excerptStyles.color} onChange={(e) => handleStyleChange('cardStyles', 'color', e.target.value, 'excerptStyles')} className="h-10 w-full" /></div>
                                        </AccordionContent>
                                    </AccordionItem>
                                </Accordion>

                                <Separator />
                                <div className="space-y-2">
                                     <h4 className="font-medium">Thumbnail Overlay</h4>
                                     <RadioGroup 
                                        value={settings.cardStyles.thumbnailOverlayType} 
                                        onValueChange={(v) => handleStyleChange('cardStyles', 'thumbnailOverlayType', v)}
                                        className="flex gap-4"
                                     >
                                        <div className="flex items-center space-x-2"><RadioGroupItem value="none" id="overlay-none" /><Label htmlFor="overlay-none">None</Label></div>
                                        <div className="flex items-center space-x-2"><RadioGroupItem value="solid" id="overlay-solid" /><Label htmlFor="overlay-solid">Solid</Label></div>
                                        <div className="flex items-center space-x-2"><RadioGroupItem value="gradient" id="overlay-gradient" /><Label htmlFor="overlay-gradient">Gradient</Label></div>
                                    </RadioGroup>
                                    
                                    {settings.cardStyles.thumbnailOverlayType === 'solid' && (
                                        <div className="space-y-2 pt-2">
                                            <Label>Overlay Color</Label>
                                            <Input type="color" value={settings.cardStyles.thumbnailOverlaySolidColor} onChange={(e) => handleStyleChange('cardStyles', 'thumbnailOverlaySolidColor', e.target.value)} className="h-10 w-full" />
                                        </div>
                                    )}
                                    {settings.cardStyles.thumbnailOverlayType === 'gradient' && (
                                        <div className="space-y-4 rounded-md border p-4">
                                            <h4 className="text-sm font-medium">Gradient Options</h4>
                                            <div className="grid grid-cols-2 gap-4">
                                                <div className="space-y-2"><Label>From</Label><Input type="color" value={settings.cardStyles.thumbnailOverlayGradient.from} onChange={(e) => handleGradientChange('thumbnailOverlayGradient', 'from', e.target.value)} className="h-10 w-full" /></div>
                                                <div className="space-y-2"><Label>To</Label><Input type="color" value={settings.cardStyles.thumbnailOverlayGradient.to} onChange={(e) => handleGradientChange('thumbnailOverlayGradient', 'to', e.target.value)} className="h-10 w-full" /></div>
                                            </div>
                                            <div className="space-y-2"><Label>Direction</Label><Select value={settings.cardStyles.thumbnailOverlayGradient.direction} onValueChange={(v) => handleGradientChange('thumbnailOverlayGradient', 'direction', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="to top">Bottom to Top</SelectItem><SelectItem value="to bottom">Top to Bottom</SelectItem><SelectItem value="to left">Right to Left</SelectItem><SelectItem value="to right">Left to Right</SelectItem></SelectContent></Select></div>
                                        </div>
                                    )}
                                     {settings.cardStyles.thumbnailOverlayType !== 'none' && (
                                        <div className="space-y-2 pt-2">
                                            <Label>Overlay Opacity</Label>
                                            <div className="flex items-center gap-4">
                                                <Slider
                                                    value={[settings.cardStyles.thumbnailOverlayOpacity]}
                                                    onValueChange={(v) => handleStyleChange('cardStyles', 'thumbnailOverlayOpacity', v[0])}
                                                    max={1}
                                                    step={0.1}
                                                />
                                                <span className="text-sm text-muted-foreground w-12 text-right">
                                                    {Math.round(settings.cardStyles.thumbnailOverlayOpacity * 100)}%
                                                </span>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </AccordionContent>
                        </AccordionItem>
                    </Accordion>
                 </CardContent>
            </Card>
        </div>
      </div>
    </main>
  );
}

    