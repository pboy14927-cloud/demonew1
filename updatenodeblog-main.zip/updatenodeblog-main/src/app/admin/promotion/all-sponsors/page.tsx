
'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { SponsoredLink, getSponsoredLinks, updateSponsoredLinks } from '@/lib/data';

export default function AllSponsoredLinksPage() {
    const [links, setLinks] = useState<(SponsoredLink & {selected?: boolean})[]>([]);
    const [filteredLinks, setFilteredLinks] = useState<SponsoredLink[]>([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [bulkAction, setBulkAction] = useState('');
    const [itemToDelete, setItemToDelete] = useState<string | null>(null);
    const { toast } = useToast();

    useEffect(() => {
        getSponsoredLinks().then(data => setLinks(data.map(d => ({...d, selected: false}))));
    }, []);

    useEffect(() => {
        setFilteredLinks(
            links.filter(link => 
                link.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                link.url.toLowerCase().includes(searchTerm.toLowerCase())
            )
        );
    }, [searchTerm, links]);

    const toggleSelect = (id: string) => {
        setLinks(prev => prev.map(link => link.id === id ? {...link, selected: !link.selected} : link));
    }

    const toggleSelectAll = (checked: boolean) => {
        setLinks(prev => prev.map(link => filteredLinks.some(fl => fl.id === link.id) ? {...link, selected: checked} : link));
    }

    const handleSaveChanges = async (newLinks: SponsoredLink[]) => {
        try {
            await updateSponsoredLinks(newLinks);
            toast({ title: 'Sponsored links updated successfully!' });
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error saving links' });
        }
    }
    
    const handleDelete = (id: string) => {
        const newLinks = links.filter(link => link.id !== id);
        setLinks(newLinks);
        handleSaveChanges(newLinks);
        setItemToDelete(null);
    }
    
    const handleBulkDelete = () => {
        const newLinks = links.filter(link => !link.selected);
        setLinks(newLinks);
        handleSaveChanges(newLinks);
    }

    const applyBulkAction = () => {
        if(bulkAction === 'delete') {
            handleBulkDelete();
        }
        setBulkAction('');
    }

    const selectedCount = filteredLinks.filter(p => p.selected).length;
    const isAllSelected = selectedCount > 0 && selectedCount === filteredLinks.length;
    const isIndeterminate = selectedCount > 0 && selectedCount < filteredLinks.length;

    return (
        <main className="p-6">
            <div className="flex items-center justify-between pb-4">
                <h1 className="text-2xl font-semibold">All Sponsored Links</h1>
                <Button asChild>
                    <Link href="/admin/promotion/all-sponsors/new">Add New Link</Link>
                </Button>
            </div>
            
             <div className="flex items-center justify-between pb-4">
                <div className="flex items-center space-x-2">
                     <Select value={bulkAction} onValueChange={setBulkAction}>
                        <SelectTrigger className="w-[180px]">
                            <SelectValue placeholder="Bulk actions" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="delete">Delete</SelectItem>
                        </SelectContent>
                    </Select>
                    <Button variant="secondary" onClick={applyBulkAction}>Apply</Button>
                </div>
                <div className="w-full max-w-sm">
                    <Input 
                        placeholder="Search links..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>
            </div>

            <div className="border rounded-lg">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead className="w-[40px]">
                                <Checkbox 
                                    checked={isAllSelected}
                                    onCheckedChange={(checked) => toggleSelectAll(Boolean(checked))}
                                    aria-label="Select all"
                                    data-state={isIndeterminate ? 'indeterminate' : (isAllSelected ? 'checked' : 'unchecked')}
                                />
                            </TableHead>
                            <TableHead>Website Name</TableHead>
                            <TableHead>URL</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {filteredLinks.length > 0 ? filteredLinks.map((link) => (
                            <TableRow key={link.id} data-state={link.selected ? "selected" : "deselected"} className="group">
                                <TableCell>
                                    <Checkbox
                                        checked={!!link.selected}
                                        onCheckedChange={() => toggleSelect(link.id)}
                                    />
                                </TableCell>
                                <TableCell className="font-medium">
                                    <Link href={`/admin/promotion/all-sponsors/edit/${link.id}`} className="hover:text-primary">{link.name}</Link>
                                    <div className="text-xs text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity">
                                        <Link href={`/admin/promotion/all-sponsors/edit/${link.id}`} className="text-primary hover:underline">Edit</Link> | 
                                        <button onClick={() => setItemToDelete(link.id)} className="text-destructive hover:underline px-1">Delete</button>
                                    </div>
                                </TableCell>
                                <TableCell><a href={link.url} target="_blank" rel="noopener noreferrer" className="hover:underline">{link.url}</a></TableCell>
                            </TableRow>
                        )) : (
                            <TableRow>
                                <TableCell colSpan={3} className="text-center text-muted-foreground">No sponsored links found.</TableCell>
                            </TableRow>
                        )}
                    </TableBody>
                </Table>
            </div>
             <AlertDialog open={!!itemToDelete} onOpenChange={(open) => !open && setItemToDelete(null)}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                    <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                    <AlertDialogDescription>
                        This action cannot be undone. This will permanently delete the sponsored link.
                    </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={() => itemToDelete && handleDelete(itemToDelete)}>Delete</AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </main>
    );
}
