
'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { ArrowLeft, Loader2 } from 'lucide-react';
import { getSponsoredLinks, updateSponsoredLinks, SponsoredLink } from '@/lib/data';
import { useToast } from '@/hooks/use-toast';

export default function NewSponsoredLinkPage() {
    const [name, setName] = useState('');
    const [url, setUrl] = useState('');
    const [openInNewTab, setOpenInNewTab] = useState(true);
    const [isLoading, setIsLoading] = useState(false);
    const { toast } = useToast();
    const router = useRouter();

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!name || !url) {
            toast({ variant: 'destructive', title: 'Name and URL are required.' });
            return;
        }

        setIsLoading(true);
        try {
            const currentLinks = await getSponsoredLinks();
            const newLink: SponsoredLink = {
                id: `link-${Date.now()}`,
                name,
                url,
                openInNewTab,
            };
            const updatedLinks = [...currentLinks, newLink];
            await updateSponsoredLinks(updatedLinks);
            toast({ title: 'Sponsored link added successfully!' });
            router.push('/admin/promotion/all-sponsors');
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error adding link.' });
            setIsLoading(false);
        }
    };

    return (
        <main className="p-6">
            <div className="mb-6">
                <Button asChild variant="outline" size="sm">
                    <Link href="/admin/promotion/all-sponsors">
                        <ArrowLeft className="mr-2 h-4 w-4" />
                        Back to All Links
                    </Link>
                </Button>
            </div>
            <h1 className="text-2xl font-semibold mb-6">Add New Sponsored Link</h1>
            <Card className="max-w-2xl">
                <form onSubmit={handleSubmit}>
                    <CardContent className="pt-6 space-y-4">
                        <div className="space-y-2">
                            <Label htmlFor="name">Website Name</Label>
                            <Input id="name" value={name} onChange={e => setName(e.target.value)} required />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="url">URL</Label>
                            <Input id="url" type="url" value={url} onChange={e => setUrl(e.target.value)} required />
                        </div>
                        <div className="flex items-center space-x-2">
                            <Checkbox
                                id="new-tab"
                                checked={openInNewTab}
                                onCheckedChange={(checked) => setOpenInNewTab(Boolean(checked))}
                            />
                            <Label htmlFor="new-tab">Open in new tab</Label>
                        </div>
                    </CardContent>
                    <CardFooter>
                        <Button type="submit" disabled={isLoading}>
                            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            Add Link
                        </Button>
                    </CardFooter>
                </form>
            </Card>
        </main>
    );
}
