
'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { SponsorSettings, getSponsorSettings, getSponsorStyleSettings, updateSponsorSettings, updateSponsorStyleSettings, SponsorStyleSettings } from '@/lib/data';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import ColorPicker from '@/components/admin/color-picker';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';


export default function SponsoredLinksSettingsPage() {
    const [sponsorSettings, setSponsorSettings] = useState<SponsorSettings | null>(null);
    const [styleSettings, setStyleSettings] = useState<SponsorStyleSettings | null>(null);
    const [loading, setLoading] = useState(true);
    const { toast } = useToast();

    useEffect(() => {
        const fetchData = async () => {
            const [sponsorsData, stylesData] = await Promise.all([
                getSponsorSettings(),
                getSponsorStyleSettings(),
            ]);
            setSponsorSettings(sponsorsData);
            setStyleSettings(stylesData);
            setLoading(false);
        };
        fetchData();
    }, []);

    const handleSponsorSettingChange = (field: keyof SponsorSettings, value: any) => {
        setSponsorSettings(prev => prev ? { ...prev, [field]: value } : null);
    };

     const handleStyleSettingChange = (field: keyof SponsorStyleSettings, value: any) => {
        setStyleSettings(prev => prev ? { ...prev, [field]: value } : null);
    };
    
    const handleGradientChange = (property: 'from' | 'to' | 'direction', value: string) => {
        setStyleSettings(prev => {
            if (!prev) return null;
            return {
                ...prev,
                gradient: {
                    ...prev.gradient,
                    [property]: value
                }
            }
        });
    }

    const handleSaveChanges = async () => {
        if (!sponsorSettings || !styleSettings) return;
        try {
            await Promise.all([
                updateSponsorSettings(sponsorSettings),
                updateSponsorStyleSettings(styleSettings),
            ]);
            toast({ title: 'Settings saved successfully!' });
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error saving settings' });
        }
    };
    
    if (loading || !sponsorSettings || !styleSettings) {
        return (
            <main className="p-6">
                <div className="flex items-center justify-between pb-6">
                    <Skeleton className="h-8 w-48" />
                    <Skeleton className="h-10 w-32" />
                </div>
                 <div className="space-y-6">
                    <Skeleton className="h-64 w-full" />
                    <Skeleton className="h-80 w-full" />
                </div>
            </main>
        );
    }

    return (
        <main className="p-6">
            <div className="flex items-center justify-between pb-6">
                <h1 className="text-2xl font-semibold">Sponsors Section Settings</h1>
                <Button onClick={handleSaveChanges}>Save All Changes</Button>
            </div>

             <div className="space-y-6">
                <Card>
                    <CardHeader>
                        <CardTitle>Content</CardTitle>
                        <CardDescription>Manage the title and description for the sponsors section on your partner page.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="space-y-2">
                            <Label htmlFor="sponsor-title">Section Title</Label>
                            <Input id="sponsor-title" value={sponsorSettings.title} onChange={(e) => handleSponsorSettingChange('title', e.target.value)} />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="sponsor-description">Description</Label>
                            <Textarea id="sponsor-description" value={sponsorSettings.description} onChange={(e) => handleSponsorSettingChange('description', e.target.value)} />
                        </div>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle>Link Styling</CardTitle>
                         <CardDescription>Customize the appearance of the sponsored links.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <h4 className="font-medium mb-2">Background</h4>
                                <RadioGroup value={styleSettings.backgroundType} onValueChange={(v) => handleStyleSettingChange('backgroundType', v)} className="mb-4">
                                    <div className="flex items-center space-x-2"><RadioGroupItem value="solid" id="bg-solid" /><Label htmlFor="bg-solid">Solid</Label></div>
                                    <div className="flex items-center space-x-2"><RadioGroupItem value="gradient" id="bg-gradient" /><Label htmlFor="bg-gradient">Gradient</Label></div>
                                </RadioGroup>
                                {styleSettings.backgroundType === 'solid' ? (
                                    <ColorPicker label="Background Color" color={styleSettings.backgroundColor} onChange={(c) => handleStyleSettingChange('backgroundColor', c)} />
                                ) : (
                                    <div className="space-y-4">
                                        <ColorPicker label="Gradient From" color={styleSettings.gradient.from} onChange={(c) => handleGradientChange('from', c)} />
                                        <ColorPicker label="Gradient To" color={styleSettings.gradient.to} onChange={(c) => handleGradientChange('to', c)} />
                                        <div className="space-y-2"><Label>Direction</Label><Select value={styleSettings.gradient.direction} onValueChange={(v) => handleGradientChange('direction', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="to right">Left to Right</SelectItem><SelectItem value="to bottom">Top to Bottom</SelectItem></SelectContent></Select></div>
                                    </div>
                                )}
                            </div>
                            <div>
                                 <h4 className="font-medium mb-2">Border & Spacing</h4>
                                 <ColorPicker label="Border Color" color={styleSettings.borderColor} onChange={(c) => handleStyleSettingChange('borderColor', c)} />
                                 <div className="space-y-2 mt-4"><Label>Border Width (px)</Label><Slider value={[styleSettings.borderWidth]} onValueChange={(v) => handleStyleSettingChange('borderWidth', v[0])} max={10} step={1} /></div>
                                 <div className="space-y-2 mt-4"><Label>Border Radius (px)</Label><Slider value={[styleSettings.borderRadius]} onValueChange={(v) => handleStyleSettingChange('borderRadius', v[0])} max={50} step={1} /></div>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </main>
    );
}
