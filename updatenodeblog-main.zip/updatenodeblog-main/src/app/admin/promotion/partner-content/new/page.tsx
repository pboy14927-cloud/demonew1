

'use server';

import ContentEditor from "@/components/editor/content-editor";
import { getAllUsers } from "@/lib/data";

export default async function NewPartnerContentPage() {
  const allUsers = await getAllUsers();
  return (
    <ContentEditor 
        title="Add New Partner Content"
        allUsers={allUsers}
        allPages={[]}
    />
  );
}
