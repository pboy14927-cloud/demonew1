

'use server';
import ContentEditor from "@/components/editor/content-editor";
import { getAllContent, getAllUsers } from "@/lib/data";
import { notFound } from "next/navigation";

type EditPartnerContentProps = {
    params: {
        id: string;
    }
}

export default async function EditPartnerContentPost({ params }: EditPartnerContentProps) {
  const posts = await getAllContent(); 
  const post = posts.find(p => p.id === params.id && p.isPartnerContent);

  if (!post) {
    notFound();
  }
  
  const allUsers = await getAllUsers();

  return (
    <ContentEditor 
        post={post} 
        title="Edit Partner Content"
        allUsers={allUsers}
        allPages={[]}
    />
  );
}
