
'use client';

import React, { useState, useMemo, useEffect } from 'react';
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { getPartnerContent, Post, User, updatePostStatus, deletePost, getUsers } from "@/lib/data";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { MoreHorizontal, MessageSquare } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from '@/hooks/use-toast';
import { DataTablePagination } from '@/components/admin/data-table-pagination';

type PartnerContentWithSelection = Post & { selected?: boolean; authorName?: string };

export default function AdminPartnerContentPage() {
  const [allContent, setAllContent] = useState<PartnerContentWithSelection[]>([]);
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState('');
  const [bulkAction, setBulkAction] = useState('');
  const [itemToDelete, setItemToDelete] = useState<string | null>(null);
  const { toast } = useToast();
  
  // Pagination State
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const fetchContent = async () => {
    const [content, users] = await Promise.all([getPartnerContent(true), getUsers()]);
    setAllContent(content.map(c => ({ ...c, selected: false })));
    setAllUsers(users);
  }

  useEffect(() => {
    fetchContent();
  }, []);
  
  const contentWithAuthors = useMemo(() => {
    const userMap = new Map(allUsers.map(user => [user.id, user.name]));
    return allContent.map(item => ({
      ...item,
      authorName: userMap.get(item.authorId) || 'Unknown'
    }));
  }, [allContent, allUsers]);

  const filteredContent = useMemo(() => {
    return contentWithAuthors
      .filter((item) => {
        if (statusFilter === "all") return item.status !== 'trash';
        if (statusFilter === 'published' || statusFilter === 'draft' || statusFilter === 'trash') {
          return item.status === statusFilter;
        }
        return true;
      })
      .filter((item) => {
        const lowerCaseSearch = searchTerm.toLowerCase();
        return (
          item.title.toLowerCase().includes(lowerCaseSearch) ||
          (item.authorName && item.authorName.toLowerCase().includes(lowerCaseSearch))
        )
      });
  }, [contentWithAuthors, statusFilter, searchTerm]);
  
  const paginatedContent = useMemo(() => {
      const startIndex = (page - 1) * pageSize;
      return filteredContent.slice(startIndex, startIndex + pageSize);
  }, [filteredContent, page, pageSize]);

  const totalPages = Math.ceil(filteredContent.length / pageSize);

  useEffect(() => {
    setPage(1);
  }, [statusFilter, searchTerm, pageSize]);

  const statusCounts = useMemo(() => {
    const counts = { all: 0, published: 0, draft: 0, trash: 0 };
    for (const item of allContent) {
       if (item.isPartnerContent) {
        if(item.status !== 'trash') counts.all++;
        if (item.status in counts) {
          // @ts-ignore
          counts[item.status]++;
        }
      }
    }
    return counts;
  }, [allContent]);


  const handleStatusChange = async (status: 'published' | 'draft' | 'trash', itemIds: string[]) => {
     try {
        await Promise.all(itemIds.map(id => updatePostStatus(id, status)));
        toast({ title: "Content updated" });
        fetchContent();
    } catch(e) {
        toast({ variant: 'destructive', title: "Error updating content" });
    }
  };
  
   const handleDeletePermanently = async (itemIds: string[]) => {
    try {
        await Promise.all(itemIds.map(id => deletePost(id)));
        toast({ title: "Content permanently deleted" });
        fetchContent();
    } catch(e) {
        toast({ variant: 'destructive', title: "Error deleting content" });
    }
    setItemToDelete(null); // Close dialog
  };


  const applyBulkAction = () => {
    const selectedIds = allContent.filter(p => p.selected).map(p => p.id);
    if(selectedIds.length === 0 || !bulkAction) return;

    if(bulkAction === 'edit') {
        // In a real app, you might show a modal for bulk editing
        alert(`Editing content: ${selectedIds.join(', ')}`);
    } else if (bulkAction === 'trash') {
        handleStatusChange('trash', selectedIds);
    } else if (bulkAction === 'delete_permanently') {
        setItemToDelete('bulk'); // Special key for bulk deletion confirmation
    } else if (bulkAction === 'restore') {
        handleStatusChange('draft', selectedIds);
    }
    setBulkAction('');
  };

  const toggleSelectAll = (checked: boolean) => {
     setAllContent(items => items.map(p => {
        if(paginatedContent.some(fp => fp.id === p.id)) {
            return {...p, selected: checked }
        }
        return p;
     }));
  }

  const toggleSelect = (itemId: string) => {
     setAllContent(items => items.map(p => p.id === itemId ? { ...p, selected: !p.selected } : p));
  }
  
  const confirmBulkDelete = () => {
      const selectedIds = allContent.filter(p => p.selected).map(p => p.id);
      handleDeletePermanently(selectedIds);
  }

  const selectedCount = paginatedContent.filter(p => p.selected).length;
  const isAllSelected = selectedCount > 0 && selectedCount === paginatedContent.length;
  const isIndeterminate = selectedCount > 0 && selectedCount < paginatedContent.length;


  return (
    <>
      <main className="p-6">
        <div className='flex items-center justify-between pb-4'>
            <h1 className="text-2xl font-semibold">Partner Content</h1>
            <Button asChild>
                <Link href="/admin/promotion/partner-content/new">Add New</Link>
            </Button>
        </div>
        <div className="flex items-center space-x-2 pb-4">
            <button onClick={() => setStatusFilter('all')} className={`px-3 py-1 text-sm ${statusFilter === 'all' ? 'border-b-2 border-primary text-primary' : 'text-muted-foreground'}`}>
                All ({statusCounts.all})
            </button>
            <button onClick={() => setStatusFilter('published')} className={`px-3 py-1 text-sm ${statusFilter === 'published' ? 'border-b-2 border-primary text-primary' : 'text-muted-foreground'}`}>
                Published ({statusCounts.published})
            </button>
            <button onClick={() => setStatusFilter('draft')} className={`px-3 py-1 text-sm ${statusFilter === 'draft' ? 'border-b-2 border-primary text-primary' : 'text-muted-foreground'}`}>
                Draft ({statusCounts.draft})
            </button>
             <button onClick={() => setStatusFilter('trash')} className={`px-3 py-1 text-sm ${statusFilter === 'trash' ? 'border-b-2 border-primary text-primary' : 'text-muted-foreground'}`}>
                Trash ({statusCounts.trash})
            </button>
        </div>
        <div className="flex items-center justify-between pb-4">
            <div className="flex items-center space-x-2">
                 <Select value={bulkAction} onValueChange={setBulkAction}>
                    <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Bulk actions" />
                    </SelectTrigger>
                    <SelectContent>
                       {statusFilter === 'trash' ? (
                          <>
                            <SelectItem value="restore">Restore</SelectItem>
                            <SelectItem value="delete_permanently">Delete Permanently</SelectItem>
                          </>
                        ) : (
                          <>
                            <SelectItem value="edit">Edit</SelectItem>
                            <SelectItem value="trash">Move to Trash</SelectItem>
                          </>
                        )}
                    </SelectContent>
                </Select>
                <Button variant="secondary" onClick={applyBulkAction}>Apply</Button>
            </div>
            <div className="w-full max-w-sm">
                <Input 
                    placeholder="Search content..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>
        </div>
        <DataTablePagination
            currentPage={page}
            totalPages={totalPages}
            onPageChange={setPage}
            pageSize={pageSize}
            onPageSizeChange={setPageSize}
            itemCount={filteredContent.length}
        />

        <div className="border rounded-lg mt-4">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[40px]">
                   <Checkbox 
                        checked={isAllSelected}
                        onCheckedChange={(checked) => toggleSelectAll(Boolean(checked))}
                        aria-label="Select all"
                        data-state={isIndeterminate ? 'indeterminate' : (isAllSelected ? 'checked' : 'unchecked')}
                    />
                </TableHead>
                <TableHead>Title</TableHead>
                <TableHead>Author</TableHead>
                <TableHead>Comments</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>
                  <span className="sr-only">Actions</span>
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginatedContent.map((item) => {
                const authorName = item.authorName || 'Unknown';
                const itemDate = new Date(item.createdAt).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric',
                });
                return (
                  <TableRow key={item.id} data-state={item.selected ? "selected" : "deselected"} className="group">
                    <TableCell>
                        <Checkbox 
                            checked={!!item.selected}
                            onCheckedChange={() => toggleSelect(item.id)}
                            aria-label={`Select "${item.title}"`}
                        />
                    </TableCell>
                    <TableCell className="font-medium">
                        <Link href={`/admin/promotion/partner-content/edit/${item.id}`} className="hover:text-primary">{item.title}</Link>
                         {item.status !== 'published' && <span className="text-muted-foreground text-xs"> &mdash; {item.status.charAt(0).toUpperCase() + item.status.slice(1)}</span>}
                         <div className="text-xs text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity">
                            {item.status === 'trash' ? (
                                <>
                                  <button onClick={() => handleStatusChange('draft', [item.id])} className="text-primary hover:underline">Restore</button> | 
                                  <button onClick={() => setItemToDelete(item.id)} className="text-destructive hover:underline px-1">Delete Permanently</button>
                                </>
                            ) : (
                                <>
                                  <Link href={`/admin/promotion/partner-content/edit/${item.id}`} className="text-primary hover:underline">Edit</Link> | 
                                  <button onClick={() => handleStatusChange('trash', [item.id])} className="text-destructive hover:underline px-1">Trash</button> | 
                                  <Link href={`/partner`} target="_blank" className="hover:underline px-1">View</Link>
                                </>
                            )}
                         </div>
                    </TableCell>
                    <TableCell>{authorName}</TableCell>
                    <TableCell>
                        <Link href="#" className="flex items-center gap-1 text-primary hover:underline">
                            <MessageSquare className="h-4 w-4" />
                            0
                        </Link>
                    </TableCell>
                    <TableCell>{itemDate}</TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button aria-haspopup="true" size="icon" variant="ghost">
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">Toggle menu</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                           <DropdownMenuItem asChild><Link href={`/admin/promotion/partner-content/edit/${item.id}`}>Edit</Link></DropdownMenuItem>
                           <DropdownMenuItem asChild><Link href={`/partner`} target="_blank">View</Link></DropdownMenuItem>
                           <DropdownMenuSeparator />
                           {item.status !== 'trash' ? (
                            <DropdownMenuItem className="text-destructive" onClick={() => handleStatusChange('trash', [item.id])}>
                                Move to Trash
                            </DropdownMenuItem>
                           ) : (
                            <>
                              <DropdownMenuItem onClick={() => handleStatusChange('draft', [item.id])}>
                                  Restore
                              </DropdownMenuItem>
                              <DropdownMenuItem className="text-destructive" onClick={() => setItemToDelete(item.id)}>
                                  Delete Permanently
                              </DropdownMenuItem>
                            </>
                           )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
        <DataTablePagination
            currentPage={page}
            totalPages={totalPages}
            onPageChange={setPage}
            pageSize={pageSize}
            onPageSizeChange={setPageSize}
            itemCount={filteredContent.length}
        />
      </main>
      <AlertDialog open={itemToDelete !== null} onOpenChange={(open) => !open && setItemToDelete(null)}>
          <AlertDialogContent>
              <AlertDialogHeader>
              <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
              <AlertDialogDescription>
                  This action cannot be undone. This will permanently delete the item and remove the data from our servers.
              </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
              <AlertDialogCancel onClick={() => setItemToDelete(null)}>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={() => {
                  if (itemToDelete === 'bulk') {
                      confirmBulkDelete();
                  } else if (itemToDelete) {
                      handleDeletePermanently([itemToDelete]);
                  }
              }}>
                  Delete
              </AlertDialogAction>
              </AlertDialogFooter>
          </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

    