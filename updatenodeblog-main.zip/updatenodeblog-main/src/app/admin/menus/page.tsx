'use client';

import React, { useState, useMemo, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { getPages, getPosts, getCategories, Page, Post, Category, getMenus, updateMenus, Menu } from '@/lib/data';
import { GripVertical, Trash2 } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors, DragEndEvent } from '@dnd-kit/core';
import { arrayMove, SortableContext, sortableKeyboardCoordinates, useSortable, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

type MenuItem = Menu['items'][0];


// Reusable component for the content inside Pages, Posts, and Categories accordions
const AddItemsPanel = ({ items, onAddToMenu }: { items: (Page | Post | Category)[], onAddToMenu: (items: any[]) => void }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedItems, setSelectedItems] = useState<string[]>([]);
    
    const filteredItems = useMemo(() => {
        return items.filter(item => 'title' in item ? item.title.toLowerCase().includes(searchTerm.toLowerCase()) : item.name.toLowerCase().includes(searchTerm.toLowerCase()));
    }, [items, searchTerm]);

    const handleSelect = (itemId: string) => {
        setSelectedItems(prev => prev.includes(itemId) ? prev.filter(id => id !== itemId) : [...prev, itemId]);
    };

    const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement> | boolean) => {
        const isChecked = typeof e === 'boolean' ? e : e.target.checked;
        if (isChecked) {
            setSelectedItems(filteredItems.map(item => item.id));
        } else {
            setSelectedItems([]);
        }
    };
    
    const handleAddClick = () => {
        const itemsToAdd = items.filter(item => selectedItems.includes(item.id));
        onAddToMenu(itemsToAdd);
        setSelectedItems([]);
    }

    return (
        <Tabs defaultValue="most-used" className="w-full">
            <TabsList className="grid w-full grid-cols-3 h-8 p-0">
                <TabsTrigger value="most-used" className="h-full text-xs">Most Used</TabsTrigger>
                <TabsTrigger value="view-all" className="h-full text-xs">View All</TabsTrigger>
                <TabsTrigger value="search" className="h-full text-xs">Search</TabsTrigger>
            </TabsList>
            <TabsContent value="most-used" className="pt-2">
                <div className="space-y-2 max-h-40 overflow-y-auto border p-2 rounded-md">
                    {items.slice(0, 3).map(item => (
                        <div key={item.id} className="flex items-center space-x-2">
                            <Checkbox id={`most-used-${item.id}`} checked={selectedItems.includes(item.id)} onCheckedChange={() => handleSelect(item.id)} />
                            <Label htmlFor={`most-used-${item.id}`} className="font-normal">{'title' in item ? item.title : item.name}</Label>
                        </div>
                    ))}
                </div>
            </TabsContent>
            <TabsContent value="view-all" className="pt-2">
                <div className="space-y-2 max-h-40 overflow-y-auto border p-2 rounded-md">
                    {items.map(item => (
                        <div key={item.id} className="flex items-center space-x-2">
                             <Checkbox id={`view-all-${item.id}`} checked={selectedItems.includes(item.id)} onCheckedChange={() => handleSelect(item.id)} />
                             <Label htmlFor={`view-all-${item.id}`} className="font-normal">{'title' in item ? item.title : item.name}</Label>
                        </div>
                    ))}
                </div>
            </TabsContent>
             <TabsContent value="search" className="pt-2">
                <Input placeholder="Search" className="mb-2" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
                <div className="space-y-2 max-h-32 overflow-y-auto border p-2 rounded-md">
                     {filteredItems.map(item => (
                        <div key={item.id} className="flex items-center space-x-2">
                             <Checkbox id={`search-${item.id}`} checked={selectedItems.includes(item.id)} onCheckedChange={() => handleSelect(item.id)} />
                             <Label htmlFor={`search-${item.id}`} className="font-normal">{'title' in item ? item.title : item.name}</Label>
                        </div>
                    ))}
                </div>
            </TabsContent>
             <div className="flex items-center justify-between mt-2">
                <div className="flex items-center space-x-2">
                    <Checkbox 
                        id={`select-all-${items[0]?.id}`} 
                        onCheckedChange={(checked) => handleSelectAll(Boolean(checked))}
                        checked={selectedItems.length > 0 && selectedItems.length === filteredItems.length}
                        />
                    <Label htmlFor={`select-all-${items[0]?.id}`} className="font-normal text-sm">Select All</Label>
                </div>
                <Button variant="secondary" size="sm" onClick={handleAddClick} disabled={selectedItems.length === 0}>Add to Menu</Button>
            </div>
        </Tabs>
    );
};

const SortableMenuItem = ({ item, onRemove }: { item: MenuItem, onRemove: (id: string) => void }) => {
    const {
        attributes,
        listeners,
        setNodeRef,
        transform,
        transition,
    } = useSortable({ id: item.id });

    const style = {
        transform: CSS.Transform.toString(transform),
        transition,
        marginLeft: `${item.depth * 2}rem`,
    };

    return (
        <div ref={setNodeRef} style={style} {...attributes}>
            <Accordion type="single" collapsible className="w-full" key={item.id}>
                <AccordionItem value={item.id} className="border rounded-md bg-background">
                    <div className="flex items-center">
                        <div {...listeners} className="cursor-move p-3">
                            <GripVertical className="h-5 w-5 text-muted-foreground" />
                        </div>
                        <AccordionTrigger className="p-3 hover:no-underline flex-1">
                            <div className="flex items-center gap-2 w-full">
                                <span>{item.label}</span>
                                <span className="text-xs text-muted-foreground ml-auto capitalize">{item.type}</span>
                            </div>
                        </AccordionTrigger>
                    </div>
                    <AccordionContent className="p-4 border-t space-y-3">
                         <div className="space-y-1">
                            <Label htmlFor={`nav-label-${item.id}`}>Navigation Label</Label>
                            <Input id={`nav-label-${item.id}`} defaultValue={item.label} />
                        </div>
                        <Button variant="link" className="text-destructive p-0 h-auto text-sm" onClick={() => onRemove(item.id)}>Remove</Button>
                    </AccordionContent>
                </AccordionItem>
            </Accordion>
        </div>
    );
};


export default function MenusPage() {
  const [allMenus, setAllMenus] = useState<Menu[]>([]);
  const [currentMenuId, setCurrentMenuId] = useState<string | null>(null);
  const [pages, setPages] = useState<Page[]>([]);
  const [posts, setPosts] = useState<Post[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [menuName, setMenuName] = useState('');
  const [menuLocations, setMenuLocations] = useState<string[]>([]);
  
  const [customLinkUrl, setCustomLinkUrl] = useState('');
  const [customLinkText, setCustomLinkText] = useState('');
  
  const [isClient, setIsClient] = useState(false);
  const { toast } = useToast();
  
  const isCreatingNew = currentMenuId === null;

  useEffect(() => {
    setIsClient(true);
    const fetchData = async () => {
        const menusData = await getMenus();
        setAllMenus(menusData);
        if (menusData.length > 0) {
            setCurrentMenuId(menusData[0].id);
        }
        setPages((await getPages()).filter(p => p.status === 'published'));
        setPosts((await getPosts()).filter(p => p.status === 'published'));
        setCategories(await getCategories());
    }
    fetchData();
  }, []);

  useEffect(() => {
      if (currentMenuId) {
          const menu = allMenus.find(m => m.id === currentMenuId);
          if (menu) {
              setMenuName(menu.name);
              setMenuItems(menu.items as MenuItem[]);
              setMenuLocations(menu.locations);
          }
      } else {
          setMenuName('');
          setMenuItems([]);
          setMenuLocations([]);
      }
  }, [currentMenuId, allMenus]);
  
  const sensors = useSensors(
    useSensor(PointerSensor, {
        activationConstraint: {
            distance: 8,
        },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over, delta } = event;
    const activeId = active.id as string;
    const overId = over?.id as string;

    if (!overId || activeId === overId) return;

    setMenuItems((items) => {
        const oldIndex = items.findIndex((item) => item.id === activeId);
        const newIndex = items.findIndex((item) => item.id === overId);
        
        let newItems = arrayMove(items, oldIndex, newIndex);
        
        const activeItemIndex = newItems.findIndex(item => item.id === activeId);
        const activeItem = newItems[activeItemIndex];

        const indentation = Math.round(delta.x / 32); 
        let newDepth = (activeItem.depth || 0) + indentation;
        
        if (newDepth < 0) newDepth = 0;
        
        const maxDepth = activeItemIndex > 0 ? (newItems[activeItemIndex - 1].depth || 0) + 1 : 0;
        if (newDepth > maxDepth) {
            newDepth = maxDepth;
        }

        newItems[activeItemIndex] = { ...activeItem, depth: newDepth };
        
        // Adjust children depths
        for (let i = activeItemIndex + 1; i < newItems.length; i++) {
            const prevItemDepth = newItems[i-1].depth || 0;
            if (newItems[i].depth > prevItemDepth + 1) {
                newItems[i].depth = prevItemDepth + 1;
            }
        }
        
        return newItems;
    });
  };

  const handleAddToMenu = (itemsToAdd: any[]) => {
      const newMenuItems = itemsToAdd.map(item => {
          let type: MenuItem['type'] = 'custom';
          let url = `/${item.slug}`;

          if('isPage' in item && item.isPage) {
            type = 'page';
            url = item.slug === 'home' ? '/' : `/${item.slug}`;
          } else if('authorId' in item && !item.isPage) {
            type = 'post';
            url = `/posts/${item.slug}`;
          } else if('parent' in item || !('authorId' in item)) {
            type = 'category';
            url = `/category/${item.slug}`;
          }
          
          return {
            id: `menu-item-${Date.now()}-${item.id}`,
            label: 'title' in item ? item.title : item.name,
            type: type,
            url: url,
            depth: 0,
          }
      });
      setMenuItems(prev => [...prev, ...newMenuItems]);
  }
  
  const handleAddCustomLink = () => {
    if(!customLinkUrl || !customLinkText) {
      toast({ variant: 'destructive', title: 'URL and Link Text are required.' });
      return;
    }
    const newItem: MenuItem = {
      id: `custom-link-${Date.now()}`,
      label: customLinkText,
      url: customLinkUrl,
      type: 'custom',
      depth: 0,
    };
    setMenuItems(prev => [...prev, newItem]);
    setCustomLinkUrl('');
    setCustomLinkText('');
  };
  
  const handleRemoveFromMenu = (id: string) => {
      setMenuItems(prev => prev.filter(item => item.id !== id));
  }

  const handleLocationChange = (location: 'header' | 'footer', checked: boolean) => {
    let newLocations: ('header' | 'footer')[] = [...menuLocations] as any;
    // Ensure only one menu per location
    if(checked) {
        newLocations.push(location);
    } else {
        newLocations = newLocations.filter(loc => loc !== location);
    }
    setMenuLocations(newLocations);
  };


  const handleSaveMenu = () => {
    if (!menuName) {
        toast({
            variant: "destructive",
            title: "Menu name is required",
        });
        return;
    }

    let updatedMenus: Menu[];
    
    if (isCreatingNew) {
        const newMenu: Menu = {
            id: `menu-${Date.now()}`,
            name: menuName,
            items: menuItems,
            locations: menuLocations as any,
        };
        updatedMenus = [...allMenus, newMenu];
        
        setCurrentMenuId(newMenu.id);
        toast({
          title: "Menu Created",
          description: `The "${menuName}" menu has been created.`,
        });
    } else {
        updatedMenus = allMenus.map(menu => 
            menu.id === currentMenuId ? { ...menu, name: menuName, items: menuItems, locations: menuLocations as any } : menu
        );
        toast({
          title: "Menu Saved",
          description: `The "${menuName}" menu has been saved.`,
        });
    }

    // Ensure only one menu per location across all menus
    let headerAssigned = false;
    let footerAssigned = false;

    updatedMenus.forEach(menu => {
        const isCurrentMenu = menu.id === (currentMenuId || `menu-${Date.now()}`);
        if(menu.locations.includes('header')) {
            if (headerAssigned && !isCurrentMenu) {
                menu.locations = menu.locations.filter(l => l !== 'header');
            } else {
                headerAssigned = true;
            }
        }
         if(menu.locations.includes('footer')) {
            if (footerAssigned && !isCurrentMenu) {
                menu.locations = menu.locations.filter(l => l !== 'footer');
            } else {
                footerAssigned = true;
            }
        }
    });

    updateMenus(updatedMenus);
    setAllMenus(updatedMenus);
  };

  const handleDeleteMenu = () => {
    if (isCreatingNew || !currentMenuId) return;
    
    const menuToDelete = allMenus.find(m => m.id === currentMenuId);
    if (!menuToDelete) return;

    const updatedMenus = allMenus.filter(menu => menu.id !== currentMenuId)
    updateMenus(updatedMenus);
    setAllMenus(updatedMenus);
    
    setCurrentMenuId(updatedMenus[0]?.id || null);

    toast({
      title: "Menu Deleted",
      description: `The "${menuToDelete.name}" menu has been deleted.`,
    });
  };
  
  const handleCreateNewMenu = () => {
    setCurrentMenuId(null);
  }

  return (
    <main className="p-6">
      <div className="flex items-center justify-between pb-6">
        <h1 className="text-2xl font-semibold">Menus</h1>
      </div>

      <div className="flex flex-wrap items-center gap-4 pb-6 border-b">
        <Label>Select a menu to edit:</Label>
        <Select value={currentMenuId || ''} onValueChange={setCurrentMenuId}>
            <SelectTrigger className="w-[250px]">
                <SelectValue placeholder="Select a menu"/>
            </SelectTrigger>
            <SelectContent>
                {allMenus.map(menu => (
                    <SelectItem key={menu.id} value={menu.id}>{menu.name}</SelectItem>
                ))}
            </SelectContent>
        </Select>
        <span>or</span>
        <Button variant="link" className="p-0 h-auto" onClick={handleCreateNewMenu}>create a new menu</Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-6 items-start">
        {/* Left Column: Add Menu Items */}
        <div className="lg:col-span-1">
          <Accordion type="multiple" defaultValue={['pages']} className="w-full space-y-4">
             {/* Pages */}
            <Card>
             <AccordionItem value="pages" className="border-b-0">
                <AccordionTrigger className="p-4 font-semibold text-base hover:no-underline">Pages</AccordionTrigger>
                <AccordionContent className="px-4 pb-4">
                    <AddItemsPanel items={pages} onAddToMenu={handleAddToMenu} />
                </AccordionContent>
            </AccordionItem>
            </Card>
            
            {/* Posts */}
            <Card>
            <AccordionItem value="posts" className="border-b-0">
                <AccordionTrigger className="p-4 font-semibold text-base hover:no-underline">Posts</AccordionTrigger>
                <AccordionContent className="px-4 pb-4">
                     <AddItemsPanel items={posts} onAddToMenu={handleAddToMenu} />
                </AccordionContent>
            </AccordionItem>
            </Card>

             {/* Categories */}
            <Card>
            <AccordionItem value="categories" className="border-b-0">
                <AccordionTrigger className="p-4 font-semibold text-base hover:no-underline">Categories</AccordionTrigger>
                <AccordionContent className="px-4 pb-4">
                     <AddItemsPanel items={categories} onAddToMenu={handleAddToMenu} />
                </AccordionContent>
            </AccordionItem>
            </Card>

             {/* Custom Links */}
             <Card>
             <AccordionItem value="custom-links" className="border-b-0">
                <AccordionTrigger className="p-4 font-semibold text-base hover:no-underline">Custom Links</AccordionTrigger>
                <AccordionContent className="px-4 pb-4 space-y-3">
                    <div className="space-y-1">
                        <Label htmlFor="custom-url">URL</Label>
                        <Input id="custom-url" placeholder="https://..." value={customLinkUrl} onChange={e => setCustomLinkUrl(e.target.value)} />
                    </div>
                     <div className="space-y-1">
                        <Label htmlFor="custom-link-text">Link Text</Label>
                        <Input id="custom-link-text" placeholder="Menu item" value={customLinkText} onChange={e => setCustomLinkText(e.target.value)} />
                    </div>
                    <div className="flex justify-end">
                      <Button variant="secondary" size="sm" onClick={handleAddCustomLink} disabled={!customLinkUrl || !customLinkText}>Add to Menu</Button>
                    </div>
                </AccordionContent>
            </AccordionItem>
            </Card>
          </Accordion>
        </div>

        {/* Right Column: Menu Structure */}
        <div className="lg:col-span-2">
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                        <span>{isCreatingNew ? 'Create New Menu' : 'Menu structure'}</span>
                    </CardTitle>
                    <CardDescription>
                        {isCreatingNew ? 'Give your menu a name, then click "Save Menu".' : 'Drag items to reorder and create sub-menus.'}
                    </CardDescription>
                </CardHeader>
                 <CardContent className="space-y-4">
                    <div className="space-y-1">
                        <Label htmlFor="menu-name">Menu Name</Label>
                        <Input id="menu-name" className="w-1/2" value={menuName} onChange={e => setMenuName(e.target.value)} />
                    </div>
                    <p className="text-sm text-muted-foreground">
                        Drag each item into the order you prefer. Click the arrow on the right of the item to reveal additional configuration options.
                    </p>
                    {isClient ? (
                     <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
                        <SortableContext items={menuItems.map(i => i.id)} strategy={verticalListSortingStrategy}>
                            <div className="border-2 border-dashed border-muted-foreground/30 rounded-lg p-4 min-h-[300px] space-y-2">
                                {menuItems.map(item => (
                                    <SortableMenuItem key={item.id} item={item} onRemove={handleRemoveFromMenu} />
                                ))}
                                 {menuItems.length === 0 && (
                                    <p className="text-muted-foreground text-center py-10">
                                        Select items from the left column to add them to this menu.
                                    </p>
                                 )}
                             </div>
                        </SortableContext>
                     </DndContext>
                    ) : (
                        <div className="border-2 border-dashed border-muted-foreground/30 rounded-lg p-4 min-h-[300px] flex items-center justify-center">
                            <p className="text-muted-foreground">Loading menu editor...</p>
                        </div>
                    )}
                </CardContent>
                 <CardFooter className="flex flex-col items-start gap-4 bg-muted/50 p-4">
                    <div>
                        <h4 className="font-semibold">Menu Settings</h4>
                        <div className="flex items-center space-x-2 mt-2">
                            <Checkbox id="auto-add-pages" />
                            <Label htmlFor="auto-add-pages" className="font-normal text-sm">
                                Auto add pages
                            </Label>
                        </div>
                         <p className="text-xs text-muted-foreground mt-1">Automatically add new top-level pages to this menu.</p>
                    </div>
                     <div>
                        <h4 className="font-semibold">Display location</h4>
                        <div className="flex flex-col space-y-2 mt-2">
                            <div className="flex items-center space-x-2">
                                <Checkbox id="display-location-header" checked={menuLocations.includes('header')} onCheckedChange={(c) => handleLocationChange('header', Boolean(c))} />
                                <Label htmlFor="display-location-header" className="font-normal text-sm">Header</Label>
                            </div>
                             <div className="flex items-center space-x-2">
                                <Checkbox id="display-location-footer" checked={menuLocations.includes('footer')} onCheckedChange={(c) => handleLocationChange('footer', Boolean(c))}/>
                                <Label htmlFor="display-location-footer" className="font-normal text-sm">Footer</Label>
                            </div>
                             <div className="flex items-center space-x-2">
                                <Checkbox id="display-location-offcanvas" />
                                <Label htmlFor="display-location-offcanvas" className="font-normal text-sm">Off Canvas Menu</Label>
                            </div>
                        </div>
                    </div>
                 </CardFooter>
                 <CardFooter className="flex justify-between items-center p-4 border-t">
                    <AlertDialog>
                        <AlertDialogTrigger asChild>
                            <Button variant="link" className="text-destructive p-0 h-auto" disabled={isCreatingNew}>Delete Menu</Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                            <AlertDialogHeader>
                                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                <AlertDialogDescription>
                                    This action cannot be undone. You are about to permanently delete the "{menuName}" menu.
                                </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={handleDeleteMenu}>Yes, delete menu</AlertDialogAction>
                            </AlertDialogFooter>
                        </AlertDialogContent>
                    </AlertDialog>
                    <Button onClick={handleSaveMenu}>{isCreatingNew ? 'Save Menu' : 'Update Menu'}</Button>
                 </CardFooter>
            </Card>
        </div>
      </div>
    </main>
  );
}