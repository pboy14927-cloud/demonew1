
'use server';

import { NextRequest, NextResponse } from 'next/server';
import { createComment } from '@/lib/data';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    const body = await request.json();
    const { postId, content, guestName, guestEmail } = body;
    
    if (!postId || !content) {
      return NextResponse.json({ message: 'Post ID and content are required.' }, { status: 400 });
    }

    // If the user is logged in, use their ID
    if (session?.user) {
        const authorId = (session.user as any).id;
        const newComment = await createComment({ postId, content, authorId });
        return NextResponse.json(newComment, { status: 201 });
    }

    // If not logged in, it's a guest comment. Validate guest fields.
    if (!guestName || !guestEmail) {
      return NextResponse.json({ message: 'Name and email are required for guest comments.' }, { status: 400 });
    }
    
    const newComment = await createComment({ postId, content, guestName, guestEmail });
    return NextResponse.json(newComment, { status: 201 });

  } catch (error: any) {
    console.error('Comment submission error:', error);
    return NextResponse.json({ message: 'An internal server error occurred.', error: error.message }, { status: 500 });
  }
}
