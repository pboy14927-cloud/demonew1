
'use server';

import { NextResponse } from 'next/server';
import { getUserIdFromSession, getUserById } from '@/lib/data';
import { query } from '@/lib/mysql';
import fs from 'fs/promises';
import path from 'path';

export async function POST(request: Request) {
    try {
        const userId = await getUserIdFromSession();
        if (!userId) {
            return NextResponse.json({ message: 'Unauthorized: No session found.' }, { status: 401 });
        }

        const user = await getUserById(userId);
        if (!user || user.role !== 'administrator') {
            return NextResponse.json({ message: 'Forbidden: Only administrators can perform this action.' }, { status: 403 });
        }
        
        const { type } = await request.json();
        
        if (!type) {
            return NextResponse.json({ message: 'Reset type not specified.' }, { status: 400 });
        }

        let message = '';

        const resetMedia = async () => {
             // Clear the media table
            await query(`DELETE FROM \`media\`;`);
            // Delete files from the uploads directory
            const uploadDir = path.join(process.cwd(), 'public', 'uploads');
            try {
                const files = await fs.readdir(uploadDir);
                for (const file of files) {
                    if (file !== '.gitkeep') { 
                        await fs.unlink(path.join(uploadDir, file));
                    }
                }
            } catch (error: any) {
                if (error.code !== 'ENOENT') throw error;
            }
            return 'Media library has been reset.';
        }
        
        const resetPosts = async () => {
            await query(`DELETE FROM \`posts\` WHERE isPage = 0 AND isPartnerContent = 0;`);
            return 'All posts have been deleted.';
        }
        
        const resetPages = async () => {
            await query(`DELETE FROM \`posts\` WHERE isPage = 1;`);
            return 'All pages have been deleted.';
        }

        const resetPartnerContent = async () => {
            await query(`DELETE FROM \`posts\` WHERE isPartnerContent = 1;`);
            return 'All partner content has been deleted.';
        }

        const resetTaxonomies = async () => {
            await query(`DELETE FROM \`categories\`;`);
            await query(`DELETE FROM \`tags\`;`);
            return 'All categories and tags have been deleted.';
        }

        const resetSettings = async () => {
            await query(`DELETE FROM \`settings\`;`);
            return 'All site settings have been reset to default.';
        }

        switch (type) {
            case 'media':
                message = await resetMedia();
                break;
            case 'posts':
                message = await resetPosts();
                break;
            case 'pages':
                message = await resetPages();
                break;
            case 'partner-content':
                message = await resetPartnerContent();
                break;
            case 'taxonomies':
                message = await resetTaxonomies();
                break;
            case 'settings':
                message = await resetSettings();
                break;
            case 'all':
                await resetPosts();
                await resetPages();
                await resetPartnerContent();
                await resetTaxonomies();
                await resetMedia();
                await resetSettings();
                message = 'Site has been factory reset. Your admin account was not affected.';
                break;
            default:
                return NextResponse.json({ message: 'Invalid reset type specified.' }, { status: 400 });
        }


        return NextResponse.json({ message }, { status: 200 });

    } catch (error: any) {
        console.error('Site reset error:', error);
        return NextResponse.json({ message: `An internal server error occurred: ${error.message}` }, { status: 500 });
    }
}
