
import { NextRequest, NextResponse } from 'next/server';
import { createPostDb, Post, query, createCategory, getCategories, getUserIdFromSession, createMedia, Media, createUser, getUsers, User } from '@/lib/data';
import { parseStringPromise } from 'xml2js';
import { promises as fs } from 'fs';
import path from 'path';
import os from 'os';

export const maxDuration = 300; 

// Helper to extract a value from a WXR item, handling CDATA
function getXmlValue(item: any, key: string, fallback: string = ''): string {
    if (item[key] && item[key][0]) {
        if (typeof item[key][0] === 'object' && item[key][0]._) {
            return item[key][0]._;
        }
        return item[key][0];
    }
    return fallback;
}

// Helper to format a date string into MySQL DATETIME format
function toMySqlDateTime(dateString: string): string {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) {
        // Fallback for invalid dates
        return new Date().toISOString().slice(0, 19).replace('T', ' ');
    }
    return date.toISOString().slice(0, 19).replace('T', ' ');
}

// Helper to download an image from a URL and save it to the DB
async function downloadAndProcessImage(imageUrl: string, userId: string): Promise<string | undefined> {
    try {
        console.log(`Downloading image: ${imageUrl}`);
        const response = await fetch(imageUrl);
        if (!response.ok) {
            console.error(`Failed to download image ${imageUrl}: ${response.statusText}`);
            return undefined;
        }

        const arrayBuffer = await response.arrayBuffer();
        const buffer = Buffer.from(arrayBuffer);
        
        const originalFileName = path.basename(new URL(imageUrl).pathname) || `import-${Date.now()}`;
        
        const mediaData: Partial<Omit<Media, 'id' | 'url'>> & { data: Buffer } = {
            fileName: originalFileName,
            fileType: response.headers.get('content-type') || 'image/jpeg',
            fileSize: buffer.length,
            altText: originalFileName.split('.').slice(0, -1).join(' '),
            uploadedBy: userId,
            data: buffer,
        };

        const newMedia = await createMedia(mediaData);
        console.log(`Successfully created media with ID: ${newMedia.id}`);

        return `/api/media/${newMedia.id}/file`;
    } catch (error) {
        console.error(`Error processing image ${imageUrl}:`, error);
        return undefined;
    }
}

type AuthorMapping = Record<string, { type: 'create' | 'assign', value: string }>;

async function processImportFile(filePath: string, userId: string, fileType: string, originalName: string, authorMapping: AuthorMapping, importAttachments: boolean) {
  console.log(`[Background Process] Starting import for file: ${filePath}`);
  try {
    const content = await fs.readFile(filePath, 'utf-8');
    let createdCount = 0;
    const processedImages = new Map<string, string | undefined>();

    const isXml = fileType.includes('xml') || originalName.endsWith('.xml');

    const createdUserMap = new Map<string, string>(); // Maps import author login to new user ID

    if (isXml) {
        const parsedXml = await parseStringPromise(content);
        const channel = parsedXml.rss?.channel?.[0] || parsedXml['rdf:RDF']?.channel?.[0];
        if (!channel) throw new Error('Invalid WXR file format.');
        
        const items = channel.item || [];
        if (items.length === 0) {
            console.log('[Background Process] No items found in import file.');
            return;
        }

        const existingCategories = await getCategories();
        const existingCategoryNames = new Set(existingCategories.map(c => c.name));
        const existingUsers = await getUsers();

        for (const item of items) {
            const postType = getXmlValue(item, 'wp:post_type', 'post');
            if (postType !== 'post' && postType !== 'page') continue;

            const status = (getXmlValue(item, 'wp:status', 'draft') === 'publish' ? 'published' : 'draft') as Post['status'];

            // Author handling
            const importAuthorLogin = getXmlValue(item, 'dc:creator', '');
            let finalAuthorId = userId; // Default to the current user

            if (authorMapping[importAuthorLogin]) {
                const mapping = authorMapping[importAuthorLogin];
                if (mapping.type === 'assign') {
                    finalAuthorId = mapping.value;
                } else if (mapping.type === 'create') {
                    if (createdUserMap.has(importAuthorLogin)) {
                        finalAuthorId = createdUserMap.get(importAuthorLogin)!;
                    } else {
                        const newUserName = mapping.value;
                        const existing = existingUsers.find(u => u.username === newUserName);
                        if (existing) {
                            finalAuthorId = existing.id;
                        } else {
                             const newUser = await createUser({
                                username: newUserName,
                                name: newUserName,
                                email: `${newUserName.toLowerCase().replace(/\s+/g, '')}@example.com`, // Placeholder email
                                password: Math.random().toString(36).slice(-8), // Random password
                                role: 'subscriber'
                            });
                            finalAuthorId = newUser.id;
                            createdUserMap.set(importAuthorLogin, finalAuthorId);
                        }
                    }
                }
            }


            const postCategories = item.category?.filter((c: any) => c.$.domain === 'category').map((c: any) => c._) || [];
            for (const catName of postCategories) {
                if (!existingCategoryNames.has(catName)) {
                    await createCategory({ name: catName });
                    existingCategoryNames.add(catName);
                }
            }

            let postContent = getXmlValue(item, 'content:encoded', '');
            if (importAttachments) {
                const contentImages = postContent.match(/<img[^>]+src="([^"]+)"/g) || [];
                for (const imgTag of contentImages) {
                    const srcMatch = imgTag.match(/src="([^"]+)"/);
                    if (srcMatch?.[1]) {
                        const oldUrl = srcMatch[1];
                        let newUrl = processedImages.get(oldUrl);
                        if (newUrl === undefined) {
                            newUrl = await downloadAndProcessImage(oldUrl, finalAuthorId);
                            processedImages.set(oldUrl, newUrl);
                        }
                        if (newUrl) postContent = postContent.replace(oldUrl, newUrl);
                    }
                }
            }

            let featuredImageUrl: string | undefined = undefined;
            if (importAttachments) {
                 const thumbMeta = item['wp:postmeta']?.find((meta: any) => getXmlValue(meta, 'wp:meta_key') === '_thumbnail_id');
                if (thumbMeta) {
                    const thumbId = getXmlValue(thumbMeta, 'wp:meta_value');
                    const attachment = items.find((att: any) => getXmlValue(att, 'wp:post_id') === thumbId);
                    if (attachment) {
                        const attachmentUrl = getXmlValue(attachment, 'wp:attachment_url');
                        if (attachmentUrl) {
                            let newUrl = processedImages.get(attachmentUrl);
                            if (newUrl === undefined) {
                                newUrl = await downloadAndProcessImage(attachmentUrl, finalAuthorId);
                                processedImages.set(attachmentUrl, newUrl);
                            }
                            if (newUrl) featuredImageUrl = newUrl;
                        }
                    }
                }
            }
           

            const excerpt = getXmlValue(item, 'excerpt:encoded');
            const newPostData: Partial<Post> = {
                title: getXmlValue(item, 'title', 'Untitled'),
                slug: getXmlValue(item, 'wp:post_name') || undefined,
                content: postContent,
                status,
                authorId: finalAuthorId,
                createdAt: toMySqlDateTime(getXmlValue(item, 'pubDate', new Date().toISOString())),
                isPage: postType === 'page',
                categories: postCategories,
                tags: item.category?.filter((c: any) => c.$.domain === 'post_tag').map((c: any) => c._) || [],
                featuredImage: featuredImageUrl,
                excerpt: excerpt || undefined,
            };
            await createPostDb(newPostData);
            createdCount++;
        }
    }
    console.log(`[Background Process] Successfully imported ${createdCount} items from ${originalName}.`);
  } catch (error) {
    console.error(`[Background Process] Failed to import file ${filePath}:`, error);
  } finally {
    // Clean up the temporary file
    await fs.unlink(filePath).catch(err => console.error(`Failed to delete temp file ${filePath}:`, err));
  }
}

export async function POST(request: NextRequest) {
  const userId = await getUserIdFromSession();
  if (!userId) {
    return NextResponse.json({ message: 'Unauthorized' }, { status: 401 });
  }

  try {
    const formData = await request.formData();
    const filePath = formData.get('filePath') as string | null;
    const originalName = formData.get('originalName') as string | null;
    const fileType = formData.get('fileType') as string | null;
    const authorMappingParam = formData.get('authorMapping') as string | null;
    const importAttachmentsParam = formData.get('importAttachments') as string | null;

    if (!filePath || !originalName || !fileType) {
      return NextResponse.json({ message: 'Missing file information.' }, { status: 400 });
    }
    
    if (!authorMappingParam) {
      return NextResponse.json({ message: 'Author mapping is required.' }, { status: 400 });
    }

    const authorMapping = JSON.parse(authorMappingParam);
    const importAttachments = importAttachmentsParam === 'true';

    // Fire-and-forget the background processing
    processImportFile(filePath, userId, fileType, originalName, authorMapping, importAttachments);

    // Immediately respond to the user
    return NextResponse.json({ 
        message: `Import started for ${originalName}. This may take several minutes. You can now safely close this window.` 
    }, { status: 202 }); // 202 Accepted indicates the request is accepted for processing

  } catch (error: any) {
    console.error('Import initiation error:', error);
    return NextResponse.json({ message: `Failed to start import process: ${error.message}` }, { status: 500 });
  }
}
