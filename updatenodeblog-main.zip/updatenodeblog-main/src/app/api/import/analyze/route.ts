
import { NextRequest, NextResponse } from 'next/server';
import { parseStringPromise } from 'xml2js';
import { promises as fs } from 'fs';
import path from 'path';
import os from 'os';

export const config = {
  api: {
    bodyParser: {
      sizeLimit: '25mb', // Set a higher limit for this specific route
    },
  },
};


// Helper to extract a value from a WXR item
function getXmlValue(item: any, key: string, fallback: string = ''): string {
    if (item[key] && item[key][0]) {
        if (typeof item[key][0] === 'object' && item[key][0]._) {
            return item[key][0]._; // Handle CDATA
        }
        return item[key][0];
    }
    return fallback;
}


export async function POST(request: NextRequest) {
    try {
        const formData = await request.formData();
        const file = formData.get('file') as File | null;

        if (!file) {
            return NextResponse.json({ message: 'No file uploaded.' }, { status: 400 });
        }
        
        // Save the file to a temporary location on the server
        const tempDir = path.join(os.tmpdir(), 'studio-imports');
        await fs.mkdir(tempDir, { recursive: true });
        const tempFilePath = path.join(tempDir, `${Date.now()}-${file.name}`);
        
        const fileBuffer = Buffer.from(await file.arrayBuffer());
        await fs.writeFile(tempFilePath, fileBuffer);

        // Analyze the file from the temp location
        const fileContent = await fs.readFile(tempFilePath, 'utf-8');
        const parsedXml = await parseStringPromise(fileContent);

        const channel = parsedXml.rss?.channel?.[0];
        if (!channel) {
            throw new Error('Invalid WXR file: Missing RSS channel.');
        }

        const authors = channel['wp:author']?.map((author: any) => ({
            login: getXmlValue(author, 'wp:author_login'),
            displayName: getXmlValue(author, 'wp:author_display_name'),
        })) || [];


        return NextResponse.json({ 
            authors, 
            filePath: tempFilePath // Pass the server file path to the next step
        });

    } catch (error: any) {
        console.error("XML Analysis Error:", error);
        return NextResponse.json({ message: 'Could not parse the XML file. Please ensure it is a valid WXR file.', error: error.message }, { status: 500 });
    }
}
