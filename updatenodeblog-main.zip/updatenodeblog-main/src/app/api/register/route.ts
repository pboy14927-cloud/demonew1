
import { NextResponse } from 'next/server';
import { getUsers } from '@/lib/data';
import { query } from '@/lib/mysql';
import bcrypt from 'bcryptjs';

export async function POST(request: Request) {
  try {
    const existingUsers = await getUsers();
    if (existingUsers.length > 0) {
      return NextResponse.json({ message: 'Registration is not allowed.' }, { status: 403 });
    }

    const { username, name, email, password } = await request.json();

    if (!username || !email || !password) {
      return NextResponse.json({ message: 'Missing required fields.' }, { status: 400 });
    }

    // Check if email or username already exists (should not happen if users table is empty, but good practice)
    const emailCheck: any[] = await query('SELECT id FROM users WHERE email = ? OR username = ?', [email, username]);
    if (emailCheck.length > 0) {
        return NextResponse.json({ message: 'A user with that email or username already exists.' }, { status: 409 });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    
    const finalName = name || username;
    const defaultAvatar = `https://placehold.co/100x100.png?text=${finalName.charAt(0)}`;

    const sql = `
      INSERT INTO users (username, name, email, password, role, avatar)
      VALUES (?, ?, ?, ?, ?, ?)
    `;
    
    await query(sql, [username, finalName, email, hashedPassword, 'administrator', defaultAvatar]);

    return NextResponse.json({ message: 'Administrator created successfully.' }, { status: 201 });

  } catch (error) {
    console.error('Registration error:', error);
    return NextResponse.json({ message: 'An internal server error occurred.' }, { status: 500 });
  }
}
