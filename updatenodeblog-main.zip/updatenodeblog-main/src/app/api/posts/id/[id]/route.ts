// src/app/api/posts/id/[id]/route.ts
import { NextResponse } from 'next/server';
import { getPostById } from '@/lib/data';

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const post = await getPostById(params.id);
    if (post) {
        return NextResponse.json(post);
    }
    return NextResponse.json({ message: 'Post not found' }, { status: 404 });
  } catch (error) {
    console.error(`Error fetching post by ID ${params.id}:`, error);
    return NextResponse.json({ message: 'Internal Server Error' }, { status: 500 });
  }
}
