
'use server';

import { NextRequest, NextResponse } from 'next/server';
import { getPaginatedPostsWithAuthors } from '@/lib/data';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const page = searchParams.get('page');
  const limit = searchParams.get('limit');
  
  if (page && limit) {
      const posts = await getPaginatedPostsWithAuthors({ page: parseInt(page), limit: parseInt(limit) });
      return NextResponse.json(posts);
  }
  
  // Return empty array or error if no pagination params
  return NextResponse.json({ message: 'Page and limit parameters are required.' }, { status: 400 });
}

    