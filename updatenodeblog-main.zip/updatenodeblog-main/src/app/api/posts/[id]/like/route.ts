
'use server';

import { NextResponse } from 'next/server';
import { query } from '@/lib/mysql';

export async function POST(
  request: Request,
  { params }: { params: { id: string } }
) {
  const { id } = params;

  if (!id) {
    return NextResponse.json({ message: 'Post ID is required.' }, { status: 400 });
  }

  try {
    await query('UPDATE posts SET likes = likes + 1 WHERE id = ?', [id]);
    const [updatedPost]: any = await query('SELECT likes FROM posts WHERE id = ?', [id]);
    
    if (updatedPost.length === 0) {
       return NextResponse.json({ message: 'Post not found.' }, { status: 404 });
    }

    return NextResponse.json({ likes: updatedPost[0].likes }, { status: 200 });
  } catch (error: any) {
    console.error(`Error liking post ${id}:`, error);
    return NextResponse.json({ message: 'Failed to like post', error: error.message }, { status: 500 });
  }
}
