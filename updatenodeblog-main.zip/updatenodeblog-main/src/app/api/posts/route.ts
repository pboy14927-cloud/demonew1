
'use server';

import { NextRequest, NextResponse } from 'next/server';
import { getPublishedPosts, getPaginatedPosts } from '@/lib/data';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const page = searchParams.get('page');
  const limit = searchParams.get('limit');
  
  if (page && limit) {
      const posts = await getPaginatedPosts({ page: parseInt(page), limit: parseInt(limit) });
      return NextResponse.json(posts);
  }

  const posts = await getPublishedPosts();
  return NextResponse.json(posts);
}
