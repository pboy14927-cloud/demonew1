

'use server';

import { NextRequest, NextResponse } from 'next/server';
import { getUserIdFromSession, createUser } from '@/lib/data';

export async function POST(request: NextRequest) {
  const currentUserId = await getUserIdFromSession();
  if (!currentUserId) {
    return NextResponse.json({ message: 'Unauthorized' }, { status: 401 });
  }

  try {
    const body = await request.json();
    
    await createUser(body);

    return NextResponse.json({ message: 'User created successfully.' }, { status: 201 });

  } catch (error: any) {
    console.error('User creation error:', error);
    // Check if it's a "user already exists" error
    if (error.message.includes('already exists')) {
      return NextResponse.json({ message: error.message }, { status: 409 });
    }
    return NextResponse.json(
      { message: 'An internal server error occurred.', error: error.message },
      { status: 500 }
    );
  }
}

