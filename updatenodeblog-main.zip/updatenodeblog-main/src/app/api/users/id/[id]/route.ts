

import { NextRequest, NextResponse } from 'next/server';
import { updateUser, getUserById } from '@/lib/data';

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const { id } = params;
  try {
    const { userData, newPassword } = await request.json();
    
    // Ensure the user exists before updating
    const existingUser = await getUserById(id);
    if (!existingUser) {
      return NextResponse.json({ message: 'User not found' }, { status: 404 });
    }
    
    const updatedUser = await updateUser(id, userData, newPassword);
    
    // Return the full user object, which now has the correct avatar path
    return NextResponse.json({ message: 'User updated successfully', user: updatedUser }, { status: 200 });

  } catch (error: any) {
    console.error(`Error updating user ${id}:`, error);
    return NextResponse.json({ message: 'Failed to update user', error: error.message }, { status: 500 });
  }
}

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  const user = await getUserById(params.id);
  if (user) {
    return NextResponse.json(user);
  }
  return new Response('User not found', { status: 404 });
}

    