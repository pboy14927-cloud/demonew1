
'use server';

import { NextResponse } from 'next/server';
import { query } from '@/lib/mysql';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export async function GET(request: Request) {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as any)?.role !== 'administrator') {
      return NextResponse.json({ message: 'Forbidden' }, { status: 403 });
  }

  try {
    const rows: any[] = await query('SHOW TABLES');
    const tables = rows.map(row => Object.values(row)[0]);
    
    return NextResponse.json({ tables }, { status: 200 });
  } catch (error: any) {
    console.error('Table check error:', error);
    return NextResponse.json({ message: `Failed to check tables: ${error.message}` }, { status: 500 });
  }
}
