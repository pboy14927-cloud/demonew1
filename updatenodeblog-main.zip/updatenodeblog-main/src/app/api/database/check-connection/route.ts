
'use server';

import { NextResponse } from 'next/server';
import { query } from '@/lib/mysql';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export async function GET(request: Request) {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as any)?.role !== 'administrator') {
      return NextResponse.json({ message: 'Forbidden' }, { status: 403 });
  }

  try {
    // A simple query to check the connection
    await query('SELECT 1');
    return NextResponse.json({ message: 'Database connection successful.' }, { status: 200 });
  } catch (error: any) {
    console.error('Database connection check error:', error);
    return NextResponse.json({ message: `Database connection failed: ${error.message}` }, { status: 500 });
  }
}
