
import { NextResponse } from 'next/server';
import { getMediaById } from '@/lib/data';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { query } from '@/lib/mysql';

export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
      return NextResponse.json({ message: 'Unauthorized' }, { status: 401 });
  }

  const { id } = params;
  if (!id) {
    return NextResponse.json({ message: 'Media ID is required.' }, { status: 400 });
  }

  try {
    const { altText, fileName } = await request.json();
    
    // In a real app, you might want more validation here
    
    const result: any = await query('UPDATE media SET altText = ?, fileName = ? WHERE id = ?', [altText, fileName, id]);

    if (result.affectedRows === 0) {
        return NextResponse.json({ message: 'Media not found.' }, { status: 404 });
    }
    
    const updatedMedia = await getMediaById(id);

    return NextResponse.json(updatedMedia, { status: 200 });

  } catch (error: any) {
     console.error(`Error updating media ${id}:`, error);
    return NextResponse.json({ message: 'Failed to update media', error: error.message }, { status: 500 });
  }
}


export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
      return NextResponse.json({ message: 'Unauthorized' }, { status: 401 });
  }
  
  const { id } = params;

  if (!id) {
    return NextResponse.json({ message: 'Media ID is required.' }, { status: 400 });
  }

  try {
    const result: any = await query('DELETE FROM media WHERE id = ?', [id]);
    
    if (result.affectedRows === 0) {
        return NextResponse.json({ message: 'Media not found in DB for deletion.' }, { status: 404 });
    }

    return NextResponse.json({ message: 'Media deleted successfully.' }, { status: 200 });
  } catch (error: any) {
    console.error(`Error deleting media ${id}:`, error);
    return NextResponse.json({ message: 'Failed to delete media', error: error.message }, { status: 500 });
  }
}
