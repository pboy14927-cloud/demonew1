
import { NextResponse } from 'next/server';
import { query } from '@/lib/mysql';

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  const { id } = params;

  if (!id) {
    return new Response('Media ID is required.', { status: 400 });
  }

  try {
    const rows: any[] = await query('SELECT data, fileType FROM media WHERE id = ?', [id]);
    
    if (rows.length === 0 || !rows[0].data) {
      return new Response('Media not found.', { status: 404 });
    }
    const media = rows[0];
    const fileBuffer = Buffer.from(media.data);

    return new Response(fileBuffer, {
        status: 200,
        headers: {
            'Content-Type': media.fileType,
            'Content-Length': fileBuffer.length.toString(),
        },
    });
  } catch (error: any) {
    console.error(`Error fetching media file ${id}:`, error);
    return new Response('Failed to fetch media file.', { status: 500 });
  }
}
