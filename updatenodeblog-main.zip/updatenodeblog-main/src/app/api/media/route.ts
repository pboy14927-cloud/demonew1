
'use server';

import { NextRequest, NextResponse } from 'next/server';
import { createMedia, Media, getSettings as getSiteSettings } from '@/lib/data';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export async function POST(request: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
      return NextResponse.json({ message: 'Unauthorized' }, { status: 401 });
  }

  try {
    const formData = await request.formData();
    const file = formData.get('file') as File | null;
    const userId = (session.user as any).id;

    if (!file) {
      return NextResponse.json({ message: 'No file uploaded.' }, { status: 400 });
    }
    
    if (!userId) {
        return NextResponse.json({ message: 'User not authenticated.' }, { status: 401 });
    }

    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    const newMediaData: Partial<Omit<Media, 'id' | 'url'>> & { data: Buffer } = {
        fileName: file.name,
        fileType: file.type,
        fileSize: file.size,
        altText: file.name.split('.').slice(0, -1).join(' '),
        uploadedBy: userId,
        data: buffer,
    };

    const newMedia = await createMedia(newMediaData);

    return NextResponse.json(newMedia, { status: 201 });

  } catch (error: any) {
    console.error('Media upload error:', error);
    if(error.code === 'ER_DATA_TOO_LONG' || error.message.includes('Packet for query is too large')) {
         return NextResponse.json({ message: `File is too large. Please increase the 'max_allowed_packet' size in your MySQL configuration.` }, { status: 413 });
    }
    return NextResponse.json({ message: `An internal server error occurred: ${error.message}` }, { status: 500 });
  }
}
