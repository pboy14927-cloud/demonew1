

import { NextRequest, NextResponse } from 'next/server';
import { createTag, getUserIdFromSession } from '@/lib/data';

export async function POST(request: NextRequest) {
  const userId = await getUserIdFromSession();
  if (!userId) {
      return NextResponse.json({ message: 'Unauthorized' }, { status: 401 });
  }
  
  try {
    const body = await request.json();
    await createTag(body);
    return NextResponse.json({ message: 'Tag created successfully' }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json({ message: 'Failed to create tag', error: error.message }, { status: 500 });
  }
}

