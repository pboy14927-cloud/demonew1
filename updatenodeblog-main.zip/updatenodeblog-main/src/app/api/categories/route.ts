

import { NextRequest, NextResponse } from 'next/server';
import { createCategory, getUserIdFromSession } from '@/lib/data';

export async function POST(request: NextRequest) {
  const userId = await getUserIdFromSession();
  if (!userId) {
      return NextResponse.json({ message: 'Unauthorized' }, { status: 401 });
  }
  
  try {
    const body = await request.json();
    await createCategory(body);
    return NextResponse.json({ message: 'Category created successfully' }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json({ message: 'Failed to create category', error: error.message }, { status: 500 });
  }
}
