
'use server';

import { NextResponse } from 'next/server';
import { query } from '@/lib/mysql';

export async function POST(request: Request) {
  try {
    // This is a more robust way to check for a column's type and change it.
    const [columns]: any[] = await query(
      "SELECT COLUMN_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'media' AND COLUMN_NAME = 'url'",
      [process.env.DB_NAME]
    );

    if (columns.length > 0 && columns[0].COLUMN_TYPE.toLowerCase() !== 'longtext') {
        await query("ALTER TABLE `media` MODIFY COLUMN `url` LONGTEXT");
        return NextResponse.json({ message: 'Database schema fixed successfully. The media URL column can now store full image data.' }, { status: 200 });
    } else if (columns.length === 0) {
        // This case should ideally not happen if the initial schema setup ran
        await query("ALTER TABLE `media` ADD COLUMN `url` LONGTEXT");
        return NextResponse.json({ message: 'The `url` column was not found and has been added.' }, { status: 400 });
    } else {
        return NextResponse.json({ message: 'Database schema is already up-to-date.' }, { status: 200 });
    }

  } catch (error: any) {
    console.error('Schema fix error:', error);
    return NextResponse.json({ message: `An internal server error occurred: ${error.message}` }, { status: 500 });
  }
}
