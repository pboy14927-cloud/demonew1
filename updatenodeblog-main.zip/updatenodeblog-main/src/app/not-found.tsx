
'use server';

import PublicHeader from '@/components/public-header';
import PublicFooter from '@/components/public-footer';
import Link from 'next/link';
import BackButton from '@/components/back-button';
import InteractiveSearch from '@/components/interactive-search';
import Image from 'next/image';

export default async function NotFound() {

  return (
    <div className="flex flex-col min-h-screen">
      <PublicHeader />
      <main className="flex-grow">
        <div className="container px-4 md:px-6 py-8">
            <div className="grid md:grid-cols-2 gap-16 items-center py-12">
                <div className="text-center md:text-left">
                    <h1 className="text-9xl font-bold text-primary" style={{color: '#3498db'}}>404</h1>
                </div>
                <div>
                    <h2 className="text-3xl font-bold mb-4">Page Not Found!</h2>
                    <p className="text-muted-foreground mb-6">
                        We're sorry, but we can't find the page you were looking for. It's probably some
                        thing we've done wrong but now we know about it and we'll try to fix it. In the
                        meantime, try one of these options:
                    </p>
                    <ul className="list-disc list-inside space-y-2 mb-6">
                        <li>
                            <BackButton />
                        </li>
                        <li>
                            <Link href="/" className="text-primary hover:underline">Go to Homepage</Link>
                        </li>
                    </ul>
                    <div className="max-w-sm">
                        <InteractiveSearch />
                    </div>
                </div>
            </div>
        </div>
      </main>
      <PublicFooter />
    </div>
  );
}
