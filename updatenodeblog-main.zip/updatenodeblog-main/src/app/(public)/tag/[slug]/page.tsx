
'use server';
import { notFound } from 'next/navigation';
import { getTags, getTagBySlug, getPostsByTag, getCategoryArchiveSettings, getBrandingSettings, getSeoSettings, Tag, getPermalinkSettings } from '@/lib/data';
import ArchivePageLayout from '@/components/blog/archive-page-layout';
import { Post } from '@/lib/data';
import type { Metadata, ResolvingMetadata } from 'next';

type TagArchivePageProps = {
  params: {
    slug: string;
  };
};

function replaceTags(template: string | undefined | null, tag: Tag, brandingSettings: any, seoSettings: any) {
    if (!template) return '';
    let result = template;
    const separator = seoSettings?.separator || '-';
    const siteTitle = brandingSettings.websiteTitle;
    
    result = result.replace(/\{\{term_title\}\}/g, tag.name);
    result = result.replace(/\{\{tag_title\}\}/g, tag.name);
    result = result.replace(/\{\{tag_name\}\}/g, tag.name);
    result = result.replace(/\{\{term_description\}\}/g, tag.description || '');
    result = result.replace(/\{\{tag_description\}\}/g, tag.description || '');
    result = result.replace(/\{\{site_title\}\}/g, siteTitle);
    result = result.replace(/\{\{sep\}\}/g, ` ${separator} `);
    
    return result;
};


export async function generateMetadata({ params }: TagArchivePageProps, parent: ResolvingMetadata): Promise<Metadata> {
    const tag = await getTagBySlug(params.slug);
    if (!tag) {
        return {
            title: 'Tag Not Found'
        }
    }
    
    const brandingSettings = await getBrandingSettings();
    const seoSettings = await getSeoSettings();
    const siteUrl = brandingSettings.siteUrl || 'http://localhost:3000';
    const permalinks = await getPermalinkSettings();
    const tagBase = permalinks.tagBase || 'tag';

    const finalSeoTitle = replaceTags(
        seoSettings.taxonomies.tags.titleTemplate,
        tag,
        brandingSettings,
        seoSettings
    );
     const finalSeoDescription = replaceTags(
        seoSettings.taxonomies.tags.metaDescription,
        tag,
        brandingSettings,
        seoSettings
    );

    return {
        title: finalSeoTitle,
        description: finalSeoDescription || `Posts tagged with ${tag.name}.`,
        metadataBase: new URL(siteUrl),
        alternates: {
            canonical: `/${tagBase}/${params.slug}`,
        },
    };
}


export default async function TagArchivePage({ params }: TagArchivePageProps) {
  const tag = await getTagBySlug(params.slug);
  
  if (!tag) {
    notFound();
  }

  const posts: Post[] = await getPostsByTag(tag.name);
  const settings = await getCategoryArchiveSettings();

  return (
    <ArchivePageLayout
        title={`Tag: "${tag.name}"`}
        description={tag.description || `Posts tagged with ${tag.name}.`}
        posts={posts}
        settings={settings}
    />
  );
}

export async function generateStaticParams() {
    const tags = await getTags();
    return tags.map(tag => ({
        slug: tag.slug,
    }));
}
