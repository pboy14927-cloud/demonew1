
'use server';

import { notFound } from 'next/navigation';
import { getAllContent, getContentFromSlug, getBrandingSettings, getSeoSettings, getSinglePostSettings, getSidebarSettings, getBlogArchiveSettings, getUserById, getComments, getPublishedPosts, generatePostUrl, getCategories, getPostById, getPermalinkSettings } from '@/lib/data';
import type { Metadata, ResolvingMetadata } from 'next';
import PageRenderer from '@/components/page-renderer';
import CommentsSection from '@/components/comments-section';
import PostPageClient from '@/components/post-page-client';
import { Post, User, BrandingSettings, Category } from '@/lib/data';

type DynamicPageProps = {
    params: {
        slug: string[];
    }
    searchParams: { [key: string]: string | string[] | undefined };
}

// Generate static paths for all published posts and pages
export async function generateStaticParams() {
  const allContent = await getAllContent();
  const publishedContent = allContent.filter(p => p.status === 'published');
  
  const paths = await Promise.all(publishedContent.map(async (content) => {
    const url = await generatePostUrl(content);
    // Remove leading slash and split into segments
    return { slug: url.startsWith('/') ? url.substring(1).split('/') : url.split('/') };
  }));

  return paths;
}

// Helper function to strip HTML tags
function stripHtml(html: string){
   if(!html) return '';
   return html.replace(/<[^>]*>?/gm, '');
}

// This function needs to be outside generateMetadata to be reusable
async function replaceTags(template: string | undefined | null, contentData: Post, brandingSettings: BrandingSettings, seoSettings?: any) {
    if (!template) return '';
    let result = template;
    const separator = seoSettings?.separator || '-';
    const siteTitle = brandingSettings.websiteTitle;
    
    result = result.replace(/\{\{site_title\}\}/g, siteTitle);
    result = result.replace(/\{\{sep\}\}/g, ` ${separator} `);
    result = result.replace(/\{\{page_title\}\}/g, contentData.title || '');
    result = result.replace(/\{\{post_title\}\}/g, contentData.title || '');
    result = result.replace(/\{\{page_excerpt\}\}/g, stripHtml(contentData.excerpt || contentData.content).substring(0, 150));
    result = result.replace(/\{\{post_excerpt\}\}/g, stripHtml(contentData.excerpt || contentData.content).substring(0, 150));
    result = result.replace(/\{\{tagline\}\}/g, brandingSettings.websiteDescription || '');
    return result;
};


// Helper function to get all data needed for a post page
async function getPostPageData(postData: Post) {
    if (!postData || postData.status !== 'published') {
        return null;
    }

    const [
        settings,
        sidebarSettings,
        archiveSettings,
        author,
        brandingSettings,
        allComments,
        allPosts,
        allCategories
    ] = await Promise.all([
        getSinglePostSettings(),
        getSidebarSettings(),
        getBlogArchiveSettings(),
        getUserById(postData.authorId),
        getBrandingSettings(),
        getComments(),
        getPublishedPosts(), // Fetch for related and sidebar
        getCategories() // Fetch for sidebar
    ]);

    const postComments = allComments.filter(c => c.postId === postData.id && c.status === 'approved');

    let relatedPosts: (Post & { author: User | null })[] = [];

    if (settings.showRelatedPosts && settings.numRelatedPosts > 0) {
        const filteredRelatedPosts = allPosts
            .filter(p => p.id !== postData.id && p.categories.some(c => postData.categories.includes(c)))
            .slice(0, settings.numRelatedPosts);
        
        const relatedAuthors = await Promise.all(filteredRelatedPosts.map(p => getUserById(p.authorId)));
        
        relatedPosts = filteredRelatedPosts.map((p, index) => ({
            ...p,
            author: relatedAuthors[index]
        }));
    }
    
    return {
        post: postData,
        settings,
        sidebarSettings,
        archiveSettings,
        author,
        brandingSettings,
        postComments,
        relatedPosts,
        sidebarData: {
            latestPosts: allPosts?.slice(0, 5) || [],
            categories: allCategories || [],
        }
    };
}


export async function generateMetadata(props: DynamicPageProps, parent: ResolvingMetadata): Promise<Metadata> {
  const params = typeof props.params?.then === 'function' ? await props.params : props.params;
  const searchParams = typeof props.searchParams?.then === 'function' ? await props.searchParams : props.searchParams;

  const slug = params.slug || [];
  
  // Prevent file-like paths from being processed
  if (slug.length > 0 && slug[slug.length - 1].includes('.')) {
    return notFound();
  }

  const contentData = await getContentFromSlug(slug, searchParams);
  const brandingSettings = await getBrandingSettings();
  const seoSettings = await getSeoSettings();
  const siteUrl = brandingSettings.siteUrl || 'http://localhost:3000';
  
  if (!contentData) {
     return {
        title: `Page Not Found ${seoSettings.separator} ${brandingSettings.websiteTitle}`,
        description: "The page you are looking for does not exist.",
        metadataBase: new URL(siteUrl),
     }
  }
  
  const finalPostUrl = await generatePostUrl(contentData);

  const finalSeoTitle = await replaceTags(contentData.seo?.title || (contentData.isPage ? seoSettings.contentTypes.pages.titleTemplate : seoSettings.contentTypes.posts.titleTemplate), contentData, brandingSettings, seoSettings);
  const finalSeoDescription = await replaceTags(contentData.seo?.description || (contentData.isPage ? seoSettings.contentTypes.pages.metaDescription : seoSettings.contentTypes.posts.metaDescription), contentData, brandingSettings, seoSettings);
  
  const ogTitle = await replaceTags(contentData.seo?.facebookTitle || '', contentData, brandingSettings, seoSettings) || finalSeoTitle;
  const ogDescription = await replaceTags(contentData.seo?.facebookDescription || '', contentData, brandingSettings, seoSettings) || finalSeoDescription;
  const twitterTitle = await replaceTags(contentData.seo?.twitterTitle || '', contentData, brandingSettings, seoSettings) || finalSeoTitle;
  const twitterDescription = await replaceTags(contentData.seo?.twitterDescription || '', contentData, brandingSettings, seoSettings) || finalSeoDescription;

  const ogImage = contentData.seo?.facebookImage || contentData.featuredImage || seoSettings.social.ogImageUrl || '';
  const twitterImage = contentData.seo?.twitterImage || contentData.featuredImage || seoSettings.social.ogImageUrl || '';

  return {
    title: finalSeoTitle,
    description: finalSeoDescription,
    metadataBase: new URL(siteUrl),
    alternates: {
        canonical: contentData.seo?.canonical || finalPostUrl,
    },
    openGraph: {
      title: ogTitle,
      description: ogDescription,
      type: 'website',
      url: finalPostUrl,
      images: ogImage ? [{ url: ogImage }] : [],
    },
    twitter: {
      card: 'summary_large_image',
      title: twitterTitle,
      description: twitterDescription,
      images: twitterImage ? [twitterImage] : [],
    },
  };
}


export default async function DynamicPage(props: DynamicPageProps) {
  const params = typeof props.params?.then === 'function' ? await props.params : props.params;
  const searchParams = typeof props.searchParams?.then === 'function' ? await props.searchParams : props.searchParams;
  const slug = params.slug || [];

  // Prevent file-like paths from being processed
  if (slug.length > 0 && slug[slug.length - 1].includes('.')) {
    return notFound();
  }
  
  const contentData = await getContentFromSlug(slug, searchParams);

  if (!contentData) {
    notFound();
  }

  // If it's a regular page, render it with PageRenderer
  if (contentData.isPage) {
     return (
        <>
            <PageRenderer page={contentData} />
            {contentData.commentStatus === 'open' && (
                <div className="container px-4 md:px-6 py-12">
                    <CommentsSection postId={contentData.id} />
                </div>
            )}
        </>
      )
  }

  // Otherwise, it's a post, render the post page
  const pageData = await getPostPageData(contentData);

  if (!pageData) {
    notFound();
  }

  return (
    <>
        <PostPageClient pageData={pageData} />
    </>
  );
}
