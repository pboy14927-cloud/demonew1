
'use server';
import { notFound } from 'next/navigation';
import { getCategories, getCategoryBySlug, getPostsByCategory } from '@/lib/data';
import { getCategoryArchiveSettings, getBrandingSettings, getSeoSettings, getPermalinkSettings } from '@/lib/data';
import ArchivePageLayout from '@/components/blog/archive-page-layout';
import { Post, Category } from '@/lib/data';
import type { Metadata, ResolvingMetadata } from 'next';


type CategoryArchivePageProps = {
  params: {
    slug: string;
  };
};

function replaceTags(template: string | undefined | null, category: Category, brandingSettings: any, seoSettings: any) {
    if (!template) return '';
    let result = template;
    const separator = seoSettings?.separator || '-';
    const siteTitle = brandingSettings.websiteTitle;
    
    result = result.replace(/\{\{term_title\}\}/g, category.name);
    result = result.replace(/\{\{category_name\}\}/g, category.name);
    result = result.replace(/\{\{term_description\}\}/g, category.description || '');
    result = result.replace(/\{\{site_title\}\}/g, siteTitle);
    result = result.replace(/\{\{sep\}\}/g, ` ${separator} `);
    
    return result;
};


export async function generateMetadata({ params }: CategoryArchivePageProps, parent: ResolvingMetadata): Promise<Metadata> {
    const category = await getCategoryBySlug(params.slug);
    if (!category) {
        return {
            title: 'Category Not Found'
        }
    }
    
    const brandingSettings = await getBrandingSettings();
    const seoSettings = await getSeoSettings();
    const siteUrl = brandingSettings.siteUrl || 'http://localhost:3000';
    const permalinks = await getPermalinkSettings();
    const categoryBase = permalinks.categoryBase || 'category';

    const finalSeoTitle = replaceTags(
        seoSettings.taxonomies.categories.titleTemplate,
        category,
        brandingSettings,
        seoSettings
    );
     const finalSeoDescription = replaceTags(
        seoSettings.taxonomies.categories.metaDescription,
        category,
        brandingSettings,
        seoSettings
    );

    return {
        title: finalSeoTitle,
        description: finalSeoDescription || `Posts in the ${category.name} category.`,
        metadataBase: new URL(siteUrl),
        alternates: {
            canonical: `/${categoryBase}/${params.slug}`,
        },
    };
}


export default async function CategoryArchivePage({ params }: CategoryArchivePageProps) {
  const category = await getCategoryBySlug(params.slug);
  
  if (!category) {
    notFound();
  }

  const posts: Post[] = await getPostsByCategory(category.id);
  const settings = await getCategoryArchiveSettings();

  return (
    <ArchivePageLayout
        title={`Category: ${category.name}`}
        description={category.description || `Posts in the ${category.name} category.`}
        posts={posts}
        settings={settings}
    />
  );
}

export async function generateStaticParams() {
    const categories = await getCategories();

    return categories.map(category => ({
        slug: category.slug,
    }));
}
