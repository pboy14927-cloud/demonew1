
'use server';
import { notFound } from 'next/navigation';
import { getUserById, getPostsByAuthorId, getUsers, getCategoryArchiveSettings, getBrandingSettings, getSeoSettings, getPermalinkSettings, User } from '@/lib/data';
import ArchivePageLayout from '@/components/blog/archive-page-layout';
import { Post } from '@/lib/data';
import type { Metadata, ResolvingMetadata } from 'next';
import Image from 'next/image';

type AuthorArchivePageProps = {
  params: {
    id: string;
  };
};

function replaceTags(template: string | undefined | null, author: User, brandingSettings: any, seoSettings: any) {
    if (!template) return '';
    let result = template;
    const separator = seoSettings?.separator || '-';
    const siteTitle = brandingSettings.websiteTitle;
    
    result = result.replace(/\{\{author_name\}\}/g, author.name);
    result = result.replace(/\{\{name\}\}/g, author.name);
    result = result.replace(/\{\{site_title\}\}/g, siteTitle);
    result = result.replace(/\{\{sep\}\}/g, ` ${separator} `);
    
    return result;
};


export async function generateMetadata({ params }: AuthorArchivePageProps, parent: ResolvingMetadata): Promise<Metadata> {
    const author = await getUserById(params.id);
    if (!author) {
        return {
            title: 'Author Not Found'
        }
    }
    
    const brandingSettings = await getBrandingSettings();
    const seoSettings = await getSeoSettings();
    const siteUrl = brandingSettings.siteUrl || 'http://localhost:3000';
    const permalinks = await getPermalinkSettings();
    const authorBase = permalinks.authorUrl || 'author'; 

    const finalSeoTitle = replaceTags(
        seoSettings.archives.authorArchiveTitle,
        author,
        brandingSettings,
        seoSettings
    );

    let authorImageUrl = author.avatar;
    if (authorImageUrl && authorImageUrl.startsWith('/api/media')) {
        authorImageUrl = `${siteUrl}${authorImageUrl}`;
    }

    return {
        title: finalSeoTitle,
        description: author.bio || `Posts by ${author.name}`,
        metadataBase: new URL(siteUrl),
        alternates: {
            canonical: `/${authorBase}/${params.id}`,
        },
        openGraph: {
            title: finalSeoTitle,
            description: author.bio || `Posts by ${author.name}`,
            images: authorImageUrl ? [authorImageUrl] : [],
        },
        twitter: {
            title: finalSeoTitle,
            description: author.bio || `Posts by ${author.name}`,
            images: authorImageUrl ? [authorImageUrl] : [],
        }
    };
}


export default async function AuthorArchivePage({ params }: AuthorArchivePageProps) {
  const author = await getUserById(params.id);
  
  if (!author) {
    notFound();
  }

  const posts: Post[] = await getPostsByAuthorId(params.id);
  const settings = await getCategoryArchiveSettings();
  const brandingSettings = await getBrandingSettings();
  
  let authorImageUrl = author.avatar;
  if (authorImageUrl && authorImageUrl.startsWith('/api/media')) {
      authorImageUrl = `${brandingSettings.siteUrl}${authorImageUrl}`;
  } else if (!authorImageUrl) {
      authorImageUrl = `https://placehold.co/100x100.png?text=${author.name.charAt(0)}`;
  }

  const archiveTitle = (
    <div className="flex items-center gap-4">
        <Image src={authorImageUrl} alt={author.name} width={80} height={80} className="rounded-full" />
        <div>
            <p className="text-sm text-muted-foreground">Posts by</p>
            <h1 className="text-3xl font-bold">{author.name}</h1>
        </div>
    </div>
  );

  return (
    <ArchivePageLayout
        title={archiveTitle}
        description={author.bio || `Posts written by ${author.name}.`}
        posts={posts}
        settings={settings}
    />
  );
}

export async function generateStaticParams() {
    const users = await getUsers();
    return users.map(user => ({
        id: user.id.toString(),
    }));
}
