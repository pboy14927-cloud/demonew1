
'use server';

import React from 'react';
import { getHomepageLayout, getPublishedPosts, getCategories, getSettings, getBlogArchiveSettings, getAllContent, getPostById, getUserById, getSinglePostSettings, getSidebarSettings, getComments, getBrandingSettings, Post, User, BrandingSettings, Category, getPaginatedPostsWithAuthors, getSeoSettings } from '@/lib/data';
import { notFound } from 'next/navigation';
import HomepageBuilder from '@/components/homepage-builder';
import ArchivePageLayout from '@/components/blog/archive-page-layout';
import PageRenderer from '@/components/page-renderer';
import PublicHeader from '@/components/public-header';
import PublicFooter from '@/components/public-footer';
import PostPageClient from '@/components/post-page-client';
import type { Metadata } from 'next';


// Helper to replace SEO template tags
function replaceTags(template: string | undefined | null, siteTitle: string, separator: string, tagline: string) {
    if (!template) return '';
    let result = template;
    result = result.replace(/\{\{site_title\}\}/g, siteTitle);
    result = result.replace(/\{\{sep\}\}/g, ` ${separator} `);
    result = result.replace(/\{\{tagline\}\}/g, tagline);
    return result;
};


export async function generateMetadata(): Promise<Metadata> {
  const brandingSettings = await getBrandingSettings();
  const seoSettings = await getSeoSettings();
  const siteUrl = brandingSettings.siteUrl || 'http://localhost:3000';

  const finalSeoTitle = replaceTags(seoSettings.homepageTitle, brandingSettings.websiteTitle, seoSettings.separator, brandingSettings.websiteDescription);
  const finalSeoDescription = replaceTags(seoSettings.homepageDescription, brandingSettings.websiteTitle, seoSettings.separator, brandingSettings.websiteDescription);
  
  const ogTitle = seoSettings.social.facebookTitle || finalSeoTitle;
  const ogDescription = seoSettings.social.facebookDescription || finalSeoDescription;
  const twitterTitle = seoSettings.social.twitterTitle || finalSeoTitle;
  const twitterDescription = seoSettings.social.twitterDescription || finalSeoDescription;

  const ogImage = seoSettings.social.ogImageUrl || '';
  const twitterImage = seoSettings.social.twitterImage || '';

  return {
    title: finalSeoTitle,
    description: finalSeoDescription,
    metadataBase: new URL(siteUrl),
    alternates: {
        canonical: '/',
    },
    openGraph: {
      title: ogTitle,
      description: ogDescription,
      type: 'website',
      url: '/',
      images: ogImage ? [{ url: ogImage }] : [],
    },
    twitter: {
      card: 'summary_large_image',
      title: twitterTitle,
      description: twitterDescription,
      images: twitterImage ? [twitterImage] : [],
    },
  };
}


// Helper function to get all data needed for a post page
async function getPostPageData(postData: Post) {
    if (!postData || postData.status !== 'published') {
        return null;
    }

    const [
        settings,
        sidebarSettings,
        archiveSettings,
        author,
        brandingSettings,
        allComments,
        allPosts,
        allCategories
    ] = await Promise.all([
        getSinglePostSettings(),
        getSidebarSettings(),
        getBlogArchiveSettings(),
        getUserById(postData.authorId),
        getBrandingSettings(),
        getComments(),
        getPublishedPosts(), // Fetch for related and sidebar
        getCategories() // Fetch for sidebar
    ]);

    const postComments = allComments.filter(c => c.postId === postData.id && c.status === 'approved');

    let relatedPosts: (Post & { author: User | null })[] = [];

    if (settings.showRelatedPosts && settings.numRelatedPosts > 0) {
        const filteredRelatedPosts = allPosts
            .filter(p => p.id !== postData.id && p.categories.some(c => postData.categories.includes(c)))
            .slice(0, settings.numRelatedPosts);
        
        const relatedAuthors = await Promise.all(filteredRelatedPosts.map(p => getUserById(p.authorId)));
        
        relatedPosts = filteredRelatedPosts.map((p, index) => ({
            ...p,
            author: relatedAuthors[index]
        }));
    }
    
    return {
        post: postData,
        settings,
        sidebarSettings,
        archiveSettings,
        author,
        brandingSettings,
        postComments,
        relatedPosts,
        sidebarData: {
            latestPosts: allPosts?.slice(0, 5) || [],
            categories: allCategories || [],
        }
    };
}


export default async function Home(props: { searchParams: { [key: string]: string | string[] | undefined }}) {
    const searchParams = typeof props.searchParams?.then === 'function' ? await props.searchParams : props.searchParams;
    // Handle Plain permalink structure (?p=123)
    if (searchParams && searchParams.p) {
        const postId = Array.isArray(searchParams.p) ? searchParams.p[0] : searchParams.p;
        const post = await getPostById(postId);
        if (post && post.status === 'published' && !post.isPage) {
            const pageData = await getPostPageData(post);
             if (!pageData) {
                notFound();
            }
            return (
                 <>
                    <PublicHeader />
                    <PostPageClient pageData={pageData} />
                    <PublicFooter />
                </>
            )
        }
    }
    
    // Always prioritize the homepage builder layout
    const homepageLayout = await getHomepageLayout();
    
    const [allPosts, allCategories, archiveSettings] = await Promise.all([
        getPublishedPosts(),
        getCategories(),
        getBlogArchiveSettings()
    ]);
    

    return (
        <>
            <PublicHeader />
            <HomepageBuilder 
                layout={homepageLayout}
                allPosts={allPosts}
                allCategories={allCategories}
                archiveSettings={archiveSettings}
            />
            <PublicFooter />
        </>
    );
}
