
'use server';

import { Inter, Space_Grotesk } from 'next/font/google';
import './globals.css';
import './editor-styles.css';
import Providers from '@/components/providers';
import { getBrandingSettings } from '@/lib/data';
import type { Metadata } from 'next';

const inter = Inter({
    subsets: ['latin'],
    display: 'swap',
    variable: '--font-inter',
});

const spaceGrotesk = Space_Grotesk({
    subsets: ['latin'],
    display: 'swap',
    variable: '--font-space-grotesk',
});

export async function generateMetadata(): Promise<Metadata> {
  const branding = await getBrandingSettings();
  
  return {
    icons: {
      icon: branding.faviconUrl || '/favicon.ico',
    },
  };
}

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  
  return (
    <html lang="en" suppressHydrationWarning className={`${inter.variable} ${spaceGrotesk.variable}`}>
      <head />
      <body>
          <Providers>
            <div className="flex flex-col min-h-screen">
                {children}
            </div>
          </Providers>
      </body>
    </html>
  );
}
