
'use server';

import { getCategories, getBrandingSettings, getPermalinkSettings, getSitemapSettings } from '@/lib/data';
import { Category } from '@/lib/data';

async function generateSiteMap(categories: Category[]) {
  const brandingSettings = await getBrandingSettings();
  const permalinks = await getPermalinkSettings();
  const sitemapSettings = await getSitemapSettings();
  const priority = sitemapSettings.priority.taxonomies.priority;
  const frequency = sitemapSettings.priority.taxonomies.frequency;
  const URL = brandingSettings.siteUrl.endsWith('/') ? brandingSettings.siteUrl.slice(0, -1) : brandingSettings.siteUrl;
  const categoryBase = permalinks.categoryBase || 'category';
  const now = new Date().toISOString();

  return `<?xml version="1.0" encoding="UTF-8"?>
<?xml-stylesheet type="text/xsl" href="/sitemap.xsl"?>
   <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <config>
        <siteUrl>${URL}</siteUrl>
      </config>
     ${categories
       .map(({ slug }) => {
         return `
           <url>
               <loc>${`${URL}/${categoryBase}/${slug}`}</loc>
                <lastmod>${now}</lastmod>
                <changefreq>${frequency}</changefreq>
                <priority>${priority}</priority>
           </url>
         `;
       })
       .join('')}
   </urlset>
 `;
}

export async function GET() {
    const categories = await getCategories();
    const body = await generateSiteMap(categories);

    return new Response(body, {
        status: 200,
        headers: {
        'Content-Type': 'application/xml',
        },
    });
}
