
'use server';
import { getPartnerContent, getSponsoredLinks, getSponsorSettings, getPartnerPageSettings, getSponsorStyleSettings, getSidebarSettings, getPublishedPosts, getCategories, getBrandingSettings, Post } from '@/lib/data';
import PublicHeader from '@/components/public-header';
import PublicFooter from '@/components/public-footer';
import PartnerPageContent from '@/components/partner-page-content';

export default async function PartnerPage() {
  const [
    allPartnerContent,
    sponsors,
    sponsorSettings,
    partnerPageSettings,
    sponsorStyleSettings,
    sidebarSettings,
    allPosts,
    categories,
    brandingSettings
  ] = await Promise.all([
    getPartnerContent(),
    getSponsoredLinks(),
    getSponsorSettings(),
    getPartnerPageSettings(),
    getSponsorStyleSettings(),
    getSidebarSettings(),
    getPublishedPosts(),
    getCategories(),
    getBrandingSettings()
  ]);

  const latestPosts = allPosts.slice(0, 5);
  
  const mockPage: Post = {
      id: 'partner-page',
      title: partnerPageSettings.title,
      content: partnerPageSettings.description,
      status: 'published',
      isPage: true,
      createdAt: new Date().toISOString(),
      authorId: '',
      slug: '/partner',
      categories: [],
      tags: [],
      format: 'standard',
      commentStatus: 'closed',
      pingStatus: 'closed'
  }
  
  return (
    <>
      <PublicHeader />
      <PartnerPageContent
        page={mockPage}
        partnerContent={allPartnerContent.filter(p => p.status === 'published')}
        sponsors={sponsors}
        sponsorSettings={sponsorSettings}
        partnerPageSettings={partnerPageSettings}
        sponsorStyleSettings={sponsorStyleSettings}
        sidebarSettings={sidebarSettings}
        latestPosts={latestPosts}
        categories={categories}
        brandingSettings={brandingSettings}
      />
      <PublicFooter />
    </>
  );
}
