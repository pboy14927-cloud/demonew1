
'use server';

import { getPosts, getPages, getCategories, getTags, getBrandingSettings } from '@/lib/data';

function formatSitemapDate(dateString: string) {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) {
        return 'Invalid Date';
    }
    return date.toLocaleString('en-US', {
        month: 'long',
        day: 'numeric',
        year: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
        hour12: true
    }).replace(' at', '');
}

function getFormattedGeneratedDate() {
    return new Date().toLocaleString('en-US', {
        month: 'long',
        day: 'numeric',
        year: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
        hour12: true
    }).replace(' at', '');
}

async function generateSitemapIndex() {
  const brandingSettings = await getBrandingSettings();
  const URL = brandingSettings.siteUrl.endsWith('/') ? brandingSettings.siteUrl.slice(0, -1) : brandingSettings.siteUrl;

  const sitemaps = [];
  const now = new Date().toISOString();

  const addSitemap = (path: string, count: number, lastmod: string | Date) => {
    let lastmodDate;
    if (typeof lastmod === 'string') {
        lastmodDate = new Date(lastmod);
    } else {
        lastmodDate = lastmod;
    }
    const isoLastMod = !isNaN(lastmodDate.getTime()) ? lastmodDate.toISOString() : now;
    const formattedLastMod = formatSitemapDate(isoLastMod);
    
    sitemaps.push(`
      <sitemap>
        <loc>${URL}/${path}</loc>
        <lastmod>${isoLastMod}</lastmod>
        <url_count>${count}</url_count>
        <lastmod_formatted>${formattedLastMod}</lastmod_formatted>
      </sitemap>
    `);
  };

  const posts = await getPosts();
  const publishedPosts = posts.filter(p => p.status === 'published');
  const lastPostMod = publishedPosts.length > 0 ? publishedPosts[0].createdAt : now;
  addSitemap('post-sitemap.xml', publishedPosts.length, lastPostMod);
  
  const pages = await getPages();
  const publishedPages = pages.filter(p => p.status === 'published');
  const lastPageMod = publishedPages.length > 0 ? publishedPages[0].createdAt : now;
  addSitemap('page-sitemap.xml', publishedPages.length, lastPageMod);
  
  const categories = await getCategories();
  addSitemap('category-sitemap.xml', categories.length, now);
  
  const tags = await getTags();
  addSitemap('tag-sitemap.xml', tags.length, now);

  const sitemapIndex = `
    <sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
      <config>
        <siteUrl>${URL}</siteUrl>
        <generatedDate>${getFormattedGeneratedDate()}</generatedDate>
      </config>
      ${sitemaps.join('')}
    </sitemapindex>
  `;

  return `<?xml version="1.0" encoding="UTF-8"?>
<?xml-stylesheet type="text/xsl" href="/sitemap.xsl"?>
${sitemapIndex}`;
}

export async function GET() {
    const body = await generateSitemapIndex();
    return new Response(body, {
        status: 200,
        headers: {
        'Content-Type': 'application/xml',
        },
    });
}
