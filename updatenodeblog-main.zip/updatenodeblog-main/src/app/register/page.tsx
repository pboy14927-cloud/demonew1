
'use client';

import Link from 'next/link';
import { PenSquare } from 'lucide-react';
import RegisterForm from '@/components/auth/register-form';
import { useEffect, useState } from 'react';
import { getUsers, getBrandingSettings } from '@/lib/data';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';

export default function RegisterPage() {
    const [registrationAllowed, setRegistrationAllowed] = useState(false);
    const [loading, setLoading] = useState(true);
    const [siteTitle, setSiteTitle] = useState('');

    useEffect(() => {
        const checkUsersAndSettings = async () => {
            try {
                const users = await getUsers();
                setRegistrationAllowed(users.length === 0);
                const branding = await getBrandingSettings();
                setSiteTitle(branding.websiteTitle);
            } catch (error) {
                console.error("Failed to check for existing users or settings:", error);
                setRegistrationAllowed(false);
            } finally {
                setLoading(false);
            }
        };
        checkUsersAndSettings();
    }, []);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <div className="w-full max-w-md">
        <div className="flex justify-center mb-8 h-10 items-center">
            {loading ? (
                <Skeleton className="h-8 w-48" />
            ) : (
                 <Link href="/" className="flex items-center space-x-2">
                    <PenSquare className="h-8 w-8 text-primary" />
                    <span className="text-2xl font-bold font-headline">{siteTitle}</span>
                </Link>
            )}
        </div>
        
        {loading ? (
             <div className="text-center text-muted-foreground">Loading...</div>
        ) : registrationAllowed ? (
            <RegisterForm />
        ) : (
            <div className="text-center p-8 border rounded-lg bg-card text-card-foreground">
                <h2 className="text-xl font-semibold mb-2">Registration Closed</h2>
                <p className="text-muted-foreground">
                    The administrator account has already been created. Further registrations are not allowed.
                </p>
                <Button asChild className="mt-4">
                    <Link href="/login">Go to Login</Link>
                </Button>
            </div>
        )}

        <p className="mt-4 text-center text-sm text-muted-foreground">
          <Link href="/" className="underline hover:text-primary">
            ← Back to website
          </Link>
        </p>
      </div>
    </div>
  );
}
