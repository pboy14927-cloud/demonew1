
'use server';

import { NextResponse } from 'next/server';
import { getRobotsTxtSettings, getBrandingSettings } from '@/lib/data';

export async function GET(request: Request) {
    const settings = await getRobotsTxtSettings();
    const brandingSettings = await getBrandingSettings();
    const siteUrl = brandingSettings.siteUrl.endsWith('/') ? brandingSettings.siteUrl : `${brandingSettings.siteUrl}/`;

    let contentLines: string[] = [];
    const userAgents: { [key:string]: {disallow: string[], allow: string[]} } = {};
    
    const addRule = (userAgent: string, directive: 'Allow' | 'Disallow', value: string) => {
        if (!userAgents[userAgent]) {
            userAgents[userAgent] = { allow: [], disallow: [] };
        }
        if(directive === 'Allow') {
            if (!userAgents[userAgent].allow.includes(value)) userAgents[userAgent].allow.push(value);
        } else {
             if (!userAgents[userAgent].disallow.includes(value)) userAgents[userAgent].disallow.push(value);
        }
    };
    
    // Default rule if custom is disabled
    if (!settings.enableCustomRobots) {
        addRule('*', 'Allow', '/');
    } else {
        // Add custom rules from settings
        settings.rules.forEach(rule => {
            addRule(rule.userAgent, rule.directive, rule.value);
        });
        
        // Add AI crawler blocks from settings
        if (settings.blockedCrawlers?.includes('gpt')) addRule('GPTBot', 'Disallow', '/');
        if (settings.blockedCrawlers?.includes('ads')) addRule('AdsBot-Google', 'Disallow', '/');
        if (settings.blockedCrawlers?.includes('gemini')) addRule('Google-Extended', 'Disallow', '/');
        if (settings.blockedCrawlers?.includes('cc')) addRule('CCBot', 'Disallow', '/');

        // Block internal search if enabled
        if (settings.blockInternalSearch === 'on') {
            addRule('*', 'Disallow', '/?s=');
            addRule('*', 'Disallow', '/search/');
        }
    }

    // Build the string content
    for (const userAgent in userAgents) {
        contentLines.push(`User-agent: ${userAgent}`);
        userAgents[userAgent].disallow.forEach(value => contentLines.push(`Disallow: ${value}`));
        userAgents[userAgent].allow.forEach(value => contentLines.push(`Allow: ${value}`));
        contentLines.push(''); // Add a blank line between user-agent blocks
    }

    // Add sitemap URL
    contentLines.push(`Sitemap: ${siteUrl}sitemap.xml`);

    const content = contentLines.join('\n');
    
    return new Response(content, {
        status: 200,
        headers: {
            'Content-Type': 'text/plain',
        },
    });
}
