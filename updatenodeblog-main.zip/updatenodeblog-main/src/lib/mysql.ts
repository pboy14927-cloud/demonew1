
'use server';

import mysql from 'mysql2/promise';

// This configuration will use the environment variables to connect to your database
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  port: process.env.DB_PORT ? parseInt(process.env.DB_PORT, 10) : 3306,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  connectTimeout: 10000, // 10 seconds to connect
  enableKeepAlive: true, // Keep connections alive
  keepAliveInitialDelay: 10000 // Start keep-alive pings after 10s
});

export async function query(sql: string, args?: any[]): Promise<any> {
  try {
    const [rows] = await pool.execute(sql, args);
    return rows;
  } catch (error) {
    console.error('Database query failed:', sql, args, error);
    // In a production environment, you might want to handle this more gracefully
    throw error;
  }
}
