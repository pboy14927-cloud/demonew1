
/**
 * @fileoverview This file acts as a centralized configuration hub.
 * It imports the raw data and settings from `data.ts` and exports
 * them as easily consumable functions. This helps to decouple the components
 * from the data source and makes it easier to manage settings across the app.
 */

'use server';

import {
    getSettings as getRawSettings,
    getPermalinkSettings as getRawPermalinkSettings,
    getBrandingSettings as getRawBrandingSettings,
    getMenus as getRawMenus,
    getSidebarSettings as getRawSidebarSettings,
    getBlogArchiveSettings as getRawBlogArchiveSettings,
    getCategoryArchiveSettings as getRawCategoryArchiveSettings,
    getSinglePostSettings as getRawSinglePostSettings,
} from './data';

// This function now just fetches the main settings.
// Branding settings are separate.
export async function getSettings() {
    return await getRawSettings();
};

export async function getPermalinkSettings() {
    return getRawPermalinkSettings();
}

export async function getBrandingSettings() {
    return getRawBrandingSettings();
}

export async function getMenus() {
    return getRawMenus();
}

export async function getSidebarSettings() {
    return getRawSidebarSettings();
}

export async function getBlogArchiveSettings() {
    return getRawBlogArchiveSettings();
}

export async function getCategoryArchiveSettings() {
    return getRawCategoryArchiveSettings();
}


export async function getSinglePostSettings() {
    return getRawSinglePostSettings();
}
