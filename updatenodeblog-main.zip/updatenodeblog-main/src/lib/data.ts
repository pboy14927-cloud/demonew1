

'use server';

import { query } from './mysql';
import bcrypt from 'bcryptjs';
import React from 'react';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import * as mockDb from './mock-db';


// Simple in-memory cache
const cache = new Map<string, { data: any; timestamp: number }>();
const CACHE_TTL = 1000 * 60 * 5; // 5 minutes

function setCache(key: string, data: any) {
  cache.set(key, { data, timestamp: Date.now() });
}

function getCache(key: string): any | null {
  const cached = cache.get(key);
  if (cached && (Date.now() - cached.timestamp < CACHE_TTL)) {
    return cached.data;
  }
  cache.delete(key);
  return null;
}

function invalidateCache(keyPrefix: string) {
    for (const key of cache.keys()) {
        if(key.startsWith(keyPrefix)) {
            cache.delete(key);
        }
    }
}


// Helper function to format a Date object into 'YYYY-MM-DD HH:MM:SS'
function toMySqlDateTime(date: Date): string {
    const pad = (num: number) => num.toString().padStart(2, '0');
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

// Helper to generate a URL-friendly slug
const generateSlug = (text: string) => {
    if (!text) return '';
    return text
        .toLowerCase()
        .replace(/\s+/g, '-') // Replace spaces with -
        .replace(/[^\w-]+/g, '') // Remove all non-word chars
        .replace(/--+/g, '-') // Replace multiple - with single -
        .replace(/^-+/, '') // Trim - from start of text
        .replace(/-+$/, '') // Trim - from end of text
        .slice(0, 70); // Max 70 chars
}


// Helper to get the current user's ID from the session
export async function getUserIdFromSession(): Promise<string | null> {
    try {
        const session = await getServerSession(authOptions);
        return (session?.user as any)?.id || null;
    } catch (error) {
        console.error("Error getting session:", error);
        return null;
    }
}


export type PostStatus = 'published' | 'draft' | 'trash' | 'pending';

export type SeoData = {
    title: string;
    description: string;
    canonical: string;
    facebookTitle: string;
    facebookDescription: string;
    facebookImage: string;
    twitterTitle: string;
    twitterDescription: string;
    twitterImage: string;
    ogImageUrl?: string;
    focusKeyphrase?: string;
}

export type Post = {
  id: string;
  title: string;
  slug: string;
  content: string;
  status: PostStatus;
  authorId: string;
  createdAt: string;
  topic?: string;
  categories: string[];
  tags: string[];
  selected?: boolean;
  isPage?: boolean;
  isPartnerContent?: boolean;
  featuredImage?: string | null;
  excerpt?: string;
  seo?: SeoData;
  format: 'standard' | 'gallery' | 'image' | 'video' | 'audio';
  template?: string;
  parent?: string | null;
  likes?: number;
  commentStatus: 'open' | 'closed';
  pingStatus: 'open' | 'closed';
};

export type Page = Post & { isPage: true };

export type UserRole = 'administrator' | 'editor' | 'author' | 'contributor' | 'subscriber';

export type SocialLink = {
    id: string;
    platform: string;
    url: string;
};

export type User = {
  id: string;
  username: string;
  name: string;
  firstName?: string;
  lastName?: string;
  email: string;
  avatar: string;
  role: UserRole;
  selected?: boolean;
  socialLinks: SocialLink[];
  bio?: string;
  website?: string;
};

export type Media = {
    id: string;
    fileName: string;
    fileType: string;
    fileSize: number;
    altText: string;
    url: string;
    uploadedBy: string; 
    createdAt: string;
    selected?: boolean;
}

export type Category = {
    id:string;
    name: string;
    slug: string;
    description?: string;
    parent?: string; // category id
}

export type Tag = {
    id: string;
    name: string;
    slug: string;
    description?: string;
}

export type CommentStatus = 'approved' | 'pending' | 'spam' | 'trash';

export type CommentAuthor = {
    id: string | null; // Could be a user ID or null for guests
    name: string;
    email: string;
    avatar: string;
}

export type Comment = {
    id: string;
    postId: string;
    author: CommentAuthor;
    content: string;
    createdAt: string;
    status: CommentStatus;
    selected?: boolean;
}

export type SponsoredLink = {
    id: string;
    name: string;
    url: string;
    openInNewTab: boolean;
}

type TypographyStyles = {
    fontFamily: string;
    fontSize: number;
    fontWeight: string;
    textAlign: 'left' | 'center' | 'right';
    color: string;
    colorType: 'solid' | 'gradient';
    gradient: {
        from: string;
        to: string;
        direction: 'to right' | 'to bottom' | 'to bottom right' | 'to top' | 'to left';
    }
};

export type SponsorSettings = {
    title: string;
    description: string;
    titleStyles: TypographyStyles;
    descriptionStyles: TypographyStyles;
}

export type SponsorStyleSettings = {
    backgroundType: 'solid' | 'gradient';
    backgroundColor: string;
    gradient: { from: string, to: string, direction: 'to right' | 'to bottom' | 'to bottom right'; };
    textColor: string;
    borderColor: string;
    borderWidth: number;
    borderRadius: number;
    paddingX: number;
    paddingY: number;
    fontFamily: string;
    fontSize: number;
    fontWeight: string;
    textAlign: 'left' | 'center' | 'right';
}

export type CardTypographyStyles = TypographyStyles & {
    backgroundColor?: string;
    backgroundType?: 'solid' | 'gradient';
    hoverColor?: string;
    borderWidth?: number;
    borderColor?: string;
    borderRadius?: number;
    padding?: number;
};


export type PartnerPageCardStyles = {
    categoryStyles: CardTypographyStyles;
    titleStyles: CardTypographyStyles;
    excerptStyles: CardTypographyStyles;
    thumbnailOverlayType: 'none' | 'solid' | 'gradient';
    thumbnailOverlaySolidColor: string;
    thumbnailOverlayGradient: { from: string, to: string, direction: string };
    thumbnailOverlayOpacity: number;
};

export type PartnerPageSettings = {
    title: string;
    description: string;
    recommendedContentIds: string[];
    titleStyles: TypographyStyles;
    descriptionStyles: TypographyStyles;
    recommendedContentStyles: TypographyStyles & { title: string };
    cardStyles: PartnerPageCardStyles;
    showLeftSidebar: boolean;
    showRightSidebar: boolean;
};


export type Settings = {
  siteTitle: string;
  tagline: string;
  wordpressUrl: string;
  siteUrl: string;
  adminEmail: string;
  membership: boolean;
  defaultRole: string;
  siteLanguage: string;
  timezone: string;
  dateFormat: string;
  customDateFormat: string;
  timeFormat: string;
  customTimeFormat: string;
  weekStartsOn: number;
  homepageDisplays: 'posts' | 'page';
  homepage: string;
  postsPage: string;
  defaultPostCategory: string;
  defaultPostFormat: string;
  postsPerPage: number;
  searchEngineVisibility: boolean;
  allowComments: boolean;
  commentAuthorNameEmail: boolean;
  commentRegistration: boolean;
  closeComments: boolean;
  closeCommentsDays: number;
  showCommentCookies: boolean;
  thumbnailWidth: number;
  thumbnailHeight: number;
  thumbnailCrop: boolean;
  mediumWidth: number;
  mediumHeight: number;
  largeWidth: number;
  largeHeight: number;
}

export type PermalinkSettings = {
    structure: string;
    categoryBase: string;
    tagBase: string;
    partnerContentBase?: string;
}

export type BrandingSettings = {
    websiteTitle: string;
    showTitleOnHomepage: boolean;
    websiteDescription: string;
    metaKeywords: string;
    logoUrl: string;
    logoWidth: number;
    faviconUrl: string;
    socialLinks: {id: string, platform: string, url: string}[];
    address: string;
    phone: string;
    email: string;
    siteUrl: string; // Added from general settings
}

export type MenuItem = {
    id: string;
    label: string;
    url: string;
    type: 'page' | 'post' | 'category' | 'custom';
    depth: number;
};

export type Menu = {
    id: string;
    name: string;
    items: MenuItem[];
    locations: ('header' | 'footer')[];
}

export type SocialButtonStyleSettings = {
    style: 'official' | 'custom';
    shape: 'default' | 'rounded' | 'circle';
    iconColor: string;
    borderColor: string;
    borderWidth: number;
    backgroundType: 'solid' | 'gradient';
    backgroundColor: string;
    gradient: { from: string, to: string, direction: string };
    hoverIconColor?: string;
    hoverBackgroundColor?: string;
};


export type SidebarSettings = {
    left: { desktop: boolean; };
    right: { desktop: boolean; };
    leftWidgets: string[];
    rightWidgets: string[];
    numRecentPosts: number;
    numMostCommented: number;
    numCategories: number;
    numTags: number;
    skipPosts: number;
    newsletterTitle: string;
    newsletterDescription: string;
    socialIconStyle: SocialButtonStyleSettings;
    widgetTitles: Record<string, string>;
}

export type BlogArchiveSettings = {
    layout: 'grid' | 'list' | 'classic' | 'masonry';
    postsPerPage: number;
    paginationStyle: 'numbered' | 'load-more' | 'infinite-scroll';
    showFeaturedImage: boolean;
    showAuthor: boolean;
    showDate: boolean;
    showCategories: boolean;
    showExcerpt: boolean;
    excerptLength: number;
    columns: string;
}

export type LayoutElement = {
    id: string;
    visible: boolean;
};

export type SinglePostSettings = {
    layout: LayoutElement[];
    featuredImageWidth: number;
    featuredImageHeight: number;
    showRelatedPosts: boolean;
    numRelatedPosts: number;
    relatedPostsLayout: 'grid' | 'list';
    showReadingProgressBar: boolean;
    enableDropCap: boolean;
    showLeftSidebar: boolean;
    showRightSidebar: boolean;
    showStickyShare: boolean;
    stickySharePosition: 'left' | 'right';
    showPostReactions: boolean;
    showFollowUs: boolean;
    shareButtons: SocialButtonStyleSettings;
    followButtons: SocialButtonStyleSettings;
};


export type BlockType = 
    'hero' | 'featured-posts' | 'category-grid' | 'ad-banner' | 'section' | 
    'two-column' | 'three-column' | 'four-column' | 'five-column' | 'six-column' |
    'seven-column' | 'eight-column' | 'sidebar-left' | 'sidebar-right' | 
    'accordion' | 'accordion-item' | 'call-to-action' | 'image-gallery' | 'video' | 
    'recent-posts' | 'popular-posts' | 'newsletter-form' | 'classic-grid' | 'masonry-grid' | 
    'metro-grid' | 'pinterest-style' | 'full-width-grid' | 'featured-hero' | 'carousel-block' | 
    'featured-carousel' | 'double-featured' | 'grid-below-featured' | 'classic-list' | 'compact-list' | 
    'numbered-list' | 'timeline' | 'spacer' | 'divider' | 'custom-html' | 'trending-now' | 
    'editors-pick' | 'highlights' | 'category-highlights' | 'sidebar' |
    'one-large-three-small' | 'one-large-four-small-grid' | 'featured-area-grids' |
    'grid-block' | 'large-block' | 'overlay-block' | 'list-block' | 'small-list-block' |
    'news-focus-block' | 'focus-grid-block' | 'highlights-block' | 'newsletter-form-digiotic' |
    'block-heading' | 'breadcrumbs' | 'social-icons' | 'ads-codes' | 'category-tabs' | 'paginated-block' |
    'custom-block';


export type BlockStyle = {
    backgroundColor?: string;
    textColor?: string;
    paddingTop?: number;
    paddingBottom?: number;
    paddingLeft?: number;
    paddingRight?: number;
    fontFamily?: string;
    fontSize?: number;
    fontWeight?: string;
    textAlign?: 'left' | 'center' | 'right';
    backgroundType?: 'none' | 'solid' | 'gradient';
    gradient?: { from: string, to: string, direction: string };
    colorType?: 'solid' | 'gradient';
    color?: string;
    cardBackgroundColor?: string;
    cardBorderRadius?: number;
    cardShadow?: string;
    spacing?: number;
    categoryStyles?: CardTypographyStyles;
    titleStyles?: CardTypographyStyles;
    excerptStyles?: CardTypographyStyles;
    authorStyles?: CardTypographyStyles;
    dateStyles?: CardTypographyStyles;
    readMoreStyles?: CardTypographyStyles;
    borderStyle?: 'solid' | 'dotted' | 'dashed';
    borderColor?: string;
    borderWidth?: number;
    width?: number;
    marginTop?: number;
    marginBottom?: number;
};


export type Block = {
    id: string;
    type: BlockType;
    children?: Block[];
    settings?: Record<string, any>;
    styles?: BlockStyle;
};


export type WebmasterToolsSettings = {
    googleTagManagerId: string;
    googleAnalyticsId: string;
    googleSearchConsoleKey: string;
    bingKey: string;
    yandexKey: string;
    headerScripts: string;
    footerScripts: string;
}

export type SeoSettings = {
    separator: string;
    homepageTitle: string;
    homepageDescription: string;
    knowledgeGraph: {
        type: 'person' | 'organization';
        personName: string;
        organizationName: string;
        organizationDescription: string;
        organizationLogo: string;
        phoneNumber: string;
        contactEmail: string;
    };
    contentTypes: {
        posts: { showInSearchResults: boolean; titleTemplate: string; metaDescription: string; };
        pages: { showInSearchResults: boolean; titleTemplate: string; metaDescription: string; };
    };
    taxonomies: {
        categories: { showInSearchResults: boolean; titleTemplate: string; metaDescription: string; };
        tags: { showInSearchResults: boolean; titleTemplate: string; metaDescription: string; };
    };
    social: {
        ogImageUrl: string;
        facebookTitle: string;
        facebookDescription: string;
        twitterImage: string;
        twitterTitle: string;
        twitterDescription: string;
    };
    archives: {
        authorArchiveTitle: string;
        dateArchiveTitle: string;
    }
}

export type AdditionalPage = {
    id: string;
    url: string;
    priority: string;
    frequency: 'always' | 'hourly' | 'daily' | 'weekly' | 'monthly' | 'yearly' | 'never';
    lastModified: string;
};

export type PriorityFrequency = {
    priority: string;
    frequency: 'always' | 'hourly' | 'daily' | 'weekly' | 'monthly' | 'yearly' | 'never';
};

export type SitemapSettings = {
    enabled: boolean;
    enableSitemapIndexes: boolean;
    linksPerSitemap: number;
    includeAllPostTypes: boolean;
    includePosts: boolean;
    includePages: boolean;
    includeAllTaxonomies: boolean;
    includeCategories: boolean;
    includeTags: boolean;
    dateArchiveSitemap: boolean;
    authorSitemap: boolean;
    additionalPages: AdditionalPage[];
    exclusions: {
        posts: [];
        terms: [];
    };
    priority: {
        homePage: PriorityFrequency;
        postTypes: PriorityFrequency;
        taxonomies: PriorityFrequency;
    };
    includeImages: boolean;
};

export type RobotsRule = {
    id: number;
    userAgent: string;
    directive: 'Allow' | 'Disallow';
    value: string;
};

export type HeaderElement = 'none' | 'site-logo' | 'main-navigation' | 'off-canvas-trigger' | 'login-register' | 'current-date' | 'current-time' | 'social-icons' | 'search-form' | 'theme-switcher' | 'cta-button' | 'social-theme' | 'header-ad' | 'custom-html';
export type SlotName = 'left' | 'centerLeft' | 'center' | 'centerRight' | 'right';
export type SlotSettings = Record<SlotName, HeaderElement>;

export type BarSettings = {
    enabled: boolean;
    height: number;
    layout: string;
    backgroundType: 'solid' | 'gradient';
    backgroundColor: string;
    gradientStart: string;
    gradientEnd: string;
    textColor: string;
    linkColor: string;
    linkHoverColor: string;
    slotVisibility: Record<SlotName, { desktop: boolean, tablet: boolean, mobile: boolean }>;
    styling: {
        socialIcons: SocialButtonStyleSettings;
    }
};

export type HeaderSettings = {
    topBar: BarSettings;
    mainHeader: BarSettings;
    bottomBar: BarSettings;
    topBarSlots: SlotSettings;
    mainHeaderSlots: SlotSettings;
    bottomBarSlots: SlotSettings;
    stickySection: 'none' | 'top' | 'main' | 'bottom';
    offCanvas: {
        enabled: boolean;
        menu: 'primary' | 'secondary';
        position: 'left' | 'right';
        showSearch: boolean;
        showSocial: boolean;
        showNewsletter: boolean;
        showPopular: boolean;
        showLatest: boolean;
        customContentTop: string;
        customContentBottom: string;
    },
    ctaButton: {
        text: string;
        url: string;
        openInNewTab: boolean;
        fontFamily: string;
        fontSize: number;
        fontWeight: string;
        textColor: string;
        backgroundType: 'solid' | 'gradient';
        backgroundColor: string;
        gradientStart: string;
        gradientEnd: string;
        borderColor: string;
        borderWidth: number;
        borderRadius: number;
        hoverTextColor: string;
        hoverBackgroundColor: string;
        hoverBorderColor: string;
    },
    searchForm: {
        backgroundColor: string;
        textColor: string;
        borderColor: string;
    }
};

export type FooterElement = 'none' | 'site-logo' | 'text-widget' | 'logo-with-about' | 'social-icons' | 'copyright' | 'footer-navigation' | 'recent-posts' | 'popular-posts' | 'categories' | 'tag-cloud' | 'newsletter-form' | 'custom-html' | 'footer-ad';

export type FooterSlotSettings = {
    elementType: FooterElement;
    widgetTitle: string;
};

export type FooterStyling = {
    backgroundType: 'solid' | 'gradient';
    backgroundColor: string;
    gradientStart: string;
    gradientEnd: string;
    textColor: string;
    linkColor: string;
    linkHoverColor: string;
    fontFamily: string;
    fontSize: number;
    fontWeight: string;
    socialIconStyles: SocialButtonStyleSettings;
};

export type FooterBarSettings = {
    enabled: boolean;
    layout: string;
    slots: Record<SlotName, FooterSlotSettings>;
    styling: FooterStyling;
};

export type FooterSettings = {
    topFooter: FooterBarSettings;
    mainFooter: FooterBarSettings;
    bottomFooter: FooterBarSettings;
    copyrightText: string;
    aboutText: string;
    customHtml: string;
    numPosts: number;
    numCategories: number;
    numTags: number;
    footerNavMenu: string;
};


// ===============================================
// New Database-driven functions
// ===============================================

// Helper to get a single setting value
async function getSetting(settingName: string, defaultValue: any): Promise<any> {
    const cacheKey = `setting_${settingName}`;
    if (process.env.NODE_ENV !== 'development') {
        const cachedData = getCache(cacheKey);
        if (cachedData) return cachedData;
    }

    try {
        const rows: any[] = await query('SELECT value FROM settings WHERE name = ?', [settingName]);
        if (rows.length === 0) {
            // If setting doesn't exist, create it with the default value
            await updateSetting(settingName, defaultValue);
            setCache(cacheKey, defaultValue);
            return defaultValue;
        }
        try {
            const savedValue = JSON.parse(rows[0].value);
            // Deep merge for objects to prevent losing nested properties on update
            if (typeof defaultValue === 'object' && defaultValue !== null && !Array.isArray(defaultValue)) {
                const mergedValue = { ...defaultValue, ...savedValue };
                setCache(cacheKey, mergedValue);
                return mergedValue;
            }
            setCache(cacheKey, savedValue);
            return savedValue;
        } catch {
            // Fallback for non-JSON values
            const value = rows[0].value ?? defaultValue;
            setCache(cacheKey, value);
            return value;
        }
    } catch (error) {
        console.warn(`Database query failed for setting '${settingName}'. Falling back to default. Error:`, error);
        return defaultValue;
    }
}


// Helper to update a single setting value
async function updateSetting(settingName: string, settingValue: any): Promise<void> {
    try {
        const valueToStore = typeof settingValue === 'object' ? JSON.stringify(settingValue) : String(settingValue);
        await query(
            'INSERT INTO settings (name, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE value = ?',
            [settingName, valueToStore, valueToStore]
        );
        // Invalidate cache for this setting
        invalidateCache(`setting_${settingName}`);
    } catch (error) {
        console.error(`Failed to update setting '${settingName}':`, error);
        // Don't re-throw, allow app to continue with potentially stale data
    }
}

export const getSettings = React.cache(async (): Promise<Settings> => {
    return await getSetting('siteSettings', mockDb.settings) as Settings;
});

export async function updateGeneralSettings(newSettings: Partial<Settings>) {
    for (const [key, value] of Object.entries(newSettings)) {
        await updateSetting(key, value);
    }
}

export const getPermalinkSettings = React.cache(async (): Promise<PermalinkSettings> => {
    return await getSetting('permalinkSettings', {
        structure: '/%year%/%monthnum%/%day%/%postname%/',
        categoryBase: 'category',
        tagBase: 'tag',
        partnerContentBase: 'partner-content'
    });
});

export async function updatePermalinkSettings(newSettings: Partial<PermalinkSettings>) {
    const currentSettings = await getPermalinkSettings();
    const mergedSettings = { ...currentSettings, ...newSettings };
    await updateSetting('permalinkSettings', mergedSettings);
    invalidateCache('permalinkSettings');
}

export const generatePostUrl = React.cache(async (post: Partial<Post>): Promise<string> => {
    if (!post) return '/';
    const permalinks = await getPermalinkSettings();
    const settings = await getSettings();

    if (post.isPage) {
        if (settings.postsPage && post.id === settings.postsPage) {
            return `/`;
        }
        return `/${post.slug}`;
    }

    if (post.isPartnerContent) {
        const partnerBase = permalinks.partnerContentBase || 'partner-content';
        return `/${partnerBase}/${post.slug}`;
    }

    if (!post.createdAt) return `/${post.slug}`;

    let structure = permalinks.structure;
    
    // Handle "Plain" permalink structure
    if (structure === '/?p=%post_id%') {
        return `/?p=${post.id}`;
    }
    // Handle "Numeric" permalink structure
    if (structure === '/archives/%post_id%') {
        return `/archives/${post.id}`;
    }

    const date = new Date(post.createdAt);
    
    const replacements: Record<string, string | Promise<string>> = {
        '%year%': date.getFullYear().toString(),
        '%monthnum%': (date.getMonth() + 1).toString().padStart(2, '0'),
        '%day%': date.getDate().toString().padStart(2, '0'),
        '%hour%': date.getHours().toString().padStart(2, '0'),
        '%minute%': date.getMinutes().toString().padStart(2, '0'),
        '%second%': date.getSeconds().toString().padStart(2, '0'),
        '%post_id%': post.id || '',
        '%postname%': post.slug || '',
        '%author%': (async () => {
            if(!post.authorId) return 'unknown';
            const author = await getUserById(post.authorId);
            return author ? author.name.toLowerCase().replace(/\s+/g, '-') : 'unknown';
        })(),
        '%category%': (async () => {
            if (post.categories && post.categories.length > 0) {
                const categoryName = post.categories[0];
                const allCategories = await getCategories();
                const category = allCategories.find(c => c.name === categoryName);
                return category ? category.slug : (permalinks.categoryBase || 'category');
            }
            return permalinks.categoryBase || 'category';
        })(),
    };
    
    for (const tag in replacements) {
        if (structure.includes(tag)) {
            const value = await replacements[tag];
            structure = structure.replace(new RegExp(tag, 'g'), value);
        }
    }
    
    return structure.replace(/\/+/g, '/');
});


export const getBrandingSettings = React.cache(async (): Promise<BrandingSettings> => {
    const generalSettings = await getSettings();
    const branding = await getSetting('brandingSettings', {
        showTitleOnHomepage: true,
        metaKeywords: 'blog, magazine, news, content',
        logoUrl: '',
        logoWidth: 200,
        faviconUrl: '',
        socialLinks: [],
        address: '829 Cabell Avenue Arlington, VA 22202',
        phone: '+088 012121240',
        email: 'Support@mail.com',
    });

    return {
        ...branding,
        websiteTitle: generalSettings.siteTitle,
        websiteDescription: generalSettings.tagline,
        siteUrl: generalSettings.siteUrl
    }
});

export async function updateBrandingSettings(newSettings: Partial<Omit<BrandingSettings, 'authDomainUrl' | 'siteUrl'>>) {
    const { websiteTitle, websiteDescription, ...rest } = newSettings;
    
    // Update general settings that are also on the branding page
    if (websiteTitle) await updateSetting('siteTitle', websiteTitle);
    if (websiteDescription) await updateSetting('tagline', websiteDescription);

    // Update the rest of the branding-specific settings
    const currentBranding = await getSetting('brandingSettings', {});
    const updatedBranding = { ...currentBranding, ...rest };
    await updateSetting('brandingSettings', updatedBranding);
    
    // Invalidate relevant caches
    invalidateCache('setting_'); // Covers siteTitle, tagline, etc.
    invalidateCache('brandingSettings');
}


export const getMenus = React.cache(async (): Promise<Menu[]> => {
    return await getSetting('menus', [{
        id: 'main-menu',
        name: 'Main Menu',
        items: [
          { id: '1', label: 'Home', type: 'page', url: '/', depth: 0 },
          { id: '2', label: 'About Us', type: 'page', url: '/about', depth: 0 },
          { id: '3', label: 'Contact', type: 'page', url: '/contact', depth: 0 },
        ],
        locations: ['header']
    }]);
});

export async function updateMenus(newMenus: Menu[]) {
    await updateSetting('menus', newMenus);
    invalidateCache('menus');
}

export const getSidebarSettings = React.cache(async (): Promise<SidebarSettings> => {
    return await getSetting('sidebarSettings', {
        left: { desktop: true },
        right: { desktop: true },
        leftWidgets: [],
        rightWidgets: [
            'Search',
            'Recent Posts',
            'Categories',
            'Follow Us',
            'Tag Cloud',
            'Newsletter',
            'Most Commented',
            'Advertisement',
        ],
        numRecentPosts: 5,
        numMostCommented: 5,
        numCategories: 7,
        numTags: 15,
        skipPosts: 0,
        newsletterTitle: 'Subscribe To Updates',
        newsletterDescription: 'Get the latest posts & updates delivered to your inbox.',
        socialIconStyle: {
            style: 'official',
            shape: 'rounded',
            iconColor: '#ffffff',
            borderColor: '#cccccc',
            borderWidth: 1,
            backgroundType: 'solid',
            backgroundColor: 'transparent',
            gradient: { from: '#f0f0f0', to: '#e0e0e0', direction: 'to bottom' }
        },
        widgetTitles: {
            'Search': 'Search',
            'Recent Posts': 'Recent Posts',
            'Categories': 'Categories',
            'Follow Us': 'Follow Us',
            'Tag Cloud': 'Tag Cloud',
            'Newsletter': 'Newsletter',
            'Most Commented': 'Most Commented',
            'Advertisement': 'Advertisement',
        }
    });
});


export async function updateSidebarSettings(newSettings: Partial<SidebarSettings>) {
    const currentSettings = await getSidebarSettings();
    const merged = {...currentSettings, ...newSettings};
    await updateSetting('sidebarSettings', merged);
    invalidateCache('sidebarSettings');
}

export const getBlogArchiveSettings = React.cache(async (): Promise<BlogArchiveSettings> => {
    return await getSetting('blogArchiveSettings', {
        layout: 'classic',
        postsPerPage: 8,
        paginationStyle: 'numbered',
        showFeaturedImage: true,
        showAuthor: true,
        showDate: true,
        showCategories: false,
        showExcerpt: true,
        excerptLength: 100,
        columns: '1'
    });
});

export async function updateBlogArchiveSettings(newSettings: Partial<BlogArchiveSettings>) {
    await updateSetting('blogArchiveSettings', newSettings);
    invalidateCache('blogArchiveSettings');
}

export const getCategoryArchiveSettings = React.cache(async (): Promise<BlogArchiveSettings> => {
    return await getSetting('categoryArchiveSettings', {
        layout: 'grid',
        postsPerPage: 9,
        paginationStyle: 'numbered',
        showFeaturedImage: true,
        showAuthor: true,
        showDate: true,
        showCategories: true,
        showExcerpt: true,
        excerptLength: 100,
        columns: '2',
    });
});

export async function updateCategoryArchiveSettings(newSettings: Partial<BlogArchiveSettings>) {
    await updateSetting('categoryArchiveSettings', newSettings);
    invalidateCache('categoryArchiveSettings');
}


export const getSinglePostSettings = React.cache(async (): Promise<SinglePostSettings> => {
    const defaultButtonStyles: SocialButtonStyleSettings = {
        style: 'official',
        shape: 'default',
        iconColor: '#ffffff',
        borderColor: '#cccccc',
        borderWidth: 1,
        backgroundType: 'solid',
        backgroundColor: '#f0f0f0',
        gradient: { from: '#f0f0f0', to: '#e0e0e0', direction: 'to bottom' }
    };
    
    const defaultSettings: SinglePostSettings = {
        layout: [
            { id: 'breadcrumbs', visible: true },
            { id: 'category-badge', visible: true },
            { id: 'title', visible: true },
            { id: 'excerpt', visible: false },
            { id: 'author-meta', visible: true },
            { id: 'top-share', visible: true },
            { id: 'featured-image', visible: true },
            { id: 'content', visible: true },
            { id: 'post-reactions', visible: true },
            { id: 'tags', visible: true },
            { id: 'bottom-share', visible: true },
            { id: 'author-box', visible: true },
            { id: 'related-posts', visible: true },
            { id: 'comments', visible: true }
        ],
        featuredImageWidth: 882,
        featuredImageHeight: 576,
        showRelatedPosts: true,
        numRelatedPosts: 3,
        relatedPostsLayout: 'grid',
        showReadingProgressBar: true,
        enableDropCap: false,
        showLeftSidebar: false,
        showRightSidebar: true,
        showStickyShare: true,
        stickySharePosition: 'left',
        showPostReactions: true,
        showFollowUs: true,
        shareButtons: defaultButtonStyles,
        followButtons: defaultButtonStyles,
    };

    const savedSettings = await getSetting('singlePostSettings', defaultSettings);
    // Merge to ensure new properties are present and layout is an array
    const mergedSettings = { ...defaultSettings, ...savedSettings };
    if (!Array.isArray(mergedSettings.layout) || mergedSettings.layout.length === 0) {
        mergedSettings.layout = defaultSettings.layout;
    }
    
    return mergedSettings;
});

export async function updateSinglePostSettings(newSettings: Partial<SinglePostSettings>) {
    const currentSettings = await getSinglePostSettings();
    const mergedSettings = { ...currentSettings, ...newSettings };
    await updateSetting('singlePostSettings', mergedSettings);
    invalidateCache('singlePostSettings');
}

export const getHomepageLayout = React.cache(async (): Promise<Block[]> => {
    return await getSetting('homepageLayout', []);
});

export async function updateHomepageLayout(newLayout: Block[]) {
    await updateSetting('homepageLayout', newLayout);
    invalidateCache('homepageLayout');
}

export const getHeaderSettings = React.cache(async (): Promise<HeaderSettings> => {
    const defaultSlotVisibility = { desktop: true, tablet: true, mobile: true };
    const defaultSocialIconStyles: SocialButtonStyleSettings = {
        style: 'official',
        shape: 'default',
        iconColor: '#333333',
        backgroundColor: 'transparent',
        hoverIconColor: '#007bff',
        hoverBackgroundColor: 'transparent',
        borderColor: '#ccc',
        borderWidth: 1,
        backgroundType: 'solid',
        gradient: { from: '#f0f0f0', to: '#e0e0e0', direction: 'to bottom' }
    };
    const defaultBarSettings: Omit<BarSettings, 'enabled' | 'height' | 'layout' | 'backgroundType'> = {
        backgroundColor: '#ffffff',
        gradientStart: '#ffffff',
        gradientEnd: '#ffffff',
        textColor: '#000000',
        linkColor: '#0000ff',
        linkHoverColor: '#0000aa',
        slotVisibility: { 
            left: defaultSlotVisibility, 
            centerLeft: defaultSlotVisibility, 
            center: defaultSlotVisibility, 
            centerRight: defaultSlotVisibility, 
            right: defaultSlotVisibility 
        },
        styling: {
            socialIcons: defaultSocialIconStyles,
        }
    };

    const defaultCta = {
        text: 'Buy Digiotic', 
        url: '#', 
        openInNewTab: true,
        fontFamily: 'Inter',
        fontSize: 14,
        fontWeight: '700',
        textColor: '#f4ec06',
        backgroundType: 'gradient' as 'solid' | 'gradient',
        backgroundColor: '#007bff',
        gradientStart: '#0b6fda',
        gradientEnd: '#0f0f10',
        borderColor: '#030303',
        borderWidth: 3,
        borderRadius: 14,
        hoverTextColor: '#efebeb',
        hoverBackgroundColor: '#ee1111',
        hoverBorderColor: '#0d5bf8'
    };

    const defaultSettings: HeaderSettings = {
        stickySection: 'main',
        topBar: { ...defaultBarSettings, enabled: true, height: 40, layout: 'space-between', backgroundType: 'solid' },
        mainHeader: { ...defaultBarSettings, enabled: true, height: 90, layout: '5-columns', backgroundType: 'solid' },
        bottomBar: { ...defaultBarSettings, enabled: true, height: 50, layout: 'space-between', backgroundColor: '#000000', gradientStart: '#000000', gradientEnd: '#000000', textColor: '#ffffff', linkColor: '#ffffff', linkHoverColor: '#dd3333', backgroundType: 'solid' },
        topBarSlots: { left: 'current-date', centerLeft: 'cta-button', center: 'none', centerRight: 'social-icons', right: 'search-form' },
        mainHeaderSlots: { left: 'site-logo', centerLeft: 'none', center: 'none', centerRight: 'none', right: 'main-navigation' },
        bottomBarSlots: { left: 'main-navigation', centerLeft: 'none', center: 'none', centerRight: 'none', right: 'social-theme' },
        offCanvas: { enabled: true, menu: 'primary', position: 'left', showSearch: true, showSocial: true, showNewsletter: false, showPopular: false, showLatest: true, customContentTop: '', customContentBottom: '' },
        ctaButton: defaultCta,
        searchForm: { backgroundColor: '#f0f0f0', textColor: '#000000', borderColor: '#e0e0e0' }
    };
    
    // Fetch saved settings and merge with defaults to ensure all properties exist
    const savedSettings = await getSetting('headerSettings', defaultSettings);
    const mergedSettings = { ...defaultSettings, ...savedSettings };

    // Ensure nested styling objects are also merged correctly
    mergedSettings.topBar = { ...defaultSettings.topBar, ...savedSettings.topBar };
    mergedSettings.mainHeader = { ...defaultSettings.mainHeader, ...savedSettings.mainHeader };
    mergedSettings.bottomBar = { ...defaultSettings.bottomBar, ...savedSettings.bottomBar };

    mergedSettings.topBar.styling = { ...defaultSettings.topBar.styling, ...savedSettings.topBar?.styling };
    mergedSettings.mainHeader.styling = { ...defaultSettings.mainHeader.styling, ...savedSettings.mainHeader?.styling };
    mergedSettings.bottomBar.styling = { ...defaultSettings.bottomBar.styling, ...savedSettings.bottomBar?.styling };
    
    mergedSettings.ctaButton = { ...defaultSettings.ctaButton, ...savedSettings.ctaButton };
    mergedSettings.searchForm = { ...defaultSettings.searchForm, ...savedSettings.searchForm };
    mergedSettings.offCanvas = { ...defaultSettings.offCanvas, ...savedSettings.offCanvas };

    return mergedSettings;
});


export async function updateHeaderSettings(newSettings: HeaderSettings) {
    await updateSetting('headerSettings', newSettings);
    invalidateCache('headerSettings');
}

export const getFooterSettings = React.cache(async (): Promise<FooterSettings> => {
    const defaultSlot: FooterSlotSettings = { elementType: 'none', widgetTitle: '' };
    const defaultSocialIconStyles: SocialButtonStyleSettings = {
        style: 'official',
        shape: 'circle',
        iconColor: '#ffffff',
        borderColor: '#cccccc',
        borderWidth: 1,
        backgroundType: 'solid',
        backgroundColor: 'transparent',
        gradient: { from: '#f0f0f0', to: '#e0e0e0', direction: 'to bottom' },
        hoverIconColor: '#ffffff',
        hoverBackgroundColor: '#333333'
    };
    const defaultStyling: FooterStyling = {
        backgroundType: 'solid',
        backgroundColor: '#1f2125',
        gradientStart: '#1f2125',
        gradientEnd: '#1f2125',
        textColor: '#ffffff',
        linkColor: '#bbbbbb',
        linkHoverColor: '#ffffff',
        fontFamily: 'Inter',
        fontSize: 14,
        fontWeight: '400',
        socialIconStyles: defaultSocialIconStyles
    };
    const defaultBar: FooterBarSettings = {
        enabled: false,
        layout: '5-columns',
        slots: { left: defaultSlot, centerLeft: defaultSlot, center: defaultSlot, centerRight: defaultSlot, right: defaultSlot },
        styling: defaultStyling
    };

    const settings = await getSetting('footerSettings', {
        topFooter: { ...defaultBar, enabled: true, layout: '4-columns', slots: { left: {elementType: 'logo-with-about', widgetTitle: 'About Us'}, centerLeft: {elementType: 'recent-posts', widgetTitle: 'Recent Posts'}, center: {elementType: 'categories', widgetTitle: 'Categories'}, centerRight: {elementType: 'social-icons', widgetTitle: 'Follow Us'}, right: defaultSlot }, styling: { ...defaultStyling, backgroundColor: '#2a2e34'} },
        mainFooter: { ...defaultBar, styling: { ...defaultStyling, backgroundColor: '#25292e' } },
        bottomFooter: { ...defaultBar, enabled: true, layout: 'space-between', slots: { left: {elementType: 'copyright', widgetTitle: ''}, right: {elementType: 'footer-navigation', widgetTitle: ''}, centerLeft: defaultSlot, center: defaultSlot, centerRight: defaultSlot }},
        copyrightText: 'Copyright © [year] ContentDock. All Rights Reserved.',
        aboutText: 'A modern, professional, and highly customizable theme for your Next.js project. Build a beautiful and functional website with ease.',
        customHtml: '',
        numPosts: 3,
        numCategories: 5,
        numTags: 10,
        footerNavMenu: '',
    });

    // Ensure socialIconStyles exists in each bar's styling
    if (!settings.topFooter.styling.socialIconStyles) {
        settings.topFooter.styling.socialIconStyles = defaultSocialIconStyles;
    }
     if (!settings.mainFooter.styling.socialIconStyles) {
        settings.mainFooter.styling.socialIconStyles = defaultSocialIconStyles;
    }
     if (!settings.bottomFooter.styling.socialIconStyles) {
        settings.bottomFooter.styling.socialIconStyles = defaultSocialIconStyles;
    }

    return settings;
});

export async function updateFooterSettings(settings: FooterSettings) {
    await updateSetting('footerSettings', settings);
    invalidateCache('footerSettings');
}

// Data functions
const parsePostRow = (row: any): Post | null => {
    if (!row || !row.id) return null;
    let seoData = {};
    if (row.seo) {
        if (typeof row.seo === 'string') {
            try {
                seoData = JSON.parse(row.seo);
            } catch (e) {
                console.error('Failed to parse SEO JSON:', e, 'Raw SEO data:', row.seo);
                seoData = {};
            }
        } else if (typeof row.seo === 'object') {
            seoData = row.seo;
        }
    }

    const post: Post = {
        id: row.id.toString(),
        title: row.title,
        slug: row.slug,
        content: row.content,
        status: row.status,
        authorId: row.authorId?.toString(),
        createdAt: row.createdAt,
        topic: row.topic,
        categories: Array.isArray(row.categories) ? row.categories : (row.categories ? row.categories.split(',').filter(Boolean) : []),
        tags: Array.isArray(row.tags) ? row.tags : (row.tags ? row.tags.split(',').filter(Boolean) : []),
        isPage: !!row.isPage,
        isPartnerContent: !!row.isPartnerContent,
        featuredImage: row.featuredImage,
        excerpt: row.excerpt,
        seo: seoData as SeoData,
        format: row.format || 'standard',
        commentStatus: row.commentStatus || 'open',
        pingStatus: row.pingStatus || 'open',
        template: row.template || 'default',
        parent: row.parent ? row.parent.toString() : null,
        likes: row.likes || 0,
    };
    
    // Add author details if joined
    if (row.authorName) {
        (post as any).author = {
            id: row.authorId.toString(),
            name: row.authorName,
            email: row.authorEmail,
            avatar: row.authorAvatar
        };
    }

    return post;
};


export const getAllContent = React.cache(async (forceRefresh = false): Promise<Post[]> => {
    const cacheKey = 'allContent';
    if (!forceRefresh && process.env.NODE_ENV !== 'development') {
        const cachedData = getCache(cacheKey);
        if (cachedData) return cachedData;
    }

    try {
        const sql = `
            SELECT p.*, u.name as authorName 
            FROM posts p 
            LEFT JOIN users u ON p.authorId = u.id 
            ORDER BY p.createdAt DESC
        `;
        const rows: any[] = await query(sql);
        const data = rows.map(parsePostRow).filter((p): p is Post => p !== null);
        setCache(cacheKey, data);
        return data;
    } catch(e) {
        console.warn("Database query failed for getAllContent, falling back to mock data.");
        return mockDb.posts;
    }
});

export async function createPostDb(postData: Partial<Post>): Promise<Partial<Post>> {
    const { 
        title, content, status, authorId, isPage, 
        categories = [], tags = [], featuredImage, excerpt, 
        seo = {}, format = 'standard', commentStatus = 'open', 
        pingStatus = 'open', template = 'default', parent, isPartnerContent = false 
    } = postData;

    const createdAt = postData.createdAt ? new Date(postData.createdAt) : new Date();

    let finalSlug = postData.slug || generateSlug(title || '');
    const existingResult: any = await query('SELECT slug FROM posts WHERE slug = ?', [finalSlug]);
    if (Array.isArray(existingResult) && existingResult.length > 0) {
        finalSlug = `${finalSlug}-${Date.now()}`;
    }

    const parentValue = parent === 'none' ? null : (parent || null);

    const sql = `
      INSERT INTO posts (title, slug, content, status, authorId, createdAt, isPage, isPartnerContent, categories, tags, featuredImage, excerpt, seo, format, commentStatus, pingStatus, template, parent)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    const params = [
        title || '', 
        finalSlug, 
        content || '', 
        status || 'draft', 
        authorId, 
        toMySqlDateTime(createdAt),
        isPage ? 1 : 0, 
        isPartnerContent ? 1 : 0,
        categories.join(','), 
        tags.join(','), 
        featuredImage || null, 
        excerpt || '',
        JSON.stringify(seo), 
        format || 'standard', 
        commentStatus || 'open',
        pingStatus || 'open', 
        template || 'default',
        parentValue
    ];
    
    const result: any = await query(sql, params);
    
    invalidateCache('posts');
    invalidateCache('pages');
    invalidateCache('allContent');
    
    return { 
        id: result.insertId.toString(),
        isPage,
        isPartnerContent,
    };
}



export async function updatePost(id: string, postData: Partial<Post>): Promise<void> {
    const { title, slug, content, status, authorId, categories, tags, featuredImage, excerpt, createdAt, seo, format, commentStatus, pingStatus, template, parent } = postData;
    const parentValue = (parent === 'none' || parent === '') ? null : (parent || null);
    
    const sql = `
        UPDATE posts SET
        title = ?, slug = ?, content = ?, status = ?, authorId = ?, categories = ?, tags = ?, featuredImage = ?, excerpt = ?, createdAt = ?, seo = ?, format = ?, commentStatus = ?, pingStatus = ?, template = ?, parent = ?
        WHERE id = ?
    `;
    const params = [
        title, slug, content, status, authorId, 
        categories?.join(','), tags?.join(','), featuredImage, excerpt, 
        createdAt ? toMySqlDateTime(new Date(createdAt)) : new Date(), 
        JSON.stringify(seo || {}), format, commentStatus, pingStatus, template, 
        parentValue,
        id
    ];

    await query(sql, params);
    invalidateCache('posts');
    invalidateCache('pages');
    invalidateCache('allContent');
     invalidateCache(`post_${id}`);
}

export async function updatePostStatus(id: string, status: PostStatus): Promise<void> {
    await query('UPDATE posts SET status = ? WHERE id = ?', [status, id]);
    invalidateCache('posts');
    invalidateCache('pages');
    invalidateCache('allContent');
     invalidateCache(`post_${id}`);
}

export async function deletePost(id: string): Promise<void> {
    await query('DELETE FROM posts WHERE id = ?', [id]);
    invalidateCache('posts');
    invalidateCache('pages');
    invalidateCache('allContent');
    invalidateCache(`post_${id}`);
}

export const getPosts = React.cache(async (forceRefresh = false): Promise<Post[]> => {
    const cacheKey = 'posts';
    if (!forceRefresh && process.env.NODE_ENV !== 'development') {
        const cachedData = getCache(cacheKey);
        if (cachedData) return cachedData;
    }
    try {
        const sql = `
            SELECT p.*, u.name as authorName 
            FROM posts p 
            LEFT JOIN users u ON p.authorId = u.id 
            WHERE p.isPage = 0 AND p.isPartnerContent = 0 
            ORDER BY p.createdAt DESC
        `;
        const rows: any[] = await query(sql);
        const data = rows.map(parsePostRow).filter((p): p is Post => p !== null);
        setCache(cacheKey, data);
        return data;
    } catch(e) {
        console.warn("Database query failed for getPosts, falling back to mock data.");
        return mockDb.posts.filter(p => !p.isPage && !p.isPartnerContent);
    }
});

export const getPaginatedPosts = React.cache(async ({ page, limit }: { page: number, limit: number }): Promise<Post[]> => {
    try {
        const offset = (page - 1) * limit;
        const rows: any[] = await query('SELECT * FROM posts WHERE status = "published" AND isPage = 0 ORDER BY createdAt DESC LIMIT ? OFFSET ?', [limit, offset]);
        return rows.map(parsePostRow).filter((p): p is Post => p !== null);
    } catch(e) {
        console.warn("Database query failed for getPaginatedPosts, falling back to mock data.");
        const offset = (page - 1) * limit;
        return mockDb.posts.filter(p => p.status === 'published' && !p.isPage).slice(offset, offset + limit);
    }
});

export const getPages = React.cache(async (forceRefresh = false): Promise<Page[]> => {
    const cacheKey = 'pages';
    if (!forceRefresh && process.env.NODE_ENV !== 'development') {
        const cachedData = getCache(cacheKey);
        if (cachedData) return cachedData;
    }
    try {
        const sql = `
            SELECT p.*, u.name as authorName 
            FROM posts p 
            LEFT JOIN users u ON p.authorId = u.id 
            WHERE p.isPage = 1 
            ORDER BY p.createdAt DESC
        `;
        const rows: any[] = await query(sql);
        const data = rows.map(row => ({ ...parsePostRow(row), isPage: true })).filter((p): p is Page => p !== null);
        setCache(cacheKey, data);
        return data;
    } catch(e) {
        console.warn("Database query failed for getPages, falling back to mock data.");
        return mockDb.posts.filter(p => p.isPage) as Page[];
    }
});

export const getPartnerContent = React.cache(async (forceRefresh = false): Promise<Post[]> => {
    const cacheKey = 'partnerContent';
    if (!forceRefresh && process.env.NODE_ENV !== 'development') {
        const cachedData = getCache(cacheKey);
        if (cachedData) return cachedData;
    }
    try {
        const sql = `
            SELECT p.*, u.name as authorName 
            FROM posts p 
            LEFT JOIN users u ON p.authorId = u.id 
            WHERE p.isPartnerContent = 1 
            ORDER BY p.createdAt DESC
        `;
        const rows: any[] = await query(sql);
        const data = rows.map(row => parsePostRow(row) as Post).filter((p): p is Post => p !== null && !!p.isPartnerContent);
        setCache(cacheKey, data);
        return data;
    } catch(e) {
        console.warn("Database query failed for getPartnerContent, falling back to mock data.");
        return mockDb.posts.filter(p => p.isPartnerContent);
    }
});

export const getPostById = async (id: string): Promise<Post | undefined> => {
    const cacheKey = `post_${id}`;
    if(process.env.NODE_ENV !== 'development') {
        const cachedData = getCache(cacheKey);
        if(cachedData) return cachedData;
    }

    try {
        const rows: any[] = await query('SELECT * FROM posts WHERE id = ?', [id]);
        if (rows.length === 0) return undefined;
        const post = parsePostRow(rows[0]);
        if (!post) return undefined;
        
        // Ensure parent is correctly set to null if it's falsy (e.g., 0, '', null)
        if (post.parent) {
        post.parent = post.parent.toString();
        } else {
        post.parent = null;
        }
        setCache(cacheKey, post);
        return post;
    } catch (e) {
        console.warn(`Database query failed for getPostById(${id}), falling back to mock data.`);
        return mockDb.posts.find(p => p.id === id);
    }
};

export const getPublishedPosts = React.cache(async (forceRefresh = false): Promise<(Post & {author: User | null})[]> => {
    const cacheKey = 'published_posts_with_authors';
    if (!forceRefresh && process.env.NODE_ENV !== 'development') {
        const cachedData = getCache(cacheKey);
        if (cachedData) return cachedData;
    }

    try {
        const sql = `
            SELECT p.*, u.id as authorId, u.name as authorName, u.email as authorEmail, u.avatar as authorAvatar
            FROM posts p
            LEFT JOIN users u ON p.authorId = u.id
            WHERE p.status = "published" AND p.isPage = 0 AND p.isPartnerContent = 0 
            ORDER BY p.createdAt DESC
        `;

        const rows: any[] = await query(sql);
        const data = rows.map(row => parsePostRow(row)).filter((p): p is (Post & {author: User | null}) => p !== null);
        setCache(cacheKey, data);
        return data;
    } catch(e) {
         console.warn("Database query failed for getPublishedPosts, falling back to mock data.");
        const mockPosts = mockDb.posts.filter(p => p.status === 'published' && !p.isPage && !p.isPartnerContent);
        const mockAuthors = mockDb.users;
        return mockPosts.map(p => ({
            ...p,
            author: mockAuthors.find(a => a.id === p.authorId) || null
        }));
    }
});

export const getContentFromSlug = React.cache(async (slugParts: string[], searchParams?: { [key: string]: string | string[] | undefined }): Promise<Post | null> => {
    const slug = slugParts.join('/');

    try {
        // Handle "Plain" permalink structure: /?p=[id]
        if (searchParams?.p) {
            const postId = Array.isArray(searchParams.p) ? searchParams.p[0] : searchParams.p;
            if (postId && !isNaN(Number(postId))) {
                const post = await getPostById(postId);
                if (post && post.status === 'published') {
                    return post;
                }
            }
        }
        
        // Handle pages, which have a simple /slug structure
        const [page]: any[] = await query('SELECT * FROM posts WHERE slug = ? AND isPage = 1 AND status = "published"', [slug]);
        if (page) {
            return parsePostRow(page);
        }
        
        // Handle posts based on their slug (the last part of the URL)
        const postSlug = slugParts[slugParts.length - 1];
        if (!postSlug) return null;

        const [post]: any[] = await query('SELECT * FROM posts WHERE slug = ? AND isPage = 0 AND status = "published"', [postSlug]);

        if (post) {
             const postData = parsePostRow(post);
             return postData;
        }

        return null;

    } catch(e) {
        console.warn(`Database query failed for getContentFromSlug(${slug}), falling back to mock data.`);
        const post = mockDb.posts.find(p => p.slug === slug && p.status === 'published');
        return post || null;
    }
});


const parseUserRow = async (row: any): Promise<User | null> => {
    if (!row) return null;
    
    let parsedSocialLinks = [];
    try {
        if(row.socialLinks && typeof row.socialLinks === 'string') {
            parsedSocialLinks = JSON.parse(row.socialLinks);
        } else if (typeof row.socialLinks === 'object' && row.socialLinks !== null) {
            parsedSocialLinks = row.socialLinks;
        }
    } catch (e) {
        // Ignore parsing errors, default to empty array
    }
    
    let avatarUrl = row.avatar;
    // Check if avatar is a numeric ID and not a full URL
    if (avatarUrl && !isNaN(avatarUrl) && !avatarUrl.startsWith('http')) {
        avatarUrl = `/api/media/${avatarUrl}/file`;
    }

    return {
        id: row.id.toString(),
        username: row.username,
        name: row.name,
        firstName: row.firstName,
        lastName: row.lastName,
        email: row.email,
        avatar: avatarUrl,
        role: row.role,
        bio: row.bio,
        website: row.website,
        socialLinks: parsedSocialLinks,
    };
};


export const getUsers = React.cache(async (forceRefresh = false): Promise<User[]> => {
    const cacheKey = 'users';
    if (!forceRefresh && process.env.NODE_ENV !== 'development') {
        const cachedData = getCache(cacheKey);
        if (cachedData) return cachedData;
    }
    try {
        const rows: any[] = await query('SELECT id, username, name, firstName, lastName, email, avatar, role FROM users');
        const data = await Promise.all(rows.map(parseUserRow));
        const filteredData = data.filter((u): u is User => u !== null);
        setCache(cacheKey, filteredData);
        return filteredData;
    } catch (e) {
        console.warn("Database query failed for getUsers, falling back to mock data.");
        return mockDb.users;
    }
});

export const getAllUsers = async (forceRefresh = false): Promise<User[]> => {
    return getUsers(forceRefresh);
};

export const getUserById = React.cache(async (id: string): Promise<User | null> => {
    if (!id) return null;
    const cacheKey = `user_${id}`;
    if(process.env.NODE_ENV !== 'development') {
        const cachedData = getCache(cacheKey);
        if(cachedData) return cachedData;
    }

    try {
        const rows: any[] = await query('SELECT * FROM users WHERE id = ?', [id]);
        if (rows.length === 0) {
        console.warn(`User with ID ${id} not found.`);
        return null;
        }
        
        const data = await parseUserRow(rows[0]);
        if (data) setCache(cacheKey, data);
        return data;
    } catch (e) {
        console.warn(`Database query failed for getUserById(${id}), falling back to mock data.`);
        return mockDb.users.find(u => u.id === id) || null;
    }
});

export async function createUser(userData: Partial<User> & { password?: string }): Promise<User> {
  const { username, name, email, password, role, website, avatar } = userData;

  if (!username || !email || !password || !role) {
    throw new Error('Username, email, password, and role are required.');
  }

  // Check for existing email or username
  const [existingUsers]: any = await query(
    'SELECT id FROM users WHERE email = ? OR username = ?',
    [email, username]
  );

  if (Array.isArray(existingUsers) && existingUsers.length > 0) {
    throw new Error('Email or username already exists.');
  }

  const hashedPassword = await bcrypt.hash(password, 10);

  const finalName = name || username;
  const defaultAvatar = avatar || `https://placehold.co/100x100.png?text=${finalName.charAt(0).toUpperCase()}`;

  const sql = `
    INSERT INTO users (username, name, email, password, role, avatar, website)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `;

  const result: any = await query(sql, [
    username,
    finalName,
    email,
    hashedPassword,
    role,
    defaultAvatar,
    website || '',
  ]);

  invalidateCache('users');

  const newUser = await getUserById(result.insertId.toString());
  if (!newUser) {
      throw new Error("Failed to retrieve newly created user.");
  }
  return newUser;
}

export async function updateUser(id: string, userData: Partial<User>, newPassword?: string): Promise<User | null> {
    const { name, email, role, avatar, bio, website, socialLinks, firstName, lastName } = userData;
    
    // The avatar URL can be a full URL or an API path, so we check if it's an API path and extract ID
    let avatarValue = avatar;
    if (avatar && avatar.includes('/api/media/')) {
        avatarValue = avatar.split('/api/media/')[1].split('/')[0];
    }

    let sql = 'UPDATE users SET name = ?, firstName = ?, lastName = ?, email = ?, role = ?, avatar = ?, bio = ?, website = ?, socialLinks = ?';
    const params: any[] = [name, firstName, lastName, email, role, avatarValue, bio, website, JSON.stringify(socialLinks || [])];
    
    if (newPassword) {
        const hashedPassword = await bcrypt.hash(newPassword, 10);
        sql += ', password = ?';
        params.push(hashedPassword);
    }
    
    sql += ' WHERE id = ?';
    params.push(id);
    
    await query(sql, params);
    invalidateCache('users');
    invalidateCache(`user_${id}`);
    const updatedUser = await getUserById(id);
    return JSON.parse(JSON.stringify(updatedUser));
}


export const getCategories = React.cache(async (): Promise<Category[]> => {
    const cacheKey = 'categories';
    if (process.env.NODE_ENV !== 'development') {
        const cachedData = getCache(cacheKey);
        if (cachedData) return cachedData;
    }
    try {
        const data = await query('SELECT * FROM categories ORDER BY name ASC');
        setCache(cacheKey, data);
        return data;
    } catch(e) {
        console.warn("Database query failed for getCategories, falling back to mock data.");
        return mockDb.categories;
    }
});

export const getCategoryById = React.cache(async (id: string): Promise<Category | null> => {
    try {
        const rows: any[] = await query('SELECT * FROM categories WHERE id = ?', [id]);
        return rows.length > 0 ? rows[0] : null;
    } catch (e) {
        console.warn(`Database query failed for getCategoryById(${id}), falling back to mock data.`);
        return mockDb.categories.find(c => c.id === id) || null;
    }
});

export const getCategoryBySlug = React.cache(async (slug: string): Promise<Category | null> => {
    try {
        const rows: any[] = await query('SELECT * FROM categories WHERE slug = ?', [slug]);
        return rows.length > 0 ? rows[0] : null;
    } catch(e) {
        console.warn(`Database query failed for getCategoryBySlug(${slug}), falling back to mock data.`);
        return mockDb.categories.find(c => c.slug === slug) || null;
    }
});

export async function createCategory(categoryData: Partial<Omit<Category, 'id'>>): Promise<void> {
    const { name, slug, description, parent } = categoryData;
    const finalSlug = slug || name?.toLowerCase().replace(/\s+/g, '-').replace(/[^\w-]+/g, '') || '';
    await query(
        'INSERT INTO categories (name, slug, description, parent) VALUES (?, ?, ?, ?)',
        [name, finalSlug, description || null, parent && parent !== 'none' ? parent : null]
    );
    invalidateCache('categories');
}

export async function updateCategory(id: string, data: Partial<Category>): Promise<void> {
    const { name, slug, description, parent } = data;
    await query(
        'UPDATE categories SET name = ?, slug = ?, description = ?, parent = ? WHERE id = ?',
        [name, slug, description, (parent === 'none' || !parent) ? null : parent, id]
    );
    invalidateCache('categories');
}

export async function deleteCategory(id: string): Promise<void> {
    await query('DELETE FROM categories WHERE id = ?', [id]);
    invalidateCache('categories');
}

export async function createTag(tagData: Partial<Omit<Tag, 'id'>>): Promise<void> {
    const { name, slug, description } = tagData;
    if (!name) return;
    const finalSlug = slug || generateSlug(name);
    await query(
        'INSERT INTO tags (name, slug, description) VALUES (?, ?, ?)',
        [name, finalSlug, description || null]
    );
    invalidateCache('tags');
}

export const getTags = React.cache(async (): Promise<Tag[]> => {
    const cacheKey = 'tags';
    if(process.env.NODE_ENV !== 'development') {
        const cachedData = getCache(cacheKey);
        if(cachedData) return cachedData;
    }
    try {
        const data = await query('SELECT * FROM tags ORDER BY name ASC');
        setCache(cacheKey, data);
        return data;
    } catch (e) {
        console.warn("Database query failed for getTags, falling back to mock data.");
        return mockDb.tags;
    }
});

export const getTagById = React.cache(async (id: string): Promise<Tag | null> => {
    try {
        const rows: any[] = await query('SELECT * FROM tags WHERE id = ?', [id]);
        return rows.length > 0 ? rows[0] : null;
    } catch(e) {
        console.warn(`Database query failed for getTagById(${id}), falling back to mock data.`);
        return mockDb.tags.find(t => t.id === id) || null;
    }
});

export const getTagBySlug = React.cache(async (slug: string): Promise<Tag | null> => {
    try {
        const rows: any[] = await query('SELECT * FROM tags WHERE slug = ?', [slug]);
        return rows.length > 0 ? rows[0] : null;
    } catch(e) {
        console.warn(`Database query failed for getTagBySlug(${slug}), falling back to mock data.`);
        return mockDb.tags.find(t => t.slug === slug) || null;
    }
});

export const getPostsByTag = React.cache(async (tagName: string): Promise<Post[]> => {
    try {
        const rows: any[] = await query(
        'SELECT * FROM posts WHERE FIND_IN_SET(?, tags) AND status = "published" AND isPage = 0 AND isPartnerContent = 0 ORDER BY createdAt DESC',
        [tagName]
        );
        return rows.map(parsePostRow).filter((p): p is Post => p !== null);
    } catch(e) {
        console.warn(`Database query failed for getPostsByTag(${tagName}), falling back to mock data.`);
        return mockDb.posts.filter(p => p.tags.includes(tagName) && p.status === 'published');
    }
});

export async function updateTag(id: string, data: Partial<Tag>): Promise<void> {
    const { name, slug, description } = data;
    await query(
        'UPDATE tags SET name = ?, slug = ?, description = ? WHERE id = ?',
        [name, slug, description, id]
    );
    invalidateCache('tags');
}

export async function deleteTag(id: string): Promise<void> {
    await query('DELETE FROM tags WHERE id = ?', [id]);
    invalidateCache('tags');
}

export const getComments = async (statusFilter?: CommentStatus, forceRefresh = false): Promise<Comment[]> => {
    const cacheKey = `comments_${statusFilter || 'all'}`;
    if (!forceRefresh && process.env.NODE_ENV !== 'development') {
        const cachedData = getCache(cacheKey);
        if (cachedData) return cachedData;
    }
    
    try {
        let sql = `
            SELECT c.*, u.id as userId, u.name as authorName, u.email as authorEmail, u.avatar as authorAvatar
            FROM comments c 
            LEFT JOIN users u ON c.authorId = u.id 
        `;
        const params: any[] = [];

        if (statusFilter) {
            sql += ' WHERE c.status = ?';
            params.push(statusFilter);
        }
        
        sql += ' ORDER BY c.createdAt DESC';
        
        const rows: any[] = await query(sql, params);
        
        const data = rows.map(row => ({
            id: row.id.toString(),
            postId: row.postId.toString(),
            content: row.content,
            createdAt: row.createdAt,
            status: row.status,
            author: {
                id: row.authorId ? row.authorId.toString() : null,
                name: row.authorName || row.guestName,
                email: row.authorEmail || row.guestEmail,
                avatar: row.authorAvatar ? `/api/media/${row.authorAvatar}/file` : `https://placehold.co/100x100.png?text=${(row.authorName || row.guestName || 'G').charAt(0)}`,
            }
        }));

        if (!statusFilter) {
        setCache(cacheKey, data);
        }

        return data;
    } catch (e) {
        console.warn(`Database query failed for getComments, falling back to mock data.`);
        return mockDb.comments;
    }
};

export async function createComment(commentData: { postId: string; content: string; authorId?: string | null; guestName?: string; guestEmail?: string }): Promise<Comment> {
    const { postId, content, authorId, guestName, guestEmail } = commentData;

    const sql = `
        INSERT INTO comments (postId, content, status, authorId, guestName, guestEmail, createdAt)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    `;
    const status: CommentStatus = 'pending';
    const createdAt = new Date();

    const result: any = await query(sql, [
        postId,
        content,
        status,
        authorId || null,
        guestName || null,
        guestEmail || null,
        toMySqlDateTime(createdAt)
    ]);
    
    invalidateCache('comments');

    let authorDetails: User | null = null;
    if (authorId) {
        authorDetails = await getUserById(authorId);
    }
    
    const newComment: Comment = {
        id: result.insertId.toString(),
        postId,
        content,
        status,
        createdAt: createdAt.toISOString(),
        author: {
            id: authorId || null,
            name: guestName || authorDetails?.name || 'Guest',
            email: guestEmail || authorDetails?.email || '',
            avatar: authorDetails?.avatar || `https://placehold.co/100x100.png?text=${(guestName || 'G').charAt(0)}`,
        },
    };
    
    return JSON.parse(JSON.stringify(newComment));
}


export async function updateCommentStatus(commentId: string, status: CommentStatus) {
    await query('UPDATE comments SET status = ? WHERE id = ?', [status, commentId]);
    invalidateCache('comments');
}

export async function updateCommentContent(commentId: string, content: string) {
    await query('UPDATE comments SET content = ? WHERE id = ?', [content, commentId]);
    invalidateCache('comments');
}


export async function deleteComment(commentId: string) {
    await query('DELETE FROM comments WHERE id = ?', [commentId]);
    invalidateCache('comments');
}


export const getWebmasterToolsSettings = React.cache(async (): Promise<WebmasterToolsSettings> => {
    return await getSetting('webmasterTools', {
        googleTagManagerId: '',
        googleAnalyticsId: '',
        googleSearchConsoleKey: '',
        bingKey: '',
        yandexKey: '',
        headerScripts: '',
        footerScripts: '',
    });
});
export async function updateWebmasterToolsSettings(settings: WebmasterToolsSettings) {
    await updateSetting('webmasterTools', settings);
    invalidateCache('webmasterTools');
}
export const getRobotsTxtSettings = React.cache(async (): Promise<{ enableCustomRobots: boolean, rules: RobotsRule[], blockInternalSearch: 'on' | 'off', blockedCrawlers: any[] }> => {
    return await getSetting('robotsTxt', {
        enableCustomRobots: false,
        rules: [],
        blockInternalSearch: 'off',
        blockedCrawlers: [],
    });
});
export async function updateRobotsTxtSettings(settings: { enableCustomRobots: boolean, rules: RobotsRule[], blockInternalSearch: 'on' | 'off', blockedCrawlers: any[] }) {
    await updateSetting('robotsTxt', settings);
    invalidateCache('robotsTxt');
}

export const getSitemapSettings = React.cache(async (): Promise<SitemapSettings> => {
    return await getSetting('sitemapSettings', {
        enabled: true,
        enableSitemapIndexes: true,
        linksPerSitemap: 1000,
        includeAllPostTypes: true,
        includePosts: true,
        includePages: true,
        includeAllTaxonomies: true,
        includeCategories: true,
        includeTags: true,
        dateArchiveSitemap: false,
        authorSitemap: false,
        additionalPages: [],
        exclusions: {
            posts: [],
            terms: [],
        },
        priority: {
            homePage: { priority: '1.0', frequency: 'daily' },
            postTypes: { priority: '0.8', frequency: 'weekly' },
            taxonomies: { priority: '0.6', frequency: 'monthly' },
        },
        includeImages: true,
    });
});

export async function updateSitemapSettings(settings: SitemapSettings) {
    await updateSetting('sitemapSettings', settings);
    invalidateCache('sitemapSettings');
}
export const getSeoSettings = React.cache(async (): Promise<SeoSettings> => {
    return await getSetting('seoSettings', {
        separator: '-',
        homepageTitle: '{{site_title}} {{sep}} {{tagline}}',
        homepageDescription: '',
        knowledgeGraph: {
            type: 'organization',
            personName: '',
            organizationName: 'Digiotic Blog',
            organizationDescription: 'A sample description',
            organizationLogo: '',
            phoneNumber: '',
            contactEmail: ''
        },
        contentTypes: {
            posts: { showInSearchResults: true, titleTemplate: '{{post_title}} {{sep}} {{site_title}}', metaDescription: '{{post_excerpt}}' },
            pages: { showInSearchResults: true, titleTemplate: '{{page_title}} {{sep}} {{site_title}}', metaDescription: '{{page_excerpt}}' },
        },
        taxonomies: {
            categories: { showInSearchResults: true, titleTemplate: 'Category: {{term_title}} {{sep}} {{site_title}}', metaDescription: '{{term_description}}' },
            tags: { showInSearchResults: true, titleTemplate: 'Tag: {{tag_title}} {{sep}} {{site_title}}', metaDescription: '{{tag_description}}' },
        },
        social: {
            ogImageUrl: '',
            facebookTitle: '',
            facebookDescription: '',
            twitterImage: '',
            twitterTitle: '',
            twitterDescription: '',
        },
        archives: {
            authorArchiveTitle: '{{author_name}} {{sep}} {{site_title}}',
            dateArchiveTitle: '{{date}} {{sep}} {{site_title}}',
        }
    });
});
export async function updateSeoSettings(settings: SeoSettings) {
    await updateSetting('seoSettings', settings);
    invalidateCache('seoSettings');
}

export async function createMedia(mediaData: Partial<Omit<Media, 'id' | 'url'>> & { data: Buffer }): Promise<Media> {
    const { fileName, fileType, fileSize, altText, uploadedBy, data } = mediaData;
    const sql = `
        INSERT INTO media (fileName, fileType, fileSize, altText, uploadedBy, data)
        VALUES (?, ?, ?, ?, ?, ?)
    `;
    const result: any = await query(sql, [fileName, fileType, fileSize, altText, uploadedBy, data]);
    invalidateCache('media');
    const newMedia = await getMediaById(result.insertId.toString());
    return newMedia!;
}


export async function getMedia(forceRefresh = false): Promise<Media[]> {
    try {
        // Caching is removed to ensure real-time updates as requested.
        const rows: any[] = await query('SELECT id, fileName, fileType, fileSize, altText, uploadedBy, createdAt FROM media ORDER BY createdAt DESC');
        const data = rows.map(row => ({
            ...row, 
            id: row.id.toString(),
            url: `/api/media/${row.id}/file`,
        }));
        return data;
    } catch (e) {
        console.warn("Database query failed for getMedia, falling back to mock data.");
        return mockDb.media;
    }
}

export async function getMediaById(id: string): Promise<Media | null> {
    try {
        const rows: any[] = await query('SELECT id, fileName, fileType, fileSize, altText, uploadedBy, createdAt FROM media WHERE id = ?', [id]);
        if (rows.length === 0) return null;
        const row = rows[0];
        return {
            ...row,
            id: row.id.toString(),
            url: `/api/media/${row.id}/file`,
        };
    } catch(e) {
        console.warn(`Database query failed for getMediaById(${id}), falling back to mock data.`);
        return mockDb.media.find(m => m.id === id) || null;
    }
}

export const getSponsoredLinks = React.cache(async (): Promise<SponsoredLink[]> => { return await getSetting('sponsoredLinks', []) });
export async function updateSponsoredLinks(links: SponsoredLink[]) { await updateSetting('sponsoredLinks', links); invalidateCache('sponsoredLinks');}

export const getPartnerPageSettings = React.cache(async (): Promise<PartnerPageSettings> => { 
    const defaultTypography: CardTypographyStyles = { 
        fontFamily: 'Inter', 
        fontSize: 16, 
        fontWeight: '400', 
        textAlign: 'left', 
        color: '#000000', 
        colorType: 'solid', 
        gradient: { from: '#000000', to: '#ffffff', direction: 'to right' },
        backgroundColor: '#dbeafe', 
        backgroundType: 'solid', 
        hoverColor: '#3b82f6'
    };
    
    return await getSetting('partnerPageSettings', {
        title: 'For Our Partners',
        description: 'Exclusive content and resources for our valued partners. Explore the latest insights, updates, and opportunities we\'ve curated just for you.',
        recommendedContentIds: [],
        titleStyles: { ...defaultTypography, fontFamily: 'Space Grotesk', fontSize: 48, fontWeight: '700', textAlign: 'center', colorType: 'gradient', gradient: { from: '#3b82f6', to: '#8b5cf6', direction: 'to right' }},
        descriptionStyles: { ...defaultTypography, fontSize: 18, textAlign: 'center', color: '#4b5563'},
        recommendedContentStyles: { ...defaultTypography, title: 'Recommended For You', fontFamily: 'Space Grotesk', fontSize: 30, fontWeight: '700', color: '#111827' },
        cardStyles: {
            categoryStyles: { ...defaultTypography, fontSize: 12, fontWeight: '600', color: '#3b82f6', backgroundColor: '#dbeafe', backgroundType: 'solid', gradient: {from: '#dbeafe', to: '#dbeafe', direction: 'to right'}},
            titleStyles: { ...defaultTypography, fontFamily: 'Space Grotesk', fontSize: 18, fontWeight: '700', color: '#111827', hoverColor: '#3b82f6'},
            excerptStyles: { ...defaultTypography, fontSize: 14, color: '#4b5563' },
            thumbnailOverlayType: 'none',
            thumbnailOverlaySolidColor: 'rgba(0,0,0,0.5)',
            thumbnailOverlayGradient: { from: 'rgba(0,0,0,0.7)', to: 'rgba(0,0,0,0)', direction: 'to top'},
            thumbnailOverlayOpacity: 0.5,
        },
        showLeftSidebar: false,
        showRightSidebar: false,
    });
});


export async function updatePartnerPageSettings(newSettings: PartnerPageSettings) {
    await updateSetting('partnerPageSettings', newSettings);
    invalidateCache('partnerPageSettings');
}

export const getCommentById = React.cache(async (id: string): Promise<Comment | undefined> => { 
    try {
        const rows: any[] = await query(`
            SELECT c.*, u.id as userId, u.name as authorName, u.email as authorEmail, u.avatar as authorAvatar
            FROM comments c 
            LEFT JOIN users u ON c.authorId = u.id 
            WHERE c.id = ?
        `, [id]);
        
        if (rows.length === 0) return undefined;

        const row = rows[0];
        const authorAvatar = row.authorAvatar ? `/api/media/${row.authorAvatar}/file` : `https://placehold.co/100x100.png?text=${(row.authorName || row.guestName || 'G').charAt(0)}`;
            
        return {
            id: row.id.toString(),
            postId: row.postId.toString(),
            content: row.content,
            createdAt: row.createdAt,
            status: row.status,
            author: {
                id: row.authorId ? row.authorId.toString() : null,
                name: row.authorName || row.guestName,
                email: row.authorEmail || row.guestEmail,
                avatar: authorAvatar
            }
        }
    } catch(e) {
         console.warn(`Database query failed for getCommentById(${id}), falling back to mock data.`);
         return mockDb.comments.find(c => c.id === id);
    }
});

export const getPostsByAuthorId = React.cache(async (authorId: string): Promise<Post[]> => {
    try {
        const sql = `
            SELECT p.*, u.name as authorName 
            FROM posts p 
            LEFT JOIN users u ON p.authorId = u.id 
            WHERE p.authorId = ? AND p.status = "published" AND p.isPage = 0 AND p.isPartnerContent = 0 
            ORDER BY p.createdAt DESC
        `;
        const rows: any[] = await query(sql, [authorId]);
        return rows.map(parsePostRow).filter((p): p is Post => p !== null);
    } catch(e) {
        console.warn(`Database query failed for getPostsByAuthorId(${authorId}), falling back to mock data.`);
        return mockDb.posts.filter(p => p.authorId === authorId && p.status === 'published');
    }
});


export const getPostsByCategory = React.cache(async (categoryId: string): Promise<Post[]> => {
    const category = await getCategoryById(categoryId);
    if (!category) {
        return [];
    }
    
    try {
        const rows: any[] = await query(
        'SELECT * FROM posts WHERE FIND_IN_SET(?, categories) AND status = "published" AND isPage = 0 AND isPartnerContent = 0 ORDER BY createdAt DESC',
        [category.name]
        );
        return rows.map(parsePostRow).filter((p): p is Post => p !== null);
    } catch(e) {
        console.warn(`Database query failed for getPostsByCategory(${categoryId}), falling back to mock data.`);
        return mockDb.posts.filter(p => p.categories.includes(category.name) && p.status === 'published');
    }
});

export const getPostsByCategorySlug = React.cache(async (slug: string): Promise<Post[]> => {
    const category = await getCategoryBySlug(slug);
    if (!category) {
        return [];
    }
    
    try {
        const rows: any[] = await query(
        'SELECT * FROM posts WHERE FIND_IN_SET(?, categories) AND status = "published" AND isPage = 0 AND isPartnerContent = 0 ORDER BY createdAt DESC',
        [category.name]
        );
        return rows.map(parsePostRow).filter((p): p is Post => p !== null);
    } catch(e) {
        console.warn(`Database query failed for getPostsByCategorySlug(${slug}), falling back to mock data.`);
        return mockDb.posts.filter(p => p.categories.includes(category.name) && p.status === 'published');
    }
});


// Function to fetch posts and their authors for pagination
export const getPaginatedPostsWithAuthors = React.cache(async ({ page, limit }: { page: number; limit: number }): Promise<(Post & { author: User | null})[]> => {
    try {
        const offset = (page - 1) * limit;
        const postsSql = `
            SELECT p.*, u.id as authorId, u.name as authorName, u.email as authorEmail, u.avatar as authorAvatar
            FROM posts p
            LEFT JOIN users u ON p.authorId = u.id
            WHERE p.status = 'published' AND p.isPage = 0 AND p.isPartnerContent = 0
            ORDER BY p.createdAt DESC
            LIMIT ? OFFSET ?
        `;
        const rows: any[] = await query(postsSql, [limit, offset]);
        
        return rows.map(row => {
            const post = parsePostRow(row);
            if (!post) return null;
            // The author is already attached in parsePostRow
            return post as Post & { author: User | null };
        }).filter((p): p is Post & { author: User | null } => p !== null);
    } catch(e) {
        console.warn(`Database query failed for getPaginatedPostsWithAuthors, falling back to mock data.`);
        const offset = (page - 1) * limit;
        const mockPosts = mockDb.posts.filter(p => p.status === 'published' && !p.isPage && !p.isPartnerContent);
        const paginatedMockPosts = mockPosts.slice(offset, offset + limit);
        const mockAuthors = mockDb.users;
        return paginatedMockPosts.map(p => ({
            ...p,
            author: mockAuthors.find(a => a.id === p.authorId) || null
        }));
    }
});

export type BlockTypeExtended = BlockType | 'five-column' | 'six-column' | 'seven-column' | 'eight-column';
export type ColorTheme = {
    background: string;
    foreground: string;
    primary: string;
    primaryForeground: string;
    secondary: string;
    secondaryForeground: string;
    muted: string;
    mutedForeground: string;
    accent: string;
    accentForeground: string;
    destructive: string;
    destructiveForeground: string;
    border: string;
    input: string;
    ring: string;
    customCss?: string;
}
export const getThemeSettings = React.cache(async (): Promise<ColorTheme> => {
    return await getSetting('themeSettings', {
        background: '#f0f0f1',
        foreground: '#22262b',
        primary: '#0a75c3',
        primaryForeground: '#ffffff',
        secondary: '#e6e7e8',
        secondaryForeground: '#22262b',
        muted: '#e6e7e8',
        mutedForeground: '#595d63',
        accent: '#e6e7e8',
        accentForeground: '#22262b',
        destructive: '#d63638',
        destructiveForeground: '#ffffff',
        border: '#dcdcde',
        input: '#dcdcde',
        ring: '#0a75c3',
        customCss: '',
    });
});
export async function updateThemeSettings(settings: ColorTheme) { await updateSetting('themeSettings', settings); invalidateCache('themeSettings'); }

export const getSponsorSettings = React.cache(async (): Promise<SponsorSettings> => { 
    const defaultTypography: TypographyStyles = {
        fontFamily: 'Inter',
        fontSize: 16,
        fontWeight: '400',
        textAlign: 'center',
        color: '#000000',
        colorType: 'solid',
        gradient: { from: '#000000', to: '#ffffff', direction: 'to right' },
    };
    return await getSetting('sponsorSettings', {
        title: "Our Sponsors",
        description: "We are proud to be sponsored by these amazing companies.",
        titleStyles: { ...defaultTypography, fontSize: 36, fontWeight: '700' },
        descriptionStyles: { ...defaultTypography, fontSize: 18, color: '#4b5563' },
    });
});
export async function updateSponsorSettings(newSettings: SponsorSettings) {
    await updateSetting('sponsorSettings', newSettings);
    invalidateCache('sponsorSettings');
}

export const getSponsorStyleSettings = React.cache(async (): Promise<SponsorStyleSettings> => {
    return await getSetting('sponsorStyleSettings', {
        backgroundType: 'solid',
        backgroundColor: '#ffffff',
        gradient: { from: '#e0e7ff', to: '#c7d2fe', direction: 'to right' },
        textColor: '#374151',
        borderColor: '#d1d5db',
        borderWidth: 1,
        borderRadius: 8,
        paddingX: 24,
        paddingY: 12,
        fontFamily: 'Inter',
        fontSize: 16,
        fontWeight: '500',
        textAlign: 'center',
    });
});

export async function updateSponsorStyleSettings(newSettings: SponsorStyleSettings) {
    await updateSetting('sponsorStyleSettings', newSettings);
    invalidateCache('sponsorStyleSettings');
}



    