

import type { NextAuthOptions } from "next-auth"
import CredentialsProvider from "next-auth/providers/credentials";
import { getUserById } from "@/lib/data";
import { query } from "@/lib/mysql";
import bcrypt from 'bcryptjs';

export const authOptions: NextAuthOptions = {
  providers: [
    CredentialsProvider({
      name: 'Credentials',
      credentials: {
        email: { label: "Email", type: "email" },
        password: {  label: "Password", type: "password" }
      },
      async authorize(credentials) {
        if (!credentials) {
            return null;
        }
        
        try {
            const rows: any[] = await query('SELECT * FROM users WHERE email = ?', [credentials.email]);
            
            if (rows.length > 0) {
                const userRow = rows[0];
                const passwordMatch = await bcrypt.compare(credentials.password, userRow.password);

                if (passwordMatch) {
                    const user = await getUserById(userRow.id.toString());
                    if (!user) return null;
                    
                    return { 
                        id: user.id, 
                        name: user.name, 
                        email: user.email, 
                        role: user.role,
                        image: user.avatar
                    };
                }
            }
        } catch (error) {
            console.error("Authorize error:", error);
            return null;
        }
        
        return null;
      }
    })
  ],
  pages: {
    signIn: '/login',
  },
  callbacks: {
    async jwt({ token, user }) {
        if (user) {
            token.id = user.id;
            // @ts-ignore
            token.role = user.role;
            token.picture = user.image;
        }
        return token;
    },
    async session({ session, token }) {
        if (session.user) {
            // @ts-ignore
            session.user.id = token.id;
            // @ts-ignore
            session.user.role = token.role;
            if (token.picture) {
                session.user.image = token.picture as string;
            }
        }
        return session;
    }
  }
};
