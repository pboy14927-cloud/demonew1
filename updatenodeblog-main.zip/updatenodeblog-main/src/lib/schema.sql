-- schema.sql

CREATE TABLE IF NOT EXISTS `posts` (
  `id` VARCHAR(255) NOT NULL,
  `title` TEXT NOT NULL,
  `slug` VARCHAR(255) NOT NULL,
  `content` LONGTEXT,
  `status` ENUM('published', 'draft', 'trash', 'pending') NOT NULL DEFAULT 'draft',
  `authorId` VARCHAR(255) NOT NULL,
  `createdAt` DATETIME NOT NULL,
  `isPage` BOOLEAN DEFAULT FALSE,
  `isPartnerContent` BOOLEAN DEFAULT FALSE,
  `categories` TEXT,
  `tags` TEXT,
  `featuredImage` VARCHAR(255),
  `excerpt` TEXT,
  `seo` JSON,
  `format` VARCHAR(255) DEFAULT 'standard',
  `commentStatus` ENUM('open', 'closed') DEFAULT 'open',
  `pingStatus` ENUM('open', 'closed') DEFAULT 'open',
  `template` VARCHAR(255) DEFAULT 'default',
  `parent` VARCHAR(255) NULL DEFAULT NULL,
  `likes` INT DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `slug_UNIQUE` (`slug` ASC),
  INDEX `fk_posts_users_idx` (`authorId` ASC),
  INDEX `status_idx` (`status` ASC),
  INDEX `isPage_idx` (`isPage` ASC)
);

CREATE TABLE IF NOT EXISTS `users` (
  `id` VARCHAR(255) NOT NULL,
  `username` VARCHAR(255) NOT NULL UNIQUE,
  `name` VARCHAR(255) NOT NULL,
  `firstName` VARCHAR(255),
  `lastName` VARCHAR(255),
  `email` VARCHAR(255) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `avatar` VARCHAR(255),
  `role` ENUM('administrator', 'editor', 'author', 'contributor', 'subscriber') NOT NULL DEFAULT 'subscriber',
  `bio` TEXT,
  `website` VARCHAR(255),
  `socialLinks` JSON,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `email_UNIQUE` (`email` ASC)
);

CREATE TABLE IF NOT EXISTS `media` (
  `id` VARCHAR(255) NOT NULL,
  `fileName` VARCHAR(255) NOT NULL,
  `fileType` VARCHAR(255) NOT NULL,
  `fileSize` VARCHAR(255),
  `dimensions` VARCHAR(255),
  `url` LONGTEXT,
  `altText` TEXT,
  `sizes` JSON,
  `uploadedBy` VARCHAR(255),
  `createdAt` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
);

CREATE TABLE IF NOT EXISTS `categories` (
    `id` VARCHAR(255) NOT NULL,
    `name` VARCHAR(255) NOT NULL,
    `slug` VARCHAR(255) NOT NULL,
    `description` TEXT,
    `parent` VARCHAR(255),
    PRIMARY KEY (`id`),
    UNIQUE INDEX `slug_UNIQUE` (`slug` ASC)
);

CREATE TABLE IF NOT EXISTS `tags` (
    `id` VARCHAR(255) NOT NULL,
    `name` VARCHAR(255) NOT NULL,
    `slug` VARCHAR(255) NOT NULL,
    `description` TEXT,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `slug_UNIQUE` (`slug` ASC)
);

CREATE TABLE IF NOT EXISTS `comments` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `postId` VARCHAR(255) NOT NULL,
  `authorId` VARCHAR(255),
  `guestName` VARCHAR(255),
  `guestEmail` VARCHAR(255),
  `content` TEXT NOT NULL,
  `createdAt` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` ENUM('approved', 'pending', 'spam', 'trash') NOT NULL DEFAULT 'pending',
  PRIMARY KEY (`id`)
);

CREATE TABLE IF NOT EXISTS `settings` (
  `name` VARCHAR(255) NOT NULL,
  `value` LONGTEXT,
  PRIMARY KEY (`name`)
);