

import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import { CSSProperties } from "react"
import { BlockStyle, SocialButtonStyleSettings } from "./data"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function mergeStyles(...styles: (BlockStyle | undefined)[]): CSSProperties {
    const merged: CSSProperties & { [key: string]: any } = {};
    for (const style of styles) {
        if (!style) continue;
        for (let [key, value] of Object.entries(style)) {
            if (value !== undefined && value !== null && value !== '') {
                // A simple way to convert camelCase to kebab-case for CSS properties
                if (key === 'gradient') continue; // Skip the object itself
                if (key === 'color' && typeof value === 'object' && value !== null && 'from' in value) {
                    value = `linear-gradient(to right, ${value.from}, ${value.to})`;
                    key = 'background'; // Special handling for gradient text
                     merged['-webkit-background-clip'] = 'text';
                    merged['color'] = 'transparent';
                }
                 const cssKey = key.replace(/[A-Z]/g, letter => `-${letter.toLowerCase()}`);
                merged[cssKey] = value;
            }
        }
    }
    return merged;
}

export const getSocialButtonStyle = (settings: SocialButtonStyleSettings): React.CSSProperties => {
    if (!settings) return {};
    const style: React.CSSProperties & { [key: string]: string } = {
        '--hover-bg': settings.hoverBackgroundColor || 'transparent',
        '--hover-text': settings.hoverIconColor || settings.iconColor,
        color: settings.iconColor,
        borderColor: settings.borderColor,
        borderWidth: `${settings.borderWidth}px`,
    };
     if (settings.backgroundType === 'gradient') {
        style.background = `linear-gradient(${settings.gradient.direction}, ${settings.gradient.from}, ${settings.gradient.to})`;
    } else {
        style.backgroundColor = settings.backgroundColor;
    }
    return style;
};

