
// src/middleware.ts
import { withAuth } from 'next-auth/middleware';

// withAuth will automatically redirect unauthenticated users to the login page.
export default withAuth({
  callbacks: {
    authorized: ({ token }) => {
      // The user is authorized if they have a token and their role is one of the allowed ones.
      const allowedRoles = ['administrator', 'editor', 'author', 'contributor'];
      // @ts-ignore
      return !!token && allowedRoles.includes(token.role);
    },
  },
});

// This config ensures the middleware runs on all paths under /admin.
export const config = {
  matcher: ['/admin/:path*'],
};
